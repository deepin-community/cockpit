cockpit.locale({
 "": {
  "plural-forms": (n) => n != 1,
  "language": "nb_NO",
  "language-direction": "ltr"
 },
 "$0 chunk size": [
  null,
  ""
 ],
 "$0 data + $1 overhead used of $2 ($3)": [
  null,
  "$0 data + $1 overhead brukt av $2 ($3)"
 ],
 "$0 day": [
  null,
  "$0 dag",
  "$0 dager"
 ],
 "$0 disk is missing": [
  null,
  "$0 disk mangler",
  "$0 disker mangler"
 ],
 "$0 disks": [
  null,
  "$0 disker"
 ],
 "$0 exited with code $1": [
  null,
  "$0 avsluttet med koden $1"
 ],
 "$0 failed": [
  null,
  "$0 feilet"
 ],
 "$0 hour": [
  null,
  "$0 time",
  "$0 timer"
 ],
 "$0 is not available from any repository.": [
  null,
  "$0 er ikke tilgjengelig fra noe depot."
 ],
 "$0 key changed": [
  null,
  "$0 nøkkel endret"
 ],
 "$0 killed with signal $1": [
  null,
  "$0 drept med signal $1"
 ],
 "$0 minute": [
  null,
  "$0 minutt",
  "$0 minutter"
 ],
 "$0 month": [
  null,
  "$0 måned",
  "$0 måneder"
 ],
 "$0 slot remains": [
  null,
  "$0 slot gjenstår",
  "$0 slot-er gjenstår"
 ],
 "$0 used of $1 ($2 saved)": [
  null,
  "$0 brukt av $1 ($2 lagret)"
 ],
 "$0 week": [
  null,
  "$0 uke",
  "$0 uker"
 ],
 "$0 will be installed.": [
  null,
  "$0 vil bli installert."
 ],
 "$0 year": [
  null,
  "$0 år",
  "$0 år"
 ],
 "$name (from $host)": [
  null,
  "$name (fra $host)"
 ],
 "1 MiB": [
  null,
  "1 MiB"
 ],
 "1 day": [
  null,
  "1 dag"
 ],
 "1 hour": [
  null,
  "1 time"
 ],
 "1 minute": [
  null,
  "1 minutt"
 ],
 "1 week": [
  null,
  "1 uke"
 ],
 "128 KiB": [
  null,
  "128 KiB"
 ],
 "16 KiB": [
  null,
  "16 KiB"
 ],
 "2 MiB": [
  null,
  "2 MiB"
 ],
 "20 minutes": [
  null,
  "20 minutter"
 ],
 "32 KiB": [
  null,
  "32 KiB"
 ],
 "4 KiB": [
  null,
  "4 KiB"
 ],
 "40 minutes": [
  null,
  "40 minutter"
 ],
 "5 minutes": [
  null,
  "5 minutter"
 ],
 "512 KiB": [
  null,
  "512 KiB"
 ],
 "6 hours": [
  null,
  "6 timer"
 ],
 "60 minutes": [
  null,
  "60 minutter"
 ],
 "64 KiB": [
  null,
  "64 KiB"
 ],
 "8 KiB": [
  null,
  "8 KiB"
 ],
 "A fatal error occurred during the self-test operation": [
  null,
  ""
 ],
 "A filesystem with this name exists already in this pool.": [
  null,
  ""
 ],
 "A pool with this name exists already.": [
  null,
  ""
 ],
 "Abort test": [
  null,
  ""
 ],
 "Aborted": [
  null,
  ""
 ],
 "Aborted by a Controller Level Reset": [
  null,
  ""
 ],
 "Aborted due to a removal of a namespace from the namespace inventory": [
  null,
  ""
 ],
 "Aborted due to a sanitize operation": [
  null,
  ""
 ],
 "Aborted due to the processing of a Format NVM command": [
  null,
  ""
 ],
 "Aborted for unknown reason": [
  null,
  ""
 ],
 "Absent": [
  null,
  "Fraværende"
 ],
 "Actions": [
  null,
  "Handlinger"
 ],
 "Activate": [
  null,
  "Aktiver"
 ],
 "Activate before resizing": [
  null,
  ""
 ],
 "Activating $target": [
  null,
  "Aktiverer $target"
 ],
 "Add": [
  null,
  "Legg til"
 ],
 "Add $0": [
  null,
  "Legg til $0"
 ],
 "Add Network Bound Disk Encryption": [
  null,
  ""
 ],
 "Add disk": [
  null,
  "Legg til disk"
 ],
 "Add disks": [
  null,
  "Legg til disker"
 ],
 "Add iSCSI portal": [
  null,
  "Legg til iSCSI-portal"
 ],
 "Add key": [
  null,
  "Legg til nøkkel"
 ],
 "Adding \"$0\" to filesystem options": [
  null,
  ""
 ],
 "Adding key": [
  null,
  "Legger til nøkkel"
 ],
 "Adding physical volume to $target": [
  null,
  "Legger til fysisk volum til $target"
 ],
 "Adding rd.neednet=1 to kernel command line": [
  null,
  ""
 ],
 "Additional packages:": [
  null,
  "Ekstra pakker:"
 ],
 "Address": [
  null,
  "Adresse"
 ],
 "Address cannot be empty": [
  null,
  "Adressen kan ikke være tom"
 ],
 "Address is not a valid URL": [
  null,
  "Adressen er ikke en gyldig URL"
 ],
 "Administration with Cockpit Web Console": [
  null,
  "Administrasjon med Cockpit Web konsoll"
 ],
 "Advanced TCA": [
  null,
  "Avansert TCA"
 ],
 "All $0 selected physical volumes are needed for the chosen layout.": [
  null,
  ""
 ],
 "All-in-one": [
  null,
  "Alt i ett"
 ],
 "Allow overprovisioning": [
  null,
  ""
 ],
 "An additional $0 must be selected": [
  null,
  ""
 ],
 "Ansible": [
  null,
  "Ansible"
 ],
 "Ansible roles documentation": [
  null,
  "Ansible roller dokumentasjon"
 ],
 "Appropriate for critical mounts, such as /var": [
  null,
  ""
 ],
 "At least $0 disk is needed.": [
  null,
  "Minst $0 disk er nødvendig.",
  "Minst $0 disker er nødvendige."
 ],
 "At least one disk is needed.": [
  null,
  "Minst én disk er nødvendig."
 ],
 "Authentication": [
  null,
  "Autentisering"
 ],
 "Authentication is required to perform privileged tasks with the Cockpit Web Console": [
  null,
  "Autentisering er nødvendig for å utføre privilegerte oppgaver med Cockpit Web konsoll"
 ],
 "Authentication required": [
  null,
  "Autentisering kreves"
 ],
 "Automatically using NTP": [
  null,
  "Automatisk med bruk av NTP"
 ],
 "Automatically using specific NTP servers": [
  null,
  "Automatisk med bruk av spesifikke NTP servere"
 ],
 "Automation script": [
  null,
  "Automatiseringsskript"
 ],
 "Available targets on $0": [
  null,
  "Tilgjengelige mål på $0"
 ],
 "Blade": [
  null,
  "Blad"
 ],
 "Blade enclosure": [
  null,
  "Blad-kabinett"
 ],
 "Block device for filesystems": [
  null,
  "Blokk enhet for filsystemer"
 ],
 "Blocked": [
  null,
  "Blokkert"
 ],
 "Boot fails if filesystem does not mount, preventing remote access": [
  null,
  ""
 ],
 "Bus expansion chassis": [
  null,
  ""
 ],
 "Cache": [
  null,
  "Hurtigbuffer"
 ],
 "Cancel": [
  null,
  "Avbryt"
 ],
 "Cannot forward login credentials": [
  null,
  "Kan ikke videresende påloggingsinformasjonen"
 ],
 "Cannot schedule event in the past": [
  null,
  "Kan ikke tidsplanlegge hendelse i fortiden"
 ],
 "Capacity": [
  null,
  "Kapasitet"
 ],
 "Category": [
  null,
  ""
 ],
 "Change": [
  null,
  "Endre"
 ],
 "Change iSCSI initiator name": [
  null,
  "Endre navn på iSCSI Initiator"
 ],
 "Change passphrase": [
  null,
  "Endre passfrase"
 ],
 "Change system time": [
  null,
  "Endre systemtid"
 ],
 "Changed keys are often the result of an operating system reinstallation. However, an unexpected change may indicate a third-party attempt to intercept your connection.": [
  null,
  "Endrede nøkler er ofte resultatet av reinstallering av operativsystemet. Imidlertid kan en uventet endring indikere et tredjepartsforsøk på å fange opp forbindelsen din."
 ],
 "Changing partition types might prevent the system from booting.": [
  null,
  ""
 ],
 "Check that the SHA-256 or SHA-1 hash from the command matches this dialog.": [
  null,
  ""
 ],
 "Check the key hash with the Tang server.": [
  null,
  ""
 ],
 "Checking $target": [
  null,
  "Sjekker $target"
 ],
 "Checking for NBDE support in the initrd": [
  null,
  ""
 ],
 "Checking installed software": [
  null,
  "Kontrollerer installert programvare"
 ],
 "Chunk size": [
  null,
  ""
 ],
 "Cleaning up for $target": [
  null,
  "Rydder opp for $target"
 ],
 "Close": [
  null,
  "Lukk"
 ],
 "Cockpit": [
  null,
  "Cockpit"
 ],
 "Cockpit configuration of NetworkManager and Firewalld": [
  null,
  ""
 ],
 "Cockpit could not contact the given host.": [
  null,
  "Cockpit kunne ikke kontakte den angitte verten."
 ],
 "Cockpit is a server manager that makes it easy to administer your Linux servers via a web browser. Jumping between the terminal and the web tool is no problem. A service started via Cockpit can be stopped via the terminal. Likewise, if an error occurs in the terminal, it can be seen in the Cockpit journal interface.": [
  null,
  "Cockpit er en serveradministrator som gjør det enkelt å administrere Linux-serverne dine via en nettleser. Å bytte mellom terminalen og nettverktøyet er ikke noe problem. En tjeneste startet via Cockpit kan stoppes via terminalen. På samme måte, hvis det oppstår en feil i terminalen, kan den sees i Cockpit journal-grensesnittet."
 ],
 "Cockpit is not compatible with the software on the system.": [
  null,
  "Cockpit er ikke kompatibel med programvaren på systemet."
 ],
 "Cockpit is not installed": [
  null,
  "Cockpit er ikke installert"
 ],
 "Cockpit is not installed on the system.": [
  null,
  "Cockpit er ikke installert på systemet."
 ],
 "Cockpit is perfect for new sysadmins, allowing them to easily perform simple tasks such as storage administration, inspecting journals and starting and stopping services. You can monitor and administer several servers at the same time. Just add them with a single click and your machines will look after its buddies.": [
  null,
  "Cockpit er perfekt for nye sysadminer, slik at de enkelt kan utføre enkle oppgaver som lagringsadministrasjon, inspisere journaler og starte og stoppe tjenester. Du kan overvåke og administrere flere servere samtidig. Bare legg dem til med et enkelt klikk, så vil maskinene dine se etter kompisene."
 ],
 "Collect and package diagnostic and support data": [
  null,
  ""
 ],
 "Command": [
  null,
  "Kommando"
 ],
 "Compact PCI": [
  null,
  ""
 ],
 "Compatible with all systems and devices (MBR)": [
  null,
  "Kompatibel med alle systemer og enheter (MBR)"
 ],
 "Compatible with modern system and hard disks > 2TB (GPT)": [
  null,
  "Kompatibel med moderne system og harddisker> 2TB (GPT)"
 ],
 "Completed with a segment that failed and the segment that failed is not known": [
  null,
  ""
 ],
 "Completed with one or more failed segments": [
  null,
  ""
 ],
 "Compression": [
  null,
  "Komprimering"
 ],
 "Confirm": [
  null,
  "Bekreft"
 ],
 "Confirm key password": [
  null,
  "Bekreft nøkkel-passord"
 ],
 "Connection has timed out.": [
  null,
  "Tidsavbrudd for tilkoblingen."
 ],
 "Convertible": [
  null,
  "Konverterbar"
 ],
 "Copied": [
  null,
  ""
 ],
 "Copy": [
  null,
  "Kopier"
 ],
 "Copy to clipboard": [
  null,
  "Kopier til utklippstavle"
 ],
 "Create": [
  null,
  "Opprett"
 ],
 "Create RAID device": [
  null,
  "Opprett RAID-enhet"
 ],
 "Create logical volume": [
  null,
  "Opprett logisk volum"
 ],
 "Create new logical volume": [
  null,
  "Opprett nytt logisk volum"
 ],
 "Create new task file with this content.": [
  null,
  "Opprett ny oppgavefil med dette innholdet."
 ],
 "Create partition": [
  null,
  "Opprett partisjon"
 ],
 "Create partition on $0": [
  null,
  "Opprett partisjon på $0"
 ],
 "Create partition table": [
  null,
  "Opprett partisjonstabell"
 ],
 "Create snapshot": [
  null,
  "Opprett øyeblikksbilde"
 ],
 "Create thin volume": [
  null,
  "Opprett tynt volum"
 ],
 "Create volume group": [
  null,
  "Opprett volumgruppe"
 ],
 "Creating filesystem on $target": [
  null,
  "Oppretter filsystem på $target"
 ],
 "Creating logical volume $target": [
  null,
  "Oppretter logisk volum $target"
 ],
 "Creating partition $target": [
  null,
  "Oppretter partisjon $target"
 ],
 "Creating snapshot of $target": [
  null,
  "Oppretter øyeblikksbilde av $target"
 ],
 "Ctrl+Insert": [
  null,
  "Ctrl+Insert"
 ],
 "Custom mount options": [
  null,
  "Tilpassede monteringsalternativer"
 ],
 "Data used": [
  null,
  "Data brukt"
 ],
 "Data will be stored as two copies and also in an alternating fashion on the selected physical volumes, to improve both reliability and performance. At least four volumes need to be selected.": [
  null,
  ""
 ],
 "Data will be stored as two or more copies on the selected physical volumes, to improve reliability. At least two volumes need to be selected.": [
  null,
  ""
 ],
 "Data will be stored on the selected physical volumes in an alternating fashion to improve performance. At least two volumes need to be selected.": [
  null,
  ""
 ],
 "Data will be stored on the selected physical volumes so that one of them can be lost without affecting the data. At least three volumes need to be selected.": [
  null,
  ""
 ],
 "Data will be stored on the selected physical volumes so that one of them can be lost without affecting the data. Data is also stored in an alternating fashion to improve performance. At least three volumes need to be selected.": [
  null,
  ""
 ],
 "Data will be stored on the selected physical volumes so that up to two of them can be lost at the same time without affecting the data. Data is also stored in an alternating fashion to improve performance. At least five volumes need to be selected.": [
  null,
  ""
 ],
 "Data will be stored on the selected physical volumes without any additional redundancy or performance improvements.": [
  null,
  ""
 ],
 "Deactivate": [
  null,
  "Deaktiver"
 ],
 "Deactivating $target": [
  null,
  "Deaktiverer $target"
 ],
 "Deduplication": [
  null,
  "Deduplisering"
 ],
 "Degraded": [
  null,
  ""
 ],
 "Delay": [
  null,
  "Forsinkelse"
 ],
 "Delete": [
  null,
  "Slett"
 ],
 "Deleting $target": [
  null,
  "Sletter $target"
 ],
 "Deleting a logical volume will delete all data in it.": [
  null,
  "Hvis du sletter et logisk volum, slettes alle dataene i det."
 ],
 "Deleting a partition will delete all data in it.": [
  null,
  "Sletting av en partisjon vil slette alle dataene i den."
 ],
 "Description": [
  null,
  "Beskrivelse"
 ],
 "Desktop": [
  null,
  ""
 ],
 "Detachable": [
  null,
  ""
 ],
 "Device": [
  null,
  "Enhet"
 ],
 "Device file": [
  null,
  "Enhetsfil"
 ],
 "Device health (SMART)": [
  null,
  ""
 ],
 "Device is read-only": [
  null,
  "Enheten er skrivebeskyttet"
 ],
 "Diagnostic reports": [
  null,
  "Diagnose rapporter"
 ],
 "Did not complete": [
  null,
  ""
 ],
 "Disconnect": [
  null,
  "Koble fra"
 ],
 "Disk is OK": [
  null,
  "Disken er OK"
 ],
 "Disk passphrase": [
  null,
  "Disk passfrase"
 ],
 "Disks": [
  null,
  "Disker"
 ],
 "Do not mount automatically on boot": [
  null,
  "Ikke monter automatisk ved oppstart"
 ],
 "Docking station": [
  null,
  "Dokkingstasjon"
 ],
 "Downloading $0": [
  null,
  "Laster ned $0"
 ],
 "Drive": [
  null,
  "DIsk"
 ],
 "Dual rank": [
  null,
  "Dobbel rangering"
 ],
 "Edit": [
  null,
  "Rediger"
 ],
 "Edit Tang keyserver": [
  null,
  "Rediger Tang nøkkelserver"
 ],
 "Editing a key requires a free slot": [
  null,
  "Redigering av en nøkkel krever en ledig slot"
 ],
 "Ejecting $target": [
  null,
  "Løser ut $target"
 ],
 "Embedded PC": [
  null,
  "Innebygd PC"
 ],
 "Emptying $target": [
  null,
  "Tømmer $target"
 ],
 "Encrypted $0": [
  null,
  "Kryptert $0"
 ],
 "Encrypted logical volume of $0": [
  null,
  "Kryptert logisk volum på $0"
 ],
 "Encrypted partition of $0": [
  null,
  "Kryptert partisjon på $0"
 ],
 "Encryption": [
  null,
  "Kryptering"
 ],
 "Encryption options": [
  null,
  "Krypteringsalternativer"
 ],
 "Erasing $target": [
  null,
  ""
 ],
 "Error": [
  null,
  "Feil"
 ],
 "Exactly $0 physical volumes must be selected": [
  null,
  ""
 ],
 "Exactly $0 physical volumes need to be selected, one for each stripe of the logical volume.": [
  null,
  ""
 ],
 "Excellent password": [
  null,
  "Utmerket passord"
 ],
 "Expansion chassis": [
  null,
  ""
 ],
 "Extended partition": [
  null,
  "Utvidet partisjon"
 ],
 "Failed": [
  null,
  "Feilet"
 ],
 "Failed (Damaged)": [
  null,
  ""
 ],
 "Failed (Electrical)": [
  null,
  ""
 ],
 "Failed to change password": [
  null,
  "Kunne ikke endre passord"
 ],
 "Filesystem": [
  null,
  "Filsystem"
 ],
 "Filesystem name": [
  null,
  "Filsystem navn"
 ],
 "Fix NBDE support": [
  null,
  ""
 ],
 "Format": [
  null,
  "Format"
 ],
 "Format $0": [
  null,
  "Formater $0"
 ],
 "Free space": [
  null,
  "Ledig plass"
 ],
 "Go to now": [
  null,
  "Gå til nå"
 ],
 "Grow": [
  null,
  ""
 ],
 "Grow content": [
  null,
  ""
 ],
 "Grow logical size of $0": [
  null,
  "Øk logisk størrelse på $0"
 ],
 "Grow logical volume": [
  null,
  "Øk logisk volum"
 ],
 "Grow to take all space": [
  null,
  "Voks for å ta all plass"
 ],
 "Handheld": [
  null,
  "Håndholdt"
 ],
 "Hard Disk Drive": [
  null,
  ""
 ],
 "Host key is incorrect": [
  null,
  "Vertsnøkkelen er feil"
 ],
 "How to check": [
  null,
  ""
 ],
 "I confirm I want to lose this data forever": [
  null,
  ""
 ],
 "ID": [
  null,
  "ID"
 ],
 "INTERNAL ERROR - This logical volume is marked as active and should have an associated block device. However, no such block device could be found.": [
  null,
  ""
 ],
 "Important data might be deleted:": [
  null,
  ""
 ],
 "In a terminal, run: ": [
  null,
  ""
 ],
 "In progress": [
  null,
  ""
 ],
 "In sync": [
  null,
  "I synk"
 ],
 "Inconsistent filesystem mount": [
  null,
  "Inkonsistent filsystemmontering"
 ],
 "Index memory": [
  null,
  "Indeks minne"
 ],
 "Install": [
  null,
  "Installer"
 ],
 "Install NFS support": [
  null,
  "Installer NFS-støtte"
 ],
 "Install software": [
  null,
  "Installer programvare"
 ],
 "Installing $0": [
  null,
  "Installerer $0"
 ],
 "Internal error": [
  null,
  "Intern feil"
 ],
 "Invalid date format": [
  null,
  "Ugyldig datoformat"
 ],
 "Invalid date format and invalid time format": [
  null,
  "Ugyldig datoformat og ugyldig tidsformat"
 ],
 "Invalid file permissions": [
  null,
  "Ugyldige filtillatelser"
 ],
 "Invalid time format": [
  null,
  "Ugyldig tidsformat"
 ],
 "Invalid timezone": [
  null,
  "Ugyldig tidssone"
 ],
 "Invalid username or password": [
  null,
  "Ugyldig brukernavn eller passord"
 ],
 "IoT gateway": [
  null,
  "IoT-gateway"
 ],
 "Jobs": [
  null,
  "Jobber"
 ],
 "Kernel dump": [
  null,
  "Kjerne dump"
 ],
 "Key password": [
  null,
  "Nøkkel-passord"
 ],
 "Key slots with unknown types can not be edited here": [
  null,
  "Nøkkel-slots med ukjente typer kan ikke redigeres her"
 ],
 "Key source": [
  null,
  "Nøkkelkilde"
 ],
 "Keys": [
  null,
  "Nøkler"
 ],
 "Keyserver": [
  null,
  "Nøkkelserver"
 ],
 "Keyserver address": [
  null,
  "Nøkkelserver adresse"
 ],
 "Keyserver removal may prevent unlocking $0.": [
  null,
  "Fjerning av nøkkelserver kan forhindre opplåsing av $0."
 ],
 "Label": [
  null,
  ""
 ],
 "Laptop": [
  null,
  ""
 ],
 "Layout": [
  null,
  ""
 ],
 "Learn more": [
  null,
  "Lær mer"
 ],
 "Linear": [
  null,
  ""
 ],
 "Linux swap space": [
  null,
  ""
 ],
 "Loading system modifications...": [
  null,
  "Laster inn systemendringer ..."
 ],
 "Loading...": [
  null,
  "Laster..."
 ],
 "Local mount point": [
  null,
  "Lokalt monteringspunkt"
 ],
 "Location": [
  null,
  "Plassering"
 ],
 "Lock": [
  null,
  "Lås"
 ],
 "Locked encrypted device might contain data": [
  null,
  ""
 ],
 "Locking $target": [
  null,
  "Låser $target"
 ],
 "Log in": [
  null,
  "Logg inn"
 ],
 "Log messages": [
  null,
  "Logg meldinger"
 ],
 "Logical": [
  null,
  "Logisk"
 ],
 "Logical size": [
  null,
  "Logisk størrelse"
 ],
 "Logical volume": [
  null,
  "Logisk volum"
 ],
 "Logical volume (snapshot)": [
  null,
  "Logisk volum (øyeblikksbilde)"
 ],
 "Logical volume of $0": [
  null,
  "Logisk volum på $0"
 ],
 "Login failed": [
  null,
  "Innlogging feilet"
 ],
 "Low profile desktop": [
  null,
  ""
 ],
 "Lunch box": [
  null,
  "Lunsjboks"
 ],
 "Main server chassis": [
  null,
  ""
 ],
 "Manually": [
  null,
  "Manuelt"
 ],
 "Marking $target as faulty": [
  null,
  "Markerer $target som feilende"
 ],
 "Message to logged in users": [
  null,
  "Melding til innloggede brukere"
 ],
 "Metadata used": [
  null,
  "Metadata brukt"
 ],
 "Mini PC": [
  null,
  "Mini-PC"
 ],
 "Mini tower": [
  null,
  ""
 ],
 "Mirrored (RAID 1)": [
  null,
  ""
 ],
 "Model": [
  null,
  "Modell"
 ],
 "Modifying $target": [
  null,
  "Endrer $target"
 ],
 "Mount": [
  null,
  "Montér"
 ],
 "Mount after network becomes available, ignore failure": [
  null,
  ""
 ],
 "Mount also automatically on boot": [
  null,
  "Monter også automatisk ved oppstart"
 ],
 "Mount at boot": [
  null,
  "Monter ved oppstart"
 ],
 "Mount automatically on $0 on boot": [
  null,
  "Monter automatisk på $0 ved oppstart"
 ],
 "Mount before services start": [
  null,
  ""
 ],
 "Mount configuration": [
  null,
  "Monterings-konfigurasjon"
 ],
 "Mount filesystem": [
  null,
  "Monter filsystem"
 ],
 "Mount now": [
  null,
  "Monter nå"
 ],
 "Mount on $0 now": [
  null,
  "Monter på $0 nå"
 ],
 "Mount options": [
  null,
  "Innstillinger for montering"
 ],
 "Mount point": [
  null,
  "Monteringspunkt"
 ],
 "Mount point cannot be empty": [
  null,
  "Monteringspunkt kan ikke være tomt"
 ],
 "Mount point cannot be empty.": [
  null,
  "Monteringspunkt kan ikke være tomt."
 ],
 "Mount point is already used for $0": [
  null,
  "Monteringspunktet er allerede brukt for $0"
 ],
 "Mount point must start with \"/\".": [
  null,
  "Monteringspunktet må starte med \"/\"."
 ],
 "Mount read only": [
  null,
  "Monter skrivebeskyttet"
 ],
 "Mount without waiting, ignore failure": [
  null,
  ""
 ],
 "Mounting $target": [
  null,
  "Monterer $target"
 ],
 "Mounts before services start": [
  null,
  ""
 ],
 "Mounts in parallel with services": [
  null,
  ""
 ],
 "Mounts in parallel with services, but after network is available": [
  null,
  ""
 ],
 "Multi-system chassis": [
  null,
  ""
 ],
 "NFS mount": [
  null,
  "NFS-montering"
 ],
 "NTP server": [
  null,
  "NTP Server"
 ],
 "Name": [
  null,
  "Navn"
 ],
 "Name can not be empty.": [
  null,
  "Navnet kan ikke være tomt."
 ],
 "Name cannot be empty.": [
  null,
  "Navnet kan ikke være tomt."
 ],
 "Name cannot be longer than $0 bytes": [
  null,
  "Navnet kan ikke være lengre enn $0 byte"
 ],
 "Name cannot be longer than $0 characters": [
  null,
  "Navnet kan ikke være lengre enn $0 tegn"
 ],
 "Name cannot be longer than 127 characters.": [
  null,
  "Navnet kan ikke være lengre enn 127 tegn."
 ],
 "Name cannot contain the character '$0'.": [
  null,
  "Navnet kan ikke inneholde tegnet '$0'."
 ],
 "Name cannot contain whitespace.": [
  null,
  "Navnet kan ikke inneholde mellomrom."
 ],
 "Need a spare disk": [
  null,
  ""
 ],
 "Need at least one NTP server": [
  null,
  "Trenger minst en NTP-server"
 ],
 "Networking": [
  null,
  "Nettverk"
 ],
 "New NFS mount": [
  null,
  "Ny NFS-montering"
 ],
 "New passphrase": [
  null,
  "Ny passfrase"
 ],
 "New password was not accepted": [
  null,
  "Nytt passord ble ikke godtatt"
 ],
 "Next": [
  null,
  "Neste"
 ],
 "No available slots": [
  null,
  "Ingen tilgjengelige slots"
 ],
 "No delay": [
  null,
  "Ingen forsinkelse"
 ],
 "No disks are available.": [
  null,
  "Ingen disker er tilgjengelige."
 ],
 "No filesystem": [
  null,
  "Ingen filsystem"
 ],
 "No free key slots": [
  null,
  "Ingen ledige nøkkelslots"
 ],
 "No free space": [
  null,
  "Ingen ledig plass"
 ],
 "No keys added": [
  null,
  "Ingen nøkler lagt til"
 ],
 "No logical volumes": [
  null,
  "Ingen logiske volumer"
 ],
 "No media inserted": [
  null,
  "Ingen medier satt inn"
 ],
 "No partitioning": [
  null,
  "Ingen partisjonering"
 ],
 "No results found": [
  null,
  "Ingen resultater funnet"
 ],
 "No such file or directory": [
  null,
  "Ingen slik fil eller katalog"
 ],
 "No system modifications": [
  null,
  "Ingen systemendringer"
 ],
 "Not a valid private key": [
  null,
  "Ikke en gyldig privat nøkkel"
 ],
 "Not found": [
  null,
  "Ikke funnet"
 ],
 "Not permitted to perform this action.": [
  null,
  "Ikke tillatt å utføre denne handlingen."
 ],
 "Not running": [
  null,
  "Kjører ikke"
 ],
 "Not synchronized": [
  null,
  "Ikke synkronisert"
 ],
 "Notebook": [
  null,
  ""
 ],
 "Number of bad sectors": [
  null,
  ""
 ],
 "Ok": [
  null,
  "Ok"
 ],
 "Old passphrase": [
  null,
  "Gammel passordfrase"
 ],
 "Old password not accepted": [
  null,
  "Gammelt passord aksepteres ikke"
 ],
 "Once Cockpit is installed, enable it with \"systemctl enable --now cockpit.socket\".": [
  null,
  "Når Cockpit er installert, kan den aktiveres med \"systemctl enable --now cockpit.socket\"."
 ],
 "Only $0 of $1 are used.": [
  null,
  "Bare $0 av $1 brukes."
 ],
 "Operation '$operation' on $target": [
  null,
  "Operasjon '$operation' på $target"
 ],
 "Options": [
  null,
  "Alternativer"
 ],
 "Other": [
  null,
  "Annen"
 ],
 "PackageKit crashed": [
  null,
  "PackageKit krasjet"
 ],
 "Partition": [
  null,
  "Partisjon"
 ],
 "Partition of $0": [
  null,
  "Partisjon på $0"
 ],
 "Partitioning": [
  null,
  "Partisjonering"
 ],
 "Passphrase": [
  null,
  "Passfrase"
 ],
 "Passphrase cannot be empty": [
  null,
  "Passfrasen kan ikke være tom"
 ],
 "Passphrase removal may prevent unlocking $0.": [
  null,
  "Fjerning av passfrase kan forhindre opplåsing av $0."
 ],
 "Passphrases do not match": [
  null,
  "Passfraser stemmer ikke overens"
 ],
 "Password": [
  null,
  "Passord"
 ],
 "Password is not acceptable": [
  null,
  "Passord er ikke akseptabelt"
 ],
 "Password is too weak": [
  null,
  "Passordet er for svakt"
 ],
 "Password not accepted": [
  null,
  "Passord ikke akseptert"
 ],
 "Paste": [
  null,
  "Lim inn"
 ],
 "Path on server": [
  null,
  "Sti på server"
 ],
 "Path on server cannot be empty.": [
  null,
  "Sti på server kan ikke være tom."
 ],
 "Path on server must start with \"/\".": [
  null,
  "Stien på serveren må starte med \"/\"."
 ],
 "Path to file": [
  null,
  "Sti til fil"
 ],
 "Peripheral chassis": [
  null,
  "Perifert chassis"
 ],
 "Permanently delete $0?": [
  null,
  ""
 ],
 "Physical": [
  null,
  "Fysisk"
 ],
 "Physical volumes": [
  null,
  "Fysiske volumer"
 ],
 "Pick date": [
  null,
  "Velg dato"
 ],
 "Pizza box": [
  null,
  "Pizzaboks"
 ],
 "Please unmount them first.": [
  null,
  ""
 ],
 "Pool for thin logical volumes": [
  null,
  "Pool for tynne logiske volumer"
 ],
 "Pool for thinly provisioned volumes": [
  null,
  "Pool for tynt provisjonerte volumer"
 ],
 "Port": [
  null,
  "Port"
 ],
 "Portable": [
  null,
  "Bærbar"
 ],
 "Power on hours": [
  null,
  ""
 ],
 "Present": [
  null,
  "Til stede"
 ],
 "Processes using the location": [
  null,
  ""
 ],
 "Prompting via ssh-add timed out": [
  null,
  "Spørring via ssh-add ble tidsavbrutt"
 ],
 "Prompting via ssh-keygen timed out": [
  null,
  "Spørring via ssh-keygen ble tidsavbrutt"
 ],
 "Provide the passphrase for the pool on these block devices:": [
  null,
  ""
 ],
 "Purpose": [
  null,
  "Formål"
 ],
 "RAID ($0)": [
  null,
  "RAID ($0)"
 ],
 "RAID 0": [
  null,
  "RAID 0"
 ],
 "RAID 0 (stripe)": [
  null,
  "RAID 0 (stripe)"
 ],
 "RAID 1": [
  null,
  "RAID 1"
 ],
 "RAID 1 (mirror)": [
  null,
  "RAID 1 (speil)"
 ],
 "RAID 10": [
  null,
  "RAID 10"
 ],
 "RAID 10 (stripe of mirrors)": [
  null,
  "RAID 10 (stripe av speil)"
 ],
 "RAID 4": [
  null,
  "RAID 4"
 ],
 "RAID 4 (dedicated parity)": [
  null,
  "RAID 4 (dedikert paritet)"
 ],
 "RAID 5": [
  null,
  "RAID 5"
 ],
 "RAID 5 (distributed parity)": [
  null,
  "RAID 5 (distribuert paritet)"
 ],
 "RAID 6": [
  null,
  "RAID 6"
 ],
 "RAID 6 (double distributed parity)": [
  null,
  "RAID 6 (dobbel fordelt paritet)"
 ],
 "RAID chassis": [
  null,
  "RAID chassis"
 ],
 "RAID level": [
  null,
  "RAID-nivå"
 ],
 "RAID10 needs an even number of physical volumes": [
  null,
  ""
 ],
 "Rack mount chassis": [
  null,
  ""
 ],
 "Reboot": [
  null,
  "Omstart"
 ],
 "Recovering": [
  null,
  "Gjenoppretter"
 ],
 "Related processes and services will be forcefully stopped.": [
  null,
  ""
 ],
 "Related processes will be forcefully stopped.": [
  null,
  ""
 ],
 "Related services will be forcefully stopped.": [
  null,
  ""
 ],
 "Removals:": [
  null,
  ""
 ],
 "Remove": [
  null,
  "Fjern"
 ],
 "Remove $0?": [
  null,
  "Fjern $0?"
 ],
 "Remove device": [
  null,
  "Fjern enheten"
 ],
 "Removing $0": [
  null,
  "Fjerner $0"
 ],
 "Removing a passphrase without confirmation of another passphrase may prevent unlocking or key management, if other passphrases are forgotten or lost.": [
  null,
  ""
 ],
 "Removing physical volume from $target": [
  null,
  "Fjerner fysisk volum fra $target"
 ],
 "Rename": [
  null,
  "Omdøp"
 ],
 "Rename logical volume": [
  null,
  "Omdøp logisk volum"
 ],
 "Rename volume group": [
  null,
  "Omdøp volumgruppe"
 ],
 "Renaming $target": [
  null,
  "Omdøper $target"
 ],
 "Repair": [
  null,
  ""
 ],
 "Repairing $target": [
  null,
  "Reparerer $target"
 ],
 "Repeat passphrase": [
  null,
  "Gjenta passfrasen"
 ],
 "Resizing $target": [
  null,
  ""
 ],
 "Resizing an encrypted filesystem requires unlocking the disk. Please provide a current disk passphrase.": [
  null,
  "Å endre størrelse på et kryptert filsystem krever at du låser opp disken. Oppgi en aktuell passfrase."
 ],
 "Reuse existing encryption ($0)": [
  null,
  ""
 ],
 "Run extended test": [
  null,
  ""
 ],
 "Run this command over a trusted network or physically on the remote machine:": [
  null,
  ""
 ],
 "Running": [
  null,
  "Kjører"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "SHA-1": [
  null,
  ""
 ],
 "SHA-256": [
  null,
  ""
 ],
 "SMART self-test of $target": [
  null,
  "SMART selvtest av $target"
 ],
 "SSH key": [
  null,
  "SSH-nøkkel"
 ],
 "Save": [
  null,
  "Lagre"
 ],
 "Save space by compressing individual blocks with LZ4": [
  null,
  "Spar plass ved å komprimere individuelle blokker med LZ4"
 ],
 "Save space by storing identical data blocks just once": [
  null,
  "Spar plass ved å lagre identiske datablokker bare en gang"
 ],
 "Saving a new passphrase requires unlocking the disk. Please provide a current disk passphrase.": [
  null,
  "For å lagre en ny passfrase, må du låse opp disken. Oppgi en aktuell passfrase."
 ],
 "Sealed-case PC": [
  null,
  ""
 ],
 "Securely erasing $target": [
  null,
  ""
 ],
 "Security Enhanced Linux configuration and troubleshooting": [
  null,
  ""
 ],
 "Select the physical volumes that should be used to repair the logical volume. At least $0 are needed.": [
  null,
  ""
 ],
 "Server": [
  null,
  "Server"
 ],
 "Server address": [
  null,
  "Serveradresse"
 ],
 "Server address cannot be empty.": [
  null,
  "Serveradressen kan ikke være tom."
 ],
 "Server cannot be empty.": [
  null,
  "Serveren kan ikke være tom."
 ],
 "Server has closed the connection.": [
  null,
  "Serveren har lukket forbindelsen."
 ],
 "Service": [
  null,
  "Tjeneste"
 ],
 "Set": [
  null,
  "Sett"
 ],
 "Set limit of virtual filesystem size": [
  null,
  ""
 ],
 "Set time": [
  null,
  "Sett tid"
 ],
 "Setting up loop device $target": [
  null,
  ""
 ],
 "Shell script": [
  null,
  "Shell-skript"
 ],
 "Shift+Insert": [
  null,
  "Shift+Insert"
 ],
 "Shrink": [
  null,
  "Krymp"
 ],
 "Shrink logical volume": [
  null,
  "Krymp logisk volum"
 ],
 "Shrink volume": [
  null,
  "Krymp volum"
 ],
 "Shut down": [
  null,
  "Slå av"
 ],
 "Single rank": [
  null,
  ""
 ],
 "Size": [
  null,
  "Størrelse"
 ],
 "Size cannot be negative": [
  null,
  "Størrelse kan ikke være negativ"
 ],
 "Size cannot be zero": [
  null,
  "Størrelsen kan ikke være null"
 ],
 "Size is too large": [
  null,
  "Størrelsen er for stor"
 ],
 "Size must be a number": [
  null,
  "Størrelsen må være et tall"
 ],
 "Size must be at least $0": [
  null,
  "Størrelsen må være minst $0"
 ],
 "Slot $0": [
  null,
  "Slot $0"
 ],
 "Solid State Drive": [
  null,
  ""
 ],
 "Some block devices of this pool have grown in size after the pool was created. The pool can be safely grown to use the newly available space.": [
  null,
  ""
 ],
 "Sorry": [
  null,
  ""
 ],
 "Space-saving computer": [
  null,
  "Plassbesparende datamaskin"
 ],
 "Spare": [
  null,
  "Reserve"
 ],
 "Spare capacity is below the threshold": [
  null,
  ""
 ],
 "Specific time": [
  null,
  "Spesifikk tid"
 ],
 "Start": [
  null,
  "Start"
 ],
 "Start multipath": [
  null,
  ""
 ],
 "Starting swapspace $target": [
  null,
  ""
 ],
 "State": [
  null,
  "Tilstand"
 ],
 "Stick PC": [
  null,
  ""
 ],
 "Stop": [
  null,
  "Stopp"
 ],
 "Stop and remove": [
  null,
  "Stopp og fjern"
 ],
 "Stop and unmount": [
  null,
  "Stopp og demonter"
 ],
 "Stop device": [
  null,
  "Stopp enhet"
 ],
 "Stopping swapspace $target": [
  null,
  ""
 ],
 "Storage": [
  null,
  "Lagring"
 ],
 "Storage can not be managed on this system.": [
  null,
  "Lagring kan ikke administreres på dette systemet."
 ],
 "Storage logs": [
  null,
  "Lagringslogger"
 ],
 "Store passphrase": [
  null,
  ""
 ],
 "Stored passphrase": [
  null,
  ""
 ],
 "Striped (RAID 0)": [
  null,
  ""
 ],
 "Striped and mirrored (RAID 10)": [
  null,
  ""
 ],
 "Stripes": [
  null,
  ""
 ],
 "Sub-Chassis": [
  null,
  ""
 ],
 "Sub-Notebook": [
  null,
  ""
 ],
 "Swap": [
  null,
  "Swap"
 ],
 "Synchronized": [
  null,
  "Synkronisert"
 ],
 "Synchronized with $0": [
  null,
  "Synkronisert med $0"
 ],
 "Synchronizing": [
  null,
  "Synkroniserer"
 ],
 "Tablet": [
  null,
  "Nettbrett"
 ],
 "Tang keyserver": [
  null,
  "Tang nøkkelserver"
 ],
 "Target": [
  null,
  "Mål"
 ],
 "Temperature outside of recommended thresholds": [
  null,
  ""
 ],
 "The creation of this VDO device did not finish and the device can't be used.": [
  null,
  "Opprettelsen av denne VDO-enheten ble ikke fullført, og enheten kan ikke brukes."
 ],
 "The currently logged in user is not permitted to see information about keys.": [
  null,
  "Den påloggede brukeren har ikke lov til å se informasjon om nøkler."
 ],
 "The disk needs to be unlocked before formatting.  Please provide a existing passphrase.": [
  null,
  ""
 ],
 "The filesystem has no permanent mount point.": [
  null,
  "Filsystemet har ikke noe permanent monteringspunkt."
 ],
 "The filesystem is configured to be automatically mounted on boot but its encryption container will not be unlocked at that time.": [
  null,
  "Filsystemet er konfigurert til å monteres automatisk ved oppstart, men krypteringsbeholderen blir ikke låst opp på det tidspunktet."
 ],
 "The filesystem is currently mounted but will not be mounted after the next boot.": [
  null,
  "Filsystemet er for øyeblikket montert, men blir ikke montert etter neste oppstart."
 ],
 "The filesystem is currently mounted on $0 but will be mounted on $1 on the next boot.": [
  null,
  "Filsystemet er for øyeblikket montert på $0, men vil bli montert på $1 ved neste oppstart."
 ],
 "The filesystem is currently mounted on $0 but will not be mounted after the next boot.": [
  null,
  "Filsystemet er for øyeblikket montert på $0, men blir ikke montert etter neste oppstart."
 ],
 "The filesystem is currently not mounted but will be mounted on the next boot.": [
  null,
  "Filsystemet er foreløpig ikke montert, men vil bli montert på neste oppstart."
 ],
 "The filesystem is not mounted.": [
  null,
  "Filsystemet er ikke montert."
 ],
 "The filesystem will be unlocked and mounted on the next boot. This might require inputting a passphrase.": [
  null,
  ""
 ],
 "The initrd must be regenerated.": [
  null,
  ""
 ],
 "The key password can not be empty": [
  null,
  "Nøkkelpassordet kan ikke være tomt"
 ],
 "The key passwords do not match": [
  null,
  "Nøkkelpassordene stemmer ikke overens"
 ],
 "The last key slot can not be removed": [
  null,
  "Den siste nøkkel-sloten kan ikke fjernes"
 ],
 "The listed processes and services will be forcefully stopped.": [
  null,
  ""
 ],
 "The listed processes will be forcefully stopped.": [
  null,
  ""
 ],
 "The logged in user is not permitted to view system modifications": [
  null,
  "Den påloggede brukeren har ikke lov til å se systemendringer"
 ],
 "The mount point $0 is in use by these processes:": [
  null,
  ""
 ],
 "The mount point $0 is in use by these services:": [
  null,
  ""
 ],
 "The resulting fingerprint is fine to share via public methods, including email.": [
  null,
  "Det resulterende fingeravtrykket er greit å dele via offentlige metoder, inkludert e-post."
 ],
 "The resulting fingerprint is fine to share via public methods, including email. If you are asking someone else to do the verification for you, they can send the results using any method.": [
  null,
  ""
 ],
 "The server refused to authenticate using any supported methods.": [
  null,
  "Serveren nektet å godkjenne ved hjelp av de støttede metodene."
 ],
 "The system does not currently support unlocking a filesystem with a Tang keyserver during boot.": [
  null,
  ""
 ],
 "The system does not currently support unlocking the root filesystem with a Tang keyserver.": [
  null,
  ""
 ],
 "There are devices with multiple paths on the system, but the multipath service is not running.": [
  null,
  ""
 ],
 "There is not enough space available that could be used for a repair. At least $0 are needed on physical volumes that are not already used for this logical volume.": [
  null,
  ""
 ],
 "These additional steps are necessary:": [
  null,
  ""
 ],
 "These changes will be made:": [
  null,
  ""
 ],
 "Thin logical volume": [
  null,
  "Tynt logisk volum"
 ],
 "This MDRAID device has no write-intent bitmap. Such a bitmap can reduce synchronization times significantly.": [
  null,
  ""
 ],
 "This NFS mount is in use and only its options can be changed.": [
  null,
  "Denne NFS-monteringen er i bruk, og bare alternativene kan endres."
 ],
 "This VDO device does not use all of its backing device.": [
  null,
  ""
 ],
 "This keyserver is the only way to unlock the pool and can not be removed.": [
  null,
  ""
 ],
 "This logical volume has lost some of its physical volumes and can no longer be used. You need to delete it and create a new one to take its place.": [
  null,
  ""
 ],
 "This logical volume has lost some of its physical volumes but has not lost any data yet. You should repair it to restore its original redundancy.": [
  null,
  ""
 ],
 "This logical volume has lost some of its physical volumes but might not have lost any data yet. You might be able to repair it.": [
  null,
  ""
 ],
 "This logical volume is not completely used by its content.": [
  null,
  "Dette logiske volumet brukes ikke fullstendig av innholdet."
 ],
 "This passphrase is the only way to unlock the pool and can not be removed.": [
  null,
  ""
 ],
 "This pool does not use all the space on its block devices.": [
  null,
  ""
 ],
 "This tool configures the SELinux policy and can help with understanding and resolving policy violations.": [
  null,
  ""
 ],
 "This tool configures the system to write kernel crash dumps. It supports the \"local\" (disk), \"ssh\", and \"nfs\" dump targets.": [
  null,
  ""
 ],
 "This tool generates an archive of configuration and diagnostic information from the running system. The archive may be stored locally or centrally for recording or tracking purposes or may be sent to technical support representatives, developers or system administrators to assist with technical fault-finding and debugging.": [
  null,
  ""
 ],
 "This tool manages local storage, such as filesystems, LVM2 volume groups, and NFS mounts.": [
  null,
  ""
 ],
 "This tool manages networking such as bonds, bridges, teams, VLANs and firewalls using NetworkManager and Firewalld. NetworkManager is incompatible with Ubuntu's default systemd-networkd and Debian's ifupdown scripts.": [
  null,
  ""
 ],
 "This volume group is missing some physical volumes.": [
  null,
  ""
 ],
 "Tier": [
  null,
  ""
 ],
 "Time zone": [
  null,
  "Tidssone"
 ],
 "To ensure that your connection is not intercepted by a malicious third-party, please verify the host key fingerprint:": [
  null,
  "For å sikre at forbindelsen din ikke blir fanget opp av en ondsinnet tredjepart, må du verifisere vertsnøkkelens fingeravtrykk:"
 ],
 "To verify a fingerprint, run the following on $0 while physically sitting at the machine or through a trusted network:": [
  null,
  "For å bekrefte et fingeravtrykk, kjør følgende på $ 0 mens du sitter fysisk ved maskinen eller gjennom et pålitelig nettverk:"
 ],
 "Toggle date picker": [
  null,
  ""
 ],
 "Too much data": [
  null,
  "For mye data"
 ],
 "Total size: $0": [
  null,
  "Total størrelse: $0"
 ],
 "Tower": [
  null,
  ""
 ],
 "Trust and add host": [
  null,
  ""
 ],
 "Trust key": [
  null,
  ""
 ],
 "Trying to synchronize with $0": [
  null,
  "Prøver å synkronisere med $0"
 ],
 "Type": [
  null,
  "Type"
 ],
 "Type must be of the form NNNNNNNN-NNNN-NNNN-NNNN-NNNNNNNNNNNN.": [
  null,
  ""
 ],
 "Type must contain exactly two hexadecimal characters (0 to 9, A to F).": [
  null,
  ""
 ],
 "UUID": [
  null,
  "UUID"
 ],
 "Unable to reach server": [
  null,
  "Kan ikke nå serveren"
 ],
 "Unable to remove mount": [
  null,
  "Kan ikke fjerne monteringen"
 ],
 "Unable to unmount filesystem": [
  null,
  "Kan ikke avmontere filsystemet"
 ],
 "Unexpected PackageKit error during installation of $0: $1": [
  null,
  ""
 ],
 "Unknown": [
  null,
  "Ukjent"
 ],
 "Unknown ($0)": [
  null,
  "Ukjent ($0)"
 ],
 "Unknown host name": [
  null,
  "Ukjent vertsnavn"
 ],
 "Unknown type": [
  null,
  "Ukjent type"
 ],
 "Unlock": [
  null,
  "Lås opp"
 ],
 "Unlock before resizing": [
  null,
  ""
 ],
 "Unlocking $target": [
  null,
  "Låser opp $target"
 ],
 "Unmount": [
  null,
  "Demonter"
 ],
 "Unmount now": [
  null,
  "Demonter nå"
 ],
 "Unmounting $target": [
  null,
  "Demonterer $target"
 ],
 "Unrecognized data": [
  null,
  "Ukjente data"
 ],
 "Unrecognized data can not be made smaller here.": [
  null,
  ""
 ],
 "Untrusted host": [
  null,
  ""
 ],
 "Usage": [
  null,
  "Bruk"
 ],
 "Use compression": [
  null,
  "Bruk komprimering"
 ],
 "Use deduplication": [
  null,
  "Bruk deduplisering"
 ],
 "Used": [
  null,
  "Brukt"
 ],
 "Useful for mounts that are optional or need interaction (such as passphrases)": [
  null,
  ""
 ],
 "User": [
  null,
  "Bruker"
 ],
 "Username": [
  null,
  "Brukernavn"
 ],
 "VDO backing devices can not be made smaller": [
  null,
  ""
 ],
 "VDO device $0": [
  null,
  "VDO-enhet $0"
 ],
 "VDO filesystem volume (compression/deduplication)": [
  null,
  ""
 ],
 "Vendor": [
  null,
  "Leverandør"
 ],
 "Verify key": [
  null,
  "Verifiser nøkkel"
 ],
 "Very securely erasing $target": [
  null,
  ""
 ],
 "View automation script": [
  null,
  "Vis automatiseringsskript"
 ],
 "Virtual filesystem sizes are larger than the pool. Overprovisioning can not be disabled.": [
  null,
  ""
 ],
 "Volatile memory backup failed": [
  null,
  ""
 ],
 "Volume group": [
  null,
  "Volumgruppe"
 ],
 "Volume size is $0. Content size is $1.": [
  null,
  "Volumstørrelsen er $0. Innholdsstørrelsen er $1."
 ],
 "Waiting for other software management operations to finish": [
  null,
  "Venter på at andre programvareadministrasjons-operasjoner skal fullføres"
 ],
 "Web Console for Linux servers": [
  null,
  "Web konsoll for Linux servere"
 ],
 "World wide name": [
  null,
  ""
 ],
 "Write-mostly": [
  null,
  ""
 ],
 "You are connecting to $0 for the first time.": [
  null,
  "Du kobler til $0 for første gang."
 ],
 "Your browser does not allow paste from the context menu. You can use Shift+Insert.": [
  null,
  ""
 ],
 "Your session has been terminated.": [
  null,
  "Økten din er avsluttet."
 ],
 "Your session has expired. Please log in again.": [
  null,
  "Økten din har utløpt. Vennligst logg inn igjen."
 ],
 "Zone": [
  null,
  ""
 ],
 "[binary data]": [
  null,
  "[binære data]"
 ],
 "[no data]": [
  null,
  "[ingen data]"
 ],
 "btrfs subvolume $0 of $1": [
  null,
  ""
 ],
 "device of btrfs volume": [
  null,
  ""
 ],
 "edit": [
  null,
  "rediger"
 ],
 "format": [
  null,
  "format"
 ],
 "grow": [
  null,
  ""
 ],
 "in less than a minute": [
  null,
  ""
 ],
 "less than a minute ago": [
  null,
  ""
 ],
 "mount": [
  null,
  "monter"
 ],
 "none": [
  null,
  "ingen"
 ],
 "password quality": [
  null,
  "passordkvalitet"
 ],
 "read only": [
  null,
  "skrivebeskyttet"
 ],
 "remove from LVM2": [
  null,
  ""
 ],
 "remove from btrfs volume": [
  null,
  ""
 ],
 "show less": [
  null,
  "vis mindre"
 ],
 "show more": [
  null,
  "vis mer"
 ],
 "stop": [
  null,
  ""
 ],
 "stopped": [
  null,
  ""
 ],
 "unknown target": [
  null,
  "ukjent mål"
 ],
 "unmount": [
  null,
  "unmount"
 ],
 "unpartitioned space on $0": [
  null,
  "upartisjonert plass på $0"
 ],
 "yes": [
  null,
  "ja"
 ],
 "format-bytes\u0004bytes": [
  null,
  "bytes"
 ]
});
