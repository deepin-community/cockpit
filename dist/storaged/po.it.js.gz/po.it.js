cockpit.locale({
 "": {
  "plural-forms": (n) => n != 1,
  "language": "it",
  "language-direction": "ltr"
 },
 "$0 GiB": [
  null,
  "$0 GiB"
 ],
 "$0 can not be made larger": [
  null,
  "$0 non può essere aumentato"
 ],
 "$0 can not be made smaller": [
  null,
  "$0 non può essere ridotto"
 ],
 "$0 chunk size": [
  null,
  "$0 Dimensione del blocco"
 ],
 "$0 data + $1 overhead used of $2 ($3)": [
  null,
  "$0 dati + $1 overhead utilizzato di $2 ($3)"
 ],
 "$0 day": [
  null,
  "$0 giorno",
  "$0 giorni"
 ],
 "$0 disk is missing": [
  null,
  "$0 disco inesistente",
  "$0 dischi inesistenti"
 ],
 "$0 disks": [
  null,
  "$0 dischi"
 ],
 "$0 exited with code $1": [
  null,
  "$0 terminato con codice $1"
 ],
 "$0 failed": [
  null,
  "$0 fallito"
 ],
 "$0 filesystem": [
  null,
  "File system $0"
 ],
 "$0 hour": [
  null,
  "$0 ora",
  "$0 ore"
 ],
 "$0 is in use": [
  null,
  "$0 è in uso"
 ],
 "$0 is not available from any repository.": [
  null,
  "$0 non è disponibile in nessun archivio web."
 ],
 "$0 key changed": [
  null,
  "Chiave $0 modificata"
 ],
 "$0 killed with signal $1": [
  null,
  "$0 terminato con codice $1"
 ],
 "$0 minute": [
  null,
  "$0 minuto",
  "$0 minuti"
 ],
 "$0 month": [
  null,
  "$0 mese",
  "$0 mesi"
 ],
 "$0 partitions": [
  null,
  "$0 partizioni"
 ],
 "$0 slot remains": [
  null,
  "$0 slot disponibile",
  "$0 slot disponibili"
 ],
 "$0 synchronized": [
  null,
  "$0 sincronizzato"
 ],
 "$0 used of $1 ($2 saved)": [
  null,
  "$0 usato di $1 ($2 salvato)"
 ],
 "$0 used, $1 total": [
  null,
  "$0 usati, $1 totale"
 ],
 "$0 week": [
  null,
  "$0 settimana",
  "$0 settimane"
 ],
 "$0 will be installed.": [
  null,
  "$0 sarà installato."
 ],
 "$0 year": [
  null,
  "$0 anno",
  "$0 anni"
 ],
 "$name (from $host)": [
  null,
  "$name (da $host)"
 ],
 "(Not part of target)": [
  null,
  "(Non parte del target)"
 ],
 "(no assigned mount point)": [
  null,
  "(nessun punto di montaggio assegnato)"
 ],
 "(not mounted)": [
  null,
  "(non montato)"
 ],
 "(recommended)": [
  null,
  "(raccomandato)"
 ],
 "1 MiB": [
  null,
  "1 MiB"
 ],
 "1 day": [
  null,
  "1 giorno"
 ],
 "1 hour": [
  null,
  "1 ora"
 ],
 "1 minute": [
  null,
  "1 minuto"
 ],
 "1 week": [
  null,
  "1 settimana"
 ],
 "128 KiB": [
  null,
  "128 KiB"
 ],
 "16 KiB": [
  null,
  "16 KiB"
 ],
 "2 MiB": [
  null,
  "2 MiB"
 ],
 "20 minutes": [
  null,
  "20 minuti"
 ],
 "32 KiB": [
  null,
  "32 KiB"
 ],
 "4 KiB": [
  null,
  "4 KiB"
 ],
 "40 minutes": [
  null,
  "40 minuti"
 ],
 "5 minutes": [
  null,
  "5 minuti"
 ],
 "512 KiB": [
  null,
  "512 KiB"
 ],
 "6 hours": [
  null,
  "6 ore"
 ],
 "60 minutes": [
  null,
  "60 minuti"
 ],
 "64 KiB": [
  null,
  "64 KiB"
 ],
 "8 KiB": [
  null,
  "8 KiB"
 ],
 "A compatible version of Cockpit is not installed on $0.": [
  null,
  "Una versione compatibile di Cockpit non è installata su $0."
 ],
 "A fatal error occurred during the self-test operation": [
  null,
  ""
 ],
 "A filesystem with this name exists already in this pool.": [
  null,
  "Un filesystem con questo nome esiste già in questo pool."
 ],
 "A new SSH key at $0 will be created for $1 on $2 and it will be added to the $3 file of $4 on $5.": [
  null,
  "Una nuova chiave SSH in $0 verrà creata per $1 su $2 e sarà aggiunta al file $3 di $4 su $5."
 ],
 "A pool with this name exists already.": [
  null,
  "Esiste già un pool con questo nome."
 ],
 "A volume group with missing physical volumes can not be renamed.": [
  null,
  "Un gruppo di volumi con volumi fisici mancanti non può essere rinominato."
 ],
 "Abort test": [
  null,
  ""
 ],
 "Aborted": [
  null,
  ""
 ],
 "Aborted by a Controller Level Reset": [
  null,
  ""
 ],
 "Aborted due to a removal of a namespace from the namespace inventory": [
  null,
  ""
 ],
 "Aborted due to a sanitize operation": [
  null,
  ""
 ],
 "Aborted due to the processing of a Format NVM command": [
  null,
  ""
 ],
 "Aborted for unknown reason": [
  null,
  ""
 ],
 "Absent": [
  null,
  "Assente"
 ],
 "Acceptable password": [
  null,
  "Password accettabile"
 ],
 "Action": [
  null,
  "Azione"
 ],
 "Actions": [
  null,
  "Azioni"
 ],
 "Activate": [
  null,
  "Attiva"
 ],
 "Activate before resizing": [
  null,
  "Attiva prima del ridimensionamento"
 ],
 "Activating $target": [
  null,
  "Attivazione $target"
 ],
 "Add": [
  null,
  "Aggiungi"
 ],
 "Add $0": [
  null,
  "Aggiungi $0"
 ],
 "Add Network Bound Disk Encryption": [
  null,
  "Aggiungi la crittografia dei dischi legati alla rete"
 ],
 "Add Tang keyserver": [
  null,
  "Aggiungi il server delle chiavi Tang"
 ],
 "Add a bitmap": [
  null,
  "Aggiungi una bitmap"
 ],
 "Add block devices": [
  null,
  "Aggiungi dispositivi a blocchi"
 ],
 "Add disk": [
  null,
  "Aggiungi disco"
 ],
 "Add disks": [
  null,
  "Aggiungi dischi"
 ],
 "Add iSCSI portal": [
  null,
  "Aggiungi portale iSCSI"
 ],
 "Add key": [
  null,
  "Aggiungi chiave"
 ],
 "Add keyserver": [
  null,
  "Aggiungi il server delle chiavi"
 ],
 "Add passphrase": [
  null,
  "Aggiungi la passphrase"
 ],
 "Add physical volume": [
  null,
  "Aggiungi volume fisico"
 ],
 "Adding \"$0\" to encryption options": [
  null,
  "Aggiungi \"$0\" alle Opzioni di cifratura"
 ],
 "Adding \"$0\" to filesystem options": [
  null,
  "Aggiunta di \"$0\" alle opzioni del filesystem"
 ],
 "Adding a keyserver requires unlocking the pool. Please provide the existing pool passphrase.": [
  null,
  "L'aggiunta di un server delle chiavi richiede lo sblocco del pool. Fornire la passphrase del pool esistente."
 ],
 "Adding key": [
  null,
  "Aggiungo la chiave"
 ],
 "Adding physical volume to $target": [
  null,
  "Aggiungo il volume fisico a $target"
 ],
 "Adding rd.neednet=1 to kernel command line": [
  null,
  "Aggiunta di rd.neednet=1 alla riga di comando del kernel"
 ],
 "Additional packages:": [
  null,
  "Pacchetti aggiuntivi:"
 ],
 "Address": [
  null,
  "Indirizzo"
 ],
 "Address cannot be empty": [
  null,
  "L'indirizzo non può essere vuoto"
 ],
 "Address is not a valid URL": [
  null,
  "L'indirizzo non è un URL valido"
 ],
 "Administration with Cockpit Web Console": [
  null,
  "Amministrazione con Cockpit Web Console"
 ],
 "Advanced TCA": [
  null,
  "TCA avanzato"
 ],
 "All $0 selected physical volumes are needed for the chosen layout.": [
  null,
  "Tutti i volumi fisici selezionati da $ 0 sono necessari per il layout scelto."
 ],
 "All-in-one": [
  null,
  "Tutto in una volta"
 ],
 "Allocated": [
  null,
  "Assegnato"
 ],
 "Allow overprovisioning": [
  null,
  "Consenti provisioning eccessivo"
 ],
 "An additional $0 must be selected": [
  null,
  "È necessario selezionare $0 aggiuntivi"
 ],
 "Ansible": [
  null,
  "Ansible"
 ],
 "Ansible roles documentation": [
  null,
  "Documentazione sui ruoli Ansible"
 ],
 "Appropriate for critical mounts, such as /var": [
  null,
  "È appropriato per i montaggi critici, come ad esempio /var"
 ],
 "At boot": [
  null,
  "all'avvio"
 ],
 "At least $0 disk is needed.": [
  null,
  "È necessario almeno $0 disco.",
  "Sono necessari almeno $0 dischi."
 ],
 "At least one block device is needed.": [
  null,
  "È necessario almeno un dispositivo a blocchi."
 ],
 "At least one disk is needed.": [
  null,
  "È necessario almeno un disco."
 ],
 "At least one subvolume needs to be mounted": [
  null,
  "È necessario montare almeno un sottovolume"
 ],
 "Authentication": [
  null,
  "Autenticazione"
 ],
 "Authentication is required to perform privileged tasks with the Cockpit Web Console": [
  null,
  "E' necessario autenticarsi per eseguire azioni privilegiate con Cockpit Web Console"
 ],
 "Authentication required": [
  null,
  "Autenticazione necessaria"
 ],
 "Authorize SSH key": [
  null,
  "Autorizza chiave SSH"
 ],
 "Automatically using NTP": [
  null,
  "Automaticamente utilizzando NTP"
 ],
 "Automatically using additional NTP servers": [
  null,
  "Automaticamente utilizzando server NTP addizionali"
 ],
 "Automatically using specific NTP servers": [
  null,
  "Automaticamente utilizzando server NTP specifici"
 ],
 "Automation script": [
  null,
  "Script di automazione"
 ],
 "Available targets on $0": [
  null,
  "Target disponibili su $0"
 ],
 "BIOS boot partition": [
  null,
  "Partizione di avvio del BIOS"
 ],
 "Blade": [
  null,
  "Blade"
 ],
 "Blade enclosure": [
  null,
  "Chassis del blade"
 ],
 "Block device": [
  null,
  "Blocca dispositivo"
 ],
 "Block device for filesystems": [
  null,
  "Dispositivo di blocco per i filesystem"
 ],
 "Block devices": [
  null,
  "Dispositivi a blocchi"
 ],
 "Blocked": [
  null,
  "Bloccato"
 ],
 "Boot fails if filesystem does not mount, preventing remote access": [
  null,
  "L'avvio fallisce se il filesystem non viene montato, impedendo l'accesso remoto"
 ],
 "Boot still succeeds when filesystem does not mount": [
  null,
  "L'avvio riesce comunque quando il filesystem non viene montato"
 ],
 "Bus expansion chassis": [
  null,
  "Bus di espansione chassis"
 ],
 "Cache": [
  null,
  "Cache"
 ],
 "Cancel": [
  null,
  "Annulla"
 ],
 "Cannot forward login credentials": [
  null,
  "Impossibile inoltrare le credenziali di accesso"
 ],
 "Cannot schedule event in the past": [
  null,
  "Non è possibile programmare eventi del passato"
 ],
 "Capacity": [
  null,
  "Capacità"
 ],
 "Category": [
  null,
  "Categoria"
 ],
 "Change": [
  null,
  "Cambia"
 ],
 "Change iSCSI initiater name": [
  null,
  "Modificare il nome dell'iniziatore iSCSI"
 ],
 "Change iSCSI initiator name": [
  null,
  "Cambia il nome dell'iniziatore iSCSI"
 ],
 "Change label": [
  null,
  "Cambia etichetta"
 ],
 "Change passphrase": [
  null,
  "Cambiare la frase di accesso"
 ],
 "Change system time": [
  null,
  "Modifica dell'ora di sistema"
 ],
 "Changed keys are often the result of an operating system reinstallation. However, an unexpected change may indicate a third-party attempt to intercept your connection.": [
  null,
  "La modifica delle chiavi sono di solito il risultato di una reinstallazione del sistema. Tuttavia, una modifica inaspettata può indicare un tentativo di intercettazione da parte di un soggetto terzo."
 ],
 "Changing partition types might prevent the system from booting.": [
  null,
  "La modifica del tipo di partizione potrebbe impedire l'avvio del sistema."
 ],
 "Check that the SHA-256 or SHA-1 hash from the command matches this dialog.": [
  null,
  "Controlla che l'hash SHA-256 o SHA-1 del comando corrisponda a questa finestra di dialogo."
 ],
 "Check the key hash with the Tang server.": [
  null,
  "Controlla l'hash della chiave con il server Tang."
 ],
 "Checking $target": [
  null,
  "Controllo $target"
 ],
 "Checking MDRAID device $target": [
  null,
  "Controllo del dispositivo MDRAID $target"
 ],
 "Checking and repairing MDRAID device $target": [
  null,
  "Controllo e riparazione del dispositivo MDRAID $target"
 ],
 "Checking filesystem usage": [
  null,
  "Controllo dell'utilizzo del file system"
 ],
 "Checking for $0 package": [
  null,
  "Verifica per $0 pacchetto"
 ],
 "Checking for NBDE support in the initrd": [
  null,
  "Verifica del supporto NBDE in initrd"
 ],
 "Checking installed software": [
  null,
  "Verifica del software installato"
 ],
 "Chunk size": [
  null,
  "Dimensione chunk"
 ],
 "Cleaning up for $target": [
  null,
  "Pulizia per $target"
 ],
 "Clear input value": [
  null,
  "Cancella il valore immesso"
 ],
 "Cleartext device": [
  null,
  "Dispositivo con testo in chiaro"
 ],
 "Close": [
  null,
  "Chiudi"
 ],
 "Cockpit": [
  null,
  "Cockpit"
 ],
 "Cockpit configuration of NetworkManager and Firewalld": [
  null,
  "Configurazione Cockpit del NetworkManager e del Firewalld"
 ],
 "Cockpit could not contact the given host.": [
  null,
  "Cockpit non ha potuto contattare l'host inserito."
 ],
 "Cockpit is a server manager that makes it easy to administer your Linux servers via a web browser. Jumping between the terminal and the web tool is no problem. A service started via Cockpit can be stopped via the terminal. Likewise, if an error occurs in the terminal, it can be seen in the Cockpit journal interface.": [
  null,
  "Cockpit è un gestore di server che rende facile amministrare i server Linux tramite un browser web. Cambiare tra il terminale e lo strumento web non è un problema. Un servizio avviato tramite Cockpit può essere interrotto tramite il terminale. Allo stesso modo, se si verifica un errore nel terminale, può essere visto nella sezione del registro di Cockpit."
 ],
 "Cockpit is not compatible with the software on the system.": [
  null,
  "Cockpit non è compatibile con il software del sistema."
 ],
 "Cockpit is not installed": [
  null,
  "Cockpit non è installato"
 ],
 "Cockpit is not installed on the system.": [
  null,
  "Cockpit non è installato sul sistema."
 ],
 "Cockpit is perfect for new sysadmins, allowing them to easily perform simple tasks such as storage administration, inspecting journals and starting and stopping services. You can monitor and administer several servers at the same time. Just add them with a single click and your machines will look after its buddies.": [
  null,
  "Cockpit è perfetto per i nuovi amministratori di sistema, consentendo loro di eseguire facilmente semplici operazioni come la gestione dell'archiviazione, l'ispezione del registro e l'avvio e l'arresto dei servizi. È possibile monitorare e amministrare più server allo stesso tempo. Basta aggiungerli con un solo clic e se ne prenderà subito cura."
 ],
 "Collect and package diagnostic and support data": [
  null,
  "Raccogliere e creare un pacchetto di dati diagnostici e di supporto"
 ],
 "Collect kernel crash dumps": [
  null,
  "Acquisisci i dump dei crash del kernel"
 ],
 "Command": [
  null,
  "Comando"
 ],
 "Compact PCI": [
  null,
  "PCI compatto"
 ],
 "Compatible with all systems and devices (MBR)": [
  null,
  "Compatibile con tutti i sistemi e dispositivi (MBR)"
 ],
 "Compatible with modern system and hard disks > 2TB (GPT)": [
  null,
  "Compatibile con sistemi moderni e dischi rigidi > 2TB (GPT)"
 ],
 "Completed with a segment that failed and the segment that failed is not known": [
  null,
  ""
 ],
 "Completed with one or more failed segments": [
  null,
  ""
 ],
 "Compression": [
  null,
  "Compressione"
 ],
 "Confirm": [
  null,
  "Conferma"
 ],
 "Confirm deletion of $0": [
  null,
  "Conferma la cancellazione di $0"
 ],
 "Confirm key password": [
  null,
  "Conferma la password chiave"
 ],
 "Confirm removal with an alternate passphrase": [
  null,
  "Conferma la rimozione con una passphrase alternativa"
 ],
 "Confirm stopping of $0": [
  null,
  "Confermare l'arresto di $0"
 ],
 "Connection has timed out.": [
  null,
  "Il collegamento è scaduto."
 ],
 "Convertible": [
  null,
  "Convertibile"
 ],
 "Copied": [
  null,
  "Copiato"
 ],
 "Copy": [
  null,
  "Copia"
 ],
 "Copy to clipboard": [
  null,
  "Copia negli appunti"
 ],
 "Create": [
  null,
  "Crea"
 ],
 "Create $0": [
  null,
  "Crea $0"
 ],
 "Create LVM2 volume group": [
  null,
  "Crea gruppo di volumi LVM2"
 ],
 "Create MDRAID device": [
  null,
  "Crea il dispositivo MDRAID"
 ],
 "Create RAID device": [
  null,
  "Creare un dispositivo RAID"
 ],
 "Create Stratis pool": [
  null,
  "Crea un pool Stratis"
 ],
 "Create a new SSH key and authorize it": [
  null,
  "Crea una nuova chiave SSH e autorizzala"
 ],
 "Create a snapshot of filesystem $0": [
  null,
  "Crea uno snapshot del filesystem $0"
 ],
 "Create and mount": [
  null,
  "Crea e monta"
 ],
 "Create and start": [
  null,
  "Crea e inizia"
 ],
 "Create filesystem": [
  null,
  "Crea filesystem"
 ],
 "Create logical volume": [
  null,
  "Crea un volume logico"
 ],
 "Create new filesystem": [
  null,
  "Crea nuovo filesystem"
 ],
 "Create new logical volume": [
  null,
  "Crea un nuovo volume logico"
 ],
 "Create new task file with this content.": [
  null,
  "Crea un nuovo file di attività con questo contenuto."
 ],
 "Create new thinly provisioned logical volume": [
  null,
  "Crea un nuovo volume logico con thin provisioning"
 ],
 "Create only": [
  null,
  "crea soltanto"
 ],
 "Create partition": [
  null,
  "Crea partizione"
 ],
 "Create partition on $0": [
  null,
  "Crea partizione su $0"
 ],
 "Create partition table": [
  null,
  "Crea tabella delle partizioni"
 ],
 "Create snapshot": [
  null,
  "Crea snapshot"
 ],
 "Create snapshot and mount": [
  null,
  "Crea snapshot e monta"
 ],
 "Create snapshot only": [
  null,
  "Crea soltanto lo snapshot"
 ],
 "Create storage device": [
  null,
  "Crea dispositivo di archiviazione"
 ],
 "Create subvolume": [
  null,
  "Crea sottovolume"
 ],
 "Create thin volume": [
  null,
  "Crea volume thin"
 ],
 "Create volume group": [
  null,
  "Crea gruppo di volumi"
 ],
 "Creating LVM2 volume group $target": [
  null,
  "Creazione di un gruppo di volumi LVM2 $target"
 ],
 "Creating MDRAID device $target": [
  null,
  "Creazione del dispositivo MDRAID $target"
 ],
 "Creating VDO device": [
  null,
  "Creazione del dispositivo VDO"
 ],
 "Creating filesystem on $target": [
  null,
  "Creazione del filesystem su $target"
 ],
 "Creating logical volume $target": [
  null,
  "Creazione di un volume logico $target"
 ],
 "Creating partition $target": [
  null,
  "Creazione della partizione $target"
 ],
 "Creating snapshot of $target": [
  null,
  "Creazione di uno snapshot di $target"
 ],
 "Ctrl+Insert": [
  null,
  "Ctrl+Insert"
 ],
 "Currently in use": [
  null,
  "Attualmente in uso"
 ],
 "Custom": [
  null,
  "Personalizzato"
 ],
 "Custom mount options": [
  null,
  "Opzioni di montaggio personalizzate"
 ],
 "Custom type": [
  null,
  "Tipo personalizzato"
 ],
 "Data": [
  null,
  "Dati"
 ],
 "Data used": [
  null,
  "Dati utilizzati"
 ],
 "Data will be stored as two copies and also in an alternating fashion on the selected physical volumes, to improve both reliability and performance. At least four volumes need to be selected.": [
  null,
  "I dati verranno archiviati in due copie e anche in modo alternato sui volumi fisici selezionati, per migliorare sia l'affidabilità che le prestazioni. È necessario selezionare almeno quattro volumi."
 ],
 "Data will be stored as two or more copies on the selected physical volumes, to improve reliability. At least two volumes need to be selected.": [
  null,
  "I dati verranno archiviati in due o più copie sui volumi fisici selezionati, per migliorare l'affidabilità. È necessario selezionare almeno due volumi."
 ],
 "Data will be stored on the selected physical volumes in an alternating fashion to improve performance. At least two volumes need to be selected.": [
  null,
  "I dati verranno archiviati sui volumi fisici selezionati in modo alternato per migliorare le prestazioni. È necessario selezionare almeno due volumi."
 ],
 "Data will be stored on the selected physical volumes so that one of them can be lost without affecting the data. At least three volumes need to be selected.": [
  null,
  "I dati verranno archiviati sui volumi fisici selezionati in modo che uno di essi possa andare perso senza influire sui dati. È necessario selezionare almeno tre volumi."
 ],
 "Data will be stored on the selected physical volumes so that one of them can be lost without affecting the data. Data is also stored in an alternating fashion to improve performance. At least three volumes need to be selected.": [
  null,
  "I dati verranno archiviati sui volumi fisici selezionati in modo che uno di essi possa andare perso senza influire sui dati. I dati vengono inoltre archiviati in modo alternato per migliorare le prestazioni. È necessario selezionare almeno tre volumi."
 ],
 "Data will be stored on the selected physical volumes so that up to two of them can be lost at the same time without affecting the data. Data is also stored in an alternating fashion to improve performance. At least five volumes need to be selected.": [
  null,
  "I dati verranno archiviati sui volumi fisici selezionati in modo che fino a due di essi possano andare persi contemporaneamente senza influire sui dati. I dati vengono inoltre archiviati in modo alternato per migliorare le prestazioni. È necessario selezionare almeno cinque volumi."
 ],
 "Data will be stored on the selected physical volumes without any additional redundancy or performance improvements.": [
  null,
  "I dati verranno archiviati sui volumi fisici selezionati senza alcuna ridondanza aggiuntiva o miglioramenti delle prestazioni."
 ],
 "Deactivate": [
  null,
  "Disattiva"
 ],
 "Deactivate logical volume $0/$1?": [
  null,
  "Disattivare il volume logico $0/$1?"
 ],
 "Deactivating $target": [
  null,
  "Disattivazione $target"
 ],
 "Dedicated parity (RAID 4)": [
  null,
  "Parità dedicata (RAID 4)"
 ],
 "Deduplication": [
  null,
  "Deduplicazione"
 ],
 "Degraded": [
  null,
  ""
 ],
 "Delay": [
  null,
  "Ritardo"
 ],
 "Delete": [
  null,
  "Cancella"
 ],
 "Delete group": [
  null,
  "Elimina gruppo"
 ],
 "Delete pool": [
  null,
  "Elimina pool"
 ],
 "Deleting $target": [
  null,
  "Eliminazione $target"
 ],
 "Deleting LVM2 volume group $target": [
  null,
  "Eliminazione del gruppo di volumi LVM2 $target"
 ],
 "Deleting a Stratis pool will erase all data it contains.": [
  null,
  "L'eliminazione di un pool Stratis cancellerà tutti i dati in esso contenuti."
 ],
 "Deleting a filesystem will delete all data in it.": [
  null,
  "L'eliminazione di un filesystem cancellerà tutti i dati in esso contenuti."
 ],
 "Deleting a logical volume will delete all data in it.": [
  null,
  "L'eliminazione di un volume logico cancellerà tutti i dati in esso contenuti."
 ],
 "Deleting a partition will delete all data in it.": [
  null,
  "L'eliminazione di una partizione cancellerà tutti i dati in essa contenuti."
 ],
 "Deleting erases all data on a MDRAID device.": [
  null,
  "L'eliminazione cancella tutti i dati su un dispositivo MDRAID."
 ],
 "Deleting erases all data on a VDO device.": [
  null,
  "L'eliminazione cancella tutti i dati su un dispositivo VDO."
 ],
 "Deleting erases all data on a volume group.": [
  null,
  "L'eliminazione cancella tutti i dati su un gruppo di volumi."
 ],
 "Deleting erases all data on this subvolume and all it's children.": [
  null,
  "L'eliminazione cancella tutti i dati su questo sottovolume e tutti i suoi figli."
 ],
 "Description": [
  null,
  "Descrizione"
 ],
 "Desktop": [
  null,
  "Desktop"
 ],
 "Detachable": [
  null,
  "Rimovibile"
 ],
 "Device": [
  null,
  "Dispositivo"
 ],
 "Device contains unrecognized data": [
  null,
  "Il dispositivo contiene dati non riconosciuti"
 ],
 "Device file": [
  null,
  "File dispositivo"
 ],
 "Device health (SMART)": [
  null,
  ""
 ],
 "Device is read-only": [
  null,
  "Il dispositivo è in sola lettura"
 ],
 "Device number": [
  null,
  "Numero del dispositivo"
 ],
 "Diagnostic reports": [
  null,
  "Rapporti diagnostici"
 ],
 "Did not complete": [
  null,
  ""
 ],
 "Disconnect": [
  null,
  "Disconnetti"
 ],
 "Disk is OK": [
  null,
  "Il disco è OK"
 ],
 "Disk is failing": [
  null,
  "Disco non funzionante"
 ],
 "Disk passphrase": [
  null,
  "Frase di accesso del disco"
 ],
 "Disks": [
  null,
  "Dischi"
 ],
 "Dismiss": [
  null,
  "Scarta"
 ],
 "Distributed parity (RAID 5)": [
  null,
  "Parità distribuita (RAID 5)"
 ],
 "Do not mount": [
  null,
  "Non montare"
 ],
 "Do not mount automatically on boot": [
  null,
  "Non montare automaticamente all'avvio"
 ],
 "Docking station": [
  null,
  "Stazione di docking"
 ],
 "Does not mount during boot": [
  null,
  "Non montare durante il boot"
 ],
 "Double distributed parity (RAID 6)": [
  null,
  "Doppia parità distribuita (RAID 6)"
 ],
 "Downloading $0": [
  null,
  "Download di $0"
 ],
 "Drive": [
  null,
  "Unità"
 ],
 "Dual rank": [
  null,
  "Dual rank"
 ],
 "EFI system partition": [
  null,
  "Partizione di sistema EFI"
 ],
 "Edit": [
  null,
  "Modifica"
 ],
 "Edit Tang keyserver": [
  null,
  "Modifica Tang keyserver"
 ],
 "Edit mount point": [
  null,
  "Modifica punto di montaggio"
 ],
 "Editing a key requires a free slot": [
  null,
  "La modifica di una chiave richiede uno slot libero"
 ],
 "Ejecting $target": [
  null,
  "Espulsione $target"
 ],
 "Embedded PC": [
  null,
  "PC integrato"
 ],
 "Emptying $target": [
  null,
  "Svuotamento $target"
 ],
 "Enabling $0": [
  null,
  "Abilitazione di $0"
 ],
 "Encrypt data with a Tang keyserver": [
  null,
  "Crittografa i dati con un keyserver Tang"
 ],
 "Encrypt data with a passphrase": [
  null,
  "Crittografare i dati con una passphrase"
 ],
 "Encrypted $0": [
  null,
  "$0 crittografato"
 ],
 "Encrypted Stratis pool": [
  null,
  "Pool Stratis crittografato"
 ],
 "Encrypted logical volume of $0": [
  null,
  "Volume logico criptato di $0"
 ],
 "Encrypted partition of $0": [
  null,
  "Partizione criptata di $0"
 ],
 "Encryption": [
  null,
  "Cifratura"
 ],
 "Encryption options": [
  null,
  "Opzioni di cifratura"
 ],
 "Encryption type": [
  null,
  "Tipo di crittografia"
 ],
 "Erasing $target": [
  null,
  "Cancellazione $target"
 ],
 "Error": [
  null,
  "Errore"
 ],
 "Error installing $0: PackageKit is not installed": [
  null,
  "Errore nell'installazione di $0: PackageKit non è installato"
 ],
 "Exactly $0 physical volumes must be selected": [
  null,
  "È necessario selezionare esattamente volumi fisici da $0"
 ],
 "Exactly $0 physical volumes need to be selected, one for each stripe of the logical volume.": [
  null,
  "È necessario selezionare esattamente volumi fisici da $0, uno per ogni stripe del volume logico."
 ],
 "Excellent password": [
  null,
  "Password eccellente"
 ],
 "Expansion chassis": [
  null,
  "Chassis di espansione"
 ],
 "Extended partition": [
  null,
  "Partizione estesa"
 ],
 "Failed": [
  null,
  "Fallito"
 ],
 "Failed (Damaged)": [
  null,
  ""
 ],
 "Failed (Electrical)": [
  null,
  ""
 ],
 "Failed to change password": [
  null,
  "Impossibile cambiare la password"
 ],
 "Failed to enable $0 in firewalld": [
  null,
  "Impossibile abilitare firewalld"
 ],
 "Filesystem": [
  null,
  "File system"
 ],
 "Filesystem is locked": [
  null,
  "Il filesystem è bloccato"
 ],
 "Filesystem is mounted read-only": [
  null,
  "Il filesystem è montato in sola lettura"
 ],
 "Filesystem name": [
  null,
  "Nome del file system"
 ],
 "Filesystem outside the target": [
  null,
  "File system esterno alla destinazione"
 ],
 "Filesystems are already mounted below this mountpoint.": [
  null,
  "I filesystem sono già montati sotto questo punto di montaggio."
 ],
 "Firmware version": [
  null,
  "Versione del firmware"
 ],
 "Fix NBDE support": [
  null,
  "Fix supporto NBDE"
 ],
 "Format": [
  null,
  "Formatta"
 ],
 "Format $0": [
  null,
  "Formatta $0"
 ],
 "Format and mount": [
  null,
  "Formatta e monta"
 ],
 "Format and start": [
  null,
  "Formatta e avvia"
 ],
 "Format only": [
  null,
  "Formatta soltanto"
 ],
 "Formatting erases all data on a storage device.": [
  null,
  "La formattazione cancellerà tutti i dati contenuti in un dispositivo di memoria."
 ],
 "Free space": [
  null,
  "Spazio libero"
 ],
 "Go to now": [
  null,
  "Vai ora"
 ],
 "Grow": [
  null,
  "Espandi"
 ],
 "Grow content": [
  null,
  "Espandi Contenuto"
 ],
 "Grow logical size of $0": [
  null,
  "Espandi le dimensioni logiche di $0"
 ],
 "Grow logical volume": [
  null,
  "Espandi il volume logico"
 ],
 "Grow partition": [
  null,
  "Aumenta la partizione"
 ],
 "Grow the pool to take all space": [
  null,
  "Fai crescere il pool per occupare tutto lo spazio"
 ],
 "Grow to take all space": [
  null,
  "Espandi per occupare tutto lo spazio"
 ],
 "Handheld": [
  null,
  "Palmare"
 ],
 "Hard Disk Drive": [
  null,
  "Unità disco rigido"
 ],
 "Hide confirmation password": [
  null,
  "Nascondi la password di conferma"
 ],
 "Hide password": [
  null,
  "Nascondi la password"
 ],
 "Host key is incorrect": [
  null,
  "La chiave host non è corretta"
 ],
 "How to check": [
  null,
  "Come controllare"
 ],
 "I confirm I want to lose this data forever": [
  null,
  "Confermo di voler perdere questi dati per sempre"
 ],
 "ID": [
  null,
  "ID"
 ],
 "INTERNAL ERROR - This logical volume is marked as active and should have an associated block device. However, no such block device could be found.": [
  null,
  "ERRORE INTERNO: questo volume logico è contrassegnato come attivo e dovrebbe avere un dispositivo a blocchi associato. Tuttavia non è stato trovato alcun dispositivo a blocchi di questo tipo."
 ],
 "If the fingerprint matches, click 'Trust and add host'. Otherwise, do not connect and contact your administrator.": [
  null,
  "Se l'impronta digitale corrisponde, fai clic su \"Affida e aggiungi host\". Altrimenti non connetterti e contatta il tuo amministratore."
 ],
 "Important data might be deleted:": [
  null,
  "I dati importanti potrebbero essere eliminati:"
 ],
 "In a terminal, run: ": [
  null,
  "Nel terminale, esegui: "
 ],
 "In sync": [
  null,
  "In sincronizzazione"
 ],
 "Inactive logical volume": [
  null,
  "Volume logico inattivo"
 ],
 "Inconsistent filesystem mount": [
  null,
  "Montaggio del filesystem incoerente"
 ],
 "Index memory": [
  null,
  "Memoria indice"
 ],
 "Initialize": [
  null,
  "Inizializzare"
 ],
 "Initialize disk $0": [
  null,
  "Inizializza il disco $0"
 ],
 "Initializing erases all data on a disk.": [
  null,
  "L'inizializzazione cancella tutti i dati su un disco."
 ],
 "Install": [
  null,
  "Installa"
 ],
 "Install NFS support": [
  null,
  "Installa il supporto NFS"
 ],
 "Install Stratis support": [
  null,
  "Installa il supporto Stratis"
 ],
 "Install software": [
  null,
  "Installa il software"
 ],
 "Installing $0": [
  null,
  "Installazione di $0"
 ],
 "Installing $0 would remove $1.": [
  null,
  "L'installazione di $0 rimuoverebbe $1."
 ],
 "Installing packages": [
  null,
  "Installazione pacchetti"
 ],
 "Internal error": [
  null,
  "Errore interno"
 ],
 "Invalid date format": [
  null,
  "Formato data non valido"
 ],
 "Invalid date format and invalid time format": [
  null,
  "Formato data non valido e formato ora non valido"
 ],
 "Invalid file permissions": [
  null,
  "Autorizzazioni file non valide"
 ],
 "Invalid time format": [
  null,
  "Formato ora non valido"
 ],
 "Invalid timezone": [
  null,
  "Fuso orario non valido"
 ],
 "Invalid username or password": [
  null,
  "Password o nome utente non valido"
 ],
 "IoT gateway": [
  null,
  "Gateway IoT"
 ],
 "Jobs": [
  null,
  "Lavori"
 ],
 "Kernel dump": [
  null,
  "Kernel dump"
 ],
 "Key password": [
  null,
  "Password della chiave"
 ],
 "Key slots with unknown types can not be edited here": [
  null,
  "Gli slot per chiavi con tipi sconosciuti non possono essere modificati qui"
 ],
 "Key source": [
  null,
  "Fonte chiave"
 ],
 "Keys": [
  null,
  "Chiavi"
 ],
 "Keyserver": [
  null,
  "Key server"
 ],
 "Keyserver address": [
  null,
  "Indirizzo Key server"
 ],
 "Keyserver removal may prevent unlocking $0.": [
  null,
  "La rimozione del key server può impedire lo sblocco di $0."
 ],
 "LVM2 VDO pool": [
  null,
  "Pool VDO LVM2"
 ],
 "LVM2 logical volume": [
  null,
  "Volume logico LVM2"
 ],
 "LVM2 logical volumes": [
  null,
  "Volumi logici LVM2"
 ],
 "LVM2 physical volume": [
  null,
  "Volume fisico LVM2"
 ],
 "LVM2 physical volumes": [
  null,
  "Volumi fisici LVM2"
 ],
 "LVM2 volume group": [
  null,
  "Gruppo di volumi LVM2"
 ],
 "LVM2 volume group $0": [
  null,
  "Gruppo di volumi LVM2 $0"
 ],
 "Label": [
  null,
  "Etichetta"
 ],
 "Laptop": [
  null,
  "Portatile"
 ],
 "Last cannot be removed": [
  null,
  "L'ultimo non può essere rimosso"
 ],
 "Last disk can not be removed": [
  null,
  "L'ultimo disco non può essere rimosso"
 ],
 "Last modified: $0": [
  null,
  "Ultima modifica: $0"
 ],
 "Layout": [
  null,
  "Layout"
 ],
 "Learn more": [
  null,
  "Per saperne di più"
 ],
 "Limit size": [
  null,
  "Limita dimensione"
 ],
 "Limit virtual filesystem size": [
  null,
  "Limita la dimensione del filesystem virtuale"
 ],
 "Linear": [
  null,
  "Lineare"
 ],
 "Linux filesystem data": [
  null,
  "Dati del file system Linux"
 ],
 "Linux swap space": [
  null,
  "Spazio di scambio Linux"
 ],
 "Loading system modifications...": [
  null,
  "Caricamento modifiche del sistema..."
 ],
 "Loading...": [
  null,
  "Caricamento in corso..."
 ],
 "Local mount point": [
  null,
  "Punto di montaggio locale"
 ],
 "Local storage": [
  null,
  "Archiviazione locale"
 ],
 "Location": [
  null,
  "Posizione"
 ],
 "Lock": [
  null,
  "Blocca"
 ],
 "Lock $0?": [
  null,
  "Bloccare $0?"
 ],
 "Locked data": [
  null,
  "Dati bloccati"
 ],
 "Locked encrypted device might contain data": [
  null,
  "Il dispositivo crittografato bloccato potrebbe contenere dati"
 ],
 "Locking $target": [
  null,
  "Blocco $target"
 ],
 "Log in": [
  null,
  "Accedi"
 ],
 "Log in to $0": [
  null,
  "Entra in $0"
 ],
 "Log messages": [
  null,
  "Messaggi di log"
 ],
 "Logical": [
  null,
  "Logico"
 ],
 "Logical Volume Manager partition": [
  null,
  "Partizione del gestore del volume logico"
 ],
 "Logical size": [
  null,
  "Dimensione logica"
 ],
 "Logical volume": [
  null,
  "Volume logico"
 ],
 "Logical volume (snapshot)": [
  null,
  "Volume logico (snapshot)"
 ],
 "Logical volume of $0": [
  null,
  "Volume logico di $0"
 ],
 "Login failed": [
  null,
  "Login fallito"
 ],
 "Low profile desktop": [
  null,
  "Desktop a basso profilo"
 ],
 "Lunch box": [
  null,
  "Lunch box"
 ],
 "MDRAID device": [
  null,
  "Dispositivo MDRAID"
 ],
 "MDRAID device $0": [
  null,
  "Dispositivo MDRAID $0"
 ],
 "MDRAID device is recovering": [
  null,
  "Il dispositivo MDRAID è in fase di ripristino"
 ],
 "MDRAID device must be running": [
  null,
  "Il dispositivo MDRAID deve essere in esecuzione"
 ],
 "MDRAID disk": [
  null,
  "Disco MDRAID"
 ],
 "MDRAID disks": [
  null,
  "Dischi MDRAID"
 ],
 "Main server chassis": [
  null,
  "Chassis del server principale"
 ],
 "Manage storage": [
  null,
  "Gestisci archiviazione"
 ],
 "Manually": [
  null,
  "Manualmente"
 ],
 "Marking $target as faulty": [
  null,
  "Marco $target come difettoso"
 ],
 "Media drive": [
  null,
  "Unità multimediale"
 ],
 "Message to logged in users": [
  null,
  "Messaggio agli utenti autenticati"
 ],
 "Metadata used": [
  null,
  "Metadati utilizzati"
 ],
 "Mini PC": [
  null,
  "Mini PC"
 ],
 "Mini tower": [
  null,
  "Mini tower"
 ],
 "Mirrored (RAID 1)": [
  null,
  "Con mirroring (RAID 1)"
 ],
 "Model": [
  null,
  "Modello"
 ],
 "Modifying $target": [
  null,
  "Modifica $target"
 ],
 "Mount": [
  null,
  "Monta"
 ],
 "Mount after network becomes available, ignore failure": [
  null,
  "Monta dopo che la rete diventa disponibile, ignora il fallimento"
 ],
 "Mount also automatically on boot": [
  null,
  "Monta anche automaticamente all'avvio"
 ],
 "Mount at boot": [
  null,
  "Montaggio all'avvio"
 ],
 "Mount automatically on $0 on boot": [
  null,
  "Monta automaticamente su $0 all'avvio"
 ],
 "Mount before services start": [
  null,
  "Monta prima dell'avvio dei servizi"
 ],
 "Mount configuration": [
  null,
  "Configurazione di montaggio"
 ],
 "Mount filesystem": [
  null,
  "Monta Filesystem"
 ],
 "Mount now": [
  null,
  "Monta ora"
 ],
 "Mount on $0 now": [
  null,
  "Monta ora su $0"
 ],
 "Mount options": [
  null,
  "Opzioni di montaggio"
 ],
 "Mount point": [
  null,
  "Punto di montaggio"
 ],
 "Mount point cannot be empty": [
  null,
  "Il punto di montaggio non può essere vuoto"
 ],
 "Mount point cannot be empty.": [
  null,
  "Il punto di montaggio non può essere vuoto."
 ],
 "Mount point is already used for $0": [
  null,
  "Punto di montaggio già utilizzato per $0"
 ],
 "Mount point must start with \"/\".": [
  null,
  "Il punto di montaggio deve iniziare con \"/\"."
 ],
 "Mount read only": [
  null,
  "Monta in sola lettura"
 ],
 "Mount without waiting, ignore failure": [
  null,
  "Monta senza aspettare, ignora il fallimento"
 ],
 "Mounting $target": [
  null,
  "Monto $target"
 ],
 "Mounts before services start": [
  null,
  "Monta prima dell'avvio dei servizi"
 ],
 "Mounts in parallel with services": [
  null,
  "Monta durante l'avvio dei servizi"
 ],
 "Mounts in parallel with services, but after network is available": [
  null,
  "Monta in parallelo con i servizi, ma dopo che la rete è disponibile"
 ],
 "Multi-system chassis": [
  null,
  "Chassis multisistema"
 ],
 "Multipathed devices": [
  null,
  "Dispositivi con percorsi multipli"
 ],
 "NFS mount": [
  null,
  "Montaggio NFS"
 ],
 "NTP server": [
  null,
  "Server NTP"
 ],
 "Name": [
  null,
  "Nome"
 ],
 "Name can not be empty.": [
  null,
  "Il nome non può essere vuoto."
 ],
 "Name cannot be empty.": [
  null,
  "Il nome non può essere vuoto."
 ],
 "Name cannot be longer than $0 bytes": [
  null,
  "Il nome non può essere più lungo di $0 byte"
 ],
 "Name cannot be longer than $0 characters": [
  null,
  "Il nome non può essere più lungo di $0 caratteri"
 ],
 "Name cannot be longer than 127 characters.": [
  null,
  "Il nome non può essere più lungo di 127 caratteri."
 ],
 "Name cannot be longer than 255 characters.": [
  null,
  "Il nome non può contenere più di 255 caratteri."
 ],
 "Name cannot contain the character '$0'.": [
  null,
  "Il nome non può contenere il carattere '$0''."
 ],
 "Name cannot contain the character '/'.": [
  null,
  "Il nome non può contenere il carattere \"/\"."
 ],
 "Name cannot contain whitespace.": [
  null,
  "Il nome non può contenere spazi bianchi."
 ],
 "Need a spare disk": [
  null,
  "Hai bisogno di un disco di riserva"
 ],
 "Need at least one NTP server": [
  null,
  "E' necessario almeno un server NTP"
 ],
 "Networked storage": [
  null,
  "Archiviazione in rete"
 ],
 "Networking": [
  null,
  "Rete"
 ],
 "New NFS mount": [
  null,
  "Nuovo supporto NFS"
 ],
 "New passphrase": [
  null,
  "Nuova frase di accesso"
 ],
 "New password was not accepted": [
  null,
  "La nuova password non è stata accettata"
 ],
 "Next": [
  null,
  "Avanti"
 ],
 "No available slots": [
  null,
  "Non ci sono slot disponibili"
 ],
 "No block devices are available.": [
  null,
  "Non sono disponibili dispositivi a blocchi."
 ],
 "No block devices found": [
  null,
  "Nessun dispositivo a blocchi trovato"
 ],
 "No delay": [
  null,
  "Nessun ritardo"
 ],
 "No devices found": [
  null,
  "Nessun dispositivo trovato"
 ],
 "No disks are available.": [
  null,
  "Nessun disco disponibile."
 ],
 "No disks found": [
  null,
  "Nessun disco trovato"
 ],
 "No drives found": [
  null,
  "Nessuna unità trovata"
 ],
 "No encryption": [
  null,
  "Nessuna crittografia"
 ],
 "No filesystem": [
  null,
  "Nessun file system"
 ],
 "No filesystems": [
  null,
  "Nessun file system"
 ],
 "No free key slots": [
  null,
  "Nessuno slot libero per le chiavi"
 ],
 "No free space": [
  null,
  "Nessuno spazio libero disponibile"
 ],
 "No free space after this partition": [
  null,
  "Nessuno spazio libero dopo questa partizione"
 ],
 "No keys added": [
  null,
  "Nessuna chiave aggiunta"
 ],
 "No logical volumes": [
  null,
  "Nessun volume logico"
 ],
 "No media inserted": [
  null,
  "Nessun supporto inserito"
 ],
 "No partitioning": [
  null,
  "Nessun partizionamento"
 ],
 "No partitions found": [
  null,
  "Nessuna partizione trovata"
 ],
 "No physical volumes found": [
  null,
  "Nessun volume fisico trovato"
 ],
 "No results found": [
  null,
  "nessun risultato trovato"
 ],
 "No snapshots found": [
  null,
  "Nessuno snapshot trovato"
 ],
 "No storage found": [
  null,
  "Nessun spazio di archiviazione trovato"
 ],
 "No subvolumes": [
  null,
  "Nessun sottovolume"
 ],
 "No such file or directory": [
  null,
  "Nessun file o directory"
 ],
 "No system modifications": [
  null,
  "Nessuna modifica di sistema"
 ],
 "Not a valid private key": [
  null,
  "Chiave privata invalida"
 ],
 "Not enough free space": [
  null,
  "Spazio libero insufficiente"
 ],
 "Not enough space": [
  null,
  "Spazio insufficiente"
 ],
 "Not enough space to grow": [
  null,
  "Spazio insufficiente per crescere"
 ],
 "Not found": [
  null,
  "Non trovato"
 ],
 "Not permitted to perform this action.": [
  null,
  "Non è consentito eseguire questa azione."
 ],
 "Not running": [
  null,
  "Non in esecuzione"
 ],
 "Not synchronized": [
  null,
  "Non sincronizzato"
 ],
 "Notebook": [
  null,
  "Portatile"
 ],
 "Number of bad sectors": [
  null,
  ""
 ],
 "Occurrences": [
  null,
  "Occorrenze"
 ],
 "Ok": [
  null,
  "Ok"
 ],
 "Old passphrase": [
  null,
  "Vecchia frase di accesso"
 ],
 "Old password not accepted": [
  null,
  "Vecchia password non accettata"
 ],
 "Once Cockpit is installed, enable it with \"systemctl enable --now cockpit.socket\".": [
  null,
  "Una volta installato Cockpit, abilitarlo con \"systemctl enable --now cockpit.socket\"."
 ],
 "Only $0 of $1 are used.": [
  null,
  "Solo $0 di $1 sono utilizzati."
 ],
 "Operation '$operation' on $target": [
  null,
  "Operazione '$operation' su $target"
 ],
 "Options": [
  null,
  "Opzioni"
 ],
 "Other": [
  null,
  "Altro"
 ],
 "Overprovisioning": [
  null,
  "Provisioning eccessivo"
 ],
 "Overwrite": [
  null,
  "Sovrascrivere"
 ],
 "Overwrite existing data with zeros (slower)": [
  null,
  "Sovrascrivere i dati esistenti con zeri (lento)"
 ],
 "PID": [
  null,
  "PID"
 ],
 "PackageKit crashed": [
  null,
  "PackageKit si è interrotto"
 ],
 "Partition": [
  null,
  "Partizione"
 ],
 "Partition of $0": [
  null,
  "Partizione di $0"
 ],
 "Partition size is $0. Content size is $1.": [
  null,
  "La dimensione della partizione è $ 0. La dimensione del contenuto è $ 1."
 ],
 "Partitioning": [
  null,
  "Partizionamento"
 ],
 "Partitions": [
  null,
  "Partizioni"
 ],
 "Passphrase": [
  null,
  "Frase di accesso"
 ],
 "Passphrase can not be empty": [
  null,
  "La frase di accesso non può essere vuota"
 ],
 "Passphrase cannot be empty": [
  null,
  "La frase di accesso non può essere vuota"
 ],
 "Passphrase from any other key slot": [
  null,
  "Passphrase da qualsiasi altro slot per chiavi"
 ],
 "Passphrase removal may prevent unlocking $0.": [
  null,
  "La rimozione della frase di accesso può impedire lo sblocco $0."
 ],
 "Passphrases do not match": [
  null,
  "Le frasi di accesso non corrispondono"
 ],
 "Password": [
  null,
  "Password"
 ],
 "Password is not acceptable": [
  null,
  "La password non è accettabile"
 ],
 "Password is too weak": [
  null,
  "La password è troppo debole"
 ],
 "Password not accepted": [
  null,
  "Password non accettata"
 ],
 "Paste": [
  null,
  "Incolla"
 ],
 "Paste error": [
  null,
  "Incolla errore"
 ],
 "Path on server": [
  null,
  "Percorso su server"
 ],
 "Path on server cannot be empty.": [
  null,
  "Il percorso sul server non può essere vuoto."
 ],
 "Path on server must start with \"/\".": [
  null,
  "Il percorso sul server deve iniziare con \"/\"."
 ],
 "Path to file": [
  null,
  "Percorso del file"
 ],
 "Peripheral chassis": [
  null,
  "Chassis periferico"
 ],
 "Permanently delete $0?": [
  null,
  "Eliminare definitivamente $0?"
 ],
 "Permanently delete logical volume $0/$1?": [
  null,
  "Eliminare definitivamente il volume logico $0/$1?"
 ],
 "Permanently delete subvolume $0?": [
  null,
  "Eliminare definitivamente il sottovolume $0?"
 ],
 "Physical": [
  null,
  "Fisico"
 ],
 "Physical volumes": [
  null,
  "Volumi fisici"
 ],
 "Physical volumes can not be resized here": [
  null,
  "I volumi fisici non possono essere ridimensionati qui"
 ],
 "Pick date": [
  null,
  "Scegli una data"
 ],
 "Pizza box": [
  null,
  "Pizza box"
 ],
 "Please unmount them first.": [
  null,
  "Per favore smontali prima."
 ],
 "Pool for thin logical volumes": [
  null,
  "Pool per volumi logici thin"
 ],
 "Pool for thinly provisioned LVM2 logical volumes": [
  null,
  "Pool per volumi logici LVM2 con thin provisioning"
 ],
 "Pool for thinly provisioned volumes": [
  null,
  "Pool per volumi con thin provisioning"
 ],
 "Pool passphrase": [
  null,
  "Passphrase del pool"
 ],
 "Port": [
  null,
  "Porta"
 ],
 "Portable": [
  null,
  "Portatile"
 ],
 "Power on hours": [
  null,
  ""
 ],
 "PowerPC PReP boot partition": [
  null,
  "Partizione di avvio PReP di PowerPC"
 ],
 "Present": [
  null,
  "Presente"
 ],
 "Processes using the location": [
  null,
  "Elabora utilizzando la posizione"
 ],
 "Prompting via ssh-add timed out": [
  null,
  "Richiesta tramite ssh-add scaduta"
 ],
 "Prompting via ssh-keygen timed out": [
  null,
  "Richiesta tramite ssh-keygen scaduta"
 ],
 "Provide the passphrase for the pool on these block devices:": [
  null,
  "Fornisci la passphrase per il pool su questi dispositivi a blocchi:"
 ],
 "Purpose": [
  null,
  "Scopo"
 ],
 "RAID ($0)": [
  null,
  "RAID ($0)"
 ],
 "RAID 0": [
  null,
  "RAID 0"
 ],
 "RAID 0 (stripe)": [
  null,
  "RAID 0 (stripe)"
 ],
 "RAID 1": [
  null,
  "RAID 1"
 ],
 "RAID 1 (mirror)": [
  null,
  "RAID 1 (mirror)"
 ],
 "RAID 10": [
  null,
  "RAID 10"
 ],
 "RAID 10 (stripe of mirrors)": [
  null,
  "RAID 10 (stripe di mirror)"
 ],
 "RAID 4": [
  null,
  "RAID 4"
 ],
 "RAID 4 (dedicated parity)": [
  null,
  "RAID 4 (parità dedicata)"
 ],
 "RAID 5": [
  null,
  "RAID 5"
 ],
 "RAID 5 (distributed parity)": [
  null,
  "RAID 5 (parità distribuita)"
 ],
 "RAID 6": [
  null,
  "RAID 6"
 ],
 "RAID 6 (double distributed parity)": [
  null,
  "RAID 6 (doppia parità distribuita)"
 ],
 "RAID chassis": [
  null,
  "Chassis RAID"
 ],
 "RAID level": [
  null,
  "Livello RAID"
 ],
 "RAID10 needs an even number of physical volumes": [
  null,
  "RAID10 necessita di un numero pari di volumi fisici"
 ],
 "Rack mount chassis": [
  null,
  "Chassis a rack"
 ],
 "Reading": [
  null,
  "Lettura"
 ],
 "Reboot": [
  null,
  "Riavvia"
 ],
 "Recovering": [
  null,
  "Recupero"
 ],
 "Recovering MDRAID device $target": [
  null,
  "Ripristino del dispositivo MDRAID $target"
 ],
 "Regenerating initrd": [
  null,
  "rigenerazione del initrd"
 ],
 "Related processes and services will be forcefully stopped.": [
  null,
  "I processi e i servizi correlati verranno interrotti forzatamente."
 ],
 "Related processes will be forcefully stopped.": [
  null,
  "I processi correlati verranno interrotti forzatamente."
 ],
 "Related services will be forcefully stopped.": [
  null,
  "I servizi correlati verranno interrotti forzatamente."
 ],
 "Removals:": [
  null,
  "Rimozioni:"
 ],
 "Remove": [
  null,
  "Elimina"
 ],
 "Remove $0?": [
  null,
  "Rimuovere $0?"
 ],
 "Remove Tang keyserver?": [
  null,
  "Rimuovere keyserver Tang?"
 ],
 "Remove device": [
  null,
  "Rimuovere il dispositivo"
 ],
 "Remove missing physical volumes?": [
  null,
  "Rimuovere i volumi fisici mancanti?"
 ],
 "Remove passphrase in key slot $0?": [
  null,
  "Rimuovere la frase di accesso in slot $0?"
 ],
 "Remove passphrase?": [
  null,
  "Rimuovere la passphrase?"
 ],
 "Removing $0": [
  null,
  "Rimozione $0"
 ],
 "Removing $target from MDRAID device": [
  null,
  "Rimozione di $target dal dispositivo MDRAID"
 ],
 "Removing a passphrase without confirmation of another passphrase may prevent unlocking or key management, if other passphrases are forgotten or lost.": [
  null,
  "La rimozione di una passphrase senza la conferma di un'altra passphrase può impedire lo sblocco o la gestione delle chiavi, se altre passphrase vengono dimenticate o perse."
 ],
 "Removing physical volume from $target": [
  null,
  "Rimozione del volume fisico da $target"
 ],
 "Rename": [
  null,
  "Rinomina"
 ],
 "Rename Stratis pool": [
  null,
  "Rinomina il pool Stratis"
 ],
 "Rename filesystem": [
  null,
  "Rinominare file system"
 ],
 "Rename logical volume": [
  null,
  "Rinomina il volume logico"
 ],
 "Rename volume group": [
  null,
  "Rinomina gruppo di volumi"
 ],
 "Renaming $target": [
  null,
  "Rinomino $target"
 ],
 "Repair": [
  null,
  "Ripara"
 ],
 "Repair logical volume $0": [
  null,
  "Riparare il volume logico $0"
 ],
 "Repairing $target": [
  null,
  "Riparazione $target"
 ],
 "Repeat passphrase": [
  null,
  "Ripeti la frase di accesso"
 ],
 "Resizing $target": [
  null,
  "Ridimensionamento $target"
 ],
 "Resizing an encrypted filesystem requires unlocking the disk. Please provide a current disk passphrase.": [
  null,
  "Il ridimensionamento di un file system crittografato richiede lo sblocco del disco. Fornire la frase di accesso corrente del disco."
 ],
 "Reuse existing encryption": [
  null,
  "Riutilizza la crittografia esistente"
 ],
 "Reuse existing encryption ($0)": [
  null,
  "Riutilizza la crittografia esistente ($0)"
 ],
 "Row expansion": [
  null,
  "Espansione delle righe"
 ],
 "Row select": [
  null,
  "Seleziona riga"
 ],
 "Run extended test": [
  null,
  ""
 ],
 "Run this command over a trusted network or physically on the remote machine:": [
  null,
  "Esegui questo comando su una rete affidabile o fisicamente sul computer remoto:"
 ],
 "Running": [
  null,
  "In esecuzione"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "SHA-1": [
  null,
  "SHA-1"
 ],
 "SHA-256": [
  null,
  "SHA-256"
 ],
 "SMART self-test of $target": [
  null,
  "Autotest SMART di $target"
 ],
 "SSH key": [
  null,
  "Chiave SSH"
 ],
 "SSH key login": [
  null,
  "Accesso tramite chiave SSH"
 ],
 "Save": [
  null,
  "Salva"
 ],
 "Save space by compressing individual blocks with LZ4": [
  null,
  "Risparmia spazio comprimendo i singoli blocchi con LZ4"
 ],
 "Save space by storing identical data blocks just once": [
  null,
  "Risparmia spazio memorizzando blocchi di dati identici una sola volta"
 ],
 "Saving a new passphrase requires unlocking the disk. Please provide a current disk passphrase.": [
  null,
  "Per salvare una nuova frase di accesso è necessario sbloccare il disco. Fornire una frase di accesso attuale del disco."
 ],
 "Sealed-case PC": [
  null,
  "PC sigillato"
 ],
 "Securely erasing $target": [
  null,
  "Cancellazione sicura di $target"
 ],
 "Security Enhanced Linux configuration and troubleshooting": [
  null,
  "Configurazione e risoluzione dei problemi di Security Enhanced Linux"
 ],
 "Select an option": [
  null,
  "Seleziona un'opzione"
 ],
 "Select the physical volumes that should be used to repair the logical volume. At least $0 are needed.": [
  null,
  "Selezionare i volumi fisici da utilizzare per riparare il volume logico. Sono necessari almeno $0."
 ],
 "Server": [
  null,
  "Server"
 ],
 "Server address": [
  null,
  "Indirizzo del server"
 ],
 "Server address cannot be empty.": [
  null,
  "L'indirizzo del server non può essere vuoto."
 ],
 "Server cannot be empty.": [
  null,
  "Il server non può essere vuoto."
 ],
 "Server has closed the connection.": [
  null,
  "Il server ha chiuso la connessione."
 ],
 "Service": [
  null,
  "Servizio"
 ],
 "Services using the location": [
  null,
  "Servizi che utilizzano la posizione"
 ],
 "Set": [
  null,
  "Imposta"
 ],
 "Set initial size": [
  null,
  "Imposta la dimensione iniziale"
 ],
 "Set limit of virtual filesystem size": [
  null,
  "Imposta il limite della dimensione del filesystem virtuale"
 ],
 "Set partition type of $0": [
  null,
  "Imposta il tipo di partizione su $0"
 ],
 "Set time": [
  null,
  "Imposta tempo"
 ],
 "Setting up loop device $target": [
  null,
  "Impostazione del dispositivo di loop $target"
 ],
 "Shell script": [
  null,
  "Script di shell"
 ],
 "Shift+Insert": [
  null,
  "Shift+Insert"
 ],
 "Show all $0 rows": [
  null,
  "Mostra tutte le righe $0"
 ],
 "Show confirmation password": [
  null,
  "Mostra password di conferma"
 ],
 "Show password": [
  null,
  "Mostra password"
 ],
 "Shrink": [
  null,
  "Riduci"
 ],
 "Shrink logical volume": [
  null,
  "Restringi il volume logico"
 ],
 "Shrink partition": [
  null,
  "Riduci la partizione"
 ],
 "Shrink volume": [
  null,
  "Riduci il Volume"
 ],
 "Shut down": [
  null,
  "Arresta"
 ],
 "Single rank": [
  null,
  "Single rank"
 ],
 "Size": [
  null,
  "Dimensione"
 ],
 "Size cannot be negative": [
  null,
  "La dimensione non può essere negativa"
 ],
 "Size cannot be zero": [
  null,
  "La dimensione non può essere zero"
 ],
 "Size is too large": [
  null,
  "La dimensione è troppo grande"
 ],
 "Size must be a number": [
  null,
  "La dimensione deve essere un numero"
 ],
 "Size must be at least $0": [
  null,
  "La dimensione deve essere almeno $0"
 ],
 "Slot $0": [
  null,
  "Slot $0"
 ],
 "Snapshot": [
  null,
  "Snapshot"
 ],
 "Snapshot origin": [
  null,
  "Origine dell'istantanea"
 ],
 "Snapshots": [
  null,
  "Istantanee"
 ],
 "Solid State Drive": [
  null,
  "Unità a stato solido"
 ],
 "Some block devices of this pool have grown in size after the pool was created. The pool can be safely grown to use the newly available space.": [
  null,
  "Alcuni dispositivi a blocchi di questo pool sono aumentati di dimensioni dopo la creazione del pool. La piscina può essere ampliata in tutta sicurezza per utilizzare lo spazio appena disponibile."
 ],
 "Sorry": [
  null,
  "Scusa"
 ],
 "Space-saving computer": [
  null,
  "Computer space-saving"
 ],
 "Spare": [
  null,
  "Ricambio"
 ],
 "Spare capacity is below the threshold": [
  null,
  ""
 ],
 "Specific time": [
  null,
  "Tempo specifico"
 ],
 "Start": [
  null,
  "Avvia"
 ],
 "Start multipath": [
  null,
  "Avvia Multipath"
 ],
 "Started": [
  null,
  "Avviato"
 ],
 "Starting MDRAID device $target": [
  null,
  "Avvio del dispositivo MDRAID $target"
 ],
 "Starting swapspace $target": [
  null,
  "Avvio dello spazio di swap $target"
 ],
 "State": [
  null,
  "Stato"
 ],
 "Stick PC": [
  null,
  "Stick PC"
 ],
 "Stop": [
  null,
  "Ferma"
 ],
 "Stop and remove": [
  null,
  "Ferma e rimuovi"
 ],
 "Stop and unmount": [
  null,
  "Ferma e smonta"
 ],
 "Stop device": [
  null,
  "Ferma dispositivo"
 ],
 "Stopping MDRAID device $target": [
  null,
  "Arresto del dispositivo MDRAID $target"
 ],
 "Stopping swapspace $target": [
  null,
  "Arresto dello spazio di swap $target"
 ],
 "Storage": [
  null,
  "Archiviazione"
 ],
 "Storage can not be managed on this system.": [
  null,
  "L'archiviazione non può essere gestita su questo sistema."
 ],
 "Storage logs": [
  null,
  "Log archiviazione"
 ],
 "Store passphrase": [
  null,
  "Conserva la frase di accesso"
 ],
 "Stored passphrase": [
  null,
  "Frase di accesso memorizzata"
 ],
 "Stratis block device": [
  null,
  "Dispositivo a blocchi Stratis"
 ],
 "Stratis block devices": [
  null,
  "Dispositivi a blocchi Stratis"
 ],
 "Stratis blockdevs can not be made smaller": [
  null,
  "Gli sviluppatori di blocchi Stratis non possono essere ridotti"
 ],
 "Stratis filesystem": [
  null,
  "Livelli del file system"
 ],
 "Stratis filesystems": [
  null,
  "Stratis filesystems"
 ],
 "Stratis filesystems pool": [
  null,
  "Pool di filesystem Stratis"
 ],
 "Stratis pool": [
  null,
  "Pool Stratis"
 ],
 "Striped (RAID 0)": [
  null,
  ""
 ],
 "Striped and mirrored (RAID 10)": [
  null,
  ""
 ],
 "Stripes": [
  null,
  ""
 ],
 "Strong password": [
  null,
  "Password complessa"
 ],
 "Sub-Chassis": [
  null,
  "Sub-Chassis"
 ],
 "Sub-Notebook": [
  null,
  "Sub-Notebook"
 ],
 "Successfully copied to clipboard!": [
  null,
  "Copiato con successo negli appunti!"
 ],
 "Swap": [
  null,
  "Swap"
 ],
 "Swap can not be resized here": [
  null,
  "Lo Swap non può essere ridimensionato qui"
 ],
 "Synchronized": [
  null,
  "Sincronizzato"
 ],
 "Synchronized with $0": [
  null,
  "Sincronizzato con $0"
 ],
 "Synchronizing": [
  null,
  "Sincronizzazione"
 ],
 "Synchronizing MDRAID device $target": [
  null,
  "Sincronizzazione del dispositivo MDRAID $target"
 ],
 "Tablet": [
  null,
  "Tablet"
 ],
 "Tang keyserver": [
  null,
  "Keyserver Tang"
 ],
 "Target": [
  null,
  "Destinazione"
 ],
 "Temperature outside of recommended thresholds": [
  null,
  ""
 ],
 "The $0 package is not available from any repository.": [
  null,
  "Il pacchetto $0 non è disponibile da nessun repository."
 ],
 "The $0 package must be installed to create Stratis pools.": [
  null,
  "Per creare pool Stratis è necessario installare il pacchetto $0."
 ],
 "The $0 package must be installed.": [
  null,
  "Il pacchetto $0 deve essere installato."
 ],
 "The $0 package will be installed to create VDO devices.": [
  null,
  "Verrà installato il pacchetto $0 per creare dispositivi VDO."
 ],
 "The creation of this VDO device did not finish and the device can't be used.": [
  null,
  "La creazione di questo dispositivo VDO non è terminata e il dispositivo non può essere utilizzato."
 ],
 "The currently logged in user is not permitted to see information about keys.": [
  null,
  "L'utente attualmente connesso non è autorizzato a vedere le informazioni sulle chiavi."
 ],
 "The disk needs to be unlocked before formatting.  Please provide a existing passphrase.": [
  null,
  "Il disco deve essere sbloccato prima della formattazione. Fornisci una passphrase esistente."
 ],
 "The filesystem has no permanent mount point.": [
  null,
  "Il file system non ha un punto di montaggio permanente."
 ],
 "The filesystem is configured to be automatically mounted on boot but its encryption container will not be unlocked at that time.": [
  null,
  "Il file system è configurato per essere montato automaticamente all'avvio, ma il suo container di crittografia non sarà sbloccato in quel momento."
 ],
 "The filesystem is currently mounted but will not be mounted after the next boot.": [
  null,
  "Il file system è attualmente montato ma non verrà montato al prossimo avvio."
 ],
 "The filesystem is currently mounted on $0 but will be mounted on $1 on the next boot.": [
  null,
  "Il file system è attualmente montato su $0 ma verrà montato su $1 al prossimo avvio."
 ],
 "The filesystem is currently mounted on $0 but will not be mounted after the next boot.": [
  null,
  "Il file system è attualmente montato su $0 ma non verrà montato dopo il prossimo avvio."
 ],
 "The filesystem is currently not mounted but will be mounted on the next boot.": [
  null,
  "Il file system non è attualmente montato ma verrà montato al prossimo avvio."
 ],
 "The filesystem is not mounted.": [
  null,
  "Il file system non è montato."
 ],
 "The filesystem will be unlocked and mounted on the next boot. This might require inputting a passphrase.": [
  null,
  "Il filesystem verrà sbloccato e montato all'avvio successivo. Ciò potrebbe richiedere l'immissione di una passphrase."
 ],
 "The initrd must be regenerated.": [
  null,
  "L'initrd deve essere rigenerato."
 ],
 "The key password can not be empty": [
  null,
  "La password della chiave non può essere vuota"
 ],
 "The key passwords do not match": [
  null,
  "Le password della chiave non corrispondono"
 ],
 "The last key slot can not be removed": [
  null,
  "L'ultimo slot per chiavi non può essere rimosso"
 ],
 "The listed processes and services will be forcefully stopped.": [
  null,
  "I processi e i servizi elencati verranno interrotti forzatamente."
 ],
 "The listed processes will be forcefully stopped.": [
  null,
  "I processi elencati verranno interrotti forzatamente."
 ],
 "The listed services will be forcefully stopped.": [
  null,
  "I servizi elencati verranno interrotti forzatamente."
 ],
 "The logged in user is not permitted to view system modifications": [
  null,
  "L'utente che ha effettuato l'accesso non è autorizzato a visualizzare le modifiche di sistema"
 ],
 "The mount point $0 is in use by these processes:": [
  null,
  "Il punto di montaggio $0 è utilizzato da questi processi:"
 ],
 "The mount point $0 is in use by these services:": [
  null,
  "Il punto di montaggio $0 è utilizzato da questi servizi:"
 ],
 "The resulting fingerprint is fine to share via public methods, including email.": [
  null,
  "L'impronta digitale risultante è idonea per la condivisione pubblica, email inclusa."
 ],
 "The resulting fingerprint is fine to share via public methods, including email. If you are asking someone else to do the verification for you, they can send the results using any method.": [
  null,
  ""
 ],
 "The server refused to authenticate using any supported methods.": [
  null,
  "Il server ha rifiutato di autenticarsi utilizzando qualsiasi metodo supportato."
 ],
 "The system does not currently support unlocking a filesystem with a Tang keyserver during boot.": [
  null,
  "Attualmente il sistema non supporta lo sblocco di un filesystem con un keyserver Tang durante l'avvio."
 ],
 "The system does not currently support unlocking the root filesystem with a Tang keyserver.": [
  null,
  "Attualmente il sistema non supporta lo sblocco del filesystem root con un keyserver Tang."
 ],
 "There are devices with multiple paths on the system, but the multipath service is not running.": [
  null,
  "Ci sono dispositivi con percorsi multipli sul sistema, ma il servizio multipath non è in esecuzione."
 ],
 "There is not enough space available that could be used for a repair. At least $0 are needed on physical volumes that are not already used for this logical volume.": [
  null,
  ""
 ],
 "These additional steps are necessary:": [
  null,
  "Questi passaggi aggiuntivi sono necessari:"
 ],
 "Thin logical volume": [
  null,
  "Volume logico thin"
 ],
 "This MDRAID device has no write-intent bitmap. Such a bitmap can reduce synchronization times significantly.": [
  null,
  ""
 ],
 "This NFS mount is in use and only its options can be changed.": [
  null,
  "Questo supporto NFS è in uso e solo le sue opzioni possono essere modificate."
 ],
 "This VDO device does not use all of its backing device.": [
  null,
  "Questo dispositivo VDO non utilizza tutti i suoi dispositivi di supporto."
 ],
 "This keyserver is the only way to unlock the pool and can not be removed.": [
  null,
  ""
 ],
 "This logical volume has lost some of its physical volumes and can no longer be used. You need to delete it and create a new one to take its place.": [
  null,
  ""
 ],
 "This logical volume has lost some of its physical volumes but has not lost any data yet. You should repair it to restore its original redundancy.": [
  null,
  ""
 ],
 "This logical volume has lost some of its physical volumes but might not have lost any data yet. You might be able to repair it.": [
  null,
  ""
 ],
 "This logical volume is not completely used by its content.": [
  null,
  "Questo volume logico non è completamente utilizzato dal suo contenuto."
 ],
 "This passphrase is the only way to unlock the pool and can not be removed.": [
  null,
  ""
 ],
 "This tool configures the SELinux policy and can help with understanding and resolving policy violations.": [
  null,
  "Questo strumento configura i criteri SELinux e può aiutare a comprendere e risolvere le violazioni dei criteri."
 ],
 "This tool generates an archive of configuration and diagnostic information from the running system. The archive may be stored locally or centrally for recording or tracking purposes or may be sent to technical support representatives, developers or system administrators to assist with technical fault-finding and debugging.": [
  null,
  "Questo strumento genera un archivio di informazioni sulla configurazione e sulla diagnostica del sistema in esecuzione. L'archivio può essere conservato localmente o centralmente per scopi di registrazione o tracciamento oppure può essere inviato ai rappresentanti dell'assistenza tecnica, agli sviluppatori o agli amministratori di sistema per aiutarli nella ricerca di errori e nel debug."
 ],
 "This tool manages local storage, such as filesystems, LVM2 volume groups, and NFS mounts.": [
  null,
  "Questo strumento gestisce lo storage locale, come i filesystem, i gruppi di volumi LVM2 e i mount NFS."
 ],
 "This tool manages networking such as bonds, bridges, teams, VLANs and firewalls using NetworkManager and Firewalld. NetworkManager is incompatible with Ubuntu's default systemd-networkd and Debian's ifupdown scripts.": [
  null,
  "Questo strumento gestisce le reti, come i bond, i bridge, i team, le VLAN e i firewall utilizzando NetworkManager e Firewalld. NetworkManager è incompatibile con gli script systemd-networkd di Ubuntu e ifupdown di Debian."
 ],
 "This volume group is missing some physical volumes.": [
  null,
  ""
 ],
 "Tier": [
  null,
  "Livello"
 ],
 "Time zone": [
  null,
  "Fuso Orario"
 ],
 "To ensure that your connection is not intercepted by a malicious third-party, please verify the host key fingerprint:": [
  null,
  "Per assicurare che la connessione non sia intercettata da un soggetto terzo malelvolo, verifica l'impronta digitale dell'host:"
 ],
 "To verify a fingerprint, run the following on $0 while physically sitting at the machine or through a trusted network:": [
  null,
  "Per verificare un'impronta digitale, esegui su $0 mentre sei fisicamente di fronte alla macchina o attraverso una rete fidata:"
 ],
 "Toggle date picker": [
  null,
  "Attiva/disattiva la selezione della data"
 ],
 "Too much data": [
  null,
  "Troppi dati"
 ],
 "Total size: $0": [
  null,
  "Dimensione totale: $0"
 ],
 "Tower": [
  null,
  "Tower"
 ],
 "Trust key": [
  null,
  "Chiave fidata"
 ],
 "Trying to synchronize with $0": [
  null,
  "Tentativo di sincronizzazione con $0"
 ],
 "Type": [
  null,
  "Tipo"
 ],
 "Type must be of the form NNNNNNNN-NNNN-NNNN-NNNN-NNNNNNNNNNNN.": [
  null,
  ""
 ],
 "Type must contain exactly two hexadecimal characters (0 to 9, A to F).": [
  null,
  ""
 ],
 "UUID": [
  null,
  "UUID"
 ],
 "Unable to reach server": [
  null,
  "Impossibile raggiungere il server"
 ],
 "Unable to remove mount": [
  null,
  "Impossibile rimuovere il supporto"
 ],
 "Unable to unmount filesystem": [
  null,
  "Impossibile smontare il file system"
 ],
 "Unexpected PackageKit error during installation of $0: $1": [
  null,
  "Errore inatteso di PackageKit durante l'installazione di $0: $1"
 ],
 "Unknown": [
  null,
  "Sconosciuto"
 ],
 "Unknown ($0)": [
  null,
  "Sconosciuto ($0)"
 ],
 "Unknown host name": [
  null,
  "Nome host sconosciuto"
 ],
 "Unknown type": [
  null,
  "Tipo sconosciuto"
 ],
 "Unlock": [
  null,
  "Sblocca"
 ],
 "Unlock before resizing": [
  null,
  ""
 ],
 "Unlocking $target": [
  null,
  "Sbloccaggio $target"
 ],
 "Unmount": [
  null,
  "Smonta"
 ],
 "Unmount now": [
  null,
  "Smonta adesso"
 ],
 "Unmounting $target": [
  null,
  "Smontaggio $target"
 ],
 "Unrecognized data": [
  null,
  "Dati non riconosciuti"
 ],
 "Unrecognized data can not be made smaller here.": [
  null,
  "I dati non riconosciuti non possono essere ridotti qui."
 ],
 "Untrusted host": [
  null,
  "Host non fidato"
 ],
 "Usage": [
  null,
  "Utilizzo"
 ],
 "Used": [
  null,
  "Usato"
 ],
 "Useful for mounts that are optional or need interaction (such as passphrases)": [
  null,
  "Utile per i mount che sono opzionali o che necessitano di interazione (come le passphrase)"
 ],
 "User": [
  null,
  "Utente"
 ],
 "Username": [
  null,
  "Nome utente"
 ],
 "VDO backing devices can not be made smaller": [
  null,
  "I dispositivi di supporto VDO non possono essere resi più piccoli"
 ],
 "VDO device $0": [
  null,
  "Dispositivo VDO $0"
 ],
 "VDO filesystem volume (compression/deduplication)": [
  null,
  "Volume del filesystem VDO (compressione/deduplicazione)"
 ],
 "Vendor": [
  null,
  "Rivenditore"
 ],
 "Verify key": [
  null,
  "Verifica la chiave"
 ],
 "Very securely erasing $target": [
  null,
  "Cancellazione molto sicura di $target"
 ],
 "View automation script": [
  null,
  "Visualizza script di automazione"
 ],
 "Virtual filesystem sizes are larger than the pool. Overprovisioning can not be disabled.": [
  null,
  ""
 ],
 "Volatile memory backup failed": [
  null,
  ""
 ],
 "Volume group": [
  null,
  "Gruppo di volumi"
 ],
 "Volume size is $0. Content size is $1.": [
  null,
  "La dimensione del volume è $0. La dimensione del contenuto è $1."
 ],
 "Waiting for other software management operations to finish": [
  null,
  "In attesa che finiscano le altre operazioni di gestione del software"
 ],
 "Web Console for Linux servers": [
  null,
  "Web Console per server Linux"
 ],
 "Write-mostly": [
  null,
  "Write-mostly"
 ],
 "Writing": [
  null,
  "In scrittura"
 ],
 "You are connecting to $0 for the first time.": [
  null,
  "Collegamento a $0 per la prima volta"
 ],
 "Your browser does not allow paste from the context menu. You can use Shift+Insert.": [
  null,
  "Il tuo browser non consente l'incolla dal menu contestuale. Puoi usare Maiusc+Ins."
 ],
 "Your session has been terminated.": [
  null,
  "La tua sessione e' terminata."
 ],
 "Your session has expired. Please log in again.": [
  null,
  "La sessione è scaduta. Effettua di nuovo il login."
 ],
 "[binary data]": [
  null,
  "[dati binari]"
 ],
 "[no data]": [
  null,
  "[nessun dato]"
 ],
 "btrfs subvolume $0 of $1": [
  null,
  ""
 ],
 "device of btrfs volume": [
  null,
  ""
 ],
 "edit": [
  null,
  "modifica"
 ],
 "grow": [
  null,
  "Crescere"
 ],
 "in less than a minute": [
  null,
  ""
 ],
 "less than a minute ago": [
  null,
  ""
 ],
 "mount": [
  null,
  "mount"
 ],
 "none": [
  null,
  "nessuno"
 ],
 "read only": [
  null,
  "sola lettura"
 ],
 "remove from LVM2": [
  null,
  "rimuovere da LVM2"
 ],
 "show less": [
  null,
  "mostra meno"
 ],
 "show more": [
  null,
  "mostra di più"
 ],
 "shrink": [
  null,
  "riduci"
 ],
 "stop": [
  null,
  "ferma"
 ],
 "unknown target": [
  null,
  "destinazione sconosciuta"
 ],
 "unmount": [
  null,
  "smonta"
 ],
 "unpartitioned space on $0": [
  null,
  "spazio non partizionato su $0"
 ],
 "yes": [
  null,
  "si"
 ],
 "format-bytes\u0004bytes": [
  null,
  "byte"
 ]
});
