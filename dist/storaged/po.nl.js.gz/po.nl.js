cockpit.locale({
 "": {
  "plural-forms": (n) => n != 1,
  "language": "nl",
  "language-direction": "ltr"
 },
 "$0 GiB": [
  null,
  "$0 GiB"
 ],
 "$0 can not be made larger": [
  null,
  "$0 kunnen niet uitgebreid worden."
 ],
 "$0 can not be made smaller": [
  null,
  "$0 kunnen niet verkleind worden."
 ],
 "$0 can not be resized": [
  null,
  "De grootte van $0  kan hier niet gewijzigd worden."
 ],
 "$0 can not be resized here": [
  null,
  "De grootte van $0  kan hier niet gewijzigd worden."
 ],
 "$0 chunk size": [
  null,
  "$0 brokgrootte"
 ],
 "$0 data + $1 overhead used of $2 ($3)": [
  null,
  "$0 data + $1 overhead gebruikt van $2 ($3)"
 ],
 "$0 day": [
  null,
  "$0 dag",
  "$0 dagen"
 ],
 "$0 disk is missing": [
  null,
  "$0 schijf ontbreekt",
  "$0 schijven ontbreken"
 ],
 "$0 disks": [
  null,
  "$0 schijven"
 ],
 "$0 exited with code $1": [
  null,
  "$0 verlaten met code $1"
 ],
 "$0 failed": [
  null,
  "$0 mislukte"
 ],
 "$0 hour": [
  null,
  "$0 uur",
  "$0 uren"
 ],
 "$0 hours": [
  null,
  "$0 uren"
 ],
 "$0 is in use": [
  null,
  "$0 is in gebruik"
 ],
 "$0 is not available from any repository.": [
  null,
  "$0 is van geen enkele repository beschikbaar."
 ],
 "$0 key changed": [
  null,
  "$0 sleutel gewijzigd"
 ],
 "$0 killed with signal $1": [
  null,
  "$0 is afgeschoten met signaal $1"
 ],
 "$0 minute": [
  null,
  "$0 minuut",
  "$0 minuten"
 ],
 "$0 month": [
  null,
  "$0 maand",
  "$0 maanden"
 ],
 "$0 partitions": [
  null,
  "$0  partities"
 ],
 "$0 slot remains": [
  null,
  "$0 slot blijft over",
  "$0 slots blijven over"
 ],
 "$0 synchronized": [
  null,
  "$0 gesynchroniseerd"
 ],
 "$0 used of $1 ($2 saved)": [
  null,
  "$0 gebruikt van $1 ($2 opgeslagen)"
 ],
 "$0 used, $1 total": [
  null,
  "$0 gebruikt, $1 totaal"
 ],
 "$0 week": [
  null,
  "$0 week",
  "$0 weken"
 ],
 "$0 will be installed.": [
  null,
  "$0 zal geïnstalleerd worden."
 ],
 "$0 year": [
  null,
  "$0 jaar",
  "$0 jaren"
 ],
 "$name (from $host)": [
  null,
  "$name (van $host)"
 ],
 "(Not part of target)": [
  null,
  "Partitie $(Not part of target) aanmaken"
 ],
 "(recommended)": [
  null,
  "(aanbevolen)"
 ],
 "1 MiB": [
  null,
  "1 MiB"
 ],
 "1 day": [
  null,
  "1 dag"
 ],
 "1 hour": [
  null,
  "1 uur"
 ],
 "1 minute": [
  null,
  "1 minuut"
 ],
 "1 week": [
  null,
  "1 week"
 ],
 "128 KiB": [
  null,
  "128 KiB"
 ],
 "16 KiB": [
  null,
  "16 KiB"
 ],
 "2 MiB": [
  null,
  "2 MiB"
 ],
 "20 minutes": [
  null,
  "20 minuten"
 ],
 "32 KiB": [
  null,
  "32 KiB"
 ],
 "4 KiB": [
  null,
  "4 KiB"
 ],
 "40 minutes": [
  null,
  "40 minuten"
 ],
 "5 minutes": [
  null,
  "5 minuten"
 ],
 "512 KiB": [
  null,
  "512 KiB"
 ],
 "6 hours": [
  null,
  "6 uren"
 ],
 "60 minutes": [
  null,
  "60 minuten"
 ],
 "64 KiB": [
  null,
  "64 KiB"
 ],
 "8 KiB": [
  null,
  "8 KiB"
 ],
 "A compatible version of Cockpit is not installed on $0.": [
  null,
  "Er is geen compatibele versie van Cockpit geïnstalleerd op $0."
 ],
 "A fatal error occurred during the self-test operation": [
  null,
  "Een fatale fout heeft zich voorgedaan tijdens de zelf test"
 ],
 "A filesystem with this name exists already in this pool.": [
  null,
  "Er bestaat al een bestandssysteem met deze naam in deze pool."
 ],
 "A new SSH key at $0 will be created for $1 on $2 and it will be added to the $3 file of $4 on $5.": [
  null,
  "Een nieuwe SSH-sleutel op $0 wordt gemaakt voor $1 op $2 en deze wordt toegevoegd aan het $3-bestand van $4 op $5."
 ],
 "A pool with this name exists already.": [
  null,
  "Er bestaat al een pool met deze naam."
 ],
 "A volume group with missing physical volumes can not be renamed.": [
  null,
  "Een volumegroep met ontbrekende fysieke volumes kan niet worden hernoemd."
 ],
 "Abort test": [
  null,
  "Test stoppen"
 ],
 "Aborted": [
  null,
  "Geannuleerd"
 ],
 "Aborted by a Controller Level Reset": [
  null,
  "Geannuleerd door een Controller Niveau Reset"
 ],
 "Aborted due to a removal of a namespace from the namespace inventory": [
  null,
  "Afgebroken vanwege het verwijderen van een naamruimte uit de naamruimte-inventaris"
 ],
 "Aborted due to a sanitize operation": [
  null,
  "Afgebroken vanwege een ontsmettingsoperatie"
 ],
 "Aborted due to the processing of a Format NVM command": [
  null,
  "Afgebroken vanwege de verwerking van een Format NVM-opdracht"
 ],
 "Aborted for unknown reason": [
  null,
  "Afgebroken vanwege een onbekende reden"
 ],
 "Absent": [
  null,
  "Afwezig"
 ],
 "Acceptable password": [
  null,
  "Acceptabel wachtwoord"
 ],
 "Action": [
  null,
  "Actie"
 ],
 "Actions": [
  null,
  "Acties"
 ],
 "Activate": [
  null,
  "Activeren"
 ],
 "Activate before resizing": [
  null,
  "Activeren vóór het formaat wijzigen"
 ],
 "Activating $target": [
  null,
  "Activeren $target"
 ],
 "Add": [
  null,
  "Toevoegen"
 ],
 "Add $0": [
  null,
  "Toevoegen $0"
 ],
 "Add Network Bound Disk Encryption": [
  null,
  "Voeg netwerkgebonden schijfversleuteling toe"
 ],
 "Add Tang keyserver": [
  null,
  "Voeg Tang sleutelserver toe"
 ],
 "Add a bitmap": [
  null,
  "Voeg een bitmap toe"
 ],
 "Add block devices": [
  null,
  "Voeg blokapparaten toe"
 ],
 "Add disk": [
  null,
  "Schijf toevoegen"
 ],
 "Add disks": [
  null,
  "Schijven toevoegen"
 ],
 "Add iSCSI portal": [
  null,
  "iSCSI-portaal toevoegen"
 ],
 "Add key": [
  null,
  "Sleutel toevoegen"
 ],
 "Add keyserver": [
  null,
  "Voeg sleutelserver toe"
 ],
 "Add passphrase": [
  null,
  "Voeg wachtzin toe"
 ],
 "Add physical volume": [
  null,
  "Fysiek volume toevoegen"
 ],
 "Adding \"$0\" to encryption options": [
  null,
  "\"$0\" toevoegen aan versleutelingsopties"
 ],
 "Adding \"$0\" to filesystem options": [
  null,
  "\"$0\" toevoegen aan bestandssysteemopties"
 ],
 "Adding a keyserver requires unlocking the pool. Please provide the existing pool passphrase.": [
  null,
  "Om een sleutelserver toe te voegen, moet de pool worden ontgrendeld. Geef de bestaande wachtwoordzin voor de pool op."
 ],
 "Adding key": [
  null,
  "Toevoegen sleutel"
 ],
 "Adding physical volume to $target": [
  null,
  "Toevoegen van fysieke volume aan $target"
 ],
 "Adding rd.neednet=1 to kernel command line": [
  null,
  "rd.neednet=1 toevoegen aan kernelcommandoregel"
 ],
 "Additional packages:": [
  null,
  "Extra pakketten:"
 ],
 "Address": [
  null,
  "Adres"
 ],
 "Address cannot be empty": [
  null,
  "Adres mag niet leeg zijn"
 ],
 "Address is not a valid URL": [
  null,
  "Adres is geen geldige URL"
 ],
 "Administration with Cockpit Web Console": [
  null,
  "Beheer met Cockpit Web Console"
 ],
 "Advanced TCA": [
  null,
  "Geavanceerde TCA"
 ],
 "All media is in read-only mode": [
  null,
  "Alle media staan in de alleen-lezen-modus"
 ],
 "All-in-one": [
  null,
  "Alles in een"
 ],
 "Allocated": [
  null,
  "Toegewezen"
 ],
 "Allow overprovisioning": [
  null,
  "Overprovisioning toestaan"
 ],
 "An additional $0 must be selected": [
  null,
  "Er moet een extra $0 worden geselecteerd"
 ],
 "Ansible": [
  null,
  "Ansible"
 ],
 "Ansible roles documentation": [
  null,
  "Ansible rollen documentatie"
 ],
 "Appropriate for critical mounts, such as /var": [
  null,
  "Geschikt voor kritieke koppelingen, zoals /var"
 ],
 "Assessment": [
  null,
  "Beoordeling"
 ],
 "At boot": [
  null,
  "Bij opstarten"
 ],
 "At least $0 disk is needed.": [
  null,
  "Minimaal $0 schijf is noodzakelijk.",
  "Minimaal $0 schijven zijn noodzakelijk."
 ],
 "At least one block device is needed.": [
  null,
  "Minimaal één blokapparaat is noodzakelijk."
 ],
 "At least one disk is needed.": [
  null,
  "Minimaal een schijf is noodzakelijk."
 ],
 "At least one subvolume needs to be mounted": [
  null,
  "Ten minste één sub-volume moet worden gekoppeld"
 ],
 "Attributes failing": [
  null,
  "Attributen falen"
 ],
 "Authentication": [
  null,
  "Authenticatie"
 ],
 "Authentication is required to perform privileged tasks with the Cockpit Web Console": [
  null,
  "Authenticatie is vereist voor het uitvoeren van bevoorrechte taken met de Cockpit Web Console"
 ],
 "Authentication required": [
  null,
  "Authenticatie is vereist"
 ],
 "Authorize SSH key": [
  null,
  "Autoriseer SSH-sleutel"
 ],
 "Automatically using NTP": [
  null,
  "Automatisch gebruik van NTP"
 ],
 "Automatically using additional NTP servers": [
  null,
  "Automatisch gebruik van extra NTP servers"
 ],
 "Automatically using specific NTP servers": [
  null,
  "Automatisch gebruik van specifieke NTP servers"
 ],
 "Automation script": [
  null,
  "Automatiserings-script"
 ],
 "Available targets on $0": [
  null,
  "Beschikbare doelen op $0"
 ],
 "BIOS boot partition": [
  null,
  "BIOS opstart-partitie"
 ],
 "Blade": [
  null,
  "Antenne"
 ],
 "Blade enclosure": [
  null,
  "Antennebehuizing"
 ],
 "Block device": [
  null,
  "Blokapparaat"
 ],
 "Block device for filesystems": [
  null,
  "Blok apparaat voor bestandsystemen"
 ],
 "Block devices": [
  null,
  "Blokapparaten"
 ],
 "Blocked": [
  null,
  "Geblokkeerd"
 ],
 "Boot fails if filesystem does not mount, preventing remote access": [
  null,
  "Opstarten mislukt als het bestandssysteem niet aankoppelt, waardoor toegang op afstand wordt voorkomen"
 ],
 "Boot still succeeds when filesystem does not mount": [
  null,
  "Het opstarten lukt nog steeds als het bestandssysteem niet aankoppelt"
 ],
 "Bus expansion chassis": [
  null,
  "Busuitbreidingschassis"
 ],
 "Cache": [
  null,
  "Cache"
 ],
 "Cancel": [
  null,
  "Annuleren"
 ],
 "Cannot forward login credentials": [
  null,
  "Kan inloggegevens niet doorsturen"
 ],
 "Cannot schedule event in the past": [
  null,
  "Kan evenement niet in het verleden plannen"
 ],
 "Capacity": [
  null,
  "Capaciteit"
 ],
 "Category": [
  null,
  "Categorie"
 ],
 "Change": [
  null,
  "Verandering"
 ],
 "Change iSCSI initiator name": [
  null,
  "Verander naam van de iSCSI-initiator"
 ],
 "Change label": [
  null,
  "Verander label"
 ],
 "Change passphrase": [
  null,
  "Verander wachtzin"
 ],
 "Change system time": [
  null,
  "Verander systeemtijd"
 ],
 "Changed keys are often the result of an operating system reinstallation. However, an unexpected change may indicate a third-party attempt to intercept your connection.": [
  null,
  "Gewijzigde sleutels zijn vaak het resultaat van een herinstallatie van het besturingssysteem. Een onverwachte wijziging kan echter wijzen op een poging van derden om je verbinding te onderscheppen."
 ],
 "Changing partition types might prevent the system from booting.": [
  null,
  "Het wijzigen van partitie type kan ervoor zorgen dat het systeem niet meer opstart."
 ],
 "Check that the SHA-256 or SHA-1 hash from the command matches this dialog.": [
  null,
  "Controleer of de SHA-256- of SHA-1-hash van de opdracht overeenkomt met dit dialoog."
 ],
 "Check the key hash with the Tang server.": [
  null,
  "Controleer de sleutel-hash met de Tang-server."
 ],
 "Checking $target": [
  null,
  "Controleren van $target"
 ],
 "Checking MDRAID device $target": [
  null,
  "Controleren van RAID-apparaat $target"
 ],
 "Checking and repairing MDRAID device $target": [
  null,
  "Controleren en repareren van MDRAID-apparaat $target"
 ],
 "Checking filesystem usage": [
  null,
  "Bestandssysteemgebruik controleren"
 ],
 "Checking for $0 package": [
  null,
  "Controleren op $0 pakket"
 ],
 "Checking for NBDE support in the initrd": [
  null,
  "Controleren op NBDE-ondersteuning in de initrd"
 ],
 "Checking installed software": [
  null,
  "Controleren op geïnstalleerde software"
 ],
 "Chunk size": [
  null,
  "Brok grootte"
 ],
 "Cleaning up for $target": [
  null,
  "Opschonen voor $target"
 ],
 "Clear input value": [
  null,
  "Invoerwaarde wissen"
 ],
 "Cleartext device": [
  null,
  "Cleartext-apparaat"
 ],
 "Close": [
  null,
  "Sluiten"
 ],
 "Cockpit": [
  null,
  "Cockpit"
 ],
 "Cockpit configuration of NetworkManager and Firewalld": [
  null,
  "Cockpit configuratie van NetworkManager en Firewalld"
 ],
 "Cockpit could not contact the given host.": [
  null,
  "Cockpit kon geen contact maken met de opgegeven host."
 ],
 "Cockpit is a server manager that makes it easy to administer your Linux servers via a web browser. Jumping between the terminal and the web tool is no problem. A service started via Cockpit can be stopped via the terminal. Likewise, if an error occurs in the terminal, it can be seen in the Cockpit journal interface.": [
  null,
  "Cockpit is een serverbeheerder waarmee je Linux-servers eenvoudig kunt beheren via een webbrowser. Omschakelen tussen de terminal en het webgereedschap is geen probleem. Een service gestart via Cockpit kan via de terminal worden gestopt. Evenzo, als er een fout optreedt in de terminal, kan deze worden gezien in de Cockpit-logboekinterface."
 ],
 "Cockpit is not compatible with the software on the system.": [
  null,
  "Cockpit is niet compatibel met de software op het systeem."
 ],
 "Cockpit is not installed": [
  null,
  "Cockpit is niet geïnstalleerd"
 ],
 "Cockpit is not installed on the system.": [
  null,
  "Cockpit is niet op het systeem geïnstalleerd."
 ],
 "Cockpit is perfect for new sysadmins, allowing them to easily perform simple tasks such as storage administration, inspecting journals and starting and stopping services. You can monitor and administer several servers at the same time. Just add them with a single click and your machines will look after its buddies.": [
  null,
  "Cockpit is perfect voor nieuwe systeembeheerders, waardoor ze eenvoudig eenvoudige taken kunnen uitvoeren, zoals opslagbeheer, het inspecteren van logboeken en het starten en stoppen van services. Je kunt meerdere servers tegelijkertijd bewaken en beheren. Voeg ze gewoon toe met een enkele klik en je machines zullen voor zijn maatjes zorgen."
 ],
 "Collect and package diagnostic and support data": [
  null,
  "Verzamel en verpak diagnostische en ondersteuningsdata"
 ],
 "Collect kernel crash dumps": [
  null,
  "Verzamel kernelcrashdumps"
 ],
 "Command": [
  null,
  "Commando"
 ],
 "Compact PCI": [
  null,
  "Compact PCI"
 ],
 "Compatible with all systems and devices (MBR)": [
  null,
  "Compatibel met alle systemen en apparaten (MBR)"
 ],
 "Compatible with modern system and hard disks > 2TB (GPT)": [
  null,
  "Verenigbaar met moderne systemen en harde schijven > 2TB (GPT)"
 ],
 "Completed with a segment that failed and the segment that failed is not known": [
  null,
  "Voltooid met een segment dat is mislukt en het segment dat is mislukt is onbekend"
 ],
 "Completed with one or more failed segments": [
  null,
  "Voltooid met één of meer gefaalde segmenten"
 ],
 "Compression": [
  null,
  "Compressie"
 ],
 "Confirm": [
  null,
  "Bevestigen"
 ],
 "Confirm deletion of $0": [
  null,
  "Bevestig het verwijderen van $0"
 ],
 "Confirm key password": [
  null,
  "Bevestig sleutelwachtwoord"
 ],
 "Confirm removal with an alternate passphrase": [
  null,
  "Bevestig verwijderen met een alternatieve wachtzin"
 ],
 "Confirm stopping of $0": [
  null,
  "Bevestig het stoppen van $0"
 ],
 "Connection has timed out.": [
  null,
  "Er is een time-out opgetreden voor de verbinding."
 ],
 "Convertible": [
  null,
  "Converteerbaar"
 ],
 "Copied": [
  null,
  "Gekopieerd"
 ],
 "Copy": [
  null,
  "Kopiëren"
 ],
 "Copy to clipboard": [
  null,
  "Kopiëren naar clipboard"
 ],
 "Create": [
  null,
  "Aanmaken"
 ],
 "Create $0": [
  null,
  "Maak $0 aan"
 ],
 "Create LVM2 volume group": [
  null,
  "Aanmaken LVM2-volumegroep"
 ],
 "Create MDRAID device": [
  null,
  "Maak MDRAID-apparaat aan"
 ],
 "Create RAID device": [
  null,
  "Maak RAID-apparaat aan"
 ],
 "Create Stratis pool": [
  null,
  "Maak Stratus pool aan"
 ],
 "Create a new SSH key and authorize it": [
  null,
  "Maak een nieuwe SSH-sleutel en autoriseer deze"
 ],
 "Create a snapshot of filesystem $0": [
  null,
  "Snapshot van bestandssysteem $0 aanmaken"
 ],
 "Create and mount": [
  null,
  "Aanmaken en aankoppelen"
 ],
 "Create filesystem": [
  null,
  "Bestandssysteem aanmaken"
 ],
 "Create logical volume": [
  null,
  "Maak logische volume aan"
 ],
 "Create new filesystem": [
  null,
  "Nieuw bestandssysteem aanmaken"
 ],
 "Create new logical volume": [
  null,
  "Maak nieuwe logische volume aan"
 ],
 "Create new task file with this content.": [
  null,
  "Maak nieuw taakbestand aan met deze inhoud."
 ],
 "Create new thinly provisioned logical volume": [
  null,
  "Maak nieuw dun logisch volume aan"
 ],
 "Create only": [
  null,
  "Alleen aanmaken"
 ],
 "Create partition": [
  null,
  "Partitie aanmaken"
 ],
 "Create partition on $0": [
  null,
  "Partitie aanmaken op $0"
 ],
 "Create partition table": [
  null,
  "Partitietabel aanmaken"
 ],
 "Create snapshot": [
  null,
  "Maak snapshot aan"
 ],
 "Create snapshot and mount": [
  null,
  "Maak snapshot en koppel aan"
 ],
 "Create snapshot only": [
  null,
  "Maak alleen een snapshot"
 ],
 "Create subvolume": [
  null,
  "Maak subvolume aan"
 ],
 "Create thin volume": [
  null,
  "Maak dun volume aan"
 ],
 "Create volume group": [
  null,
  "Maak volumegroep aan"
 ],
 "Creating LVM2 volume group $target": [
  null,
  "LVM2-Volumegroep $target aanmaken"
 ],
 "Creating VDO device": [
  null,
  "VDO-apparaat aanmaken"
 ],
 "Creating filesystem on $target": [
  null,
  "Bestandssysteem op $target aanmaken"
 ],
 "Creating logical volume $target": [
  null,
  "Logisch volume $target aanmaken"
 ],
 "Creating partition $target": [
  null,
  "Partitie $target aanmaken"
 ],
 "Creating snapshot of $target": [
  null,
  "Snapshot van $target aanmaken"
 ],
 "Ctrl+Insert": [
  null,
  "Ctrl+Insert"
 ],
 "Currently in use": [
  null,
  "Momenteel in gebruik"
 ],
 "Custom mount options": [
  null,
  "Aangepaste aankoppelopties"
 ],
 "Data": [
  null,
  "Data"
 ],
 "Data used": [
  null,
  "Gebruikte data"
 ],
 "Data will be stored as two copies and also in an alternating fashion on the selected physical volumes, to improve both reliability and performance. At least four volumes need to be selected.": [
  null,
  "Data wordt als twee kopieën en ook op afwisselende wijze op de geselecteerde fysieke volumes opgeslagen, om zowel de betrouwbaarheid als de prestaties te verbeteren. Er moeten minimaal vier volumes worden geselecteerd."
 ],
 "Data will be stored as two or more copies on the selected physical volumes, to improve reliability. At least two volumes need to be selected.": [
  null,
  "Data wordt opgeslagen als twee of meer kopieën op de geselecteerde fysieke volumes, om de betrouwbaarheid te verbeteren. Er moeten minimaal twee volumes worden geselecteerd."
 ],
 "Data will be stored on the selected physical volumes in an alternating fashion to improve performance. At least two volumes need to be selected.": [
  null,
  "Data wordt afwisselend op de geselecteerde fysieke volumes opgeslagen om de prestaties te verbeteren. Er moeten minimaal twee volumes worden geselecteerd."
 ],
 "Data will be stored on the selected physical volumes so that one of them can be lost without affecting the data. At least three volumes need to be selected.": [
  null,
  "Data wordt opgeslagen op de geselecteerde fysieke volumes, zodat een ervan verloren kan gaan zonder de data te beïnvloeden. Er moeten minimaal drie volumes worden geselecteerd."
 ],
 "Data will be stored on the selected physical volumes so that one of them can be lost without affecting the data. Data is also stored in an alternating fashion to improve performance. At least three volumes need to be selected.": [
  null,
  "Data wordt opgeslagen op de geselecteerde fysieke volumes, zodat een ervan verloren kan gaan zonder de data te beïnvloeden. Data wordt ook afwisselend opgeslagen om de prestaties te verbeteren. Er moeten minimaal drie volumes worden geselecteerd."
 ],
 "Data will be stored on the selected physical volumes so that up to two of them can be lost at the same time without affecting the data. Data is also stored in an alternating fashion to improve performance. At least five volumes need to be selected.": [
  null,
  "Data wordt op de geselecteerde fysieke volumes opgeslagen, zodat er maximaal twee tegelijk verloren kunnen gaan zonder dat dit gevolgen heeft voor de data. Data wordt ook afwisselend opgeslagen om de prestaties te verbeteren. Er moeten minimaal vijf volumes worden geselecteerd."
 ],
 "Data will be stored on the selected physical volumes without any additional redundancy or performance improvements.": [
  null,
  "Data wordt opgeslagen op de geselecteerde fysieke volumes zonder enige extra redundantie of prestatieverbeteringen."
 ],
 "Deactivate": [
  null,
  "Deactiveren"
 ],
 "Deactivating $target": [
  null,
  "$target deactiveren"
 ],
 "Dedicated parity (RAID 4)": [
  null,
  "Toegewijde pariteit (RAID 4)"
 ],
 "Deduplication": [
  null,
  "Deduplicatie"
 ],
 "Degraded": [
  null,
  "Gedegradeerd"
 ],
 "Delay": [
  null,
  "Vertraging"
 ],
 "Delete": [
  null,
  "Verwijderen"
 ],
 "Delete group": [
  null,
  "Groep verwijderen"
 ],
 "Deleting $target": [
  null,
  "Verwijder $target"
 ],
 "Deleting LVM2 volume group $target": [
  null,
  "LVM2-volumegroep $target verwijderen"
 ],
 "Deleting a Stratis pool will erase all data it contains.": [
  null,
  "Verwijderen van een Stratis pool zal alle data die het bevat wissen."
 ],
 "Deleting a filesystem will delete all data in it.": [
  null,
  "Verwijderen van een bestandssysteem zal alle data erop wissen."
 ],
 "Deleting a logical volume will delete all data in it.": [
  null,
  "Verwijderen van een logische volume zal alle data erop wissen."
 ],
 "Deleting a partition will delete all data in it.": [
  null,
  "Verwijderen van een partitie zal alle data erop wissen."
 ],
 "Deleting erases all data on a VDO device.": [
  null,
  "Verwijderen vernietigt alle data op een VDO-apparaat."
 ],
 "Deleting erases all data on a volume group.": [
  null,
  "Verwijderen vernietigt alle data op een volumegroep."
 ],
 "Description": [
  null,
  "Beschrijving"
 ],
 "Desktop": [
  null,
  "Bureaublad"
 ],
 "Detachable": [
  null,
  "Demonteerbaar"
 ],
 "Device": [
  null,
  "Apparaat"
 ],
 "Device file": [
  null,
  "Apparaatbestand"
 ],
 "Device health (SMART)": [
  null,
  "Apparaat-gezondheid (SMART)"
 ],
 "Device is read-only": [
  null,
  "Apparaat is alleen-lezen"
 ],
 "Diagnostic reports": [
  null,
  "Diagnostische rapporten"
 ],
 "Did not complete": [
  null,
  "Niet voltooid"
 ],
 "Disconnect": [
  null,
  "Verbinding verbreken"
 ],
 "Disk is OK": [
  null,
  "Schijf is OK"
 ],
 "Disk is failing": [
  null,
  "Schijf werkt niet"
 ],
 "Disk passphrase": [
  null,
  "Schijf wachtzin"
 ],
 "Disks": [
  null,
  "Schijven"
 ],
 "Dismiss": [
  null,
  "Afwijzen"
 ],
 "Distributed parity (RAID 5)": [
  null,
  "Gedistribueerde pariteit (RAID 5)"
 ],
 "Do not mount": [
  null,
  "Koppel niet aan"
 ],
 "Do not mount automatically on boot": [
  null,
  "Niet automatisch aankoppelen tijdens het opstarten"
 ],
 "Docking station": [
  null,
  "Docking station"
 ],
 "Does not mount during boot": [
  null,
  "Wordt niet aangekoppeld tijdens het opstarten"
 ],
 "Double distributed parity (RAID 6)": [
  null,
  "Dubbel gedistribueerde pariteit (RAID 6)"
 ],
 "Downloading $0": [
  null,
  "$0 downloaden"
 ],
 "Drive": [
  null,
  "Station"
 ],
 "Dual rank": [
  null,
  "Dubbele rangorde"
 ],
 "Edit": [
  null,
  "Bewerken"
 ],
 "Edit Tang keyserver": [
  null,
  "Bewerk Tang sleutelserver"
 ],
 "Editing a key requires a free slot": [
  null,
  "Een sleutel bewerken vereist een vrij slot"
 ],
 "Ejecting $target": [
  null,
  "$target uitwerpen"
 ],
 "Embedded PC": [
  null,
  "Ingebouwde pc"
 ],
 "Emptying $target": [
  null,
  "$target leegmaken"
 ],
 "Enabling $0": [
  null,
  "$0 inschakelen"
 ],
 "Encrypt data with a Tang keyserver": [
  null,
  "Versleutel data met een Tang sleutelserver"
 ],
 "Encrypt data with a passphrase": [
  null,
  "Versleutel data met een wachtzin"
 ],
 "Encrypted $0": [
  null,
  "$0 versleuteld"
 ],
 "Encrypted logical volume of $0": [
  null,
  "Versleutelde logische volume van $0"
 ],
 "Encrypted partition of $0": [
  null,
  "Versleutelde partitie van $0"
 ],
 "Encryption": [
  null,
  "Versleuteling"
 ],
 "Encryption options": [
  null,
  "Versleutelingsopties"
 ],
 "Encryption type": [
  null,
  "Versleutelingstype"
 ],
 "Erasing $target": [
  null,
  "$target wissen"
 ],
 "Error": [
  null,
  "Fout"
 ],
 "Error installing $0: PackageKit is not installed": [
  null,
  "Fout bij het installeren van $0: PackageKit is niet geïnstalleerd"
 ],
 "Exactly $0 physical volumes must be selected": [
  null,
  "Er moeten exact $0 fysieke volumes worden geselecteerd"
 ],
 "Exactly $0 physical volumes need to be selected, one for each stripe of the logical volume.": [
  null,
  "Er moeten exact $0 fysieke volumes worden geselecteerd, één voor elke streep van het logische volume."
 ],
 "Excellent password": [
  null,
  "Uitstekend wachtwoord"
 ],
 "Expansion chassis": [
  null,
  "Uitbreidingschassis"
 ],
 "Extended partition": [
  null,
  "Uitgebreide partitie"
 ],
 "Failed": [
  null,
  "Mislukt"
 ],
 "Failed (Damaged)": [
  null,
  "Gefaald (Beschadigd)"
 ],
 "Failed (Electrical)": [
  null,
  "Gefaald (Elektrisch)"
 ],
 "Failed to change password": [
  null,
  "Kan wachtwoord niet veranderen"
 ],
 "Failed to enable $0 in firewalld": [
  null,
  "Kan $0 niet inschakelen in firewalld"
 ],
 "Filesystem": [
  null,
  "Bestandssysteem"
 ],
 "Filesystem is locked": [
  null,
  "Bestandssysteem is vergrendeld"
 ],
 "Filesystem name": [
  null,
  "Bestandssysteemnaam"
 ],
 "Filesystems are already mounted below this mountpoint.": [
  null,
  "Bestandssystemen zijn al aangekoppeld op dit aankoppelpunt."
 ],
 "Fix NBDE support": [
  null,
  "NBDE-ondersteuning repareren"
 ],
 "Format": [
  null,
  "Formatteren"
 ],
 "Format $0": [
  null,
  "$0 formatteren"
 ],
 "Format and mount": [
  null,
  "Formatteren en aankoppelen"
 ],
 "Format only": [
  null,
  "Alleen formatteren"
 ],
 "Formatting erases all data on a storage device.": [
  null,
  "Formatteren verwijdert alle data op een opslagapparaat."
 ],
 "Free space": [
  null,
  "Vrije ruimte"
 ],
 "Go to now": [
  null,
  "Ga nu naar"
 ],
 "Grow": [
  null,
  "Vergroten"
 ],
 "Grow content": [
  null,
  "Vergroot inhoud"
 ],
 "Grow logical size of $0": [
  null,
  "Vergroot logische grootte van $0"
 ],
 "Grow logical volume": [
  null,
  "Vergroot logische volume"
 ],
 "Grow partition": [
  null,
  "Laat partitie groeien"
 ],
 "Grow the pool to take all space": [
  null,
  "Vergroot de pool om alle ruimte in te nemen"
 ],
 "Grow to take all space": [
  null,
  "Vergroot om alle ruimte in te nemen"
 ],
 "Handheld": [
  null,
  "Handheld"
 ],
 "Hide confirmation password": [
  null,
  "Bevestigingswachtwoord verbergen"
 ],
 "Hide password": [
  null,
  "Wachtwoord verbergen"
 ],
 "Host key is incorrect": [
  null,
  "Hostsleutel is onjuist"
 ],
 "How to check": [
  null,
  "Hoe te controleren"
 ],
 "I confirm I want to lose this data forever": [
  null,
  "Ik bevestig dat ik deze data voor eeuwig wil verliezen"
 ],
 "ID": [
  null,
  "ID"
 ],
 "INTERNAL ERROR - This logical volume is marked as active and should have an associated block device. However, no such block device could be found.": [
  null,
  "INTERNE ERROR - Dit logische volume is gemarkeerd als actief en zou een bijbehorend blokapparaat moeten hebben. Er kon echter geen dergelijk blokapparaat worden gevonden."
 ],
 "If the fingerprint matches, click 'Trust and add host'. Otherwise, do not connect and contact your administrator.": [
  null,
  "Als de vingerafdruk overeenkomt, klik dan op 'Vertrouw en host toevoegen'. Verbind anders niet en neem contact op met je beheerder."
 ],
 "Important data might be deleted:": [
  null,
  "Belangrijke gegevens kunnen worden verwijderd:"
 ],
 "In a terminal, run: ": [
  null,
  "Voer in een terminal uit: "
 ],
 "In sync": [
  null,
  "Synchroon"
 ],
 "Inconsistent filesystem mount": [
  null,
  "Inconsistente bestandssysteemkoppeling"
 ],
 "Index memory": [
  null,
  "Indexgeheugen"
 ],
 "Initialize": [
  null,
  "Initialiseren"
 ],
 "Initialize disk $0": [
  null,
  "Initialiseren van schijf $0"
 ],
 "Initializing erases all data on a disk.": [
  null,
  "Initialiseren verwijdert alle data op een schijf."
 ],
 "Install": [
  null,
  "Installeren"
 ],
 "Install NFS support": [
  null,
  "Installeer NFS-ondersteuning"
 ],
 "Install Stratis support": [
  null,
  "Installeer Stratis-ondersteuning"
 ],
 "Install software": [
  null,
  "Installeer software"
 ],
 "Installing $0": [
  null,
  "$0 installeren"
 ],
 "Installing $0 would remove $1.": [
  null,
  "Als je $0 installeert, wordt $1 verwijderd."
 ],
 "Installing packages": [
  null,
  "Pakketten installeren"
 ],
 "Internal error": [
  null,
  "Interne fout"
 ],
 "Invalid date format": [
  null,
  "Ongeldige datum"
 ],
 "Invalid date format and invalid time format": [
  null,
  "Ongeldige datumnotatie en ongeldige tijdnotatie"
 ],
 "Invalid file permissions": [
  null,
  "Ongeldige bestandsrechten"
 ],
 "Invalid time format": [
  null,
  "Ongeldige tijdnotatie"
 ],
 "Invalid timezone": [
  null,
  "Ongeldige tijdzone"
 ],
 "Invalid username or password": [
  null,
  "Ongeldige gebruikersnaam of wachtwoord"
 ],
 "IoT gateway": [
  null,
  "IoT-gateway"
 ],
 "Jobs": [
  null,
  "Taken"
 ],
 "Kernel dump": [
  null,
  "Kerneldump"
 ],
 "Key password": [
  null,
  "Sleutelwachtwoord"
 ],
 "Key slots with unknown types can not be edited here": [
  null,
  "Sleutelslots met onbekende typen kunnen hier niet worden bewerkt"
 ],
 "Key source": [
  null,
  "Sleutelbron"
 ],
 "Keys": [
  null,
  "Sleutels"
 ],
 "Keyserver": [
  null,
  "Sleutelserver"
 ],
 "Keyserver address": [
  null,
  "Sleutelserveradres"
 ],
 "Keyserver removal may prevent unlocking $0.": [
  null,
  "Het verwijderen van keyserver kan voorkomen dat $0 wordt ontgrendeld."
 ],
 "LVM2 physical volume": [
  null,
  "LVM2 fysieke volume"
 ],
 "LVM2 volume group": [
  null,
  "LVM2 volumegroep"
 ],
 "LVM2 volume group $0": [
  null,
  "LVM2 volumegroep $0"
 ],
 "Label": [
  null,
  "Label:"
 ],
 "Laptop": [
  null,
  "Laptop"
 ],
 "Last modified: $0": [
  null,
  "Laatst gewijzigd: $0"
 ],
 "Layout": [
  null,
  "Indeling"
 ],
 "Learn more": [
  null,
  "Kom meer te weten"
 ],
 "Linear": [
  null,
  "Lineair"
 ],
 "Loading system modifications...": [
  null,
  "Systeemwijzigingen laden..."
 ],
 "Loading...": [
  null,
  "Laden..."
 ],
 "Local mount point": [
  null,
  "Lokale aankoppelpunten"
 ],
 "Location": [
  null,
  "Locatie"
 ],
 "Lock": [
  null,
  "Slot"
 ],
 "Locking $target": [
  null,
  "$target vergrendelen"
 ],
 "Log in": [
  null,
  "Inloggen"
 ],
 "Log in to $0": [
  null,
  "Log in op $0"
 ],
 "Log messages": [
  null,
  "Log berichten"
 ],
 "Logical": [
  null,
  "Logisch"
 ],
 "Logical size": [
  null,
  "Logische grootte"
 ],
 "Logical volume": [
  null,
  "Logische volume"
 ],
 "Logical volume (snapshot)": [
  null,
  "Logische volume (Snapshot)"
 ],
 "Logical volume of $0": [
  null,
  "Logische volume van $0"
 ],
 "Login failed": [
  null,
  "Inloggen mislukte"
 ],
 "Low profile desktop": [
  null,
  "Laag profiel bureaublad"
 ],
 "Lunch box": [
  null,
  "Lunchbox"
 ],
 "Main server chassis": [
  null,
  "Hoofdserverchassis"
 ],
 "Manage storage": [
  null,
  "Beheerde opslag"
 ],
 "Manually": [
  null,
  "Handmatig"
 ],
 "Marking $target as faulty": [
  null,
  "$target als defect markeren"
 ],
 "Message to logged in users": [
  null,
  "Bericht aan ingelogde gebruikers"
 ],
 "Metadata used": [
  null,
  "Gebruikte metadata"
 ],
 "Mini PC": [
  null,
  "Mini PC"
 ],
 "Mini tower": [
  null,
  "Mini tower"
 ],
 "Mirrored (RAID 1)": [
  null,
  "Gespiegeld (RAID 1)"
 ],
 "Model": [
  null,
  "Model"
 ],
 "Modifying $target": [
  null,
  "$target aanpassen"
 ],
 "Mount": [
  null,
  "Aankoppelen"
 ],
 "Mount Point": [
  null,
  "Aankoppelpunt"
 ],
 "Mount after network becomes available, ignore failure": [
  null,
  "Aankoppelen nadat het netwerk beschikbaar is, negeer de fout"
 ],
 "Mount also automatically on boot": [
  null,
  "Koppel ook automatisch aan tijdens het opstarten"
 ],
 "Mount at boot": [
  null,
  "Koppel aan tijdens het opstarten"
 ],
 "Mount automatically on $0 on boot": [
  null,
  "Koppel automatisch aan op $0 tijdens het opstarten"
 ],
 "Mount before services start": [
  null,
  "Aankoppelen voordat de services starten"
 ],
 "Mount configuration": [
  null,
  "Aankoppelconfiguratie"
 ],
 "Mount filesystem": [
  null,
  "Bestandssysteem aankoppelen"
 ],
 "Mount now": [
  null,
  "Koppel nu aan"
 ],
 "Mount on $0 now": [
  null,
  "Koppel nu aan op $0"
 ],
 "Mount options": [
  null,
  "Aankoppelopties"
 ],
 "Mount point": [
  null,
  "Aankoppelpunt"
 ],
 "Mount point cannot be empty": [
  null,
  "Aankoppelpunt mag niet leeg zijn"
 ],
 "Mount point cannot be empty.": [
  null,
  "Aankoppelpunt mag niet leeg zijn."
 ],
 "Mount point is already used for $0": [
  null,
  "Aankoppelpunt wordt al gebruikt voor $0"
 ],
 "Mount point must start with \"/\".": [
  null,
  "Aankoppelpunt moet beginnen met \"/\"."
 ],
 "Mount read only": [
  null,
  "Koppel alleen-lezen aan"
 ],
 "Mount without waiting, ignore failure": [
  null,
  "Aankoppelen zonder te wachten, negeer mislukken"
 ],
 "Mounting $target": [
  null,
  "$target aankoppelen"
 ],
 "Mounts before services start": [
  null,
  "Aankoppelen voordat services starten"
 ],
 "Mounts in parallel with services": [
  null,
  "Aankoppelen in parallel met services"
 ],
 "Mounts in parallel with services, but after network is available": [
  null,
  "Wordt parallel met services gekoppeld, maar nadat het netwerk beschikbaar is"
 ],
 "Multi-system chassis": [
  null,
  "Chassis met meerdere systemen"
 ],
 "NFS mount": [
  null,
  "NFS-aankoppeling"
 ],
 "NTP server": [
  null,
  "NTP-server"
 ],
 "Name": [
  null,
  "Naam"
 ],
 "Name can not be empty.": [
  null,
  "Naam mag niet leeg zijn."
 ],
 "Name cannot be empty.": [
  null,
  "Naam mag niet leeg zijn."
 ],
 "Name cannot be longer than $0 bytes": [
  null,
  "Naam mag niet langer zijn dan $0 bytes"
 ],
 "Name cannot be longer than $0 characters": [
  null,
  "Naam mag niet langer dan $0 lettertekens"
 ],
 "Name cannot be longer than 127 characters.": [
  null,
  "Naam mag niet langer zijn dan 127 lettertekens."
 ],
 "Name cannot contain the character '$0'.": [
  null,
  "Naam mag het letterteken '$0' niet bevatten."
 ],
 "Name cannot contain whitespace.": [
  null,
  "Naam mag geen spaties bevatten."
 ],
 "Need a spare disk": [
  null,
  "Reserve schijf nodig"
 ],
 "Need at least one NTP server": [
  null,
  "Minimaal één NTP-server nodig"
 ],
 "Networking": [
  null,
  "Netwerken"
 ],
 "New NFS mount": [
  null,
  "Nieuwe NFS-aankoppeling"
 ],
 "New passphrase": [
  null,
  "Nieuwe wachtzin"
 ],
 "New password was not accepted": [
  null,
  "Nieuw wachtwoord is niet geaccepteerd"
 ],
 "Next": [
  null,
  "Volgende"
 ],
 "No available slots": [
  null,
  "Geen slots beschikbaar"
 ],
 "No block devices are available.": [
  null,
  "Geen blokapparaten beschikbaar."
 ],
 "No delay": [
  null,
  "Geen vertraging"
 ],
 "No disks are available.": [
  null,
  "Geen schijven beschikbaar."
 ],
 "No encryption": [
  null,
  "Geen versleuteling"
 ],
 "No filesystem": [
  null,
  "Geen bestandssysteem"
 ],
 "No filesystems": [
  null,
  "Geen bestandssystemen"
 ],
 "No free key slots": [
  null,
  "Geen vrije sleutel slots"
 ],
 "No free space": [
  null,
  "Geen vrije ruimte"
 ],
 "No free space after this partition": [
  null,
  "Geen vrije ruimte na deze partitie"
 ],
 "No keys added": [
  null,
  "Geen sleutels toegevoegd"
 ],
 "No logical volumes": [
  null,
  "Geen logische volumes"
 ],
 "No media inserted": [
  null,
  "Geen media geplaatst"
 ],
 "No partitioning": [
  null,
  "Geen partitionering"
 ],
 "No results found": [
  null,
  "Geen resultaten gevonden"
 ],
 "No such file or directory": [
  null,
  "Bestand of map bestaat niet"
 ],
 "No system modifications": [
  null,
  "Geen systeemwijzigingen"
 ],
 "Not a valid private key": [
  null,
  "Geen geldige privésleutel"
 ],
 "Not enough space": [
  null,
  "Niet genoeg ruimte"
 ],
 "Not found": [
  null,
  "Niet gevonden"
 ],
 "Not permitted to perform this action.": [
  null,
  "Niet toegestaan om deze actie uit te voeren."
 ],
 "Not running": [
  null,
  "Niet actief"
 ],
 "Not synchronized": [
  null,
  "Niet gesynchroniseerd"
 ],
 "Notebook": [
  null,
  "Notebook"
 ],
 "Number of bad sectors": [
  null,
  "Aantal slechte sectoren"
 ],
 "Occurrences": [
  null,
  "Voorvallen"
 ],
 "Ok": [
  null,
  "OK"
 ],
 "Old passphrase": [
  null,
  "Oude wachtzin"
 ],
 "Old password not accepted": [
  null,
  "Oude wachtwoord niet geaccepteerd"
 ],
 "Once Cockpit is installed, enable it with \"systemctl enable --now cockpit.socket\".": [
  null,
  "Nadat Cockpit geïnstalleerd is, schakel je het in met \"systemctl enable --now cockpit.socket\"."
 ],
 "Only $0 of $1 are used.": [
  null,
  "Alleen $0 van $1 worden gebruikt."
 ],
 "Operation '$operation' on $target": [
  null,
  "Bewerking '$operation' op $target"
 ],
 "Options": [
  null,
  "Opties"
 ],
 "Other": [
  null,
  "Andere"
 ],
 "Overwrite": [
  null,
  "Overschrijven"
 ],
 "Overwrite existing data with zeros (slower)": [
  null,
  "Bestaande data overschrijven met nullen (langzamer)"
 ],
 "PID": [
  null,
  "PID"
 ],
 "PackageKit crashed": [
  null,
  "PackageKit is gecrasht"
 ],
 "Partition": [
  null,
  "Partitie"
 ],
 "Partition of $0": [
  null,
  "Partitie van $0"
 ],
 "Partition size is $0. Content size is $1.": [
  null,
  "Partitiegrootte is $0. Inhoudsgrootte is $1."
 ],
 "Partitioning": [
  null,
  "Partitionering"
 ],
 "Partitions": [
  null,
  "Partities"
 ],
 "Passphrase": [
  null,
  "Wachtzin"
 ],
 "Passphrase can not be empty": [
  null,
  "Wachtzin mag niet leeg zijn"
 ],
 "Passphrase cannot be empty": [
  null,
  "Wachtzin mag niet leeg zijn"
 ],
 "Passphrase from any other key slot": [
  null,
  "Wachtzin van een ander sleutelslot"
 ],
 "Passphrase removal may prevent unlocking $0.": [
  null,
  "Verwijdering van wachtzin kan voorkomen dat $0 wordt ontgrendeld."
 ],
 "Passphrases do not match": [
  null,
  "Wachtzinnen komen niet overeen"
 ],
 "Password": [
  null,
  "Wachtwoord"
 ],
 "Password is not acceptable": [
  null,
  "Wachtwoord is niet acceptabel"
 ],
 "Password is too weak": [
  null,
  "Wachtwoord is te zwak"
 ],
 "Password not accepted": [
  null,
  "Wachtwoord wordt niet geaccepteerd"
 ],
 "Paste": [
  null,
  "Plakken"
 ],
 "Paste error": [
  null,
  "Plakfout"
 ],
 "Path on server": [
  null,
  "Pad op server"
 ],
 "Path on server cannot be empty.": [
  null,
  "Pad op server mag niet leeg zijn."
 ],
 "Path on server must start with \"/\".": [
  null,
  "Pad op server moet beginnen met \"/\"."
 ],
 "Path to file": [
  null,
  "Pad naar bestand"
 ],
 "Peripheral chassis": [
  null,
  "Randchassis"
 ],
 "Permanently delete $0?": [
  null,
  "$0 permanent verwijderen?"
 ],
 "Physical": [
  null,
  "Fysiek"
 ],
 "Physical Volumes": [
  null,
  "Fysieke volumes"
 ],
 "Physical volumes": [
  null,
  "Fysieke volumes"
 ],
 "Pick date": [
  null,
  "Kies datum"
 ],
 "Pizza box": [
  null,
  "Pizzadoos"
 ],
 "Please unmount them first.": [
  null,
  "Ontkoppel ze eerst."
 ],
 "Pool for thin logical volumes": [
  null,
  "Pool voor dunne logische volumes"
 ],
 "Pool for thinly provisioned volumes": [
  null,
  "Pool voor dun ingerichte volumes"
 ],
 "Pool passphrase": [
  null,
  "Pool wachtzin"
 ],
 "Port": [
  null,
  "Poort"
 ],
 "Portable": [
  null,
  "Draagbaar"
 ],
 "Power on hours": [
  null,
  "Aantal uren aan"
 ],
 "Present": [
  null,
  "Aanwezig"
 ],
 "Processes using the location": [
  null,
  "Processen die de locatie gebruiken"
 ],
 "Prompting via ssh-add timed out": [
  null,
  "Vragen via ssh-add is verlopen"
 ],
 "Prompting via ssh-keygen timed out": [
  null,
  "Vragen ssh-keygen is verlopen"
 ],
 "Provide the passphrase for the pool on these block devices:": [
  null,
  "Geef de wachtzin voor de pool op deze blokapparaten:"
 ],
 "Purpose": [
  null,
  "Doel"
 ],
 "RAID ($0)": [
  null,
  "RAID ($0)"
 ],
 "RAID 0": [
  null,
  "RAID 0"
 ],
 "RAID 0 (stripe)": [
  null,
  "RAID 0 (stripe)"
 ],
 "RAID 1": [
  null,
  "RAID 1"
 ],
 "RAID 1 (mirror)": [
  null,
  "RAID 1 (spiegel)"
 ],
 "RAID 10": [
  null,
  "RAID 10"
 ],
 "RAID 10 (stripe of mirrors)": [
  null,
  "RAID 10 (stripe van spiegels)"
 ],
 "RAID 4": [
  null,
  "RAID 4"
 ],
 "RAID 4 (dedicated parity)": [
  null,
  "RAID 4 (toegewijde pariteit)"
 ],
 "RAID 5": [
  null,
  "RAID 5"
 ],
 "RAID 5 (distributed parity)": [
  null,
  "RAID 5 (gedistribueerde pariteit)"
 ],
 "RAID 6": [
  null,
  "RAID 6"
 ],
 "RAID 6 (double distributed parity)": [
  null,
  "RAID 6 (dubbel gedistribueerde pariteit)"
 ],
 "RAID chassis": [
  null,
  "RAID-chassis"
 ],
 "RAID level": [
  null,
  "RAID-niveau"
 ],
 "RAID10 needs an even number of physical volumes": [
  null,
  "RAID10 heeft een even aantal fysieke volumes nodig"
 ],
 "Rack mount chassis": [
  null,
  "Rackmontagechassis"
 ],
 "Reading": [
  null,
  "Lezen"
 ],
 "Reboot": [
  null,
  "Opnieuw opstarten"
 ],
 "Recovering": [
  null,
  "Herstellen"
 ],
 "Regenerating initrd": [
  null,
  "initrd opnieuw genereren"
 ],
 "Related processes and services will be forcefully stopped.": [
  null,
  "Gerelateerde processen en services worden met kracht gestopt."
 ],
 "Related processes will be forcefully stopped.": [
  null,
  "Gerelateerde processen worden met kracht gestopt."
 ],
 "Related services will be forcefully stopped.": [
  null,
  "Gerelateerde services worden met kracht gestopt."
 ],
 "Removals:": [
  null,
  "Verwijderingen:"
 ],
 "Remove": [
  null,
  "Verwijderen"
 ],
 "Remove $0?": [
  null,
  "$0 verwijderen?"
 ],
 "Remove Tang keyserver?": [
  null,
  "Tang-sleutelserver verwijderen?"
 ],
 "Remove device": [
  null,
  "Verwijder apparaat"
 ],
 "Remove missing physical volumes?": [
  null,
  "Ontbrekende fysieke volumes verwijderen?"
 ],
 "Remove passphrase in key slot $0?": [
  null,
  "Wachtzin in sleutelslot $0 verwijderen?"
 ],
 "Remove passphrase?": [
  null,
  "Wachtzin verwijderen?"
 ],
 "Removing $0": [
  null,
  "$0 verwijderen"
 ],
 "Removing a passphrase without confirmation of another passphrase may prevent unlocking or key management, if other passphrases are forgotten or lost.": [
  null,
  "Het verwijderen van een wachtzin zonder bevestiging van een andere wachtzin kan ontgrendeling of sleutelbeheer voorkomen als andere wachtzinnen worden vergeten of verloren gaan."
 ],
 "Removing physical volume from $target": [
  null,
  "Fysiek volume verwijderen uit $target"
 ],
 "Rename": [
  null,
  "Hernoemen"
 ],
 "Rename Stratis pool": [
  null,
  "Naam van Stratis pool wijzigen"
 ],
 "Rename filesystem": [
  null,
  "Bestandssysteem hernoemen"
 ],
 "Rename logical volume": [
  null,
  "Hernoemen logische volume"
 ],
 "Rename volume group": [
  null,
  "Hernoem volumegroep"
 ],
 "Renaming $target": [
  null,
  "Hernoem $target"
 ],
 "Repair": [
  null,
  "Herstellen"
 ],
 "Repair logical volume $0": [
  null,
  "Herstel logische volume $0"
 ],
 "Repairing $target": [
  null,
  "$target repareren"
 ],
 "Repeat passphrase": [
  null,
  "Herhaal wachtzin"
 ],
 "Resizing $target": [
  null,
  "Grootte van $target wijzigen"
 ],
 "Resizing an encrypted filesystem requires unlocking the disk. Please provide a current disk passphrase.": [
  null,
  "Het wijzigen van de grootte van een versleuteld bestandssysteem vereist dat de schijf wordt ontgrendeld. Geef een huidige wachtzin voor de schijf op."
 ],
 "Reuse existing encryption": [
  null,
  "Bestaande versleuteling hergebruiken"
 ],
 "Reuse existing encryption ($0)": [
  null,
  "Hergebruiken van bestaande versleuteling ($0)"
 ],
 "Run extended test": [
  null,
  "Start uitgebreide test"
 ],
 "Run this command over a trusted network or physically on the remote machine:": [
  null,
  "Voer deze opdracht uit via een vertrouwd netwerk of fysiek op de externe machine:"
 ],
 "Running": [
  null,
  "Uitvoeren"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "SHA-1": [
  null,
  "SHA-1"
 ],
 "SHA-256": [
  null,
  "SHA256"
 ],
 "SMART self-test of $target": [
  null,
  "SMART zelftest van $target"
 ],
 "SSH key": [
  null,
  "SSH-sleutel"
 ],
 "Save": [
  null,
  "Opslaan"
 ],
 "Save space by compressing individual blocks with LZ4": [
  null,
  "Bespaar ruimte door afzonderlijke blokken te comprimeren met LZ4"
 ],
 "Save space by storing identical data blocks just once": [
  null,
  "Bespaar ruimte door identieke datablokken slechts één keer op te slaan"
 ],
 "Saving a new passphrase requires unlocking the disk. Please provide a current disk passphrase.": [
  null,
  "Voor het opslaan van een nieuwe wachtzin moet de schijf worden ontgrendeld. Geef een huidige wachtzin voor de schijf op."
 ],
 "Sealed-case PC": [
  null,
  "Gesloten PC"
 ],
 "Securely erasing $target": [
  null,
  "$target veilig wissen"
 ],
 "Security Enhanced Linux configuration and troubleshooting": [
  null,
  "Security Enhanced Linux configuratie en probleemoplossing"
 ],
 "Server": [
  null,
  "Server"
 ],
 "Server address": [
  null,
  "Serveradres"
 ],
 "Server address cannot be empty.": [
  null,
  "Serveradres mag niet leeg zijn."
 ],
 "Server cannot be empty.": [
  null,
  "Server mag niet leeg zijn."
 ],
 "Server has closed the connection.": [
  null,
  "Server heeft de verbinding verbroken."
 ],
 "Service": [
  null,
  "Service"
 ],
 "Services using the location": [
  null,
  "Services die gebruik maken van de locatie"
 ],
 "Set": [
  null,
  "Instellen"
 ],
 "Set limit of virtual filesystem size": [
  null,
  "Stel het limiet in voor de grootte van het virtuele bestandssysteem"
 ],
 "Set time": [
  null,
  "Stel tijd in"
 ],
 "Setting up loop device $target": [
  null,
  "Loop apparaat $target instellen"
 ],
 "Shell script": [
  null,
  "Shell-script"
 ],
 "Shift+Insert": [
  null,
  "Shift+Insert"
 ],
 "Show confirmation password": [
  null,
  "Bevestigingswachtwoord tonen"
 ],
 "Show password": [
  null,
  "Wachtwoord tonen"
 ],
 "Shrink": [
  null,
  "Krimpen"
 ],
 "Shrink logical volume": [
  null,
  "Krimp logische volume"
 ],
 "Shrink partition": [
  null,
  "Verklein partitie"
 ],
 "Shrink volume": [
  null,
  "Krimp volume"
 ],
 "Shut down": [
  null,
  "Afsluiten"
 ],
 "Single rank": [
  null,
  "Enkele rang"
 ],
 "Size": [
  null,
  "Grootte"
 ],
 "Size cannot be negative": [
  null,
  "Grootte mag niet negatief zijn"
 ],
 "Size cannot be zero": [
  null,
  "Grootte mag niet nul zijn"
 ],
 "Size is too large": [
  null,
  "Grootte is te groot"
 ],
 "Size must be a number": [
  null,
  "Grootte moet een getal zijn"
 ],
 "Size must be at least $0": [
  null,
  "Grootte moet tenminste #0 zijn"
 ],
 "Slot $0": [
  null,
  "Slot $0"
 ],
 "Snapshot": [
  null,
  "Snapshot"
 ],
 "Some block devices of this pool have grown in size after the pool was created. The pool can be safely grown to use the newly available space.": [
  null,
  "Sommige blokapparaten van deze pool zijn groter geworden nadat de pool is gemaakt. De pool kan veilig worden vergroot om de nieuw beschikbare ruimte te gebruiken."
 ],
 "Sorry": [
  null,
  "Excuus!"
 ],
 "Space-saving computer": [
  null,
  "Ruimtebesparende computer"
 ],
 "Spare": [
  null,
  "Reserve"
 ],
 "Spare capacity is below the threshold": [
  null,
  "Reservecapaciteit ligt onder de drempelwaarde"
 ],
 "Specific time": [
  null,
  "Specifieke tijd"
 ],
 "Start": [
  null,
  "Start"
 ],
 "Start multipath": [
  null,
  "Start multipath"
 ],
 "Started": [
  null,
  "Gestart"
 ],
 "Starting swapspace $target": [
  null,
  "Swapspace $target starten"
 ],
 "State": [
  null,
  "Toestand"
 ],
 "Stick PC": [
  null,
  "Stick PC"
 ],
 "Stop": [
  null,
  "Stop"
 ],
 "Stop and remove": [
  null,
  "Stop en verwijder"
 ],
 "Stop and unmount": [
  null,
  "Stoppen en ontkoppelen"
 ],
 "Stop device": [
  null,
  "Stop apparaat"
 ],
 "Stopping swapspace $target": [
  null,
  "Swapspace $target stoppen"
 ],
 "Storage": [
  null,
  "Opslag"
 ],
 "Storage can not be managed on this system.": [
  null,
  "Opslag kan op dit systeem niet beheerd worden."
 ],
 "Storage logs": [
  null,
  "Opslaglogboeken"
 ],
 "Store passphrase": [
  null,
  "Sla wachtzin op"
 ],
 "Stored passphrase": [
  null,
  "Opgeslagen wachtzin"
 ],
 "Stratis blockdevs can not be made smaller": [
  null,
  "Stratis blockdevs kunnen niet kleiner gemaakt worden"
 ],
 "Stratis pool": [
  null,
  "Stratis-pool"
 ],
 "Striped (RAID 0)": [
  null,
  "Gestreept (RAID 0)"
 ],
 "Striped and mirrored (RAID 10)": [
  null,
  "Gestreept en gespiegeld (RAID 10)"
 ],
 "Stripes": [
  null,
  "Strepen"
 ],
 "Strong password": [
  null,
  "Sterk wachtwoord"
 ],
 "Sub-Chassis": [
  null,
  "Sub-chassis"
 ],
 "Sub-Notebook": [
  null,
  "Sub-notebook"
 ],
 "Successfully copied to clipboard!": [
  null,
  "Succesvol naar het klembord gekopieerd!"
 ],
 "Swap": [
  null,
  "Swap"
 ],
 "Synchronized": [
  null,
  "Gesynchroniseerd"
 ],
 "Synchronized with $0": [
  null,
  "Gesynchroniseerd met $0"
 ],
 "Synchronizing": [
  null,
  "Synchroniseren"
 ],
 "Tablet": [
  null,
  "Tablet"
 ],
 "Tang keyserver": [
  null,
  "Tang sleutelserver"
 ],
 "Target": [
  null,
  "Doel"
 ],
 "Temperature outside of recommended thresholds": [
  null,
  "Temperatuur buiten de aanbevolen drempelwaarde"
 ],
 "The $0 package is not available from any repository.": [
  null,
  "Het $0 pakket is van geen enkele repository beschikbaar."
 ],
 "The $0 package must be installed to create Stratis pools.": [
  null,
  "Het $0 pakket moet worden geïnstalleerd om Stratis pools aan te maken."
 ],
 "The $0 package must be installed.": [
  null,
  "Het $0 pakket moet worden geïnstalleerd."
 ],
 "The $0 package will be installed to create VDO devices.": [
  null,
  "Het $0 pakket zal worden geïnstalleerd om VDO-apparaten aan te maken."
 ],
 "The SSH key $0 of $1 on $2 will be added to the $3 file of $4 on $5.": [
  null,
  "De SSH-sleutel $0 van $1 op $2 zal worden toegevoegd aan het $3 bestand van $4 op $5."
 ],
 "The SSH key $0 will be made available for the remainder of the session and will be available for login to other hosts as well.": [
  null,
  "De SSH-sleutel $0 zal beschikbaar worden gesteld voor de rest van de sessie en zal ook beschikbaar zijn om in te loggen bij andere hosts."
 ],
 "The SSH key for logging in to $0 is protected by a password, and the host does not allow logging in with a password. Please provide the password of the key at $1.": [
  null,
  "De SSH-sleutel voor inloggen op $0 is beschermd met een wachtwoord en de host staat inloggen met een wachtwoord niet toe. Geef het wachtwoord van de sleutel op $1."
 ],
 "The SSH key for logging in to $0 is protected. You can log in with either your login password or by providing the password of the key at $1.": [
  null,
  "De SSH-sleutel voor inloggen op $0 is beschermd. Je kunt inloggen met je inlogwachtwoord of door het wachtwoord van de sleutel op te geven op $1."
 ],
 "The creation of this VDO device did not finish and the device can't be used.": [
  null,
  "Het aanmaken van dit VDO-apparaat is niet voltooid en het apparaat kan niet gebruikt worden."
 ],
 "The currently logged in user is not permitted to see information about keys.": [
  null,
  "De momenteel ingelogde gebruiker mag geen informatie over sleutels zien."
 ],
 "The disk needs to be unlocked before formatting.  Please provide a existing passphrase.": [
  null,
  "De schijf moet worden ontgrendeld voor het formatteren.  Geef een bestaande wachtzin op."
 ],
 "The filesystem has no permanent mount point.": [
  null,
  "Het bestandssysteem heeft geen permanent koppelpunt."
 ],
 "The filesystem is configured to be automatically mounted on boot but its encryption container will not be unlocked at that time.": [
  null,
  "Het bestandssysteem is geconfigureerd om automatisch te worden aangekoppeld bij het opstarten, maar de encryptiecontainer wordt op dat moment niet ontgrendeld."
 ],
 "The filesystem is currently mounted but will not be mounted after the next boot.": [
  null,
  "Het bestandssysteem is momenteel aangekoppeld, maar wordt niet aangekoppeld na de volgende keer opstarten."
 ],
 "The filesystem is currently mounted on $0 but will be mounted on $1 on the next boot.": [
  null,
  "Het bestandssysteem is momenteel aangekoppeld op $0 maar zal worden aangekoppeld op $1 bij de volgende opstart."
 ],
 "The filesystem is currently mounted on $0 but will not be mounted after the next boot.": [
  null,
  "Het bestandssysteem is momenteel aangekoppeld op $0 maar zal niet aangekoppeld worden na de volgende opstart."
 ],
 "The filesystem is currently not mounted but will be mounted on the next boot.": [
  null,
  "Het bestandssysteem is momenteel niet aangekoppeld, maar wordt bij de volgende opstart aangekoppeld."
 ],
 "The filesystem is not mounted.": [
  null,
  "Het bestandssysteem is niet aangekoppeld."
 ],
 "The filesystem will be unlocked and mounted on the next boot. This might require inputting a passphrase.": [
  null,
  "Het bestandssysteem wordt ontgrendeld en aangekoppeld bij de volgende keer opstarten. Hiervoor moet mogelijk een wachtzin worden ingevoerd."
 ],
 "The fingerprint should match:": [
  null,
  "De vingerafdruk moet overeenkomen met:"
 ],
 "The initrd must be regenerated.": [
  null,
  "De initrd moet opnieuw worden gegenereerd."
 ],
 "The key password can not be empty": [
  null,
  "Het sleutelwachtwoord mag niet leeg zijn"
 ],
 "The key passwords do not match": [
  null,
  "De sleutelwachtwoorden komen niet overeen"
 ],
 "The last key slot can not be removed": [
  null,
  "De laatste sleutelslot kan niet verwijderd worden"
 ],
 "The listed processes and services will be forcefully stopped.": [
  null,
  "De vermelde processen en services worden met kracht gestopt."
 ],
 "The listed processes will be forcefully stopped.": [
  null,
  "De vermelde processen worden met kracht gestopt."
 ],
 "The listed services will be forcefully stopped.": [
  null,
  "De vermelde services worden met kracht gestopt."
 ],
 "The logged in user is not permitted to view system modifications": [
  null,
  "De ingelogde gebruiker mag geen systeemwijzigingen bekijken"
 ],
 "The mount point $0 is in use by these processes:": [
  null,
  "Het aankoppelpunt $0 is in gebruik bij deze processen:"
 ],
 "The mount point $0 is in use by these services:": [
  null,
  "Het aankoppelpunt $0 is in gebruik bij deze services:"
 ],
 "The password can not be empty": [
  null,
  "Het wachtwoord mag niet leeg zijn"
 ],
 "The resulting fingerprint is fine to share via public methods, including email.": [
  null,
  "De resulterende vingerafdruk is prima te delen via openbare methoden, inclusief e-mail."
 ],
 "The resulting fingerprint is fine to share via public methods, including email. If you are asking someone else to do the verification for you, they can send the results using any method.": [
  null,
  "De resulterende vingerafdruk kan prima worden gedeeld via openbare methoden, waaronder e-mail. Als je iemand anders vraagt om de verificatie voor je uit te voeren, kan hij of zij de resultaten op elke gewenste manier verzenden."
 ],
 "The server refused to authenticate using any supported methods.": [
  null,
  "De server weigerde te verifiëren met behulp van ondersteunde methoden."
 ],
 "The system does not currently support unlocking a filesystem with a Tang keyserver during boot.": [
  null,
  "Het systeem ondersteunt momenteel niet het ontgrendelen van een bestandssysteem met een Tang-sleutelserver tijdens het opstarten."
 ],
 "The system does not currently support unlocking the root filesystem with a Tang keyserver.": [
  null,
  "Het systeem biedt momenteel geen ondersteuning voor het ontgrendelen van het rootbestandssysteem met een Tang-sleutelserver."
 ],
 "There are devices with multiple paths on the system, but the multipath service is not running.": [
  null,
  "Er zijn apparaten met meerdere paden op het systeem, maar de multipath-service is niet actief."
 ],
 "There is not enough space available that could be used for a repair. At least $0 are needed on physical volumes that are not already used for this logical volume.": [
  null,
  "Er is niet voldoende ruimte beschikbaar die kan worden gebruikt voor een reparatie. Er is minimaal $0 nodig voor fysieke volumes die nog niet voor dit logische volume worden gebruikt."
 ],
 "These additional steps are necessary:": [
  null,
  "Deze extra stappen zijn nodig:"
 ],
 "These changes will be made:": [
  null,
  "Deze veranderingen zullen worden gemaakt:"
 ],
 "Thin logical volume": [
  null,
  "Dunne logische volume"
 ],
 "This NFS mount is in use and only its options can be changed.": [
  null,
  "Deze NFS-mount is in gebruik en alleen de opties kunnen gewijzigd worden."
 ],
 "This VDO device does not use all of its backing device.": [
  null,
  "Dit VDO-apparaat gebruikt niet al zijn achtergrondapparatuur."
 ],
 "This device is currently in use.": [
  null,
  "Dit apparaat is momenteel in gebruik."
 ],
 "This keyserver is the only way to unlock the pool and can not be removed.": [
  null,
  "Deze keyserver is de enige manier om de pool te ontgrendelen en kan niet worden verwijderd."
 ],
 "This logical volume has lost some of its physical volumes and can no longer be used. You need to delete it and create a new one to take its place.": [
  null,
  "Dit logische volume heeft een deel van zijn fysieke volumes verloren en kan niet langer worden gebruikt. Je moet het verwijderen en een nieuwe maken om zijn plaats in te nemen."
 ],
 "This logical volume has lost some of its physical volumes but has not lost any data yet. You should repair it to restore its original redundancy.": [
  null,
  "Dit logische volume heeft een deel van zijn fysieke volumes verloren, maar nog geen data. Je moet het repareren om de oorspronkelijke redundantie te herstellen."
 ],
 "This logical volume has lost some of its physical volumes but might not have lost any data yet. You might be able to repair it.": [
  null,
  "Dit logische volume heeft een deel van zijn fysieke volumes verloren, maar mogelijk nog geen data. Misschien kun je het repareren."
 ],
 "This logical volume is not completely used by its content.": [
  null,
  "Dit logische volume wordt niet volledig gebruikt door de inhoud."
 ],
 "This partition is not completely used by its content.": [
  null,
  "Deze partitie wordt niet volledig gebruikt door de inhoud ervan."
 ],
 "This passphrase is the only way to unlock the pool and can not be removed.": [
  null,
  "Deze wachtzin is de enige manier om de pool te ontgrendelen en kan niet worden verwijderd."
 ],
 "This pool does not use all the space on its block devices.": [
  null,
  "Deze pool gebruikt niet alle ruimte op zijn blokapparaten."
 ],
 "This pool is in a degraded state.": [
  null,
  "Deze pool bevindt zich in een slechte staat."
 ],
 "This tool configures the SELinux policy and can help with understanding and resolving policy violations.": [
  null,
  "Dit gereedschap configureert het SELinux-beleid en kan helpen bij het begrijpen en oplossen van beleidsschendingen."
 ],
 "This tool generates an archive of configuration and diagnostic information from the running system. The archive may be stored locally or centrally for recording or tracking purposes or may be sent to technical support representatives, developers or system administrators to assist with technical fault-finding and debugging.": [
  null,
  "Dit gereedschap genereert een archief met configuratie- en diagnostische informatie van het draaiende systeem. Het archief kan lokaal of centraal worden opgeslagen voor opname- of trackingsoeleinden of kan worden verzonden naar vertegenwoordigers van de technische ondersteuning, ontwikkelaars of systeembeheerders om te helpen bij het opsporen van technische fouten en het debuggen."
 ],
 "This tool manages local storage, such as filesystems, LVM2 volume groups, and NFS mounts.": [
  null,
  "Dit gereedschap beheert lokale opslag, zoals bestandssystemen, LVM2-volumegroepen en NFS-koppelingen."
 ],
 "This tool manages networking such as bonds, bridges, teams, VLANs and firewalls using NetworkManager and Firewalld. NetworkManager is incompatible with Ubuntu's default systemd-networkd and Debian's ifupdown scripts.": [
  null,
  "Dit gereedschap beheert netwerken zoals bindingen, bruggen, teams, VLAN's en firewalls met behulp van NetworkManager en Firewalld. NetworkManager is niet compatibel met Ubuntu's standaard systemd-networkd en Debian's ifupdown-scripts."
 ],
 "This volume group is missing some physical volumes.": [
  null,
  "Bij deze volumegroep ontbreken enkele fysieke volumes."
 ],
 "Tier": [
  null,
  "Niveau"
 ],
 "Time zone": [
  null,
  "Tijdzone"
 ],
 "To ensure that your connection is not intercepted by a malicious third-party, please verify the host key fingerprint:": [
  null,
  "Controleer de vingerafdruk van de hostsleutel om ervoor te zorgen dat je verbinding niet wordt onderschept door een kwaadwillende derde partij:"
 ],
 "To verify a fingerprint, run the following on $0 while physically sitting at the machine or through a trusted network:": [
  null,
  "Om een vingerafdruk te verifiëren, voer je het volgende uit op $0 terwijl je fysiek achter de machine zit of via een vertrouwd netwerk:"
 ],
 "Toggle date picker": [
  null,
  "Datumkiezer omschakelen"
 ],
 "Too much data": [
  null,
  "Teveel data"
 ],
 "Total size: $0": [
  null,
  "Totale grootte: $0"
 ],
 "Tower": [
  null,
  "Toren"
 ],
 "Trust and add host": [
  null,
  "Vertrouw en voeg host toe"
 ],
 "Trust key": [
  null,
  "Vertrouwenssleutel"
 ],
 "Trying to synchronize with $0": [
  null,
  "Bezig met synchroniseren met $0"
 ],
 "Type": [
  null,
  "Type"
 ],
 "Type must be of the form NNNNNNNN-NNNN-NNNN-NNNN-NNNNNNNNNNNN.": [
  null,
  "Het type moet in de vorm zijn van NNNNNNNN-NNNN-NNNN-NNNN-NNNNNNNNNNNN."
 ],
 "Type must contain exactly two hexadecimal characters (0 to 9, A to F).": [
  null,
  "Het type moet precies twee hexadecimale tekens bevatten (0 tot en met 9, A tot en met F)."
 ],
 "UUID": [
  null,
  "UUID"
 ],
 "Unable to log in to $0. The host does not accept password login or any of your SSH keys.": [
  null,
  "Kan niet inloggen op $0. De host accepteert geen aanmelden met wachtwoord of een van je SSH-sleutels."
 ],
 "Unable to reach server": [
  null,
  "Kan server niet bereiken"
 ],
 "Unable to remove mount": [
  null,
  "Kan aankoppeling niet verwijderen"
 ],
 "Unable to repair logical volume $0": [
  null,
  "Kan logische volume $0 niet repareren"
 ],
 "Unable to unmount filesystem": [
  null,
  "Kan bestandssysteem niet afkoppelen"
 ],
 "Unexpected PackageKit error during installation of $0: $1": [
  null,
  "Onverwachte PackageKit-fout tijdens installatie van $0: $1"
 ],
 "Unknown": [
  null,
  "Onbekend"
 ],
 "Unknown ($0)": [
  null,
  "Onbekend ($0)"
 ],
 "Unknown host name": [
  null,
  "Onbekende hostnaam"
 ],
 "Unknown type": [
  null,
  "Onbekend type"
 ],
 "Unlock": [
  null,
  "Ontgrendelen"
 ],
 "Unlock automatically on boot": [
  null,
  "Automatisch ontgrendelen bij opstarten"
 ],
 "Unlock before resizing": [
  null,
  "Ontgrendelen voordat het formaat wijzigt"
 ],
 "Unlock encrypted Stratis pool": [
  null,
  "Ontgrendel versleutelde Stratis pool"
 ],
 "Unlocking $target": [
  null,
  "Ontgrendelen $target"
 ],
 "Unlocking disk": [
  null,
  "Schijf ontgrendelen"
 ],
 "Unmount": [
  null,
  "Afkoppelen"
 ],
 "Unmount filesystem $0": [
  null,
  "Bestandssysteem $0 afkoppelen"
 ],
 "Unmount now": [
  null,
  "Nu afkoppelen"
 ],
 "Unmounting $target": [
  null,
  "$target afkoppelen"
 ],
 "Unrecognized data": [
  null,
  "Onbekende data"
 ],
 "Unrecognized data can not be made smaller here.": [
  null,
  "Onbekende data kan hier niet kleiner gemaakt worden."
 ],
 "Untrusted host": [
  null,
  "Niet vertrouwde host"
 ],
 "Usage": [
  null,
  "Gebruik"
 ],
 "Usage of $0": [
  null,
  "Gebruik van $0"
 ],
 "Use": [
  null,
  "Gebruik"
 ],
 "Use compression": [
  null,
  "Gebruik compressie"
 ],
 "Use deduplication": [
  null,
  "Gebruik deduplicatie"
 ],
 "Used": [
  null,
  "Gebruikt"
 ],
 "Useful for mounts that are optional or need interaction (such as passphrases)": [
  null,
  "Handig voor aankoppelingen die optioneel zijn of interactie nodig hebben (zoals wachtwoordzinnen)"
 ],
 "User": [
  null,
  "Gebruiker"
 ],
 "Username": [
  null,
  "Gebruikersnaam"
 ],
 "VDO backing devices can not be made smaller": [
  null,
  "VDO-ondersteuningsapparaten kunnen niet kleiner gemaakt worden"
 ],
 "VDO device $0": [
  null,
  "VDO-apparaat $0"
 ],
 "VDO filesystem volume (compression/deduplication)": [
  null,
  "VDO-bestandssysteemvolume (compressie/deduplicatie)"
 ],
 "Vendor": [
  null,
  "Leverancier"
 ],
 "Verify fingerprint": [
  null,
  "Vingerafdruk verifiëren"
 ],
 "Verify key": [
  null,
  "Verifieer sleutel"
 ],
 "Very securely erasing $target": [
  null,
  "Zeer veilig wissen van $target"
 ],
 "View all logs": [
  null,
  "Bekijk alle logboeken"
 ],
 "View automation script": [
  null,
  "Bekijk automatiseringsscript"
 ],
 "View logs": [
  null,
  "Bekijk logboeken"
 ],
 "Virtual filesystem sizes are larger than the pool. Overprovisioning can not be disabled.": [
  null,
  "De grootte van het virtuele bestandssysteem is groter dan de pool. Overprovisioning kan niet worden uitgeschakeld."
 ],
 "Visit firewall": [
  null,
  "Bezoek firewall"
 ],
 "Volatile memory backup failed": [
  null,
  "Vluchtige geheugenback-up mislukt"
 ],
 "Volume group": [
  null,
  "Volumegroep"
 ],
 "Volume size is $0. Content size is $1.": [
  null,
  "Volumegrootte is $0. Inhoudsgrootte is $1."
 ],
 "Waiting for other software management operations to finish": [
  null,
  "Wachten tot andere softwarebeheerhandelingen voltooid zijn"
 ],
 "Weak password": [
  null,
  "Zwak wachtwoord"
 ],
 "Web Console for Linux servers": [
  null,
  "Webconsole voor Linux-servers"
 ],
 "Write-mostly": [
  null,
  "Meestal-schrijven"
 ],
 "Writing": [
  null,
  "Schrijven"
 ],
 "You are connecting to $0 for the first time.": [
  null,
  "Je maakt voor de eerste keer verbinding met $0."
 ],
 "Your browser does not allow paste from the context menu. You can use Shift+Insert.": [
  null,
  "Je browser staat plakken vanuit het contextmenu niet toe. Je kunt Shift+Insert gebruiken."
 ],
 "Your session has been terminated.": [
  null,
  "Je sessie is beëindigd."
 ],
 "Your session has expired. Please log in again.": [
  null,
  "Je sessie is verlopen. Log nogmaals in."
 ],
 "Zone": [
  null,
  "Zone"
 ],
 "[binary data]": [
  null,
  "[binaire data]"
 ],
 "[no data]": [
  null,
  "[geen data]"
 ],
 "after network": [
  null,
  "na netwerk"
 ],
 "backing device for VDO device": [
  null,
  "steunapparaat voor VDO-apparaat"
 ],
 "btrfs subvolume $0 of $1": [
  null,
  "btrfs subvolume $0 van $1"
 ],
 "delete": [
  null,
  "verwijderen"
 ],
 "device of btrfs volume": [
  null,
  "apparaat van btrfs volume"
 ],
 "edit": [
  null,
  "bewerken"
 ],
 "format": [
  null,
  "formatteren"
 ],
 "grow": [
  null,
  "toenemen"
 ],
 "ignore failure": [
  null,
  "negeer mislukken"
 ],
 "in less than a minute": [
  null,
  "in minder dan een minuut"
 ],
 "initialize": [
  null,
  "initialiseren"
 ],
 "less than a minute ago": [
  null,
  "minder dan een minuut geleden"
 ],
 "member of Stratis pool": [
  null,
  "onderdeel van Stratis-pool"
 ],
 "mount": [
  null,
  "aankoppelen"
 ],
 "never mount at boot": [
  null,
  "nooit aankoppelen tijdens opstarten"
 ],
 "none": [
  null,
  "geen"
 ],
 "password quality": [
  null,
  "wachtwoordkwaliteit"
 ],
 "physical volume of LVM2 volume group": [
  null,
  "fysieke volume van LVM2-volumegroep"
 ],
 "read only": [
  null,
  "alleen-lezen"
 ],
 "remove from LVM2": [
  null,
  "verwijderen uit LVM2"
 ],
 "show less": [
  null,
  "toon minder"
 ],
 "show more": [
  null,
  "toon meer"
 ],
 "shrink": [
  null,
  "krimpen"
 ],
 "stop": [
  null,
  "stop"
 ],
 "stop boot on failure": [
  null,
  "stop opstarten bij mislukken"
 ],
 "unknown target": [
  null,
  "onbekend doel"
 ],
 "unmount": [
  null,
  "afkoppelen"
 ],
 "unpartitioned space on $0": [
  null,
  "niet-gepartitioneerde ruimte op $0"
 ],
 "using key description $0": [
  null,
  "gebruik sleutelbeschrijving $0"
 ],
 "yes": [
  null,
  "ja"
 ],
 "format-bytes\u0004bytes": [
  null,
  "bytes"
 ]
});
