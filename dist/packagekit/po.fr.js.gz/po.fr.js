cockpit.locale({
 "": {
  "plural-forms": (n) => n > 1,
  "language": "fr",
  "language-direction": "ltr"
 },
 "$0 GiB": [
  null,
  "$0 GiB"
 ],
 "$0 day": [
  null,
  "$0 jour",
  "$0 jours"
 ],
 "$0 exited with code $1": [
  null,
  "$0 quitté avec le code $1"
 ],
 "$0 failed": [
  null,
  "$0 échoué"
 ],
 "$0 hour": [
  null,
  "$0 heure",
  "$0 heures"
 ],
 "$0 is not available from any repository.": [
  null,
  "$0 n’est disponible dans aucun référentiel."
 ],
 "$0 key changed": [
  null,
  "$0 clé modifiée"
 ],
 "$0 killed with signal $1": [
  null,
  "$0 killed avec un signal $1"
 ],
 "$0 minute": [
  null,
  "$0 minute",
  "$0 minutes"
 ],
 "$0 month": [
  null,
  "$0 mois",
  "$0 mois"
 ],
 "$0 package": [
  null,
  "$0 paquet",
  "$0 paquets"
 ],
 "$0 package needs a system reboot": [
  null,
  "$0 le paquet a besoin d’un redémarrage du système",
  "$0 les paquets doivent être redémarrés"
 ],
 "$0 security fix available": [
  null,
  "$0 correctif de sécurité disponible",
  "$0 correctifs de sécurité disponibles"
 ],
 "$0 service needs to be restarted": [
  null,
  "$0 le service doit être relancé",
  "$0 les services doivent être redémarrés"
 ],
 "$0 update available": [
  null,
  "$0 mise à jour disponible",
  "$0 mises à jour disponibles"
 ],
 "$0 week": [
  null,
  "$0 semaine",
  "$0 semaines"
 ],
 "$0 will be installed.": [
  null,
  "$0 sera installé."
 ],
 "$0 year": [
  null,
  "$0 an",
  "$0 ans"
 ],
 ", including $1 security fix": [
  null,
  ", y compris $1 correctif de sécurité",
  ", y compris $1 correctifs de sécurité"
 ],
 "1 day": [
  null,
  "1 jour"
 ],
 "1 hour": [
  null,
  "1 heure"
 ],
 "1 minute": [
  null,
  "1 minute"
 ],
 "1 week": [
  null,
  "1 semaine"
 ],
 "20 minutes": [
  null,
  "20 minutes"
 ],
 "40 minutes": [
  null,
  "40 minutes"
 ],
 "5 minutes": [
  null,
  "5 minutes"
 ],
 "6 hours": [
  null,
  "6 heures"
 ],
 "60 minutes": [
  null,
  "60 minutes"
 ],
 "A compatible version of Cockpit is not installed on $0.": [
  null,
  "Une version compatible de Cockpit n’est pas installée sur $0."
 ],
 "A new SSH key at $0 will be created for $1 on $2 and it will be added to the $3 file of $4 on $5.": [
  null,
  "Une nouvelle clé SSH à $0 sera créée pour $1 sur $2 et elle sera ajoutée au fichier $3 de $4 sur $5."
 ],
 "A package needs a system reboot for the updates to take effect:": [
  null,
  "Un paquet nécessite un redémarrage du système pour que les mises à jour prennent effet :",
  "Certains paquets nécessitent un redémarrage du système pour que les mises à jour prennent effet :"
 ],
 "A service needs to be restarted for the updates to take effect:": [
  null,
  "Un service doit être redémarré pour que les mises à jour prennent effet :",
  "Certains services doivent être redémarrés pour que les mises à jour prennent effet :"
 ],
 "Absent": [
  null,
  "Absent"
 ],
 "Acceptable password": [
  null,
  "Mot de passe acceptable"
 ],
 "Add $0": [
  null,
  "Ajouter $0"
 ],
 "Additional packages:": [
  null,
  "Paquets supplémentaires :"
 ],
 "Administration with Cockpit Web Console": [
  null,
  "Administration avec la console web de Cockpit"
 ],
 "Advanced TCA": [
  null,
  "TCA avancé"
 ],
 "All updates": [
  null,
  "Toutes les mises à jour"
 ],
 "All-in-one": [
  null,
  "Tout en un"
 ],
 "Ansible": [
  null,
  "Ansible"
 ],
 "Ansible roles documentation": [
  null,
  "Documentation des rôles Ansible"
 ],
 "Apply kernel live patches": [
  null,
  "Appliquer les correctifs à chaud du noyau"
 ],
 "Applying updates": [
  null,
  "Application des mises à jour"
 ],
 "Applying updates failed": [
  null,
  "L’application des mises à jour a échoué"
 ],
 "Authentication": [
  null,
  "Authentification"
 ],
 "Authentication is required to perform privileged tasks with the Cockpit Web Console": [
  null,
  "Une authentification est nécessaire pour effectuer les tâches privilégiées dans la console web Cockpit"
 ],
 "Authorize SSH key": [
  null,
  "Autoriser la clé SSH"
 ],
 "Automatic updates": [
  null,
  "Mises à jour automatiques"
 ],
 "Automatically using NTP": [
  null,
  "Utiliser automatiquement NTP"
 ],
 "Automatically using additional NTP servers": [
  null,
  "Utilisation automatique de serveurs NTP supplémentaires"
 ],
 "Automatically using specific NTP servers": [
  null,
  "Utiliser automatiquement des serveurs NTP spécifiques"
 ],
 "Automation script": [
  null,
  "Script d’automatisation"
 ],
 "Available updates": [
  null,
  "Mises à jour disponibles"
 ],
 "Blade": [
  null,
  "Lame"
 ],
 "Blade enclosure": [
  null,
  "Boîtier en lame"
 ],
 "Bug fix updates available": [
  null,
  "Mises à jour des corrections de bogues disponibles"
 ],
 "Bugs": [
  null,
  "Anomalies"
 ],
 "Bus expansion chassis": [
  null,
  "Châssis d’extension de bus"
 ],
 "CVE": [
  null,
  "CVE"
 ],
 "Cancel": [
  null,
  "Annuler"
 ],
 "Cannot forward login credentials": [
  null,
  "Impossible de transférer les identifiants de connexion"
 ],
 "Cannot schedule event in the past": [
  null,
  "Impossible de planifier un événement dans le passé"
 ],
 "Change": [
  null,
  "Modifier"
 ],
 "Change system time": [
  null,
  "Modifier l’heure du système"
 ],
 "Changed keys are often the result of an operating system reinstallation. However, an unexpected change may indicate a third-party attempt to intercept your connection.": [
  null,
  "Les changements de clés sont souvent le résultat d’une réinstallation du système d’exploitation. Cependant, un changement inattendu peut indiquer une tentative d’interception de votre connexion par un tiers."
 ],
 "Check for updates": [
  null,
  "Vérifier les mises à jour"
 ],
 "Checking for package updates...": [
  null,
  "Vérification des mises à jour des paquets..."
 ],
 "Checking installed software": [
  null,
  "Vérification des logiciels installés"
 ],
 "Checking software status": [
  null,
  "Vérification de l’état des logiciels"
 ],
 "Clear input value": [
  null,
  "Effacer la valeur saisie"
 ],
 "Close": [
  null,
  "Fermer"
 ],
 "Cockpit": [
  null,
  "Cockpit"
 ],
 "Cockpit configuration of NetworkManager and Firewalld": [
  null,
  "Configuration du cockpit de NetworkManager et Firewalld"
 ],
 "Cockpit could not contact the given host.": [
  null,
  "Cockpit n’a pas pu contacter l’hôte indiqué."
 ],
 "Cockpit is a server manager that makes it easy to administer your Linux servers via a web browser. Jumping between the terminal and the web tool is no problem. A service started via Cockpit can be stopped via the terminal. Likewise, if an error occurs in the terminal, it can be seen in the Cockpit journal interface.": [
  null,
  "Cockpit est un gestionnaire de serveur qui facilite l’administration de vos serveurs Linux via un navigateur Web. Sauter entre le terminal et l’outil web n’est pas un problème. Un service démarré via Cockpit peut être arrêté via le terminal. De même, si une erreur se produit dans le terminal, elle s’affiche dans l’interface du journal Cockpit."
 ],
 "Cockpit is not compatible with the software on the system.": [
  null,
  "Cockpit n’est pas compatible avec le logiciel sur le système."
 ],
 "Cockpit is not installed": [
  null,
  "Cockpit n’est pas installé"
 ],
 "Cockpit is not installed on the system.": [
  null,
  "Cockpit n’est pas installé sur le système."
 ],
 "Cockpit is perfect for new sysadmins, allowing them to easily perform simple tasks such as storage administration, inspecting journals and starting and stopping services. You can monitor and administer several servers at the same time. Just add them with a single click and your machines will look after its buddies.": [
  null,
  "Cockpit est parfait pour les nouveaux administrateurs système, leur permettant d’effectuer facilement des tâches simples telles que l’administration du stockage, l’inspection des journaux, le démarrage et l’arrêt des services. Vous pouvez surveiller et administrer plusieurs serveurs en même temps. Il suffit de les ajouter en un seul clic et vos machines s’occuperont de leurs pairs."
 ],
 "Collect and package diagnostic and support data": [
  null,
  "Collecte et regroupement des données de diagnostic et d'assistance"
 ],
 "Collect kernel crash dumps": [
  null,
  "Collecter les vidages de mémoire sur incidents du noyau"
 ],
 "Compact PCI": [
  null,
  "PCI compact"
 ],
 "Confirm key password": [
  null,
  "Confirmer le mot de passe de la clé"
 ],
 "Connection has timed out.": [
  null,
  "La connexion a expiré."
 ],
 "Continue": [
  null,
  "Poursuivre"
 ],
 "Convertible": [
  null,
  "Convertible"
 ],
 "Copied": [
  null,
  "Copié"
 ],
 "Copy": [
  null,
  "Copier"
 ],
 "Copy to clipboard": [
  null,
  "Copier dans le presse-papier"
 ],
 "Create $0": [
  null,
  "Créer $0"
 ],
 "Create a new SSH key and authorize it": [
  null,
  "Créer une nouvelle clé SSH et l’autoriser"
 ],
 "Create new task file with this content.": [
  null,
  "Créez un nouveau fichier de tâches avec ce contenu."
 ],
 "Ctrl+Insert": [
  null,
  "Ctrl+Inser"
 ],
 "Danger alert:": [
  null,
  "Alerte de danger :"
 ],
 "Delay": [
  null,
  "Retard"
 ],
 "Desktop": [
  null,
  "Bureau"
 ],
 "Detachable": [
  null,
  "Détachable"
 ],
 "Details": [
  null,
  "Détails"
 ],
 "Diagnostic reports": [
  null,
  "Rapports de diagnostic"
 ],
 "Disabled": [
  null,
  "Désactivé"
 ],
 "Docking station": [
  null,
  "Station d’accueil"
 ],
 "Downloaded": [
  null,
  "Téléchargé"
 ],
 "Downloading": [
  null,
  "Téléchargement"
 ],
 "Downloading $0": [
  null,
  "Téléchargement de $0"
 ],
 "Dual rank": [
  null,
  "Double rang"
 ],
 "Edit": [
  null,
  "Modifier"
 ],
 "Embedded PC": [
  null,
  "PC intégré"
 ],
 "Enable": [
  null,
  "Activer"
 ],
 "Enabled": [
  null,
  "Activée"
 ],
 "Enhancement updates available": [
  null,
  "Mises à jour des améliorations disponibles"
 ],
 "Errata": [
  null,
  "Errata"
 ],
 "Excellent password": [
  null,
  "Mot de passe excellent"
 ],
 "Expansion chassis": [
  null,
  "Châssis d’extension"
 ],
 "Failed to change password": [
  null,
  "Échec de la modification du mot de passe"
 ],
 "Failed to enable $0 in firewalld": [
  null,
  "Échec de l’activation $0 dans firewalld"
 ],
 "Failed to parse unit files for dnf-automatic.timer or dnf-automatic-install.timer. Please remove custom overrides to configure automatic updates.": [
  null,
  "Échec de l’analyse des fichiers unitaires pour dnf-automatic.timer ou dnf-automatic-install.timer. Veuillez supprimer les remplacements personnalisés pour configurer les mises à jour automatiques."
 ],
 "Failed to restart service": [
  null,
  "Échec du redémarrage du service"
 ],
 "Fridays": [
  null,
  "Vendredis"
 ],
 "Go to now": [
  null,
  "Aller à maintenant"
 ],
 "Handheld": [
  null,
  "Portable"
 ],
 "Hide confirmation password": [
  null,
  "Masquer le mot de passe de confirmation"
 ],
 "Hide password": [
  null,
  "Masquer le mot de passe"
 ],
 "History package count": [
  null,
  "Comptage des paquets d’historique"
 ],
 "Host key is incorrect": [
  null,
  "La clé de l’hôte est incorrecte"
 ],
 "If the fingerprint matches, click 'Trust and add host'. Otherwise, do not connect and contact your administrator.": [
  null,
  "Si l’empreinte digitale correspond, cliquez sur « Accepter la clé et ajouter l'hôte ». Sinon, ne vous connectez pas et contactez votre administrateur."
 ],
 "Ignore": [
  null,
  "Ignorer"
 ],
 "Info": [
  null,
  "Info"
 ],
 "Initializing...": [
  null,
  "Initialisation..."
 ],
 "Install": [
  null,
  "Installer"
 ],
 "Install all updates": [
  null,
  "Installer toutes les mises à jour"
 ],
 "Install kpatch updates": [
  null,
  "Installer les mises à jour de kpatch"
 ],
 "Install security updates": [
  null,
  "Installer les mises à jour de sécurité"
 ],
 "Install software": [
  null,
  "Installer le logiciel"
 ],
 "Installed": [
  null,
  "installée"
 ],
 "Installing": [
  null,
  "Installation"
 ],
 "Installing $0": [
  null,
  "Installation de $0"
 ],
 "Internal error": [
  null,
  "Erreur interne"
 ],
 "Invalid date format": [
  null,
  "Format de date non valide"
 ],
 "Invalid date format and invalid time format": [
  null,
  "Format de date non valide et format d’heure non valide"
 ],
 "Invalid file permissions": [
  null,
  "Les autorisations de fichier ne sont pas valides"
 ],
 "Invalid time format": [
  null,
  "Format d’heure non valide"
 ],
 "Invalid timezone": [
  null,
  "Fuseau horaire incorrect"
 ],
 "IoT gateway": [
  null,
  "Passerelle IoT"
 ],
 "Kernel dump": [
  null,
  "Kernel Dump"
 ],
 "Kernel live patch $0 is active": [
  null,
  "Le correctif à chaud du noyau $0 est actif"
 ],
 "Kernel live patch $0 is installed": [
  null,
  "Le correctif à chaud du noyau $0 est installé"
 ],
 "Kernel live patch settings": [
  null,
  "Paramètres des correctifs à chaud du noyau"
 ],
 "Kernel live patching": [
  null,
  "Corrections à chaud du noyau"
 ],
 "Key password": [
  null,
  "Mot de passe clé"
 ],
 "Laptop": [
  null,
  "Portable"
 ],
 "Last checked: $0": [
  null,
  "Dernière vérification : $0"
 ],
 "Learn more": [
  null,
  "En savoir plus"
 ],
 "Loading available updates failed": [
  null,
  "Le chargement des mises à jour disponibles a échoué"
 ],
 "Loading available updates, please wait...": [
  null,
  "Le chargement des mises à jour disponibles est en cours, veuillez patienter..."
 ],
 "Loading system modifications...": [
  null,
  "Chargement des modifications système..."
 ],
 "Log in": [
  null,
  "Connexion"
 ],
 "Log in to $0": [
  null,
  "Connectez-vous à $0"
 ],
 "Log messages": [
  null,
  "Enregistrer les messages"
 ],
 "Login failed": [
  null,
  "Échec de la connexion"
 ],
 "Low profile desktop": [
  null,
  "Bureau de profil bas"
 ],
 "Lunch box": [
  null,
  "Lunch Box"
 ],
 "Main server chassis": [
  null,
  "Châssis principal du serveur"
 ],
 "Manage storage": [
  null,
  "Gérer le stockage"
 ],
 "Manually": [
  null,
  "Manuellement"
 ],
 "Message to logged in users": [
  null,
  "Message aux utilisateurs connectés"
 ],
 "Mini PC": [
  null,
  "Mini PC"
 ],
 "Mini tower": [
  null,
  "Mini Tour"
 ],
 "Mondays": [
  null,
  "lundis"
 ],
 "More info...": [
  null,
  "Plus d’infos..."
 ],
 "Multi-system chassis": [
  null,
  "Châssis multi-système"
 ],
 "NTP server": [
  null,
  "Serveur NTP"
 ],
 "Name": [
  null,
  "Nom"
 ],
 "Need at least one NTP server": [
  null,
  "Besoin d’au moins un serveur NTP"
 ],
 "Networking": [
  null,
  "Réseau"
 ],
 "New password was not accepted": [
  null,
  "Le nouveau mot de passe n’a pas été accepté"
 ],
 "No delay": [
  null,
  "Aucun délai"
 ],
 "No results found": [
  null,
  "Aucun résultat trouvé"
 ],
 "No such file or directory": [
  null,
  "Aucun fichier ou répertoire de ce nom"
 ],
 "No system modifications": [
  null,
  "Aucune modification système"
 ],
 "No updates": [
  null,
  "Pas de mise à jour"
 ],
 "Not a valid private key": [
  null,
  "Clé privée non valide"
 ],
 "Not available": [
  null,
  "Indisponible"
 ],
 "Not installed": [
  null,
  "Non installé"
 ],
 "Not permitted to perform this action.": [
  null,
  "Non autorisé à effectuer cette action."
 ],
 "Not registered": [
  null,
  "Non inscrit"
 ],
 "Not set up": [
  null,
  "Non défini"
 ],
 "Not synchronized": [
  null,
  "Non synchronisé"
 ],
 "Notebook": [
  null,
  "Ordinateur portable"
 ],
 "Occurrences": [
  null,
  "Occurrences"
 ],
 "Ok": [
  null,
  "Ok"
 ],
 "Old password not accepted": [
  null,
  "Ancien mot de passe non accepté"
 ],
 "Once Cockpit is installed, enable it with \"systemctl enable --now cockpit.socket\".": [
  null,
  "Une fois que Cockpit est installé, l’activer avec « systemctl enable --now cockpit.socket »."
 ],
 "Other": [
  null,
  "Autre"
 ],
 "Package information": [
  null,
  "Informations sur le paquet"
 ],
 "PackageKit crashed": [
  null,
  "Plantage de « PackageKit »"
 ],
 "PackageKit is not installed": [
  null,
  "PackageKit non installé"
 ],
 "PackageKit reported error code $0": [
  null,
  "PackageKit a signalé le code d’erreur $0"
 ],
 "Packages": [
  null,
  "Paquets"
 ],
 "Password": [
  null,
  "Mot de passe"
 ],
 "Password is not acceptable": [
  null,
  "Le mot de passe n’est pas acceptable"
 ],
 "Password is too weak": [
  null,
  "Le mot de passe est trop faible"
 ],
 "Password not accepted": [
  null,
  "Mot de passe non accepté"
 ],
 "Paste": [
  null,
  "Coller"
 ],
 "Paste error": [
  null,
  "Erreur de collage"
 ],
 "Path to file": [
  null,
  "Chemin d’accès au fichier"
 ],
 "Peripheral chassis": [
  null,
  "Châssis périphérique"
 ],
 "Pick date": [
  null,
  "Choisissez une date"
 ],
 "Pizza box": [
  null,
  "Pizza Box"
 ],
 "Please resolve the issue and reload this page.": [
  null,
  "Veuillez résoudre le problème et recharger cette page."
 ],
 "Portable": [
  null,
  "Portable"
 ],
 "Present": [
  null,
  "Présent"
 ],
 "Prompting via ssh-add timed out": [
  null,
  "L’invite via ssh-add a expiré"
 ],
 "Prompting via ssh-keygen timed out": [
  null,
  "L’invite via ssh-keygen a expiré"
 ],
 "RAID chassis": [
  null,
  "Châssis RAID"
 ],
 "Rack mount chassis": [
  null,
  "Châssis de montage en rack"
 ],
 "Reboot": [
  null,
  "Redémarrer"
 ],
 "Reboot after completion": [
  null,
  "Redémarrage une fois terminé"
 ],
 "Reboot recommended": [
  null,
  "Redémarrage recommandé"
 ],
 "Reboot system...": [
  null,
  "Redémarrer le système..."
 ],
 "Refreshing package information": [
  null,
  "Actualisation des informations du paquet"
 ],
 "Register…": [
  null,
  "Enregistrement…"
 ],
 "Reloading the state of remaining services": [
  null,
  "Recharger l’état des services restants"
 ],
 "Removals:": [
  null,
  "Suppressions :"
 ],
 "Removing $0": [
  null,
  "Suppression de $0"
 ],
 "Restart services": [
  null,
  "Redémarrage des services"
 ],
 "Restart services...": [
  null,
  "Redémarrer les services..."
 ],
 "Restarting": [
  null,
  "Redémarrage"
 ],
 "Row expansion": [
  null,
  "Agrandissement de ligne"
 ],
 "Row select": [
  null,
  "Sélection de ligne"
 ],
 "Run this command over a trusted network or physically on the remote machine:": [
  null,
  "Exécutez cette commande sur un réseau de confiance ou en la tapant physiquement sur la machine distante :"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "SSH key": [
  null,
  "Clé SSH"
 ],
 "SSH key login": [
  null,
  "Connexion par clé SSH"
 ],
 "Saturdays": [
  null,
  "Samedis"
 ],
 "Save": [
  null,
  "Enregistrer"
 ],
 "Save changes": [
  null,
  "Enregistrer les modifications"
 ],
 "Sealed-case PC": [
  null,
  "PC scellé"
 ],
 "Security Enhanced Linux configuration and troubleshooting": [
  null,
  "Configuration et dépannage de Linux avec renforcement de la sécurité"
 ],
 "Security updates available": [
  null,
  "Mises à jour de sécurité disponibles"
 ],
 "Security updates only": [
  null,
  "Mises à jour de sécurité uniquement"
 ],
 "Security updates will be applied $0 at $1": [
  null,
  "Les mises à jour de sécurité seront appliquées $0 à $1"
 ],
 "Select an option": [
  null,
  "Sélectionner une option"
 ],
 "Server has closed the connection.": [
  null,
  "Le serveur a fermé la connexion."
 ],
 "Set time": [
  null,
  "Régler l’heure"
 ],
 "Set up": [
  null,
  "Installation"
 ],
 "Setting up": [
  null,
  "Mise en place"
 ],
 "Settings": [
  null,
  "Paramètres"
 ],
 "Severity": [
  null,
  "Gravité"
 ],
 "Shell script": [
  null,
  "Script shell"
 ],
 "Shift+Insert": [
  null,
  "Maj+Inser"
 ],
 "Show confirmation password": [
  null,
  "Afficher le mot de passe de confirmation"
 ],
 "Show password": [
  null,
  "Afficher le mot de passe"
 ],
 "Shut down": [
  null,
  "Fermeture"
 ],
 "Single rank": [
  null,
  "Rang unique"
 ],
 "Software updates": [
  null,
  "Mises à jour de logiciel"
 ],
 "Some other program is currently using the package manager, please wait...": [
  null,
  "Un autre programme utilise actuellement le gestionnaire de paquets, veuillez patienter..."
 ],
 "Some software needs to be restarted manually": [
  null,
  "Certains logiciels doivent être redémarrés manuellement"
 ],
 "Space-saving computer": [
  null,
  "Ordinateur gain de place"
 ],
 "Specific time": [
  null,
  "Temps spécifique"
 ],
 "Status": [
  null,
  "État"
 ],
 "Stick PC": [
  null,
  "Stick PC"
 ],
 "Storage": [
  null,
  "Stockage"
 ],
 "Strong password": [
  null,
  "Mot de passe fort"
 ],
 "Sub-Chassis": [
  null,
  "Sous-châssis"
 ],
 "Sub-Notebook": [
  null,
  "Sub-Notebook"
 ],
 "Sundays": [
  null,
  "Dimanches"
 ],
 "Synchronized": [
  null,
  "Synchronisé"
 ],
 "Synchronized with $0": [
  null,
  "Synchronisé avec $0"
 ],
 "Synchronizing": [
  null,
  "Synchronisation"
 ],
 "System is up to date": [
  null,
  "Le système est à jour"
 ],
 "Tablet": [
  null,
  "Tablette"
 ],
 "The SSH key $0 of $1 on $2 will be added to the $3 file of $4 on $5.": [
  null,
  "La clé SSH $0 de $1 sur $2 sera ajoutée au fichier $3 de $4 sur $5."
 ],
 "The SSH key $0 will be made available for the remainder of the session and will be available for login to other hosts as well.": [
  null,
  "La clé SSH $0 sera disponible pour le reste de la session et sera également disponible pour la connexion à d’autres hôtes."
 ],
 "The SSH key for logging in to $0 is protected by a password, and the host does not allow logging in with a password. Please provide the password of the key at $1.": [
  null,
  "La clé SSH permettant de se connecter à $0 est protégée par un mot de passe, et l’hôte ne permet pas de se connecter avec un mot de passe. Veuillez fournir le mot de passe de la clé à $1."
 ],
 "The SSH key for logging in to $0 is protected. You can log in with either your login password or by providing the password of the key at $1.": [
  null,
  "La clé SSH permettant de se connecter à $0 est protégée. Vous pouvez vous connecter avec votre mot de passe de connexion ou en fournissant le mot de passe de la clé à $1."
 ],
 "The fingerprint should match:": [
  null,
  "Les empreintes doivent correspondre :"
 ],
 "The following service will be restarted:": [
  null,
  "Le service suivant sera redémarré :",
  "Les services suivants seront redémarrés :"
 ],
 "The key password can not be empty": [
  null,
  "Le mot de passe de la clé ne peut pas être vide"
 ],
 "The key passwords do not match": [
  null,
  "Les mots de passe sont différents"
 ],
 "The logged in user is not permitted to view system modifications": [
  null,
  "L’utilisateur actuellement connecté n’est pas autorisé à voir les modifications système"
 ],
 "The password can not be empty": [
  null,
  "Le mot de passe ne peut pas être vide"
 ],
 "The resulting fingerprint is fine to share via public methods, including email.": [
  null,
  "L’empreinte digitale qui en résulte peut être partagée via des méthodes publiques, y compris par courrier électronique."
 ],
 "The resulting fingerprint is fine to share via public methods, including email. If you are asking someone else to do the verification for you, they can send the results using any method.": [
  null,
  "L'empreinte qui en découle peut être partagée publiquement par e-mail ou autre sans risque. Si vous demandez à quelqu'un d'autre de faire la vérification pour vous, cette personne peut vous envoyer les résultats par n'importe quel biais."
 ],
 "The server refused to authenticate using any supported methods.": [
  null,
  "Le serveur a refusé d’authentifier en utilisant des méthodes prises en charge."
 ],
 "This host will reboot after updates are installed.": [
  null,
  "Cet hôte redémarrera après l’installation des mises à jour."
 ],
 "This system is not registered": [
  null,
  "Ce système n’est pas enregistré"
 ],
 "This tool configures the SELinux policy and can help with understanding and resolving policy violations.": [
  null,
  "Cet outil configure la politique SELinux et peut aider à comprendre et à résoudre les violations de la politique."
 ],
 "This tool configures the system to write kernel crash dumps. It supports the \"local\" (disk), \"ssh\", and \"nfs\" dump targets.": [
  null,
  "Cet outil configure le système pour qu'il écrive les vidages de mémoire sur incidents du noyau. Il prend en charge les cibles \"local\" (disque), \"ssh\" et \"nfs\"."
 ],
 "This tool generates an archive of configuration and diagnostic information from the running system. The archive may be stored locally or centrally for recording or tracking purposes or may be sent to technical support representatives, developers or system administrators to assist with technical fault-finding and debugging.": [
  null,
  "Cet outil génère une archive des informations de configuration et de diagnostic du système en cours d'exécution. Ces archives peuvent être stockées localement ou centralement à des fins d'enregistrement ou de suivi, ou être envoyées aux représentants du support technique, aux développeurs ou aux administrateurs système pour les aider dans la recherche d'erreurs techniques et le débogage."
 ],
 "This tool manages local storage, such as filesystems, LVM2 volume groups, and NFS mounts.": [
  null,
  "Cet outil gère le stockage local, tel que les systèmes de fichiers, les groupes de volumes LVM2 et les montages NFS."
 ],
 "This tool manages networking such as bonds, bridges, teams, VLANs and firewalls using NetworkManager and Firewalld. NetworkManager is incompatible with Ubuntu's default systemd-networkd and Debian's ifupdown scripts.": [
  null,
  "Cet outil gère les réseaux tels que les liens, les ponts, les équipes, les VLAN et les pare-feu en utilisant NetworkManager et Firewalld. NetworkManager est incompatible avec les scripts par défaut systemd-networkd d'Ubuntu et ifupdown de Debian."
 ],
 "Thursdays": [
  null,
  "Jeudis"
 ],
 "Time": [
  null,
  "Temps"
 ],
 "Time zone": [
  null,
  "Fuseau horaire"
 ],
 "To ensure that your connection is not intercepted by a malicious third-party, please verify the host key fingerprint:": [
  null,
  "Pour vous assurer que votre connexion n’est pas interceptée par un tiers malveillant, veuillez vérifier l’empreinte de la clé de l’hôte :"
 ],
 "To get software updates, this system needs to be registered with Red Hat, either using the Red Hat Customer Portal or a local subscription server.": [
  null,
  "Pour obtenir des mises à jour logicielles, ce système doit être enregistré auprès de Red Hat, en utilisant le portail client Red Hat ou un serveur d’abonnement local."
 ],
 "To verify a fingerprint, run the following on $0 while physically sitting at the machine or through a trusted network:": [
  null,
  "Pour vérifier une empreinte digitale, exécutez les opérations suivantes sur $0 en étant physiquement assis devant la machine ou en passant par un réseau de confiance :"
 ],
 "Toggle date picker": [
  null,
  "Basculer le sélecteur de date"
 ],
 "Too much data": [
  null,
  "Trop de données"
 ],
 "Total size: $0": [
  null,
  "Taille totale : $0"
 ],
 "Tower": [
  null,
  "Tower"
 ],
 "Trust and add host": [
  null,
  "Faire confiance à l'hôte et l'ajouter"
 ],
 "Trying to synchronize with $0": [
  null,
  "Synchronisation avec $0 en cours d'essai"
 ],
 "Tuesdays": [
  null,
  "Mardis"
 ],
 "Type": [
  null,
  "Type"
 ],
 "Unable to log in to $0 using SSH key authentication. Please provide the password.": [
  null,
  "Impossible de se connecter à $0 en utilisant l'authentification par clé SSH. Veuillez fournir le mot de passe."
 ],
 "Unable to log in to $0. The host does not accept password login or any of your SSH keys.": [
  null,
  "Impossible de se connecter à $0. L’hôte n’accepte pas le mot de passe de connexion ou l’une de vos clés SSH."
 ],
 "Unavailable packages": [
  null,
  "Paquets indisponibles"
 ],
 "Unknown": [
  null,
  "Inconnu"
 ],
 "Unknown host: $0": [
  null,
  "Hôte inconnu : $0"
 ],
 "Untrusted host": [
  null,
  "Hôte non sécurisé"
 ],
 "Update Success Table": [
  null,
  "Mise à jour du tableau des réussites"
 ],
 "Update history": [
  null,
  "Mise à jour Historique"
 ],
 "Update was successful": [
  null,
  "La mise à jour est réussie"
 ],
 "Updated": [
  null,
  "Actualisé"
 ],
 "Updated packages may require a reboot to take effect.": [
  null,
  "Les paquets mis à jour peuvent nécessiter un redémarrage pour prendre effet."
 ],
 "Updates available": [
  null,
  "Mises à jour disponibles"
 ],
 "Updates history": [
  null,
  "Historique des mises à jour"
 ],
 "Updates will be applied $0 at $1": [
  null,
  "Les mises à jour seront appliquées $0 à $1"
 ],
 "Updating": [
  null,
  "Mise à jour en cours"
 ],
 "Verified": [
  null,
  "Vérifié"
 ],
 "Verify fingerprint": [
  null,
  "Vérifier l'empreinte digitale"
 ],
 "Verifying": [
  null,
  "Vérification"
 ],
 "Version": [
  null,
  "Version"
 ],
 "View all logs": [
  null,
  "Voir tous les journaux"
 ],
 "View automation script": [
  null,
  "Afficher le script d’automation"
 ],
 "View update log": [
  null,
  "Afficher le journal des mises à jour"
 ],
 "Visit firewall": [
  null,
  "Visitez le pare-feu"
 ],
 "Waiting for other software management operations to finish": [
  null,
  "Attente de la fin des autres opérations de gestion du logiciel"
 ],
 "Weak password": [
  null,
  "Mot de passe faible"
 ],
 "Web Console for Linux servers": [
  null,
  "Console web pour serveurs Linux"
 ],
 "Web Console will restart": [
  null,
  "La console Web va redémarrer"
 ],
 "Wednesdays": [
  null,
  "Mercredis"
 ],
 "When": [
  null,
  "Quand"
 ],
 "When the Web Console is restarted, you will no longer see progress information. However, the update process will continue in the background. Reconnect to continue watching the update process.": [
  null,
  "Lorsque la console Web est redémarrée, vous ne verrez plus les informations relatives à la progression. Toutefois, le processus de mise à jour se poursuivra en arrière-plan. Reconnectez-vous pour continuer à suivre le processus de mise à jour."
 ],
 "You are connecting to $0 for the first time.": [
  null,
  "Vous vous connectez à $0 pour la première fois."
 ],
 "Your browser does not allow paste from the context menu. You can use Shift+Insert.": [
  null,
  "Votre navigateur n’autorise pas le collage à partir du menu contextuel. Vous pouvez utiliser Maj+Insérer."
 ],
 "Your server will close the connection soon. You can reconnect after it has restarted.": [
  null,
  "Votre serveur fermera la connexion bientôt. Vous pouvez vous reconnecter après le redémarrage."
 ],
 "Your session has been terminated.": [
  null,
  "Votre session a été interrompue."
 ],
 "Your session has expired. Please log in again.": [
  null,
  "Votre session a expiré. Veuillez vous reconnecter."
 ],
 "Zone": [
  null,
  "Zone"
 ],
 "[binary data]": [
  null,
  "[données binaires]"
 ],
 "[no data]": [
  null,
  "[pas de données]"
 ],
 "at": [
  null,
  "à"
 ],
 "bug fix": [
  null,
  "Correctif de bogue"
 ],
 "enhancement": [
  null,
  "amélioration"
 ],
 "every Friday": [
  null,
  "tous le Vendredi"
 ],
 "every Monday": [
  null,
  "tous les Lundi"
 ],
 "every Saturday": [
  null,
  "tous les Samedi"
 ],
 "every Sunday": [
  null,
  "tous les Dimanches"
 ],
 "every Thursday": [
  null,
  "tous les Jeudi"
 ],
 "every Tuesday": [
  null,
  "tous les Mardi"
 ],
 "every Wednesday": [
  null,
  "tous les Mercredi"
 ],
 "every day": [
  null,
  "tous les jours"
 ],
 "for current and future kernels": [
  null,
  "pour les noyaux actuels et futurs"
 ],
 "for current kernel only": [
  null,
  "pour le noyau actuel uniquement"
 ],
 "in less than a minute": [
  null,
  "dans moins d'une minute"
 ],
 "less than a minute ago": [
  null,
  "il y a moins d'une minute"
 ],
 "password quality": [
  null,
  "qualité mot de passe"
 ],
 "patches": [
  null,
  "correctifs"
 ],
 "security": [
  null,
  "sécurité"
 ],
 "show less": [
  null,
  "montrer moins"
 ],
 "show more": [
  null,
  "montrer plus"
 ]
});
