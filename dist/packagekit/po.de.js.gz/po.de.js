cockpit.locale({
 "": {
  "plural-forms": (n) => n != 1,
  "language": "de",
  "language-direction": "ltr"
 },
 "$0 GiB": [
  null,
  "$0 GiB"
 ],
 "$0 day": [
  null,
  "$0 Tag",
  "$0 Tage"
 ],
 "$0 exited with code $1": [
  null,
  "$0 mit Code $1 beendet"
 ],
 "$0 failed": [
  null,
  "$0 fehlgeschlagen"
 ],
 "$0 hour": [
  null,
  "$0 Stunde",
  "$0 Stunden"
 ],
 "$0 is not available from any repository.": [
  null,
  "$0 ist in keinem Repository verfügbar."
 ],
 "$0 key changed": [
  null,
  "$0 Schlüssel geändert"
 ],
 "$0 killed with signal $1": [
  null,
  "$0 mit Signal $1 beendet"
 ],
 "$0 minute": [
  null,
  "$0 Minute",
  "$0 Minuten"
 ],
 "$0 month": [
  null,
  "$0 Monat",
  "$0 Monate"
 ],
 "$0 package": [
  null,
  "$0 Paket",
  "$0 Pakete"
 ],
 "$0 package needs a system reboot": [
  null,
  "$0 Paket benötigt einen Systemneustart",
  "$0 Pakete benötigen einen Systemneustart"
 ],
 "$0 security fix available": [
  null,
  "$0 Sicherheitsupdate verfügbar",
  "$0 Sicherheitsupdates verfügbar"
 ],
 "$0 service needs to be restarted": [
  null,
  "$0 Dienst muss neu gestartet werden",
  "$0 Dienste müssen neu gestartet werden"
 ],
 "$0 update available": [
  null,
  "$0 Aktualisierung verfügbar",
  "$0 Aktualisierungen verfügbar"
 ],
 "$0 week": [
  null,
  "$0 Woche",
  "$0 Wochen"
 ],
 "$0 will be installed.": [
  null,
  "$0 wird installiert."
 ],
 "$0 year": [
  null,
  "$0 Jahr",
  "$0 Jahre"
 ],
 ", including $1 security fix": [
  null,
  ", einschließlich $1 Sicherheitsupdate",
  ", einschließlich $1 Sicherheitsupdates"
 ],
 "1 day": [
  null,
  "1 Tag"
 ],
 "1 hour": [
  null,
  "1 Stunde"
 ],
 "1 minute": [
  null,
  "1 Minute"
 ],
 "1 week": [
  null,
  "1 Woche"
 ],
 "20 minutes": [
  null,
  "20 Minuten"
 ],
 "40 minutes": [
  null,
  "40 Minuten"
 ],
 "5 minutes": [
  null,
  "5 Minuten"
 ],
 "6 hours": [
  null,
  "6 Stunden"
 ],
 "60 minutes": [
  null,
  "60 Minuten"
 ],
 "A compatible version of Cockpit is not installed on $0.": [
  null,
  "Eine kompatible Version von Cockpit ist auf $0 nicht installiert."
 ],
 "A new SSH key at $0 will be created for $1 on $2 and it will be added to the $3 file of $4 on $5.": [
  null,
  "Ein neuer SSH-Schlüssel unter $0 wird für $1 auf $2 erstellt und zur Datei $3 von $4 auf $5 hinzugefügt."
 ],
 "A package needs a system reboot for the updates to take effect:": [
  null,
  "Ein Paket benötigt einen Neustart des Systems, damit die Aktualisierungen wirksam werden:",
  "Einige Pakete benötigen einen Neustart des Systems, damit die Aktualisierungen wirksam werden:"
 ],
 "A service needs to be restarted for the updates to take effect:": [
  null,
  "Ein Dienst muss neu gestartet werden, damit die Aktualisierungen wirksam werden:",
  "Einige Dienste müssen neu gestartet werden, damit die Aktualisierungen wirksam werden:"
 ],
 "Absent": [
  null,
  "Abwesend"
 ],
 "Acceptable password": [
  null,
  "Akzeptables Passwort"
 ],
 "Add $0": [
  null,
  "$0 hinzufügen"
 ],
 "Additional packages:": [
  null,
  "Zusatzpakete:"
 ],
 "Administration with Cockpit Web Console": [
  null,
  "Mit der Cockpit Web Konsole administrieren"
 ],
 "Advanced TCA": [
  null,
  "Fortgeschrittenes TCA"
 ],
 "All updates": [
  null,
  "Alle Updates"
 ],
 "All-in-one": [
  null,
  "Alles-in-einem"
 ],
 "Ansible": [
  null,
  "Ansible"
 ],
 "Ansible roles documentation": [
  null,
  "Ansible Rollendokumentation"
 ],
 "Apply kernel live patches": [
  null,
  "Kernel-Live-Patches anwenden"
 ],
 "Applying updates": [
  null,
  "Aktualisierungen werden angewandt"
 ],
 "Applying updates failed": [
  null,
  "Das Anwenden der Updates ist fehlgeschlagen"
 ],
 "Authentication": [
  null,
  "Authentifizierung"
 ],
 "Authentication is required to perform privileged tasks with the Cockpit Web Console": [
  null,
  "Privilegierte Aktionen der Cockpit Web-Konsole benötigen Berechtigung"
 ],
 "Authorize SSH key": [
  null,
  "SSH-Schlüssel autorisieren"
 ],
 "Automatic updates": [
  null,
  "Automatische Updates"
 ],
 "Automatically using NTP": [
  null,
  "Automatisch (NTP)"
 ],
 "Automatically using additional NTP servers": [
  null,
  "Automatische Benutzung zusätzlicher NTP-Server"
 ],
 "Automatically using specific NTP servers": [
  null,
  "Automatisch (spezifische NTP-Server)"
 ],
 "Automation script": [
  null,
  "Automatisierungs-Skript"
 ],
 "Available updates": [
  null,
  "Verfügbare Updates"
 ],
 "Blade": [
  null,
  "Blade"
 ],
 "Blade enclosure": [
  null,
  "Bladegehäuse"
 ],
 "Bug fix updates available": [
  null,
  "Bug Fix Updates verfügbar"
 ],
 "Bugs": [
  null,
  "Fehlermeldungen"
 ],
 "Bus expansion chassis": [
  null,
  "Bus-Erweiterungsgehäuse"
 ],
 "CVE": [
  null,
  "CVE"
 ],
 "Cancel": [
  null,
  "Abbrechen"
 ],
 "Cannot forward login credentials": [
  null,
  "Anmeldeinformationen können nicht weitergeleitet werden"
 ],
 "Cannot schedule event in the past": [
  null,
  "Vorgang kann nicht für die Vergangenheit geplant werden"
 ],
 "Change": [
  null,
  "Ändern"
 ],
 "Change system time": [
  null,
  "Systemzeit ändern"
 ],
 "Changed keys are often the result of an operating system reinstallation. However, an unexpected change may indicate a third-party attempt to intercept your connection.": [
  null,
  "Geänderte Schlüssel sind oft das Ergebnis einer Neuinstallation des Betriebssystems. Allerdings kann eine unerwartete Änderung auf einen Versuch eines Dritten hinweisen, Ihre Verbindung auszuspähen."
 ],
 "Check for updates": [
  null,
  "Auf Aktualisierungen prüfen"
 ],
 "Checking for package updates...": [
  null,
  "Auf Paketaktualisierungen wird geprüft..."
 ],
 "Checking installed software": [
  null,
  "Installierte Software wird überprüft"
 ],
 "Checking software status": [
  null,
  "Software-Status wird überprüft"
 ],
 "Clear input value": [
  null,
  "Eingabewert löschen"
 ],
 "Close": [
  null,
  "Schließen"
 ],
 "Cockpit": [
  null,
  "Cockpit"
 ],
 "Cockpit configuration of NetworkManager and Firewalld": [
  null,
  "Cockpit Konfiguration von NetworkManager und Firewalld"
 ],
 "Cockpit could not contact the given host.": [
  null,
  "Cockpit konnte den angegebenen Host nicht erreichen."
 ],
 "Cockpit is a server manager that makes it easy to administer your Linux servers via a web browser. Jumping between the terminal and the web tool is no problem. A service started via Cockpit can be stopped via the terminal. Likewise, if an error occurs in the terminal, it can be seen in the Cockpit journal interface.": [
  null,
  "Cockpit ist ein Server Manager zur einfachen Verwaltung Ihrer Linux Server via Web Browser. Ein Wechsel zwischen dem Terminal und der Weboberfläche ist kein Problem. Ein Service, der via Cockpit gestartet wurde, kann im Terminal beendet werden. Genauso können Fehler, welche im Terminal vorkommen, im Cockpit Journal angezeigt werden."
 ],
 "Cockpit is not compatible with the software on the system.": [
  null,
  "Cockpit ist mit der Software auf dem System nicht kompatibel."
 ],
 "Cockpit is not installed": [
  null,
  "Cockpit ist nicht installiert"
 ],
 "Cockpit is not installed on the system.": [
  null,
  "Cockpit ist auf dem System nicht installiert."
 ],
 "Cockpit is perfect for new sysadmins, allowing them to easily perform simple tasks such as storage administration, inspecting journals and starting and stopping services. You can monitor and administer several servers at the same time. Just add them with a single click and your machines will look after its buddies.": [
  null,
  "Cockpit ist perfekt für neue Systemadministratoren, da es ihnen auf einfache Weise ermöglicht, simple Aufgaben wie Speicherverwaltung, Journal / Logfile Analyse oder das Starten und Stoppen von Diensten durchzuführen. Sie können gleichzeitig mehrere Server überwachen und verwalten. Fügen Sie weitere Maschinen mit einem Klick hinzu und Ihre Maschinen schauen zu ihren Kumpels."
 ],
 "Collect and package diagnostic and support data": [
  null,
  "Sammeln und Packen von Diagnose und Support Daten"
 ],
 "Collect kernel crash dumps": [
  null,
  "Sammeln von Kernel-Absturz-Auszügen"
 ],
 "Compact PCI": [
  null,
  "Kompakte PCI"
 ],
 "Confirm key password": [
  null,
  "Neues Passwort wiederholen"
 ],
 "Connection has timed out.": [
  null,
  "Zeitüberschreitung bei der Verbindung."
 ],
 "Continue": [
  null,
  "Weiter"
 ],
 "Convertible": [
  null,
  "Convertible"
 ],
 "Copied": [
  null,
  "Kopiert"
 ],
 "Copy": [
  null,
  "Kopieren"
 ],
 "Copy to clipboard": [
  null,
  "In Zwischenablage kopieren"
 ],
 "Create $0": [
  null,
  "$0 erstellen"
 ],
 "Create a new SSH key and authorize it": [
  null,
  "Einen neuen SSH-Schlüssel erstellen und ihn autorisieren"
 ],
 "Create new task file with this content.": [
  null,
  "Neue Task-Datei mit diesem Inhalt erstellen."
 ],
 "Ctrl+Insert": [
  null,
  "Strg+Einfügen"
 ],
 "Danger alert:": [
  null,
  "Gefahrenalarm:"
 ],
 "Delay": [
  null,
  "Verzögerung"
 ],
 "Desktop": [
  null,
  "Desktop"
 ],
 "Detachable": [
  null,
  "Abnehmbar"
 ],
 "Details": [
  null,
  "Details"
 ],
 "Diagnostic reports": [
  null,
  "Diagnoseberichte"
 ],
 "Disabled": [
  null,
  "Deaktiviert"
 ],
 "Docking station": [
  null,
  "Dockingstation"
 ],
 "Downloaded": [
  null,
  "Heruntergeladen"
 ],
 "Downloading": [
  null,
  "Herunterladen"
 ],
 "Downloading $0": [
  null,
  "wird heruntergeladen $0"
 ],
 "Dual rank": [
  null,
  "Doppelter Rang"
 ],
 "Edit": [
  null,
  "Bearbeiten"
 ],
 "Embedded PC": [
  null,
  "Eingebetteter PC"
 ],
 "Enable": [
  null,
  "Aktivieren"
 ],
 "Enabled": [
  null,
  "Aktiviert"
 ],
 "Enhancement updates available": [
  null,
  "Verbesserungsaktualisierungen verfügbar"
 ],
 "Errata": [
  null,
  "Errata"
 ],
 "Excellent password": [
  null,
  "Perfektes Passwort"
 ],
 "Expansion chassis": [
  null,
  "Erweiterungsgehäuse"
 ],
 "Failed to change password": [
  null,
  "Passwort konnte nicht geändert werden"
 ],
 "Failed to enable $0 in firewalld": [
  null,
  "$0 konnte nicht in firewalld aktiviert werden"
 ],
 "Failed to parse unit files for dnf-automatic.timer or dnf-automatic-install.timer. Please remove custom overrides to configure automatic updates.": [
  null,
  "Das Parsen der Unit-Datein für dnf-automatic.timer oderr dnf-automatic-install.timer ist fehlgeschlagen. Bitte eigene Überschreibungen in der Konfigurationsautomatisierung entfernen."
 ],
 "Failed to restart service": [
  null,
  "Dienst konnte nicht neu gestartet werden"
 ],
 "Fridays": [
  null,
  "Freitags"
 ],
 "Go to now": [
  null,
  "Zu 'Jetzt' gehen"
 ],
 "Handheld": [
  null,
  "Handheld"
 ],
 "Hide confirmation password": [
  null,
  "Bestätigungspasswort ausblenden"
 ],
 "Hide password": [
  null,
  "Passwort ausblenden"
 ],
 "History package count": [
  null,
  "History Packet-Anzahl"
 ],
 "Host key is incorrect": [
  null,
  "Host-Schlüssel ist falsch"
 ],
 "Ignore": [
  null,
  "Ignorieren"
 ],
 "Info": [
  null,
  "Info"
 ],
 "Initializing...": [
  null,
  "Initialisierung ..."
 ],
 "Install": [
  null,
  "Installation"
 ],
 "Install all updates": [
  null,
  "Alle Aktualisierungen installieren"
 ],
 "Install kpatch updates": [
  null,
  "kpatch-Aktualisierungen installieren"
 ],
 "Install security updates": [
  null,
  "Sicherheitsaktualisierungen installieren"
 ],
 "Install software": [
  null,
  "Software installieren"
 ],
 "Installed": [
  null,
  "Installiert"
 ],
 "Installing": [
  null,
  "Wird installiert"
 ],
 "Installing $0": [
  null,
  "$0 wird installiert"
 ],
 "Internal error": [
  null,
  "Interner Fehler"
 ],
 "Invalid date format": [
  null,
  "Ungültiges Datumsformat"
 ],
 "Invalid date format and invalid time format": [
  null,
  "Ungültiges Datumsformat und ungültiges Zeitformat"
 ],
 "Invalid file permissions": [
  null,
  "Ungültige Dateiberechtigungen"
 ],
 "Invalid time format": [
  null,
  "Ungültiges Zeitformat"
 ],
 "Invalid timezone": [
  null,
  "Ungültige Zeitzone"
 ],
 "IoT gateway": [
  null,
  "IoT-Gateway"
 ],
 "Kernel dump": [
  null,
  "Kernel dump"
 ],
 "Kernel live patch $0 is active": [
  null,
  "Kernel-Live-Patch $0 ist aktiv"
 ],
 "Kernel live patch $0 is installed": [
  null,
  "Kernel-Live-Patch $0 ist installiert"
 ],
 "Kernel live patch settings": [
  null,
  "Kernel-Live-Patch-Einstellungen"
 ],
 "Kernel live patching": [
  null,
  "Kernel-Live-Patching"
 ],
 "Key password": [
  null,
  "Schlüsselpasswort"
 ],
 "Laptop": [
  null,
  "Laptop"
 ],
 "Last checked: $0": [
  null,
  "Zuletzt geprüft: $0"
 ],
 "Learn more": [
  null,
  "Mehr erfahren"
 ],
 "Loading available updates failed": [
  null,
  "Laden verfügbarer Aktualisierungen fehlgeschlagen"
 ],
 "Loading available updates, please wait...": [
  null,
  "Verfügbare Aktualisierungen werden geladen, bitte warten ..."
 ],
 "Loading system modifications...": [
  null,
  "System-Änderungen laden..."
 ],
 "Log in": [
  null,
  "Anmelden"
 ],
 "Log in to $0": [
  null,
  "Bei $0 anmelden"
 ],
 "Log messages": [
  null,
  "Nachrichten protokollieren"
 ],
 "Login failed": [
  null,
  "Anmeldung fehlgeschlagen"
 ],
 "Low profile desktop": [
  null,
  "Low-Profile-Desktop"
 ],
 "Lunch box": [
  null,
  "Brotdose"
 ],
 "Main server chassis": [
  null,
  "Hauptservergehäuse"
 ],
 "Manage storage": [
  null,
  "Speicher verwalten"
 ],
 "Manually": [
  null,
  "Manuell"
 ],
 "Message to logged in users": [
  null,
  "Nachricht an angemeldete Benutzer"
 ],
 "Mini PC": [
  null,
  "Mini PC"
 ],
 "Mini tower": [
  null,
  "Mini-Tower"
 ],
 "Mondays": [
  null,
  "Montags"
 ],
 "More info...": [
  null,
  "Weitere Informationen..."
 ],
 "Multi-system chassis": [
  null,
  "Multi-System-Chassis"
 ],
 "NTP server": [
  null,
  "NTP-Server"
 ],
 "Name": [
  null,
  "Name"
 ],
 "Need at least one NTP server": [
  null,
  "Benötigen Sie mindestens einen NTP-Server"
 ],
 "Networking": [
  null,
  "Netzwerk"
 ],
 "New password was not accepted": [
  null,
  "Das neue Passwort wurde nicht akzeptiert"
 ],
 "No delay": [
  null,
  "Keine Verzögerung"
 ],
 "No results found": [
  null,
  "Keine Ergebnisse gefunden"
 ],
 "No such file or directory": [
  null,
  "Datei oder Verzeichnis nicht vorhanden"
 ],
 "No system modifications": [
  null,
  "Keine Systemänderungen"
 ],
 "No updates": [
  null,
  "Keine Aktualisierungen"
 ],
 "Not a valid private key": [
  null,
  "Ungültiger privater Schlüssel"
 ],
 "Not available": [
  null,
  "Nicht verfügbar"
 ],
 "Not installed": [
  null,
  "Nicht installiert"
 ],
 "Not permitted to perform this action.": [
  null,
  "Diese Aktion darf nicht ausgeführt werden."
 ],
 "Not registered": [
  null,
  "Nicht registriert"
 ],
 "Not set up": [
  null,
  "Nicht eingerichtet"
 ],
 "Not synchronized": [
  null,
  "Nicht synchronisiert"
 ],
 "Notebook": [
  null,
  "Notizbuch"
 ],
 "Occurrences": [
  null,
  "Vorkommnisse"
 ],
 "Ok": [
  null,
  "OK"
 ],
 "Old password not accepted": [
  null,
  "Altes Passwort wurde nicht akzeptiert"
 ],
 "Once Cockpit is installed, enable it with \"systemctl enable --now cockpit.socket\".": [
  null,
  "Wenn Cockpit installiert ist, aktivieren Sie es mit \"systemctl enable --now cockpit.socket\"."
 ],
 "Other": [
  null,
  "Weitere"
 ],
 "Package information": [
  null,
  "Paket-Informationen"
 ],
 "PackageKit crashed": [
  null,
  "PackageKit ist abgestürzt"
 ],
 "PackageKit is not installed": [
  null,
  "PackageKit ist nicht installiert"
 ],
 "PackageKit reported error code $0": [
  null,
  "PackageKit hat Fehlercode gemeldet $0"
 ],
 "Packages": [
  null,
  "Pakete"
 ],
 "Password": [
  null,
  "Passwort"
 ],
 "Password is not acceptable": [
  null,
  "Das Passwort kann nicht akzeptiert werden"
 ],
 "Password is too weak": [
  null,
  "Das gewählte Passwort ist zu schwach"
 ],
 "Password not accepted": [
  null,
  "Passwort wurde nicht akzeptiert"
 ],
 "Paste": [
  null,
  "Einfügen"
 ],
 "Paste error": [
  null,
  "Fehler beim Einfügen"
 ],
 "Path to file": [
  null,
  "Pfad zur Datei"
 ],
 "Peripheral chassis": [
  null,
  "Peripheriechassis"
 ],
 "Pick date": [
  null,
  "Datum auswählen"
 ],
 "Pizza box": [
  null,
  "Pizza-Box"
 ],
 "Please resolve the issue and reload this page.": [
  null,
  "Bitte beheben Sie das Problem und laden Sie diese Seite neu."
 ],
 "Portable": [
  null,
  "tragbar"
 ],
 "Present": [
  null,
  "Derzeit"
 ],
 "Prompting via ssh-add timed out": [
  null,
  "Die Aufforderung über ssh-add ist abgelaufen"
 ],
 "Prompting via ssh-keygen timed out": [
  null,
  "Die Aufforderung über ssh-keygen ist abgelaufen"
 ],
 "RAID chassis": [
  null,
  "RAID-Chassis"
 ],
 "Rack mount chassis": [
  null,
  "Rack-Einbaugehäuse"
 ],
 "Reboot": [
  null,
  "Neustart"
 ],
 "Reboot after completion": [
  null,
  "Neustart nach Fertigstellung"
 ],
 "Reboot recommended": [
  null,
  "Neustart empfohlen"
 ],
 "Reboot system...": [
  null,
  "System neu starten ..."
 ],
 "Refreshing package information": [
  null,
  "Paketinformationen aktualisieren"
 ],
 "Register…": [
  null,
  "Registrieren…"
 ],
 "Reloading the state of remaining services": [
  null,
  "Der Zustand der verbleibenden Dienste wird neu geladen"
 ],
 "Removals:": [
  null,
  "Umzüge:"
 ],
 "Removing $0": [
  null,
  "Entfernen $0"
 ],
 "Restart services": [
  null,
  "Dienste neu starten"
 ],
 "Restart services...": [
  null,
  "Dienste werden neu gestartet ..."
 ],
 "Restarting": [
  null,
  "Wird neu gestartet"
 ],
 "Row expansion": [
  null,
  "Zeilenerweiterung"
 ],
 "Row select": [
  null,
  "Zeilenauswahl"
 ],
 "Run this command over a trusted network or physically on the remote machine:": [
  null,
  "Führen Sie diesen Befehl über ein vertrauenswürdiges Netzwerk oder physisch auf dem entfernten Rechner aus:"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "SSH key": [
  null,
  "SSH-Schlüssel"
 ],
 "SSH key login": [
  null,
  "SSH-Schlüssel-Anmeldung"
 ],
 "Saturdays": [
  null,
  "Samstags"
 ],
 "Save": [
  null,
  "Speichern"
 ],
 "Save changes": [
  null,
  "Änderungen speichern"
 ],
 "Sealed-case PC": [
  null,
  "PC mit versiegeltem Gehäuse"
 ],
 "Security Enhanced Linux configuration and troubleshooting": [
  null,
  "Sicherheitsverstärkte Linuxkonfiguration und Problemlösung"
 ],
 "Security updates available": [
  null,
  "Sicherheitsupdates verfügbar"
 ],
 "Security updates only": [
  null,
  "Nur Sicherheitsaktualisierungen"
 ],
 "Security updates will be applied $0 at $1": [
  null,
  "Sicherheitsaktualisierungen werden für $0 auf $1 angewandt"
 ],
 "Select an option": [
  null,
  "Wählen Sie eine Option aus"
 ],
 "Server has closed the connection.": [
  null,
  "Der Server hat die Verbindung beendet."
 ],
 "Set time": [
  null,
  "Zeit setzen"
 ],
 "Set up": [
  null,
  "Konfiguration"
 ],
 "Setting up": [
  null,
  "Einrichten"
 ],
 "Settings": [
  null,
  "Einstellungen"
 ],
 "Severity": [
  null,
  "Schweregrad"
 ],
 "Shell script": [
  null,
  "Shell script"
 ],
 "Shift+Insert": [
  null,
  "Shift+Einfügen"
 ],
 "Show confirmation password": [
  null,
  "Bestätigungspasswort anzeigen"
 ],
 "Show password": [
  null,
  "Passwort anzeigen"
 ],
 "Shut down": [
  null,
  "Herunterfahren"
 ],
 "Single rank": [
  null,
  "Einzelner Rang"
 ],
 "Software updates": [
  null,
  "Aktualisierungen"
 ],
 "Some other program is currently using the package manager, please wait...": [
  null,
  "Ein anderes Programm verwendet derzeit den Paketmanager, bitte warten Sie ..."
 ],
 "Some software needs to be restarted manually": [
  null,
  "Manche Software muss manuell neu gestartet werden"
 ],
 "Space-saving computer": [
  null,
  "Platzsparender Computer"
 ],
 "Specific time": [
  null,
  "Bestimmte Zeit"
 ],
 "Status": [
  null,
  "Status"
 ],
 "Stick PC": [
  null,
  "Stick PC"
 ],
 "Storage": [
  null,
  "Speicher"
 ],
 "Strong password": [
  null,
  "Starkes Passwort"
 ],
 "Sub-Chassis": [
  null,
  "Sub-Chassis"
 ],
 "Sub-Notebook": [
  null,
  "Sub-Notebook"
 ],
 "Sundays": [
  null,
  "Sonntags"
 ],
 "Synchronized": [
  null,
  "Synchronisiert"
 ],
 "Synchronized with $0": [
  null,
  "Mit $0 synchronisiert"
 ],
 "Synchronizing": [
  null,
  "Wird synchronisiert"
 ],
 "System is up to date": [
  null,
  "System ist aktualisiert"
 ],
 "Tablet": [
  null,
  "Tablett"
 ],
 "The SSH key $0 of $1 on $2 will be added to the $3 file of $4 on $5.": [
  null,
  "Der SSH-Schlüssel $0 von $1 auf $2 wird der Datei $3 von $4 auf $5 hinzugefügt."
 ],
 "The SSH key $0 will be made available for the remainder of the session and will be available for login to other hosts as well.": [
  null,
  "Der SSH-Schlüssel $0 wird für den Rest der Sitzung zur Verfügung gestellt und steht auch für die Anmeldung bei anderen Hosts zur Verfügung."
 ],
 "The SSH key for logging in to $0 is protected by a password, and the host does not allow logging in with a password. Please provide the password of the key at $1.": [
  null,
  "Der SSH-Schlüssel für die Anmeldung bei $0 ist durch ein Passwort geschützt, und der Host erlaubt keine Anmeldung mit einem Passwort. Bitte geben Sie das Passwort des Schlüssels auf $1 an."
 ],
 "The SSH key for logging in to $0 is protected. You can log in with either your login password or by providing the password of the key at $1.": [
  null,
  "Der SSH-Schlüssel für die Anmeldung bei $0 ist geschützt. Sie können sich entweder mit Ihrem Anmeldepasswort oder mit dem Passwort des Schlüssels bei $1 anmelden."
 ],
 "The fingerprint should match:": [
  null,
  "Der Fingerabdruck sollte übereinstimmen:"
 ],
 "The following service will be restarted:": [
  null,
  "Der folgende Dienst wird neu gestartet:",
  "Die folgenden Dienste werden neu gestartet:"
 ],
 "The key password can not be empty": [
  null,
  "Das Schlüsselpasswort darf nicht leer sein"
 ],
 "The key passwords do not match": [
  null,
  "Die Schlüsselpasswörter stimmen nicht überein"
 ],
 "The logged in user is not permitted to view system modifications": [
  null,
  "Der angemeldete Benutzer ist nicht berechtigt, Systemänderungen einzusehen"
 ],
 "The password can not be empty": [
  null,
  "Das Passwort darf nicht leer sein"
 ],
 "The resulting fingerprint is fine to share via public methods, including email.": [
  null,
  "Der entstandene Fingerabdruck kann über öffentliche Methoden, einschließlich E-Mail, weitergegeben werden."
 ],
 "The resulting fingerprint is fine to share via public methods, including email. If you are asking someone else to do the verification for you, they can send the results using any method.": [
  null,
  "Der resultierende Fingerabdruck kann über öffentliche Methoden, einschließlich E-Mail, weitergegeben werden. Wenn Sie eine andere Person bitten, die Überprüfung für Sie vorzunehmen, kann diese die Ergebnisse mit einer beliebigen Methode übermitteln."
 ],
 "The server refused to authenticate using any supported methods.": [
  null,
  "Der Server hat die Authentifizierung mit allen unterstützten Methoden abgelehnt."
 ],
 "This host will reboot after updates are installed.": [
  null,
  "Dieser Host wird nach der Installation der Aktualisierungen neu gestartet."
 ],
 "This system is not registered": [
  null,
  "Dieses System ist nicht registriert"
 ],
 "This tool configures the SELinux policy and can help with understanding and resolving policy violations.": [
  null,
  "Dieses Tool konfiguriert die SELinux Policy und hilft dabei Verletzungen der Policy zu verstehen und aufzulösen."
 ],
 "This tool generates an archive of configuration and diagnostic information from the running system. The archive may be stored locally or centrally for recording or tracking purposes or may be sent to technical support representatives, developers or system administrators to assist with technical fault-finding and debugging.": [
  null,
  "Dieses Tool generiert ein Archiv der Konfiguration und Diagnoseinformation des laufenden Systems.Das Archiv kann lokal oder zentral abgespeichert werden zum Zweck der Archivierung oder Nachverfolgung oder kann an den Technischen Support, Entwickler oder Systemadministratoren gesendet werden, um bei der Fehlersuche oder Debugging zu helfen."
 ],
 "This tool manages local storage, such as filesystems, LVM2 volume groups, and NFS mounts.": [
  null,
  "Dieses Tool verwaltet den lokalen Speicher, wie etwa Dateisysteme, LVM2 Volume Gruppen und NFS Einhängepunkte."
 ],
 "This tool manages networking such as bonds, bridges, teams, VLANs and firewalls using NetworkManager and Firewalld. NetworkManager is incompatible with Ubuntu's default systemd-networkd and Debian's ifupdown scripts.": [
  null,
  "Dieses Tool verwaltet die Netzwerkumgebung wie etwa Bindungen, Bridges, Teams, VLANs und Firewalls durch den NetworkManager und Firewalld. Der NetworkManager ist inkompatibel mit dem Ubuntus Standard systemd-networkd und Debians ifupdown Scipts."
 ],
 "Thursdays": [
  null,
  "Donnerstags"
 ],
 "Time": [
  null,
  "Zeit"
 ],
 "Time zone": [
  null,
  "Zeitzone"
 ],
 "To ensure that your connection is not intercepted by a malicious third-party, please verify the host key fingerprint:": [
  null,
  "Überprüfen Sie bitte den Fingerabdruck des Host-Schlüssels, um sicherzustellen, dass Ihre Verbindung nicht von einem böswilligen Dritten ausgespäht wird:"
 ],
 "To get software updates, this system needs to be registered with Red Hat, either using the Red Hat Customer Portal or a local subscription server.": [
  null,
  "Um Aktualisierungen zu erhalten, muss dieses System bei Red Hat registriert sein; entweder im Red Hat Customer Portal oder einem lokalen Subscription-Dienst."
 ],
 "To verify a fingerprint, run the following on $0 while physically sitting at the machine or through a trusted network:": [
  null,
  "Um einen Fingerabdruck zu überprüfen, führen Sie die folgenden Schritte auf $0 aus, während Sie physisch an der Maschine sitzen oder über ein vertrauenswürdiges Netzwerk:"
 ],
 "Toggle date picker": [
  null,
  "Datumsauswahl umschalten"
 ],
 "Too much data": [
  null,
  "Zu viele Daten"
 ],
 "Total size: $0": [
  null,
  "Gesamtgröße: $0"
 ],
 "Tower": [
  null,
  "Turm"
 ],
 "Trust and add host": [
  null,
  "Host vertrauen und hinzufügen"
 ],
 "Trying to synchronize with $0": [
  null,
  "Versuche mit {{Server}} zu synchronisieren"
 ],
 "Tuesdays": [
  null,
  "Dienstags"
 ],
 "Type": [
  null,
  "Typ"
 ],
 "Unable to log in to $0 using SSH key authentication. Please provide the password.": [
  null,
  "Die Anmeldung bei $0 mit SSH-Schlüsselauthentifizierung ist nicht möglich. Bitte geben Sie das Passwort an."
 ],
 "Unable to log in to $0. The host does not accept password login or any of your SSH keys.": [
  null,
  "Die Anmeldung bei $0 ist nicht möglich. Der Host akzeptiert weder ein Passwort noch einen Ihrer SSH-Schlüssel."
 ],
 "Unavailable packages": [
  null,
  "Nicht verfügbare Pakete"
 ],
 "Unknown": [
  null,
  "Unbekannt"
 ],
 "Unknown host: $0": [
  null,
  "Unbekannter Host: $0"
 ],
 "Untrusted host": [
  null,
  "Nicht vertrauenswürdiger Host"
 ],
 "Update Success Table": [
  null,
  "Aktualisierungserfolgstabelle"
 ],
 "Update history": [
  null,
  "Update-Verlauf"
 ],
 "Update was successful": [
  null,
  "Aktualisierung war erfolgreich"
 ],
 "Updated": [
  null,
  "Aktualisiert"
 ],
 "Updated packages may require a reboot to take effect.": [
  null,
  "Aktualisierte Pakete erfordern möglicherweise einen Neustart, um wirksam zu werden."
 ],
 "Updates available": [
  null,
  "Updates verfügbar"
 ],
 "Updates history": [
  null,
  "Aktualisierungsverlauf"
 ],
 "Updates will be applied $0 at $1": [
  null,
  "Aktualisierungen werden $0 auf $1 angewandt"
 ],
 "Updating": [
  null,
  "Aktualisiere"
 ],
 "Verified": [
  null,
  "Verifiziert"
 ],
 "Verify fingerprint": [
  null,
  "Fingerabdruck verifizieren"
 ],
 "Verifying": [
  null,
  "Überprüfung läuft"
 ],
 "Version": [
  null,
  "Version"
 ],
 "View all logs": [
  null,
  "Alle Protokolle ansehen"
 ],
 "View automation script": [
  null,
  "Automatisierungs-Script anzeigen"
 ],
 "View update log": [
  null,
  "Aktualisierungsprotokoll ansehen"
 ],
 "Visit firewall": [
  null,
  "Firewall besuchen"
 ],
 "Waiting for other software management operations to finish": [
  null,
  "Warten, bis andere Software-Verwaltungsvorgänge abgeschlossen sind"
 ],
 "Weak password": [
  null,
  "Schwaches Passwort"
 ],
 "Web Console for Linux servers": [
  null,
  "Webkonsole für Linux-Server"
 ],
 "Web Console will restart": [
  null,
  "Web-Konsole wird neu gestartet"
 ],
 "Wednesdays": [
  null,
  "Mittwochs"
 ],
 "When": [
  null,
  "Wenn"
 ],
 "When the Web Console is restarted, you will no longer see progress information. However, the update process will continue in the background. Reconnect to continue watching the update process.": [
  null,
  "Wenn die Web-Konsole neu gestartet wird, sehen Sie keine Fortschrittsinformationen mehr. Allerdings wird der Aktualisierungsprozess im Hintergrund fortgesetzt. Stellen Sie die Verbindung wieder her, um den Aktualisierungsprozess weiter zu verfolgen."
 ],
 "You are connecting to $0 for the first time.": [
  null,
  "Sie stellen zum ersten Mal eine Verbindung zu $0 her."
 ],
 "Your browser does not allow paste from the context menu. You can use Shift+Insert.": [
  null,
  "Ihr Browser lässt das Einfügen über das Kontextmenü nicht zu. Sie können Umschalt+Einfügen verwenden."
 ],
 "Your server will close the connection soon. You can reconnect after it has restarted.": [
  null,
  "Ihr Server wird die Verbindung bald beenden. Sie können die Verbindung nach dem Neustart wiederherstellen."
 ],
 "Your session has been terminated.": [
  null,
  "Ihre Sitzung wurde beendet."
 ],
 "Your session has expired. Please log in again.": [
  null,
  "Die Session ist abgelaufen. Bitte neu einloggen."
 ],
 "Zone": [
  null,
  "Zone"
 ],
 "[binary data]": [
  null,
  "[Binärdaten]"
 ],
 "[no data]": [
  null,
  "[keine Daten]"
 ],
 "at": [
  null,
  "um"
 ],
 "bug fix": [
  null,
  "Bug-Fix"
 ],
 "enhancement": [
  null,
  "Verbesserung"
 ],
 "every Friday": [
  null,
  "jeden Freitag"
 ],
 "every Monday": [
  null,
  "jeden Montag"
 ],
 "every Saturday": [
  null,
  "jeden Samstag"
 ],
 "every Sunday": [
  null,
  "jeden Sonntag"
 ],
 "every Thursday": [
  null,
  "jeden Donnerstag"
 ],
 "every Tuesday": [
  null,
  "jeden Dienstag"
 ],
 "every Wednesday": [
  null,
  "jeden Mittwoch"
 ],
 "every day": [
  null,
  "jeden Tag"
 ],
 "for current and future kernels": [
  null,
  "für aktuelle und zukünftige Kernel"
 ],
 "for current kernel only": [
  null,
  "nur für den aktuellen Kernel"
 ],
 "in less than a minute": [
  null,
  "in weniger als einer Minute"
 ],
 "less than a minute ago": [
  null,
  "vor weniger als einer Minute"
 ],
 "password quality": [
  null,
  "Passwortqualität"
 ],
 "patches": [
  null,
  "Patches"
 ],
 "security": [
  null,
  "Sicherheit"
 ],
 "show less": [
  null,
  "zeige weniger"
 ],
 "show more": [
  null,
  "Zeig mehr"
 ]
});
