cockpit.locale({
 "": {
  "plural-forms": (n) => n != 1,
  "language": "es",
  "language-direction": "ltr"
 },
 "$0 GiB": [
  null,
  "$0 GiB"
 ],
 "$0 day": [
  null,
  "$0 día",
  "$0 días"
 ],
 "$0 exited with code $1": [
  null,
  "$0 finalizó con el código $1"
 ],
 "$0 failed": [
  null,
  "$0 falló"
 ],
 "$0 hour": [
  null,
  "$0 hora",
  "$0 horas"
 ],
 "$0 is not available from any repository.": [
  null,
  "$0 no está disponible en ningún repositorio."
 ],
 "$0 key changed": [
  null,
  "$0 clave cambiada"
 ],
 "$0 killed with signal $1": [
  null,
  "$0 terminado con señal $1"
 ],
 "$0 minute": [
  null,
  "$0 minuto",
  "$0 minutos"
 ],
 "$0 month": [
  null,
  "$0 mes",
  "$0 meses"
 ],
 "$0 package": [
  null,
  "$0 paquete",
  "$0 paquetes"
 ],
 "$0 package needs a system reboot": [
  null,
  "$0 paquete necesita un reinicio del sistema",
  "$0 paquetes necesitan un reinicio del sistema"
 ],
 "$0 security fix available": [
  null,
  "$0 Actualización de seguridad disponible",
  "$0 Actualizaciones de seguridad disponibles"
 ],
 "$0 service needs to be restarted": [
  null,
  "$0 servicio necesita reiniciarse",
  "$0 servicios necesitan reiniciarse"
 ],
 "$0 update available": [
  null,
  "$0 Actualización disponible",
  "$0 Actualizaciones disponibles"
 ],
 "$0 week": [
  null,
  "$0 semana",
  "$0 semanas"
 ],
 "$0 will be installed.": [
  null,
  "Se instalará: $0."
 ],
 "$0 year": [
  null,
  "$0 año",
  "$0 años"
 ],
 ", including $1 security fix": [
  null,
  ", incluyendo $1 corrección de seguridad",
  ", incluyendo $1 correcciones de seguridad"
 ],
 "1 day": [
  null,
  "1 día"
 ],
 "1 hour": [
  null,
  "1 hora"
 ],
 "1 minute": [
  null,
  "1 minuto"
 ],
 "1 week": [
  null,
  "1 semana"
 ],
 "20 minutes": [
  null,
  "20 minutos"
 ],
 "40 minutes": [
  null,
  "40 minutos"
 ],
 "5 minutes": [
  null,
  "5 minutos"
 ],
 "6 hours": [
  null,
  "6 horas"
 ],
 "60 minutes": [
  null,
  "60 minutos"
 ],
 "A compatible version of Cockpit is not installed on $0.": [
  null,
  "No se ha instalado una versión compatible de Cockpit en $0."
 ],
 "A new SSH key at $0 will be created for $1 on $2 and it will be added to the $3 file of $4 on $5.": [
  null,
  "Se creará una nueva clave SSH en $0 para $1 en $2 y se añadirá al fichero $3 de $4 en $5."
 ],
 "A package needs a system reboot for the updates to take effect:": [
  null,
  "Un paquete necesita un reinicio del sistema para que la actualización surta efecto:",
  "Varios paquetes necesitan un reinicio del sistema para que las actualizaciones surtan efecto:"
 ],
 "A service needs to be restarted for the updates to take effect:": [
  null,
  "Un servicio necesita reiniciarse para que las actualizaciones surtan efecto:",
  "Varios servicios necesitan reiniciarse para que las actualizaciones surtan efecto:"
 ],
 "Absent": [
  null,
  "Ausente"
 ],
 "Acceptable password": [
  null,
  "Contraseña aceptable"
 ],
 "Add $0": [
  null,
  "Añadir $0"
 ],
 "Additional packages:": [
  null,
  "Paquetes adicionales:"
 ],
 "Administration with Cockpit Web Console": [
  null,
  "Administrando con la consola Web de Cockpit"
 ],
 "Advanced TCA": [
  null,
  "TCA avanzado"
 ],
 "All updates": [
  null,
  "Todas las actualizaciones"
 ],
 "All-in-one": [
  null,
  "Todo en uno"
 ],
 "Ansible": [
  null,
  "Ansible"
 ],
 "Ansible roles documentation": [
  null,
  "Documentación de los roles de Ansible"
 ],
 "Apply kernel live patches": [
  null,
  "Aplicar los parches en vivo del kernel"
 ],
 "Applying updates": [
  null,
  "Instalando las actualizaciones"
 ],
 "Applying updates failed": [
  null,
  "Fallo al instalar las actualizaciones"
 ],
 "Authentication": [
  null,
  "Autenticación"
 ],
 "Authentication is required to perform privileged tasks with the Cockpit Web Console": [
  null,
  "Se requiere autenticación para elevar privilegios y realizar tareas de administración en la consola Web de Cockpit"
 ],
 "Authorize SSH key": [
  null,
  "Autorice la clave SSH"
 ],
 "Automatic updates": [
  null,
  "Actualizaciones automáticas"
 ],
 "Automatically using NTP": [
  null,
  "Utilizando NTP de forma automática"
 ],
 "Automatically using additional NTP servers": [
  null,
  "Utilizando automáticamente servidores NTP adicionales"
 ],
 "Automatically using specific NTP servers": [
  null,
  "Utilizando automáticamente servidores NTP específicos"
 ],
 "Automation script": [
  null,
  "Script de automatización"
 ],
 "Available updates": [
  null,
  "Actualizaciones disponibles"
 ],
 "Blade": [
  null,
  "Blade"
 ],
 "Blade enclosure": [
  null,
  "Chasis tipo blade"
 ],
 "Bug fix updates available": [
  null,
  "Actualizaciones disponibles que corrigen errores"
 ],
 "Bugs": [
  null,
  "Errores"
 ],
 "Bus expansion chassis": [
  null,
  "Chasis de expansión de bus"
 ],
 "CVE": [
  null,
  "CVE"
 ],
 "Cancel": [
  null,
  "Cancelar"
 ],
 "Cannot forward login credentials": [
  null,
  "No se pueden transferir los datos de acceso"
 ],
 "Cannot schedule event in the past": [
  null,
  "No se puede planificar un evento ocurrido en el pasado"
 ],
 "Change": [
  null,
  "Cambiar"
 ],
 "Change system time": [
  null,
  "Cambiar la hora del sistema"
 ],
 "Changed keys are often the result of an operating system reinstallation. However, an unexpected change may indicate a third-party attempt to intercept your connection.": [
  null,
  "Las llaves cambiadas pueden llevar una reinstalación del sistema operativo. Sin embargo, un cambio inesperado puede indicar un intento de interceptar su conexión mediante un tercero."
 ],
 "Check for updates": [
  null,
  "Comprobar si hay actualizaciones"
 ],
 "Checking for package updates...": [
  null,
  "Comprobando si hay actualizaciones de paquetes..."
 ],
 "Checking installed software": [
  null,
  "Comprobando el software instalado"
 ],
 "Checking software status": [
  null,
  "Comprobando estado del software"
 ],
 "Clear input value": [
  null,
  "Vaciar valor de entrada"
 ],
 "Close": [
  null,
  "Cerrar"
 ],
 "Cockpit": [
  null,
  "Cockpit"
 ],
 "Cockpit configuration of NetworkManager and Firewalld": [
  null,
  "Configuración en Cockpit de NetworkManager y Firewalld"
 ],
 "Cockpit could not contact the given host.": [
  null,
  "Cockpit no se pudo conectar con el anfitrión especificado."
 ],
 "Cockpit is a server manager that makes it easy to administer your Linux servers via a web browser. Jumping between the terminal and the web tool is no problem. A service started via Cockpit can be stopped via the terminal. Likewise, if an error occurs in the terminal, it can be seen in the Cockpit journal interface.": [
  null,
  "Cockpit es un gestor de servidores que facilita la administración de servidores Linux a través de un navegador web. Es posible alternar entre el portal web y la consola sin problemas. Un servicio que haya empezado por Cockpit se puede parar desde la terminal. Asimismo, si se produce un error en el terminal, podrá verlo en la bitácora de Cockpit."
 ],
 "Cockpit is not compatible with the software on the system.": [
  null,
  "Cockpit no es compatible con el software del sistema."
 ],
 "Cockpit is not installed": [
  null,
  "Cockpit no está instalado"
 ],
 "Cockpit is not installed on the system.": [
  null,
  "Cockpit no está instalado en el sistema."
 ],
 "Cockpit is perfect for new sysadmins, allowing them to easily perform simple tasks such as storage administration, inspecting journals and starting and stopping services. You can monitor and administer several servers at the same time. Just add them with a single click and your machines will look after its buddies.": [
  null,
  "Cockpit es ideal para administradores de sistemas nóveles, ya que permite realizar con sencillez tareas como gestionar almacenamiento, inspeccionar bitácoras e iniciar y detener servicios. Puede monitorizar y administrar varios servidores a la vez. Tan solo añádalos con solo pulsar un botón y sus máquinas se encargarán del resto."
 ],
 "Collect and package diagnostic and support data": [
  null,
  "Recoger y empaquetar datos de diagnóstico y soporte"
 ],
 "Collect kernel crash dumps": [
  null,
  "Recoger volcados de colapso del kernel"
 ],
 "Compact PCI": [
  null,
  "PCI compacto"
 ],
 "Confirm key password": [
  null,
  "Confirme la contraseña de la clave"
 ],
 "Connection has timed out.": [
  null,
  "La conexión ha caducado."
 ],
 "Continue": [
  null,
  "Continuar"
 ],
 "Convertible": [
  null,
  "Convertible"
 ],
 "Copied": [
  null,
  "Copiado"
 ],
 "Copy": [
  null,
  "Copiar"
 ],
 "Copy to clipboard": [
  null,
  "Copiar al portapapeles"
 ],
 "Create $0": [
  null,
  "Crear $0"
 ],
 "Create a new SSH key and authorize it": [
  null,
  "Crear una clave SSH nueva y autorícela"
 ],
 "Create new task file with this content.": [
  null,
  "Crear un archivo de tarea con este contenido."
 ],
 "Ctrl+Insert": [
  null,
  "Ctrl+Insert"
 ],
 "Danger alert:": [
  null,
  "Alerta de peligro:"
 ],
 "Delay": [
  null,
  "Retardo"
 ],
 "Desktop": [
  null,
  "Escritorio"
 ],
 "Detachable": [
  null,
  "Desmontable"
 ],
 "Details": [
  null,
  "Detalles"
 ],
 "Diagnostic reports": [
  null,
  "Informes de diagnóstico"
 ],
 "Disabled": [
  null,
  "Deshabilitado"
 ],
 "Docking station": [
  null,
  "Estación de acoplamiento"
 ],
 "Downloaded": [
  null,
  "Descargado"
 ],
 "Downloading": [
  null,
  "Descargando"
 ],
 "Downloading $0": [
  null,
  "Descargando $0"
 ],
 "Dual rank": [
  null,
  "Rango dual"
 ],
 "Edit": [
  null,
  "Editar"
 ],
 "Embedded PC": [
  null,
  "PC integrado"
 ],
 "Enable": [
  null,
  "Habilitar"
 ],
 "Enabled": [
  null,
  "Habilitado"
 ],
 "Enhancement updates available": [
  null,
  "Actualizaciones de mejora disponibles"
 ],
 "Errata": [
  null,
  "Errata"
 ],
 "Excellent password": [
  null,
  "Contraseña excelente"
 ],
 "Expansion chassis": [
  null,
  "Chasis de expansión"
 ],
 "Failed to change password": [
  null,
  "Error al cambiar contraseña"
 ],
 "Failed to enable $0 in firewalld": [
  null,
  "Fallo al habilitar $0 en firewalld"
 ],
 "Failed to parse unit files for dnf-automatic.timer or dnf-automatic-install.timer. Please remove custom overrides to configure automatic updates.": [
  null,
  "No se pudieron analizar los archivos de la unidad para dnf-automatic.timer o dnf-automatic-install.timer. Elimine las anulaciones personalizadas para configurar las actualizaciones automáticas."
 ],
 "Failed to restart service": [
  null,
  "Fallo al reiniciar el servicio"
 ],
 "Fridays": [
  null,
  "Los viernes"
 ],
 "Go to now": [
  null,
  "Ir a ahora"
 ],
 "Handheld": [
  null,
  "Dispositivo de mano"
 ],
 "Hide confirmation password": [
  null,
  "Ocultar contraseña de confirmación"
 ],
 "Hide password": [
  null,
  "Ocultar contraseña"
 ],
 "History package count": [
  null,
  "Cuenta del histórico de paquetes"
 ],
 "Host key is incorrect": [
  null,
  "La tecla del anfitrión es incorrecta"
 ],
 "If the fingerprint matches, click 'Trust and add host'. Otherwise, do not connect and contact your administrator.": [
  null,
  "Si la huella coincide, pulse \"Confiar en el anfitrión y añadirlo\". En caso contrario, no se conecte y contacte con su administrador."
 ],
 "Ignore": [
  null,
  "Ignorar"
 ],
 "Info": [
  null,
  "Información"
 ],
 "Initializing...": [
  null,
  "Inicializando..."
 ],
 "Install": [
  null,
  "Instalar"
 ],
 "Install all updates": [
  null,
  "Instalar todas las actualizaciones"
 ],
 "Install kpatch updates": [
  null,
  "Instalar todas las actualizaciones de kpatch"
 ],
 "Install security updates": [
  null,
  "Instalar las actualizaciones de seguridad"
 ],
 "Install software": [
  null,
  "Instalar software"
 ],
 "Installed": [
  null,
  "Instalado"
 ],
 "Installing": [
  null,
  "Instalando"
 ],
 "Installing $0": [
  null,
  "Instalando $0"
 ],
 "Internal error": [
  null,
  "Error interno"
 ],
 "Invalid date format": [
  null,
  "Formato de fecha inválido"
 ],
 "Invalid date format and invalid time format": [
  null,
  "Formato de fecha y hora inválidos"
 ],
 "Invalid file permissions": [
  null,
  "Permisos de archivo inválido"
 ],
 "Invalid time format": [
  null,
  "Formato de hora inválido"
 ],
 "Invalid timezone": [
  null,
  "Zona horaria no válida"
 ],
 "IoT gateway": [
  null,
  "Pasarela IoT"
 ],
 "Kernel dump": [
  null,
  "Volcado del kernel"
 ],
 "Kernel live patch $0 is active": [
  null,
  "El parche en vivo $0 del kernel está activo"
 ],
 "Kernel live patch $0 is installed": [
  null,
  "El parche en vivo $0 del kernel está instalado"
 ],
 "Kernel live patch settings": [
  null,
  "Ajustes de los parches en vivo del kernel"
 ],
 "Kernel live patching": [
  null,
  "Aplicación de parches en vivo del kernel"
 ],
 "Key password": [
  null,
  "Contraseña de la clave"
 ],
 "Laptop": [
  null,
  "Portátil"
 ],
 "Last checked: $0": [
  null,
  "Última comprobación: $0"
 ],
 "Learn more": [
  null,
  "Aprenda más"
 ],
 "Loading available updates failed": [
  null,
  "Fallo al cargar las actualizaciones disponibles"
 ],
 "Loading available updates, please wait...": [
  null,
  "Cargando actualizaciones disponibles, por favor espere..."
 ],
 "Loading system modifications...": [
  null,
  "Cargando modificaciones del sistema..."
 ],
 "Log in": [
  null,
  "Iniciar sesión"
 ],
 "Log in to $0": [
  null,
  "Iniciar sesión en $0"
 ],
 "Log messages": [
  null,
  "Mensajes de registro"
 ],
 "Login failed": [
  null,
  "Inicio de sesión fallido"
 ],
 "Low profile desktop": [
  null,
  "Perfil bajo de escritorio"
 ],
 "Lunch box": [
  null,
  "Caja de almuerzo"
 ],
 "Main server chassis": [
  null,
  "Chasis del servidor principal"
 ],
 "Manage storage": [
  null,
  "Gestionar el almacenamiento"
 ],
 "Manually": [
  null,
  "Manualmente"
 ],
 "Message to logged in users": [
  null,
  "Mensaje para usuarios activos"
 ],
 "Mini PC": [
  null,
  "Mini PC"
 ],
 "Mini tower": [
  null,
  "Mini Torre"
 ],
 "Mondays": [
  null,
  "Los lunes"
 ],
 "More info...": [
  null,
  "Más información…"
 ],
 "Multi-system chassis": [
  null,
  "Chasis multisistema"
 ],
 "NTP server": [
  null,
  "Servidor NTP"
 ],
 "Name": [
  null,
  "Nombre"
 ],
 "Need at least one NTP server": [
  null,
  "Se requiere al menos un servidor NTP"
 ],
 "Networking": [
  null,
  "Redes"
 ],
 "New password was not accepted": [
  null,
  "No se aceptó la nueva contraseña"
 ],
 "No delay": [
  null,
  "Sin retardo"
 ],
 "No results found": [
  null,
  "No se encontraron resultados"
 ],
 "No such file or directory": [
  null,
  "No existe el archivo o directorio"
 ],
 "No system modifications": [
  null,
  "No hay modificaciones para el sistema"
 ],
 "No updates": [
  null,
  "No actualizar"
 ],
 "Not a valid private key": [
  null,
  "No es una clave privada válida"
 ],
 "Not available": [
  null,
  "No está disponible"
 ],
 "Not installed": [
  null,
  "No instalado"
 ],
 "Not permitted to perform this action.": [
  null,
  "No está permitido llevar a cabo esta acción."
 ],
 "Not registered": [
  null,
  "No está registrado"
 ],
 "Not set up": [
  null,
  "Sin configurar"
 ],
 "Not synchronized": [
  null,
  "No está sincronizado"
 ],
 "Notebook": [
  null,
  "Portátil"
 ],
 "Occurrences": [
  null,
  "Ocurrencias"
 ],
 "Ok": [
  null,
  "Aceptar"
 ],
 "Old password not accepted": [
  null,
  "No se aceptó la contraseña vieja"
 ],
 "Once Cockpit is installed, enable it with \"systemctl enable --now cockpit.socket\".": [
  null,
  "Una vez que se instale Cockpit, habilítelo con \"systemctl enable --now cockpit.socket\"."
 ],
 "Other": [
  null,
  "Otro"
 ],
 "Package information": [
  null,
  "Información de paquetes"
 ],
 "PackageKit crashed": [
  null,
  "PackageKit colapsó"
 ],
 "PackageKit is not installed": [
  null,
  "PackageKit no está instalado"
 ],
 "PackageKit reported error code $0": [
  null,
  "PackageKit reportó un error con código $0"
 ],
 "Packages": [
  null,
  "Paquetes"
 ],
 "Password": [
  null,
  "Contraseña"
 ],
 "Password is not acceptable": [
  null,
  "La contraseña no es válida"
 ],
 "Password is too weak": [
  null,
  "La contraseña es muy débil"
 ],
 "Password not accepted": [
  null,
  "Contraseña no válida"
 ],
 "Paste": [
  null,
  "Pegar"
 ],
 "Paste error": [
  null,
  "Error al pegar"
 ],
 "Path to file": [
  null,
  "Ruta al fichero"
 ],
 "Peripheral chassis": [
  null,
  "Chasis periférico"
 ],
 "Pick date": [
  null,
  "Selecciona una fecha"
 ],
 "Pizza box": [
  null,
  "Caja de pizza"
 ],
 "Please resolve the issue and reload this page.": [
  null,
  "Por favor, resuelva el problema y recargue esta página."
 ],
 "Portable": [
  null,
  "Portable"
 ],
 "Present": [
  null,
  "Presente"
 ],
 "Prompting via ssh-add timed out": [
  null,
  "Ha expirado el tiempo de ssh-add"
 ],
 "Prompting via ssh-keygen timed out": [
  null,
  "Se ha agotado el tiempo de espera para ssh-keygen"
 ],
 "RAID chassis": [
  null,
  "Chasis RAID"
 ],
 "Rack mount chassis": [
  null,
  "Chasis montado en rack"
 ],
 "Reboot": [
  null,
  "Reiniciar"
 ],
 "Reboot after completion": [
  null,
  "Reiniciar al terminar"
 ],
 "Reboot recommended": [
  null,
  "Se recomienda reiniciar"
 ],
 "Reboot system...": [
  null,
  "Reiniciar el sistema..."
 ],
 "Refreshing package information": [
  null,
  "Actualizando la información de paquetes"
 ],
 "Register…": [
  null,
  "Registrar…"
 ],
 "Reloading the state of remaining services": [
  null,
  "Recargando el estado del resto de servicios"
 ],
 "Removals:": [
  null,
  "Borrados:"
 ],
 "Removing $0": [
  null,
  "Eliminando $0"
 ],
 "Restart services": [
  null,
  "Reiniciar servicios"
 ],
 "Restart services...": [
  null,
  "Reiniciar servicios..."
 ],
 "Restarting": [
  null,
  "Reiniciando"
 ],
 "Row expansion": [
  null,
  "Fila de expansión"
 ],
 "Row select": [
  null,
  "Seleccionar fila"
 ],
 "Run this command over a trusted network or physically on the remote machine:": [
  null,
  "Ejecute este comando en la máquina remota a través de una red de confianza o de forma física:"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "SSH key": [
  null,
  "Clave SSH"
 ],
 "SSH key login": [
  null,
  "Clave SSH de acceso"
 ],
 "Saturdays": [
  null,
  "Los sábados"
 ],
 "Save": [
  null,
  "Guardar"
 ],
 "Save changes": [
  null,
  "Guardar cambios"
 ],
 "Sealed-case PC": [
  null,
  "PC de caja sellada"
 ],
 "Security Enhanced Linux configuration and troubleshooting": [
  null,
  "Configuración de Security Enhanced Linux y resolución de problemas"
 ],
 "Security updates available": [
  null,
  "Actualizaciones de seguridad disponibles"
 ],
 "Security updates only": [
  null,
  "Sólo actualizaciones de seguridad"
 ],
 "Security updates will be applied $0 at $1": [
  null,
  "Las actualizaciones de seguridad se aplicarán el $0 a las $1"
 ],
 "Select an option": [
  null,
  "Seleccione una opción"
 ],
 "Server has closed the connection.": [
  null,
  "El servidor ha cerrado la conexión."
 ],
 "Set time": [
  null,
  "Establecer la hora"
 ],
 "Set up": [
  null,
  "Preparar"
 ],
 "Setting up": [
  null,
  "Configurar"
 ],
 "Settings": [
  null,
  "Ajustes"
 ],
 "Severity": [
  null,
  "Severidad"
 ],
 "Shell script": [
  null,
  "Script de shell"
 ],
 "Shift+Insert": [
  null,
  "Shift+Insert"
 ],
 "Show confirmation password": [
  null,
  "Mostrar contraseña de confirmación"
 ],
 "Show password": [
  null,
  "Mostrar contraseña"
 ],
 "Shut down": [
  null,
  "Apagar"
 ],
 "Single rank": [
  null,
  "Rango único"
 ],
 "Software updates": [
  null,
  "Actualizaciones de software"
 ],
 "Some other program is currently using the package manager, please wait...": [
  null,
  "Algún otro programa está usando actualmente el gestor de paquetes, por favor espere..."
 ],
 "Some software needs to be restarted manually": [
  null,
  "Parte del software necesita ser reiniciado manualmente"
 ],
 "Space-saving computer": [
  null,
  "Ordenador compacto"
 ],
 "Specific time": [
  null,
  "Hora específica"
 ],
 "Status": [
  null,
  "Estado"
 ],
 "Stick PC": [
  null,
  "PC USB"
 ],
 "Storage": [
  null,
  "Almacenamiento"
 ],
 "Strong password": [
  null,
  "Contraseña fuerte"
 ],
 "Sub-Chassis": [
  null,
  "Sub Chasis"
 ],
 "Sub-Notebook": [
  null,
  "Subportátil"
 ],
 "Sundays": [
  null,
  "Los domingos"
 ],
 "Synchronized": [
  null,
  "Sincronizado"
 ],
 "Synchronized with $0": [
  null,
  "Sincronizado con $0"
 ],
 "Synchronizing": [
  null,
  "Sincronizando"
 ],
 "System is up to date": [
  null,
  "El sistema está actualizado"
 ],
 "Tablet": [
  null,
  "Tableta"
 ],
 "The SSH key $0 of $1 on $2 will be added to the $3 file of $4 on $5.": [
  null,
  "La clave SSH $0 de $1 en $2 será añadida al archivo $3 de $4 en $5."
 ],
 "The SSH key $0 will be made available for the remainder of the session and will be available for login to other hosts as well.": [
  null,
  "La clave SSH $0 estará disponible durante el resto de la sesión y también lo estará para unirse a otros anfitriones."
 ],
 "The SSH key for logging in to $0 is protected by a password, and the host does not allow logging in with a password. Please provide the password of the key at $1.": [
  null,
  "La clave SSH para iniciar sesión en $0 está protegida por contraseña, y el anfitrión no permite iniciar sesión con contraseña. Por favor, introduzca la contraseña de dicha clave en $1."
 ],
 "The SSH key for logging in to $0 is protected. You can log in with either your login password or by providing the password of the key at $1.": [
  null,
  "La clave SSH para iniciar sesión en $0 está protegida. Puedes iniciar sesión tanto con la contraseña de usuario como introduciendo la contraseña de dicha clave en $1."
 ],
 "The fingerprint should match:": [
  null,
  "La huella debería coincidir con:"
 ],
 "The following service will be restarted:": [
  null,
  "El siguiente servicio será reiniciado:",
  "Los siguientes servicios serán reiniciados:"
 ],
 "The key password can not be empty": [
  null,
  "La contraseña de la clave no puede estar vacía"
 ],
 "The key passwords do not match": [
  null,
  "Las contraseñas de la clave no coinciden"
 ],
 "The logged in user is not permitted to view system modifications": [
  null,
  "El usuario autenticado no tiene permisos para ver las modificaciones del sistema"
 ],
 "The password can not be empty": [
  null,
  "La contraseña no puede estar vacía"
 ],
 "The resulting fingerprint is fine to share via public methods, including email.": [
  null,
  "La huella resultante es apta para compartirse en público, incluyendo correo electrónico."
 ],
 "The resulting fingerprint is fine to share via public methods, including email. If you are asking someone else to do the verification for you, they can send the results using any method.": [
  null,
  "La huella resultante puede ser distribuida por medios públicos, incluyendo correo electrónico, sin riesgos. Si está pidiendo a alguien que haga la verificación por usted, pueden enviarle los resultados usando cualquier método."
 ],
 "The server refused to authenticate using any supported methods.": [
  null,
  "El servido rehusó autenticar usando los métodos soportados."
 ],
 "This host will reboot after updates are installed.": [
  null,
  "El anfitrión se reiniciará cuando se hayan instalado las actualizaciones."
 ],
 "This system is not registered": [
  null,
  "Este sistema no está registrado"
 ],
 "This tool configures the SELinux policy and can help with understanding and resolving policy violations.": [
  null,
  "Esta herramienta configura la política de SELinux y puede ayudarle a comprender y resolver infracciones de la política."
 ],
 "This tool configures the system to write kernel crash dumps. It supports the \"local\" (disk), \"ssh\", and \"nfs\" dump targets.": [
  null,
  "Esta herramienta configura el sistema para que escriba los volcados de colapso del kernel. Admite volcados de destino\"local\" (disco), \"ssh\" y \"nfs\"."
 ],
 "This tool generates an archive of configuration and diagnostic information from the running system. The archive may be stored locally or centrally for recording or tracking purposes or may be sent to technical support representatives, developers or system administrators to assist with technical fault-finding and debugging.": [
  null,
  "Esta herramienta genera un archivo de configuración e información de diagnóstico del sistema en ejecución. El archivo puede ser almacenado localmente o centralmente para propósitos de registro o seguimiento, o puede ser enviado a representantes de soporte técnico, desarrolladores o administradores de sistemas para asistir con la detección de fallos y su corrección."
 ],
 "This tool manages local storage, such as filesystems, LVM2 volume groups, and NFS mounts.": [
  null,
  "Esta herramienta gestiona el almacenamiento local, como sistemas de archivos, grupos de volúmenes LVM2 y montajes NFS."
 ],
 "This tool manages networking such as bonds, bridges, teams, VLANs and firewalls using NetworkManager and Firewalld. NetworkManager is incompatible with Ubuntu's default systemd-networkd and Debian's ifupdown scripts.": [
  null,
  "Esta herramienta gestiona la configuración de red como agrupaciones, puentes, grupos, las VLAN y cortafuegos usando NetworkManager y Firewalld. NetworkManager es incompatible con systemd-networkd habilitado por defecto en Ubuntu y con los scripts de ifupdown de Debian."
 ],
 "Thursdays": [
  null,
  "Los jueves"
 ],
 "Time": [
  null,
  "Hora"
 ],
 "Time zone": [
  null,
  "Huso horario"
 ],
 "To ensure that your connection is not intercepted by a malicious third-party, please verify the host key fingerprint:": [
  null,
  "Para garantizar que su conexión no sea interceptada por un tercero malicioso, por favor verifique la huella de clave del anfitrión:"
 ],
 "To get software updates, this system needs to be registered with Red Hat, either using the Red Hat Customer Portal or a local subscription server.": [
  null,
  "Para obtener actualizaciones de software, este sistema necesita registrarse en Red Hat, bien usando el portal cliente de Red Hat o un servidor de suscripción local."
 ],
 "To verify a fingerprint, run the following on $0 while physically sitting at the machine or through a trusted network:": [
  null,
  "Para verificar una huella, ejecute lo siguiente en $0 mientras se sitúa físicamente frente a la máquina o a través de una red de confianza:"
 ],
 "Toggle date picker": [
  null,
  "Alternar el selector de fecha"
 ],
 "Too much data": [
  null,
  "Demasiados datos"
 ],
 "Total size: $0": [
  null,
  "Tamaño total: $0"
 ],
 "Tower": [
  null,
  "Torre"
 ],
 "Trust and add host": [
  null,
  "Confiar en el anfitrión y añadirlo"
 ],
 "Trying to synchronize with $0": [
  null,
  "Intentando sincronizar con $0"
 ],
 "Tuesdays": [
  null,
  "Los martes"
 ],
 "Type": [
  null,
  "Tipo"
 ],
 "Unable to log in to $0 using SSH key authentication. Please provide the password.": [
  null,
  "No se pudo iniciar sesión en $0 usando autenticación por clave SSH. Por favor, introduzca la contraseña."
 ],
 "Unable to log in to $0. The host does not accept password login or any of your SSH keys.": [
  null,
  "No fue capaz de iniciar sesión en $0. El hospedaje no acepta inicio de sesión por contraseña ni ninguna de sus claves SSH."
 ],
 "Unavailable packages": [
  null,
  "Paquetes no disponibles"
 ],
 "Unknown": [
  null,
  "Desconocido"
 ],
 "Unknown host: $0": [
  null,
  "Hospedaje desconocido: $0"
 ],
 "Untrusted host": [
  null,
  "Anfitrión no seguro"
 ],
 "Update Success Table": [
  null,
  "Tabla de actualización exitosa"
 ],
 "Update history": [
  null,
  "Histórico de actualización"
 ],
 "Update was successful": [
  null,
  "La actualización fue correcta"
 ],
 "Updated": [
  null,
  "Actualizado"
 ],
 "Updated packages may require a reboot to take effect.": [
  null,
  "Los paquetes actualizados pueden requerir un rearranque para tomar efecto."
 ],
 "Updates available": [
  null,
  "Actualizaciones disponibles"
 ],
 "Updates history": [
  null,
  "Histórico de actualizaciones"
 ],
 "Updates will be applied $0 at $1": [
  null,
  "Las actualizaciones se aplicarán el $0 a las $1"
 ],
 "Updating": [
  null,
  "Actualizando"
 ],
 "Verified": [
  null,
  "Verificado"
 ],
 "Verify fingerprint": [
  null,
  "Verifique la huella"
 ],
 "Verifying": [
  null,
  "Verificando"
 ],
 "Version": [
  null,
  "Versión"
 ],
 "View all logs": [
  null,
  "Ver todos los registros"
 ],
 "View automation script": [
  null,
  "Ver el script de automatización"
 ],
 "View update log": [
  null,
  "Ver registro de actualización"
 ],
 "Visit firewall": [
  null,
  "Ir al cortafuegos"
 ],
 "Waiting for other software management operations to finish": [
  null,
  "Esperando a que finalicen otras operaciones de gestión de software"
 ],
 "Weak password": [
  null,
  "Contraseña débil"
 ],
 "Web Console for Linux servers": [
  null,
  "Consola web para servidores Linux"
 ],
 "Web Console will restart": [
  null,
  "La consola Web se reiniciará"
 ],
 "Wednesdays": [
  null,
  "Los miércoles"
 ],
 "When": [
  null,
  "Cuando"
 ],
 "When the Web Console is restarted, you will no longer see progress information. However, the update process will continue in the background. Reconnect to continue watching the update process.": [
  null,
  "Cuando se reinicie la consola Web, no podrás ver la información de progreso. Sin embargo, el proceso de actualización continuará de fondo. Reconéctate para continuar viendo el proceso de actualización."
 ],
 "You are connecting to $0 for the first time.": [
  null,
  "Se está conectando con $0 por primera vez."
 ],
 "Your browser does not allow paste from the context menu. You can use Shift+Insert.": [
  null,
  "Tu navegador no admite pegar desde el menú contextual. Puedes usar Shift+Insert."
 ],
 "Your server will close the connection soon. You can reconnect after it has restarted.": [
  null,
  "Su servidor cerrará la conexión pronto. Usted se puede volver a conectar después de que se haya reiniciado."
 ],
 "Your session has been terminated.": [
  null,
  "Su sesión se ha terminado."
 ],
 "Your session has expired. Please log in again.": [
  null,
  "Su sesión ha expirado. Por favor inicie sesión otra vez."
 ],
 "Zone": [
  null,
  "Zona"
 ],
 "[binary data]": [
  null,
  "[datos binarios]"
 ],
 "[no data]": [
  null,
  "[no hay datos]"
 ],
 "at": [
  null,
  "en"
 ],
 "bug fix": [
  null,
  "correción del fallo"
 ],
 "enhancement": [
  null,
  "mejora"
 ],
 "every Friday": [
  null,
  "cada viernes"
 ],
 "every Monday": [
  null,
  "cada lunes"
 ],
 "every Saturday": [
  null,
  "cada sábado"
 ],
 "every Sunday": [
  null,
  "cada domingo"
 ],
 "every Thursday": [
  null,
  "cada jueves"
 ],
 "every Tuesday": [
  null,
  "cada martes"
 ],
 "every Wednesday": [
  null,
  "cada miércoles"
 ],
 "every day": [
  null,
  "cada día"
 ],
 "for current and future kernels": [
  null,
  "para el actual y futuros kernels"
 ],
 "for current kernel only": [
  null,
  "sólo en el kernel actual"
 ],
 "in less than a minute": [
  null,
  "es menos de un minuto"
 ],
 "less than a minute ago": [
  null,
  "es menos que hace un minuto"
 ],
 "password quality": [
  null,
  "calidad de la contraseña"
 ],
 "patches": [
  null,
  "parches"
 ],
 "security": [
  null,
  "seguridad"
 ],
 "show less": [
  null,
  "mostrar menos"
 ],
 "show more": [
  null,
  "mostrar más"
 ]
});
