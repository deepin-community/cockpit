cockpit.locale({
 "": {
  "plural-forms": (n) => n != 1,
  "language": "sv",
  "language-direction": "ltr"
 },
 "$0 GiB": [
  null,
  "$0 GiB"
 ],
 "$0 day": [
  null,
  "$0 dag",
  "$0 dagar"
 ],
 "$0 exited with code $1": [
  null,
  "$0 avslutade med kod $1"
 ],
 "$0 failed": [
  null,
  "$0 misslyckades"
 ],
 "$0 hour": [
  null,
  "$0 timme",
  "$0 timmar"
 ],
 "$0 is not available from any repository.": [
  null,
  "$0 är inte tillgängligt från något förråd."
 ],
 "$0 key changed": [
  null,
  "$0 nyckel ändrad"
 ],
 "$0 killed with signal $1": [
  null,
  "$0 dödad med signal $1"
 ],
 "$0 minute": [
  null,
  "$0 minut",
  "$0 minuter"
 ],
 "$0 month": [
  null,
  "$0 månad",
  "$0 månader"
 ],
 "$0 package": [
  null,
  "$0 paket",
  "$0 paket"
 ],
 "$0 package needs a system reboot": [
  null,
  "$0 paket behöver en omstart av systemet",
  "$0 paket behöver en omstart av systemet"
 ],
 "$0 security fix available": [
  null,
  "$0 säkerhetsuppdatering tillgänglig",
  "$0 säkerhetsuppdateringar tillgängliga"
 ],
 "$0 service needs to be restarted": [
  null,
  "$0 tjänst måste startas om",
  "$0 tjänster måste startas om"
 ],
 "$0 update available": [
  null,
  "$0 uppdatering tillgänglig",
  "$0 uppdateringar tillgängliga"
 ],
 "$0 week": [
  null,
  "$0 vecka",
  "$0 veckor"
 ],
 "$0 will be installed.": [
  null,
  "$0 kommer att installeras."
 ],
 "$0 year": [
  null,
  "$0 år",
  "$0 år"
 ],
 ", including $1 security fix": [
  null,
  ", inklusive $1 säkerhetsfix",
  ", inklusive $1 säkerhetsfixar"
 ],
 "1 day": [
  null,
  "1 dag"
 ],
 "1 hour": [
  null,
  "1 timme"
 ],
 "1 minute": [
  null,
  "1 minut"
 ],
 "1 week": [
  null,
  "1 vecka"
 ],
 "20 minutes": [
  null,
  "20 minuter"
 ],
 "40 minutes": [
  null,
  "40 minuter"
 ],
 "5 minutes": [
  null,
  "5 minuter"
 ],
 "6 hours": [
  null,
  "6 timmar"
 ],
 "60 minutes": [
  null,
  "60 minuter"
 ],
 "A compatible version of Cockpit is not installed on $0.": [
  null,
  "Ingen kompatibel version av Cockpit är installerad på $0."
 ],
 "A new SSH key at $0 will be created for $1 on $2 and it will be added to the $3 file of $4 on $5.": [
  null,
  "En ny SSH-nyckel på $0 kommer att skapas för $1 på $2 och den kommer att läggas till $3-filen på $4 på $5."
 ],
 "A package needs a system reboot for the updates to take effect:": [
  null,
  "Ett paket behöver en systemomstart för att uppdateringen skall få effekt:",
  "Några paket behöver en systemomstart för att uppdateringen skall få effekt:"
 ],
 "A service needs to be restarted for the updates to take effect:": [
  null,
  "En tjänst måste startas om för att uppdateringarna ska träda i kraft:",
  "Vissa tjänster måste startas om för att uppdateringarna ska träda i kraft:"
 ],
 "Absent": [
  null,
  "Frånvarande"
 ],
 "Acceptable password": [
  null,
  "Acceptabelt lösenord"
 ],
 "Add $0": [
  null,
  "Lägg till $0"
 ],
 "Additional packages:": [
  null,
  "Ytterligare paket:"
 ],
 "Administration with Cockpit Web Console": [
  null,
  "Administration med Cockpits webbkonsol"
 ],
 "Advanced TCA": [
  null,
  "Avancerad TCA"
 ],
 "All updates": [
  null,
  "Alla uppdateringar"
 ],
 "All-in-one": [
  null,
  "Allt i ett"
 ],
 "Ansible": [
  null,
  "Ansible"
 ],
 "Ansible roles documentation": [
  null,
  "Dokumentation för Ansibleroller"
 ],
 "Apply kernel live patches": [
  null,
  "Lägg på driftsuppdateringar av kärnan"
 ],
 "Applying updates": [
  null,
  "Lägger på uppdateringar"
 ],
 "Applying updates failed": [
  null,
  "Att lägga på uppdateringar misslyckades"
 ],
 "Authentication": [
  null,
  "Autentisering"
 ],
 "Authentication is required to perform privileged tasks with the Cockpit Web Console": [
  null,
  "Autentisering krävs för att utföra privilegierade uppgifter med Cockpits webbkonsol"
 ],
 "Authorize SSH key": [
  null,
  "Auktorisera SSH-nyckel"
 ],
 "Automatic updates": [
  null,
  "Automatiska uppdateringar"
 ],
 "Automatically using NTP": [
  null,
  "Använder automatiskt NTP"
 ],
 "Automatically using additional NTP servers": [
  null,
  "Använder automatiskt ytterligare NTP-servrar"
 ],
 "Automatically using specific NTP servers": [
  null,
  "Använder automatiskt specifika NTP-servrar"
 ],
 "Automation script": [
  null,
  "Automatiseringsskript"
 ],
 "Available updates": [
  null,
  "Tillgängliga uppdateringar"
 ],
 "Blade": [
  null,
  "Blad"
 ],
 "Blade enclosure": [
  null,
  "Bladhölje"
 ],
 "Bug fix updates available": [
  null,
  "Felrättningsuppdateringar tillgängliga"
 ],
 "Bugs": [
  null,
  "Fel"
 ],
 "Bus expansion chassis": [
  null,
  "Bussexpansionschassi"
 ],
 "CVE": [
  null,
  "CVE"
 ],
 "Cancel": [
  null,
  "Avbryt"
 ],
 "Cannot forward login credentials": [
  null,
  "Kan inte vidarebefordra inloggningsuppgifterna"
 ],
 "Cannot schedule event in the past": [
  null,
  "Kan inte schemalägga händelser som redan hänt"
 ],
 "Change": [
  null,
  "Ändra"
 ],
 "Change system time": [
  null,
  "Ändra systemtid"
 ],
 "Changed keys are often the result of an operating system reinstallation. However, an unexpected change may indicate a third-party attempt to intercept your connection.": [
  null,
  "Ändrade nycklar är ofta resultatet av en ominstallation av operativsystemet. En oväntad förändring kan dock indikera ett försök från tredje part att avlyssna din anslutning."
 ],
 "Check for updates": [
  null,
  "Kontrollera om det finns uppdateringar"
 ],
 "Checking for package updates...": [
  null,
  "Söker efter programuppdateringar..."
 ],
 "Checking installed software": [
  null,
  "Kontrollerar installerad programvara"
 ],
 "Checking software status": [
  null,
  "Kontrollerar programvarustatus"
 ],
 "Clear input value": [
  null,
  "Rensa inmatningsvärde"
 ],
 "Close": [
  null,
  "Stäng"
 ],
 "Cockpit": [
  null,
  "Cockpit"
 ],
 "Cockpit configuration of NetworkManager and Firewalld": [
  null,
  "Cockpit konfiguration av NetworkManager och Firewalld"
 ],
 "Cockpit could not contact the given host.": [
  null,
  "Cockpit kunde inte kontakta den angivna värden."
 ],
 "Cockpit is a server manager that makes it easy to administer your Linux servers via a web browser. Jumping between the terminal and the web tool is no problem. A service started via Cockpit can be stopped via the terminal. Likewise, if an error occurs in the terminal, it can be seen in the Cockpit journal interface.": [
  null,
  "Cockpit är en serverhanterare som gör det lätt att administrera dina Linuxservrar via en webbläsare. Att hoppa mellan terminalen och webbverktyget är inget problem. En tjänst som startas via Cockpit kan stoppas via terminalen. Likaledes, om ett fel uppstår i terminalen kan det ses i Cockpits journalgränssnitt."
 ],
 "Cockpit is not compatible with the software on the system.": [
  null,
  "Cockpit är inte kompatibelt med programvaran på systemet."
 ],
 "Cockpit is not installed": [
  null,
  "Cockpit är inte installerat"
 ],
 "Cockpit is not installed on the system.": [
  null,
  "Cockpit är inte installerat på systemet."
 ],
 "Cockpit is perfect for new sysadmins, allowing them to easily perform simple tasks such as storage administration, inspecting journals and starting and stopping services. You can monitor and administer several servers at the same time. Just add them with a single click and your machines will look after its buddies.": [
  null,
  "Cockpit är perfekt för nya systemadministratörer, låter dem lätt utföra enkla uppgifter såsom lagringsadministration, inspektion av journaler och att starta och stoppa tjänster. Du kan övervaka och administrera flera servrar på samma gång. Lägg bara till dem med ett enda klick och dina maskiner kommer se efter sina kompisar."
 ],
 "Collect and package diagnostic and support data": [
  null,
  "Samla och paketera diagnostik och support data"
 ],
 "Collect kernel crash dumps": [
  null,
  "Samla kärnkraschdumpar"
 ],
 "Compact PCI": [
  null,
  "Kompakt PCI"
 ],
 "Confirm key password": [
  null,
  "Bekräfta lösenord för nyckel"
 ],
 "Connection has timed out.": [
  null,
  "Anslutningens tidsgräns överskreds."
 ],
 "Continue": [
  null,
  "Fortsätt"
 ],
 "Convertible": [
  null,
  "Konvertibel"
 ],
 "Copied": [
  null,
  "Kopierade"
 ],
 "Copy": [
  null,
  "Kopiera"
 ],
 "Copy to clipboard": [
  null,
  "Kopiera till urklipp"
 ],
 "Create $0": [
  null,
  "Skapa $0"
 ],
 "Create a new SSH key and authorize it": [
  null,
  "Skapa en ny SSH-nyckel och auktorisera den"
 ],
 "Create new task file with this content.": [
  null,
  "Skapa en ny uppgiftsfil med detta innehåll."
 ],
 "Ctrl+Insert": [
  null,
  "Ctrl+Insert"
 ],
 "Danger alert:": [
  null,
  "Fara varning:"
 ],
 "Delay": [
  null,
  "Fördröjning"
 ],
 "Desktop": [
  null,
  "Skrivbord"
 ],
 "Detachable": [
  null,
  "Frånkopplingsbar"
 ],
 "Details": [
  null,
  "Detaljer"
 ],
 "Diagnostic reports": [
  null,
  "Diagnostikrapporter"
 ],
 "Disabled": [
  null,
  "Avaktiverad"
 ],
 "Docking station": [
  null,
  "Dockningsstation"
 ],
 "Downloaded": [
  null,
  "Hämtat"
 ],
 "Downloading": [
  null,
  "Hämtar"
 ],
 "Downloading $0": [
  null,
  "Hämtar $0"
 ],
 "Dual rank": [
  null,
  "Dubbelrad"
 ],
 "Edit": [
  null,
  "Redigera"
 ],
 "Embedded PC": [
  null,
  "Inbäddad PC"
 ],
 "Enable": [
  null,
  "Aktivera"
 ],
 "Enabled": [
  null,
  "Aktiverad"
 ],
 "Enhancement updates available": [
  null,
  "Förbättringsuppdateringar är tillgängliga"
 ],
 "Errata": [
  null,
  "Errata"
 ],
 "Excellent password": [
  null,
  "Utmärkt lösenord"
 ],
 "Expansion chassis": [
  null,
  "Expansionschassin"
 ],
 "Failed to change password": [
  null,
  "Misslyckades att ändra lösenord"
 ],
 "Failed to enable $0 in firewalld": [
  null,
  "Misslyckades med att aktivera $0 i firewalld"
 ],
 "Failed to parse unit files for dnf-automatic.timer or dnf-automatic-install.timer. Please remove custom overrides to configure automatic updates.": [
  null,
  "Det gick inte att analysera enhetsfiler för dnf-automatic.timer eller dnf-automatic-install.timer. Ta bort anpassade åsidosättningar för att konfigurera automatiska uppdateringar."
 ],
 "Failed to restart service": [
  null,
  "Misslyckades med att starta om tjänst"
 ],
 "Fridays": [
  null,
  "Fredagar"
 ],
 "Go to now": [
  null,
  "Gå till nu"
 ],
 "Handheld": [
  null,
  "Handhållen"
 ],
 "Hide confirmation password": [
  null,
  "Dölj bekräftelselösenord"
 ],
 "Hide password": [
  null,
  "Dölj lösenord"
 ],
 "History package count": [
  null,
  "Historiepaketantal"
 ],
 "Host key is incorrect": [
  null,
  "Värdnyckeln är felaktig"
 ],
 "If the fingerprint matches, click 'Trust and add host'. Otherwise, do not connect and contact your administrator.": [
  null,
  "Om fingeravtrycket stämmer, klicka på \"Lita på och lägg till värd\". Annars, anslut inte och kontakta din administratör."
 ],
 "Ignore": [
  null,
  "Ignorera"
 ],
 "Info": [
  null,
  "Information"
 ],
 "Initializing...": [
  null,
  "Initierar …"
 ],
 "Install": [
  null,
  "Installera"
 ],
 "Install all updates": [
  null,
  "Installera alla uppdateringar"
 ],
 "Install kpatch updates": [
  null,
  "Installera kpatch uppdateringar"
 ],
 "Install security updates": [
  null,
  "Installera säkerhetsuppdateringar"
 ],
 "Install software": [
  null,
  "Installera programvara"
 ],
 "Installed": [
  null,
  "Installerad"
 ],
 "Installing": [
  null,
  "Installerar"
 ],
 "Installing $0": [
  null,
  "Installerar $0"
 ],
 "Internal error": [
  null,
  "Internt fel"
 ],
 "Invalid date format": [
  null,
  "Felaktigt datumformat"
 ],
 "Invalid date format and invalid time format": [
  null,
  "Felaktigt datumformat och felaktigt tidsformat"
 ],
 "Invalid file permissions": [
  null,
  "Felaktiga filrättigheter"
 ],
 "Invalid time format": [
  null,
  "Felaktigt tidsformat"
 ],
 "Invalid timezone": [
  null,
  "Felaktig tidszon"
 ],
 "IoT gateway": [
  null,
  "IoT-gateway"
 ],
 "Kernel dump": [
  null,
  "Kärndump"
 ],
 "Kernel live patch $0 is active": [
  null,
  "Kärn-live-patch $0 är aktiv"
 ],
 "Kernel live patch $0 is installed": [
  null,
  "Kärn-live-patch $0 är installerad"
 ],
 "Kernel live patch settings": [
  null,
  "Kärn-live-patch-inställningar"
 ],
 "Kernel live patching": [
  null,
  "Kärn-live-patchning"
 ],
 "Key password": [
  null,
  "Nyckellösenord"
 ],
 "Laptop": [
  null,
  "Bärbar dator"
 ],
 "Last checked: $0": [
  null,
  "Senast kontrollerad: $0 sedan"
 ],
 "Learn more": [
  null,
  "Mer information"
 ],
 "Loading available updates failed": [
  null,
  "Inläsningen av tillgängliga uppdateringar misslyckades"
 ],
 "Loading available updates, please wait...": [
  null,
  "Läser in tillgängliga uppdateringar, var god dröj …"
 ],
 "Loading system modifications...": [
  null,
  "Läser in anpassningar till systemet..."
 ],
 "Log in": [
  null,
  "Logga in"
 ],
 "Log in to $0": [
  null,
  "Logga in till $0"
 ],
 "Log messages": [
  null,
  "Loggmeddelanden"
 ],
 "Login failed": [
  null,
  "Inloggningen misslyckades"
 ],
 "Low profile desktop": [
  null,
  "Lågprofilskrivbord"
 ],
 "Lunch box": [
  null,
  "Lunchlåda"
 ],
 "Main server chassis": [
  null,
  "Huvudserverchassi"
 ],
 "Manage storage": [
  null,
  "Hantera lagring"
 ],
 "Manually": [
  null,
  "Manuellt"
 ],
 "Message to logged in users": [
  null,
  "Meddelande till inloggade användare"
 ],
 "Mini PC": [
  null,
  "Mini-PC"
 ],
 "Mini tower": [
  null,
  "Minitorn"
 ],
 "Mondays": [
  null,
  "Måndagar"
 ],
 "More info...": [
  null,
  "Mer information..."
 ],
 "Multi-system chassis": [
  null,
  "Multisystemschassi"
 ],
 "NTP server": [
  null,
  "NTP-server"
 ],
 "Name": [
  null,
  "Namn"
 ],
 "Need at least one NTP server": [
  null,
  "Behöver åtminstone en NTP-server"
 ],
 "Networking": [
  null,
  "Nätverk"
 ],
 "New password was not accepted": [
  null,
  "Det nya lösenordet godtogs inte"
 ],
 "No delay": [
  null,
  "Ingen fördröjning"
 ],
 "No results found": [
  null,
  "Inga resultat funna"
 ],
 "No such file or directory": [
  null,
  "Filen eller katalogen finns inte"
 ],
 "No system modifications": [
  null,
  "Inga systemändringar"
 ],
 "No updates": [
  null,
  "Inga uppdateringar"
 ],
 "Not a valid private key": [
  null,
  "Inte en giltig privat nyckel"
 ],
 "Not available": [
  null,
  "Inte tillgängligt"
 ],
 "Not installed": [
  null,
  "Inte installerad"
 ],
 "Not permitted to perform this action.": [
  null,
  "Inte tillåtet att utföra denna åtgärd."
 ],
 "Not registered": [
  null,
  "Inte registrerad"
 ],
 "Not set up": [
  null,
  "Inte uppsatt"
 ],
 "Not synchronized": [
  null,
  "Inte synkroniserad"
 ],
 "Notebook": [
  null,
  "Bärbar (notebook)"
 ],
 "Occurrences": [
  null,
  "Förekomster"
 ],
 "Ok": [
  null,
  "Ok"
 ],
 "Old password not accepted": [
  null,
  "Det gamla lösenordet accepterades inte"
 ],
 "Once Cockpit is installed, enable it with \"systemctl enable --now cockpit.socket\".": [
  null,
  "När Cockpit är installerat, aktivera det med ”systemctl enable --now cockpit.socket”."
 ],
 "Other": [
  null,
  "Annan"
 ],
 "Package information": [
  null,
  "Paketinformation"
 ],
 "PackageKit crashed": [
  null,
  "PackageKit kraschade"
 ],
 "PackageKit is not installed": [
  null,
  "PackageKit är inte installerat"
 ],
 "PackageKit reported error code $0": [
  null,
  "PackageKit rapporterade felkod $0"
 ],
 "Packages": [
  null,
  "Paket"
 ],
 "Password": [
  null,
  "Lösenord"
 ],
 "Password is not acceptable": [
  null,
  "Lösenordet är inte godtagbart"
 ],
 "Password is too weak": [
  null,
  "Lösenordet är för svagt"
 ],
 "Password not accepted": [
  null,
  "Lösenordet accepterades inte"
 ],
 "Paste": [
  null,
  "Klistra in"
 ],
 "Paste error": [
  null,
  "Klistra in fel"
 ],
 "Path to file": [
  null,
  "Sökväg till filen"
 ],
 "Peripheral chassis": [
  null,
  "Periferichassi"
 ],
 "Pick date": [
  null,
  "Välj datum"
 ],
 "Pizza box": [
  null,
  "Pizzalåda"
 ],
 "Please resolve the issue and reload this page.": [
  null,
  "Snälla lös problemet och ladda om den här sidan."
 ],
 "Portable": [
  null,
  "Bärbar"
 ],
 "Present": [
  null,
  "Närvarande"
 ],
 "Prompting via ssh-add timed out": [
  null,
  "Tidsgränsen överskreds vid fråga via ssh-add"
 ],
 "Prompting via ssh-keygen timed out": [
  null,
  "Tidsgränsen överskreds vid fråga via ssh-keygen"
 ],
 "RAID chassis": [
  null,
  "RAID-chassi"
 ],
 "Rack mount chassis": [
  null,
  "Rackmonteringschassi"
 ],
 "Reboot": [
  null,
  "Starta om"
 ],
 "Reboot after completion": [
  null,
  "Starta om efteråt"
 ],
 "Reboot recommended": [
  null,
  "Omstart rekommenderas"
 ],
 "Reboot system...": [
  null,
  "Starta om system..."
 ],
 "Refreshing package information": [
  null,
  "Uppdaterar paketinformation"
 ],
 "Register…": [
  null,
  "Registrera …"
 ],
 "Reloading the state of remaining services": [
  null,
  "Laddar om tillståndet för återstående tjänster"
 ],
 "Removals:": [
  null,
  "Borttagningar:"
 ],
 "Removing $0": [
  null,
  "Tar bort $0"
 ],
 "Restart services": [
  null,
  "Starta om tjänster"
 ],
 "Restart services...": [
  null,
  "Starta om tjänster..."
 ],
 "Restarting": [
  null,
  "Startar om"
 ],
 "Row expansion": [
  null,
  "Radexpansion"
 ],
 "Row select": [
  null,
  "Radval"
 ],
 "Run this command over a trusted network or physically on the remote machine:": [
  null,
  "Kör det här kommandot över ett pålitligt nätverk eller fysiskt på fjärrdatorn:"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "SSH key": [
  null,
  "SSH-nyckel"
 ],
 "SSH key login": [
  null,
  "SSH-nyckel inloggning"
 ],
 "Saturdays": [
  null,
  "Lördagar"
 ],
 "Save": [
  null,
  "Spara"
 ],
 "Save changes": [
  null,
  "Spara ändringar"
 ],
 "Sealed-case PC": [
  null,
  "PC med slutet hölje"
 ],
 "Security Enhanced Linux configuration and troubleshooting": [
  null,
  "Säkerhetsförbättrad Linux-konfiguration och felsökning"
 ],
 "Security updates available": [
  null,
  "Säkerhetsuppdateringar tillgängliga"
 ],
 "Security updates only": [
  null,
  "Säkerhetsuppdateringar endast"
 ],
 "Security updates will be applied $0 at $1": [
  null,
  "Säkerhetsuppdateringar kommer att tillämpas $0 vid $1"
 ],
 "Select an option": [
  null,
  "Välj ett alternativ"
 ],
 "Server has closed the connection.": [
  null,
  "Servern har stängt förbindelsen."
 ],
 "Set time": [
  null,
  "Ställ in tiden"
 ],
 "Set up": [
  null,
  "Sätt upp"
 ],
 "Setting up": [
  null,
  "Sätter upp"
 ],
 "Settings": [
  null,
  "Inställningar"
 ],
 "Severity": [
  null,
  "Allvarsgrad"
 ],
 "Shell script": [
  null,
  "Skalskript"
 ],
 "Shift+Insert": [
  null,
  "Skift+Insert"
 ],
 "Show confirmation password": [
  null,
  "Visa bekräftelselösenord"
 ],
 "Show password": [
  null,
  "Visa lösenord"
 ],
 "Shut down": [
  null,
  "Stäng av"
 ],
 "Single rank": [
  null,
  "Ensam ordning"
 ],
 "Software updates": [
  null,
  "Programvaruuppdateringar"
 ],
 "Some other program is currently using the package manager, please wait...": [
  null,
  "Något annat program använder just nu pakethanteraren, var god dröj …"
 ],
 "Some software needs to be restarted manually": [
  null,
  "Vissa program måste startas om manuellt"
 ],
 "Space-saving computer": [
  null,
  "Utrymmessparande dator"
 ],
 "Specific time": [
  null,
  "Specifik tid"
 ],
 "Status": [
  null,
  "Status"
 ],
 "Stick PC": [
  null,
  "Pinndator"
 ],
 "Storage": [
  null,
  "Lagring"
 ],
 "Strong password": [
  null,
  "Starkt lösenord"
 ],
 "Sub-Chassis": [
  null,
  "Under-chassi"
 ],
 "Sub-Notebook": [
  null,
  "ULPC"
 ],
 "Sundays": [
  null,
  "Söndagar"
 ],
 "Synchronized": [
  null,
  "Synkroniserad"
 ],
 "Synchronized with $0": [
  null,
  "Synkroniserad med $0"
 ],
 "Synchronizing": [
  null,
  "Synkroniserar"
 ],
 "System is up to date": [
  null,
  "Systemet är uppdaterat"
 ],
 "Tablet": [
  null,
  "Platta"
 ],
 "The SSH key $0 of $1 on $2 will be added to the $3 file of $4 on $5.": [
  null,
  "SSH-nyckeln $0 av $1 på $2 kommer att läggas till $3-filen på $4 på $5."
 ],
 "The SSH key $0 will be made available for the remainder of the session and will be available for login to other hosts as well.": [
  null,
  "SSH-nyckeln $0 kommer att göras tillgänglig för resten av sessionen och kommer att vara tillgänglig för inloggning även för andra värdar."
 ],
 "The SSH key for logging in to $0 is protected by a password, and the host does not allow logging in with a password. Please provide the password of the key at $1.": [
  null,
  "SSH-nyckeln för att logga in på $0 är skyddad av ett lösenord, och värden tillåter inte inloggning med ett lösenord. Vänligen ange lösenordet för nyckeln på $1."
 ],
 "The SSH key for logging in to $0 is protected. You can log in with either your login password or by providing the password of the key at $1.": [
  null,
  "SSH-nyckeln för att logga in på $0 är skyddad. Du kan logga in med antingen ditt inloggningslösenord eller genom att ange lösenordet för nyckeln för $1."
 ],
 "The fingerprint should match:": [
  null,
  "Fingeravtrycket ska matcha:"
 ],
 "The following service will be restarted:": [
  null,
  "Följande tjänst kommer att startas om:",
  "Följande tjänster kommer att startas om:"
 ],
 "The key password can not be empty": [
  null,
  "Nyckellösenordet får inte vara tomt"
 ],
 "The key passwords do not match": [
  null,
  "Nyckellösenorden stämmer inte överens"
 ],
 "The logged in user is not permitted to view system modifications": [
  null,
  "Den inloggade användaren har inte tillåtelse att se systemändringar"
 ],
 "The password can not be empty": [
  null,
  "Lösenordet får inte vara tomt"
 ],
 "The resulting fingerprint is fine to share via public methods, including email.": [
  null,
  "Det resulterande fingeravtrycket går bra att dela via offentliga metoder, inklusive e-post."
 ],
 "The resulting fingerprint is fine to share via public methods, including email. If you are asking someone else to do the verification for you, they can send the results using any method.": [
  null,
  "Det resulterande fingeravtrycket är okej att dela via offentliga metoder, inklusive e-post. Om du ber någon annan att göra verifieringen åt dig kan de skicka resultaten med vilken metod som helst."
 ],
 "The server refused to authenticate using any supported methods.": [
  null,
  "Servern vägrade att autentisera med några stödda metoder."
 ],
 "This host will reboot after updates are installed.": [
  null,
  "Denna värd kommer att starta om efter att uppdateringar har installerats."
 ],
 "This system is not registered": [
  null,
  "Detta system är inte registrerat"
 ],
 "This tool configures the SELinux policy and can help with understanding and resolving policy violations.": [
  null,
  "Det här verktyget konfigurerar SELinux-policyn och kan hjälpa till med att förstå och lösa policy överträdelser."
 ],
 "This tool configures the system to write kernel crash dumps. It supports the \"local\" (disk), \"ssh\", and \"nfs\" dump targets.": [
  null,
  "Det här verktyget konfigurerar systemet till att kunna skriva kärnkraschdumpar till disken. Det stödjer \"lokala\" (disk), \"ssh\" och \"nfs\" dumpmål."
 ],
 "This tool generates an archive of configuration and diagnostic information from the running system. The archive may be stored locally or centrally for recording or tracking purposes or may be sent to technical support representatives, developers or system administrators to assist with technical fault-finding and debugging.": [
  null,
  "Detta verktyg genererar ett arkiv med konfiguration och diagnostisk information från det körande systemet. Arkivet kan förvaras lokalt eller centralt för inspelning eller spårningsändamål eller kan skickas till tekniska supportrepresentanter, utvecklare eller systemadministratörer för att hjälpa till med teknisk felspårning och felsökning."
 ],
 "This tool manages local storage, such as filesystems, LVM2 volume groups, and NFS mounts.": [
  null,
  "Detta verktyg hanterar lokal lagring, såsom filsystem, LVM2-volymgrupper och NFS-monteringar."
 ],
 "This tool manages networking such as bonds, bridges, teams, VLANs and firewalls using NetworkManager and Firewalld. NetworkManager is incompatible with Ubuntu's default systemd-networkd and Debian's ifupdown scripts.": [
  null,
  "Detta verktyg hanterar nätverk som bindningar, broar, team, VLAN och brandväggar med NetworkManager och Firewalld. NetworkManager är inkompatibelt med Ubuntus standard systemd-networkd och Debians ifupdown skript."
 ],
 "Thursdays": [
  null,
  "Torsdagar"
 ],
 "Time": [
  null,
  "Tid"
 ],
 "Time zone": [
  null,
  "Tidszon"
 ],
 "To ensure that your connection is not intercepted by a malicious third-party, please verify the host key fingerprint:": [
  null,
  "För att säkerställa att din anslutning inte fångas upp av en skadlig tredje part, vänligen verifiera värdnyckelns fingeravtryck:"
 ],
 "To get software updates, this system needs to be registered with Red Hat, either using the Red Hat Customer Portal or a local subscription server.": [
  null,
  "För att få programvaruuppdateringar behöver detta system registreras hos Red Hat, antingen genom att använda Red Hats kundportal eller en lokal prenumerationsserver."
 ],
 "To verify a fingerprint, run the following on $0 while physically sitting at the machine or through a trusted network:": [
  null,
  "För att verifiera ett fingeravtryck, kör följande på $0 medan du fysiskt sitter vid maskinen eller genom ett pålitligt nätverk:"
 ],
 "Toggle date picker": [
  null,
  "Växla datumväljare"
 ],
 "Too much data": [
  null,
  "För mycket data"
 ],
 "Total size: $0": [
  null,
  "Total storlek: $0"
 ],
 "Tower": [
  null,
  "Torn"
 ],
 "Trust and add host": [
  null,
  "Lita på och lägg till värd"
 ],
 "Trying to synchronize with $0": [
  null,
  "Försök att synkronisera med $0"
 ],
 "Tuesdays": [
  null,
  "Tisdagar"
 ],
 "Type": [
  null,
  "Typ"
 ],
 "Unable to log in to $0 using SSH key authentication. Please provide the password.": [
  null,
  "Det går inte att logga in på $0 med SSH-nyckelautentisering. Ange lösenordet."
 ],
 "Unable to log in to $0. The host does not accept password login or any of your SSH keys.": [
  null,
  "Det går inte att logga in på $0. Värden accepterar inte lösenordsinloggning eller någon av dina SSH-nycklar."
 ],
 "Unavailable packages": [
  null,
  "Otillgängliga paket"
 ],
 "Unknown": [
  null,
  "Okänd"
 ],
 "Unknown host: $0": [
  null,
  "Okänd värd: $0"
 ],
 "Untrusted host": [
  null,
  "Ej betrodd värd"
 ],
 "Update Success Table": [
  null,
  "Uppdatera framgångstabell"
 ],
 "Update history": [
  null,
  "Uppdateringshistorik"
 ],
 "Update was successful": [
  null,
  "Uppdateringen lyckades"
 ],
 "Updated": [
  null,
  "Uppdaterat"
 ],
 "Updated packages may require a reboot to take effect.": [
  null,
  "Uppdaterade paket kan behöva en omstart för att få effekt."
 ],
 "Updates available": [
  null,
  "Uppdateringar tillgängliga"
 ],
 "Updates history": [
  null,
  "Uppdatera historik"
 ],
 "Updates will be applied $0 at $1": [
  null,
  "Uppdateringar kommer att tillämpas $0 vid $1"
 ],
 "Updating": [
  null,
  "Uppdaterar"
 ],
 "Verified": [
  null,
  "Verifierad"
 ],
 "Verify fingerprint": [
  null,
  "Verifiera fingeravtryck"
 ],
 "Verifying": [
  null,
  "Verifierar"
 ],
 "Version": [
  null,
  "Version"
 ],
 "View all logs": [
  null,
  "Visa alla loggar"
 ],
 "View automation script": [
  null,
  "Visa automatiseringsskript"
 ],
 "View update log": [
  null,
  "Visa uppdateringsloggen"
 ],
 "Visit firewall": [
  null,
  "Besök brandvägg"
 ],
 "Waiting for other software management operations to finish": [
  null,
  "Väntar på att andra programvaruhanteringsåtgärder skall bli klara"
 ],
 "Weak password": [
  null,
  "Svagt lösenord"
 ],
 "Web Console for Linux servers": [
  null,
  "Webbkonsol för Linuxservrar"
 ],
 "Web Console will restart": [
  null,
  "Webbkonsolen kommer att starta om"
 ],
 "Wednesdays": [
  null,
  "Onsdagar"
 ],
 "When": [
  null,
  "När"
 ],
 "When the Web Console is restarted, you will no longer see progress information. However, the update process will continue in the background. Reconnect to continue watching the update process.": [
  null,
  "När webbkonsolen startas om kommer man inte längre att se förloppsinformation. Dock kommer uppdateringsprocessen att fortsätta i bakgrunden. Återanslut för att fortsätta se uppdateringsprocessen."
 ],
 "You are connecting to $0 for the first time.": [
  null,
  "Du ansluter till $0 för första gången."
 ],
 "Your browser does not allow paste from the context menu. You can use Shift+Insert.": [
  null,
  "Din webbläsare tillåter inte att klistra in från sammanhangsmenyn. Du kan använda Skift+Insert."
 ],
 "Your server will close the connection soon. You can reconnect after it has restarted.": [
  null,
  "Din server kommer stänga förbindelsen snart. Du kan återansluta efter att den har startat om."
 ],
 "Your session has been terminated.": [
  null,
  "Din session har avslutats."
 ],
 "Your session has expired. Please log in again.": [
  null,
  "Din session har gått ut. Logga in igen."
 ],
 "Zone": [
  null,
  "Zon"
 ],
 "[binary data]": [
  null,
  "[binärdata]"
 ],
 "[no data]": [
  null,
  "[inga data]"
 ],
 "at": [
  null,
  "klockan"
 ],
 "bug fix": [
  null,
  "felrättning"
 ],
 "enhancement": [
  null,
  "förbättring"
 ],
 "every Friday": [
  null,
  "varje fredag"
 ],
 "every Monday": [
  null,
  "varje måndag"
 ],
 "every Saturday": [
  null,
  "varje lördag"
 ],
 "every Sunday": [
  null,
  "varje söndag"
 ],
 "every Thursday": [
  null,
  "varje torsdag"
 ],
 "every Tuesday": [
  null,
  "varje tisdag"
 ],
 "every Wednesday": [
  null,
  "varje onsdag"
 ],
 "every day": [
  null,
  "varje dag"
 ],
 "for current and future kernels": [
  null,
  "för nuvarande och framtida kärnor"
 ],
 "for current kernel only": [
  null,
  "för nuvarande kärna endast"
 ],
 "in less than a minute": [
  null,
  "i mindre än en minut"
 ],
 "less than a minute ago": [
  null,
  "mindre än en minut sedan"
 ],
 "password quality": [
  null,
  "lösenordskvalitet"
 ],
 "patches": [
  null,
  "rättningar"
 ],
 "security": [
  null,
  "säkerhet"
 ],
 "show less": [
  null,
  "visa mindre"
 ],
 "show more": [
  null,
  "visa mer"
 ]
});
