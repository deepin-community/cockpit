cockpit.locale({
 "": {
  "plural-forms": (n) => n != 1,
  "language": "ka",
  "language-direction": "ltr"
 },
 "$0 GiB": [
  null,
  "$0 გიბ"
 ],
 "$0 day": [
  null,
  "$0 დღე",
  "დღეები: $0"
 ],
 "$0 exited with code $1": [
  null,
  "$0-ის გამოსვლის კოდია $1"
 ],
 "$0 failed": [
  null,
  "$0 წარუმატებელია"
 ],
 "$0 hour": [
  null,
  "$0 საათი",
  "საათი: $0"
 ],
 "$0 is not available from any repository.": [
  null,
  "$0 ხელმიუწვდომელია ყველა რეპოზიტორიიდან."
 ],
 "$0 key changed": [
  null,
  "$0 გასაღები შეიცვალა"
 ],
 "$0 killed with signal $1": [
  null,
  "$0 მოკვდა სიგნალით $1"
 ],
 "$0 minute": [
  null,
  "$0 წუთი",
  "წუთი: $0"
 ],
 "$0 month": [
  null,
  "$0 თვე",
  "თვე: $0"
 ],
 "$0 package": [
  null,
  "$0 პაკეტი",
  "$0 ცალი პაკეტი"
 ],
 "$0 package needs a system reboot": [
  null,
  "$0 პაკეტს სჭირდება სისტემის გადატვირთვა",
  "$0 ცალ პაკეტს სჭირდება სისტემის გადატვირთვა"
 ],
 "$0 security fix available": [
  null,
  "ხელმისაწვდომია $0 უსაფრთხოების განახლება",
  "ხელმისაწვდომია $0 ცალი უსაფრთხოების განახლება"
 ],
 "$0 service needs to be restarted": [
  null,
  "$0 სერვისს სჭირდება სისტემის გადატვირთვა",
  "$0 ცალ სერვისს სჭირდება სისტემის გადატვირთვა"
 ],
 "$0 update available": [
  null,
  "ხელმისაწვდომია $0 განახლება",
  "ხელმისაწვდომია $0 ცალი განახლება"
 ],
 "$0 week": [
  null,
  "$0 კვირა",
  "კვირა: $0"
 ],
 "$0 will be installed.": [
  null,
  "დაყენდება $0."
 ],
 "$0 year": [
  null,
  "$0 წელი",
  "წელი: $0"
 ],
 ", including $1 security fix": [
  null,
  ", $1 უსაფრთხოების პაჩი",
  ", $1 ცალი უსაფრთხოების პაჩი"
 ],
 "1 day": [
  null,
  "1 დღე"
 ],
 "1 hour": [
  null,
  "1 საათი"
 ],
 "1 minute": [
  null,
  "1 წთ"
 ],
 "1 week": [
  null,
  "1 კვირა"
 ],
 "20 minutes": [
  null,
  "20 წთ"
 ],
 "40 minutes": [
  null,
  "40 წთ"
 ],
 "5 minutes": [
  null,
  "5 წთ"
 ],
 "6 hours": [
  null,
  "5 სთ"
 ],
 "60 minutes": [
  null,
  "60 წთ"
 ],
 "A compatible version of Cockpit is not installed on $0.": [
  null,
  "$0-ზე არ აყენია Cockpit-ის თავსებადი ვერსია."
 ],
 "A new SSH key at $0 will be created for $1 on $2 and it will be added to the $3 file of $4 on $5.": [
  null,
  "ახალი SSH გასაღები $0-თვის შეიქნება $1-თვის $2-ზე და დაემატება $3 ფაილს $4-ის ფაილს $5-ზე."
 ],
 "A package needs a system reboot for the updates to take effect:": [
  null,
  "ცვლილებების სანახავად პაკეტს სისტემის გადატვირთვა სჭირდება:",
  "ზოგიერთ პაკეტს ცვლილებების სანახავად სისტემის გადატვირთვა სჭირდება:"
 ],
 "A service needs to be restarted for the updates to take effect:": [
  null,
  "განსაახლებლად სერვისს სჭირდება სისტემის გადატვირთვა:",
  "განსაახლებლად სერვისებს სჭირდებათ სისტემის გადატვირთვა:"
 ],
 "Absent": [
  null,
  "აკლია"
 ],
 "Acceptable password": [
  null,
  "მისაღები პაროლი"
 ],
 "Add $0": [
  null,
  "$0-ის დამატება"
 ],
 "Additional packages:": [
  null,
  "დამატებითი პაკეტები:"
 ],
 "Administration with Cockpit Web Console": [
  null,
  "Cockput ვებ კონსოლით ადმინისტრირება"
 ],
 "Advanced TCA": [
  null,
  "დამატებითი TCA"
 ],
 "All updates": [
  null,
  "ყველა განახლება"
 ],
 "All-in-one": [
  null,
  "ყველა-ერთში"
 ],
 "Ansible": [
  null,
  "Ansible"
 ],
 "Ansible roles documentation": [
  null,
  "Ansible-ის როლების დოკუმენტაცია"
 ],
 "Apply kernel live patches": [
  null,
  "გაშვებული ბირთვის პაჩების გადატარება"
 ],
 "Applying updates": [
  null,
  "განახლებების გადატარება"
 ],
 "Applying updates failed": [
  null,
  "განახლებების გადატარების შეცდომა"
 ],
 "Authentication": [
  null,
  "ავთენტიკაცია"
 ],
 "Authentication is required to perform privileged tasks with the Cockpit Web Console": [
  null,
  "Cockpit ვებ კონსოლში პრივილეგირებული ამოცანების შესასრულებლად საჭიროა ავთენტიკაცია"
 ],
 "Authorize SSH key": [
  null,
  "SSH გასაღების ავტორიზაცია"
 ],
 "Automatic updates": [
  null,
  "ავტომატური განახლებები"
 ],
 "Automatically using NTP": [
  null,
  "ავტომატურად, NTP-ით"
 ],
 "Automatically using additional NTP servers": [
  null,
  "დამატებითი NTP სერვერების ავტომატური გამოყენება"
 ],
 "Automatically using specific NTP servers": [
  null,
  "მითითებული NTP სერვერების ავტომატური გამოყენება"
 ],
 "Automation script": [
  null,
  "ავტომატიზაციის სკრიპტი"
 ],
 "Available updates": [
  null,
  "ხელმისაწვდომი განახლებები"
 ],
 "Blade": [
  null,
  "Blade"
 ],
 "Blade enclosure": [
  null,
  "კალათი"
 ],
 "Bug fix updates available": [
  null,
  "ხელმისაწვდომია შეცდომების გასწორებები"
 ],
 "Bugs": [
  null,
  "შეცდომები"
 ],
 "Bus expansion chassis": [
  null,
  "მატარებლის გაფართოების შასი"
 ],
 "CVE": [
  null,
  "CVE"
 ],
 "Cancel": [
  null,
  "გაუქმება"
 ],
 "Cannot forward login credentials": [
  null,
  "მომხმარებლისადაპაროლის გადაგზავნის შეცდომა"
 ],
 "Cannot schedule event in the past": [
  null,
  "მოვლენის წარსულ დროში დანიშვნა შეუძლებელია"
 ],
 "Change": [
  null,
  "შეცვლა"
 ],
 "Change system time": [
  null,
  "სისტემური დროის შეცვლა"
 ],
 "Changed keys are often the result of an operating system reinstallation. However, an unexpected change may indicate a third-party attempt to intercept your connection.": [
  null,
  "შეცვლილი გასაღებები ხშირად ოპერაციული სისტემის გადაყენებაზე მიუთითებს. ამავე დროს მოულოდნელი ცვლილება კავშირის გადასაჭერად მესამე პირის ჩარევასაც შეიძლება ნიშნავდეს."
 ],
 "Check for updates": [
  null,
  "განახლებების შემოწმება"
 ],
 "Checking for package updates...": [
  null,
  "პაკეტების განახლებების შემოწმება..."
 ],
 "Checking installed software": [
  null,
  "დაყენებული პროგრამული უზრუნველყოფის შემოწმება"
 ],
 "Checking software status": [
  null,
  "პროგრამის სტატუსის შემოწმება"
 ],
 "Clear input value": [
  null,
  "შეყვანილი მნიშვნელობის გასუფთავება"
 ],
 "Close": [
  null,
  "დახურვა"
 ],
 "Cockpit": [
  null,
  "Cockpit"
 ],
 "Cockpit configuration of NetworkManager and Firewalld": [
  null,
  "NetworkManager-ის და Firewalld-ის მორგება Cockpit-ით"
 ],
 "Cockpit could not contact the given host.": [
  null,
  "Cockpit-ს მითითებულ ჰოსტთან დაკავშირება არ შეუძლია ."
 ],
 "Cockpit is a server manager that makes it easy to administer your Linux servers via a web browser. Jumping between the terminal and the web tool is no problem. A service started via Cockpit can be stopped via the terminal. Likewise, if an error occurs in the terminal, it can be seen in the Cockpit journal interface.": [
  null,
  "Cockpit წარმოადგენს სერვერის მმართველს, რომლითაც Linux სერვერების ადმინისტრირება ბრაუზერითაც შეგიძლიათ. ტერმინალსა და ვებ ხელსაწყოს შორის გადართვა პრობლემა არაა. Cockpit-ით გაშვებული სერვისი შეგიძლიათ გააჩეროთ ტერმინალთაც. ასევე, თუ შეცდომა დაფიქსირდება ტერმინალში, მისი ნახვა Cockpit-ის საშუალებითაც შეგიძლიათ."
 ],
 "Cockpit is not compatible with the software on the system.": [
  null,
  "Cockpit-ი შეუთავსებელია თქვენს სერვერზე დაყენებულ პროგრამულ უზრუნველყოფასთან."
 ],
 "Cockpit is not installed": [
  null,
  "Cockpit-ი დაყენებული არაა"
 ],
 "Cockpit is not installed on the system.": [
  null,
  "Cockpit-ი ამ სისტემაზე დაყენებული არაა."
 ],
 "Cockpit is perfect for new sysadmins, allowing them to easily perform simple tasks such as storage administration, inspecting journals and starting and stopping services. You can monitor and administer several servers at the same time. Just add them with a single click and your machines will look after its buddies.": [
  null,
  "Cockpit შესანიშნავია ახალი სისტემური ადმინისტრატორებისთვის. ის მათ საშუალებას აძლევს ადვილად შეასრულონ ისეთი მარტივი ამოცანები, როგორიცაა შენახვის ადმინისტრირება, ჟურნალების შემოწმება და სერვისების დაწყება და გაჩერება. შეგიძლიათ ერთდროულად რამდენიმე სერვერის მონიტორინგი და ადმინისტრირება. უბრალოდ დაამატეთ ისინი ერთი დაწკაპუნებით და თქვენი მანქანები იზრუნებს მის მეგობრებზე."
 ],
 "Collect and package diagnostic and support data": [
  null,
  "მოაგროვეთ დიაგნოსტიკური და მხარდაჭერის მონაცემები"
 ],
 "Collect kernel crash dumps": [
  null,
  "ოპერაციული სისტემის ბირთვის ავარიის დამპები"
 ],
 "Compact PCI": [
  null,
  "კომპაქტური PCI"
 ],
 "Confirm key password": [
  null,
  "მეორედ შეიყვანეთ გასაღების პაროლი"
 ],
 "Connection has timed out.": [
  null,
  "კავშირის დრო გავიდა."
 ],
 "Continue": [
  null,
  "გაგრძელება"
 ],
 "Convertible": [
  null,
  "გარდაქმნადი"
 ],
 "Copied": [
  null,
  "დაკოპირებულია"
 ],
 "Copy": [
  null,
  "კოპირება"
 ],
 "Copy to clipboard": [
  null,
  "ბაფერში კოპირება"
 ],
 "Create $0": [
  null,
  "$0-ის შექმნა"
 ],
 "Create a new SSH key and authorize it": [
  null,
  "შექმენით SSH-ის ახალი გასაღები და გაატარეთ ავტორიზაცია"
 ],
 "Create new task file with this content.": [
  null,
  "ახალი ამოცანის ამ შემცველობით შექმნა."
 ],
 "Ctrl+Insert": [
  null,
  "Ctrl+Insert"
 ],
 "Danger alert:": [
  null,
  "საშიშროების შეტყობინება:"
 ],
 "Delay": [
  null,
  "დაყოვნება"
 ],
 "Desktop": [
  null,
  "სამუშაო მაგიდა"
 ],
 "Detachable": [
  null,
  "მოძრობადი"
 ],
 "Details": [
  null,
  "დეტალები"
 ],
 "Diagnostic reports": [
  null,
  "დიაგნოსტიკის ანგარიშები"
 ],
 "Disabled": [
  null,
  "გათიშულია"
 ],
 "Docking station": [
  null,
  "სამაგრი დაფა"
 ],
 "Downloaded": [
  null,
  "გადმოწერილია"
 ],
 "Downloading": [
  null,
  "გადმოწერა"
 ],
 "Downloading $0": [
  null,
  "$0-ის გადმოწერა"
 ],
 "Dual rank": [
  null,
  "ორმაგი რანგი"
 ],
 "Edit": [
  null,
  "ჩასწორება"
 ],
 "Embedded PC": [
  null,
  "ჩაშენებული PC"
 ],
 "Enable": [
  null,
  "ჩართვა"
 ],
 "Enabled": [
  null,
  "ჩართულია"
 ],
 "Enhancement updates available": [
  null,
  "ხელმისაწვდომია განახლებები"
 ],
 "Errata": [
  null,
  "დამატებითი პაჩები"
 ],
 "Excellent password": [
  null,
  "გადასარევი პაროლი"
 ],
 "Expansion chassis": [
  null,
  "გაფართოების კორპუსი"
 ],
 "Failed to change password": [
  null,
  "პაროლის შეცვლის შეცდომა"
 ],
 "Failed to enable $0 in firewalld": [
  null,
  "firewalld-ში $0-ის ჩართვის შეცდომა"
 ],
 "Failed to parse unit files for dnf-automatic.timer or dnf-automatic-install.timer. Please remove custom overrides to configure automatic updates.": [
  null,
  "dnf-automatic.timer ან dnf-automatic-install.timer-ისთვის სერვისის ფაილების დამუშავება ვერ მოხერხდა. გთხოვთ, წაშალოთ მორგებული უგულებელყოფა ავტომატური განახლებების კონფიგურაციისთვის."
 ],
 "Failed to restart service": [
  null,
  "სერვისის რესტარტის შეცდომა"
 ],
 "Fridays": [
  null,
  "კვირაობით"
 ],
 "Go to now": [
  null,
  "ახლავე გადასვლა"
 ],
 "Handheld": [
  null,
  "ჯიბის"
 ],
 "Hide confirmation password": [
  null,
  "დადასტურების პაროლის დამალვა"
 ],
 "Hide password": [
  null,
  "პაროლის დამალვა"
 ],
 "History package count": [
  null,
  "ისტორიის პაკეტის რიცხვი"
 ],
 "Host key is incorrect": [
  null,
  "ჰოსტის გასაღები არასწორია"
 ],
 "If the fingerprint matches, click 'Trust and add host'. Otherwise, do not connect and contact your administrator.": [
  null,
  "თუ ანაბეჭდი ემთხვევა, დააწექით \"ჰოსტის ნდობა და დამატებას\", ან არ შეხვიდეთ და დაუკავშირდით ადმინისტრატორს."
 ],
 "Ignore": [
  null,
  "იგნორი"
 ],
 "Info": [
  null,
  "ინფორმაცია"
 ],
 "Initializing...": [
  null,
  "ინიციალიზაცია..."
 ],
 "Install": [
  null,
  "დაყენება"
 ],
 "Install all updates": [
  null,
  "ყველა განახლების დაყენება"
 ],
 "Install kpatch updates": [
  null,
  "Kpatch-ის განახლების დაყენება"
 ],
 "Install security updates": [
  null,
  "უსაფრთხოების განახლებების დაყენება"
 ],
 "Install software": [
  null,
  "პროგრამების დაყენება"
 ],
 "Installed": [
  null,
  "დაყენებული"
 ],
 "Installing": [
  null,
  "მიმდინარეობს დაყენება"
 ],
 "Installing $0": [
  null,
  "$0-ის დაყენება"
 ],
 "Internal error": [
  null,
  "შიდა შეცდომა"
 ],
 "Invalid date format": [
  null,
  "თარიღის არასწორი ფორმატი"
 ],
 "Invalid date format and invalid time format": [
  null,
  "თარიღისა და დროის არასწორი ფორმატი"
 ],
 "Invalid file permissions": [
  null,
  "ფაილის არასწორი წვდომები"
 ],
 "Invalid time format": [
  null,
  "დროის არასწორი ფორმატი"
 ],
 "Invalid timezone": [
  null,
  "დროის არასწორი სარტყელი"
 ],
 "IoT gateway": [
  null,
  "IoT gateway"
 ],
 "Kernel dump": [
  null,
  "ბირთვის დამპი"
 ],
 "Kernel live patch $0 is active": [
  null,
  "ცოცხალი ბირთვის პაჩი $0 ახლა აქტიურია"
 ],
 "Kernel live patch $0 is installed": [
  null,
  "ცოცხალი ბირთვის პაჩი $0 დაყენებულია"
 ],
 "Kernel live patch settings": [
  null,
  "ჩართული ბირთვის პაჩის მორგება"
 ],
 "Kernel live patching": [
  null,
  "ოპერაციული სისტემის გაშვებული ბირთვის ჩასწორება"
 ],
 "Key password": [
  null,
  "გასაღების პაროლი"
 ],
 "Laptop": [
  null,
  "ლეპტოპი"
 ],
 "Last checked: $0": [
  null,
  "ბოლოს შემოწმდა: $0"
 ],
 "Learn more": [
  null,
  "გაიგეთ მეტი"
 ],
 "Loading available updates failed": [
  null,
  "ხელმისაწვდომი განახლებების ჩატვირთვი შეცდომა"
 ],
 "Loading available updates, please wait...": [
  null,
  "მიმდინარეობს ხელისაწვდომი განახლებების ჩატვირთვა. გთხოვთ მოითმინოთ..."
 ],
 "Loading system modifications...": [
  null,
  "სისტემის ცვლილებების ჩატვირთვა..."
 ],
 "Log in": [
  null,
  "შესვლა"
 ],
 "Log in to $0": [
  null,
  "$0-ში შესვლა"
 ],
 "Log messages": [
  null,
  "ჟურნალის შეტყობინებები"
 ],
 "Login failed": [
  null,
  "შესვლა წარუმატებელია"
 ],
 "Low profile desktop": [
  null,
  "დაბალი პროფილის სამუშაო მაგიდა"
 ],
 "Lunch box": [
  null,
  "Lunch box"
 ],
 "Main server chassis": [
  null,
  "სერვერის მთავარი შასი"
 ],
 "Manage storage": [
  null,
  "საცავის მართვა"
 ],
 "Manually": [
  null,
  "ხელით მითითებული"
 ],
 "Message to logged in users": [
  null,
  "შესული მომხმარებლებისთვის შეტყობინების გაგზავნა"
 ],
 "Mini PC": [
  null,
  "მინი PC"
 ],
 "Mini tower": [
  null,
  "კომპიუტერი პატარა ყუთით"
 ],
 "Mondays": [
  null,
  "ორშაბათობით"
 ],
 "More info...": [
  null,
  "მეტი ინფორმაცია..."
 ],
 "Multi-system chassis": [
  null,
  "მრავალსისტემიანი ყუთი"
 ],
 "NTP server": [
  null,
  "NTP სერვერი"
 ],
 "Name": [
  null,
  "სახელი"
 ],
 "Need at least one NTP server": [
  null,
  "საჭიროა ერთი NTP სერვერი მაინც"
 ],
 "Networking": [
  null,
  "ქსელი"
 ],
 "New password was not accepted": [
  null,
  "ახალი პაროლი მიუღებელია"
 ],
 "No delay": [
  null,
  "დაყოვნების გარეშე"
 ],
 "No results found": [
  null,
  "შედეგები ნაპოვნი არაა"
 ],
 "No such file or directory": [
  null,
  "ფაილი ან საქაღალდე არ არსებობს"
 ],
 "No system modifications": [
  null,
  "სისტემა შეცვლილი არაა"
 ],
 "No updates": [
  null,
  "განახლებების გარეშე"
 ],
 "Not a valid private key": [
  null,
  "არ წარმოადგენს სწორ პირად გასაღებს"
 ],
 "Not available": [
  null,
  "ხელმიუწვდომელია"
 ],
 "Not installed": [
  null,
  "დაყენებული არაა"
 ],
 "Not permitted to perform this action.": [
  null,
  "არ გაქვთ მითითებული მოქმედების შესასრულებლად საკმარისი წვდომა."
 ],
 "Not registered": [
  null,
  "რეგისტრირებული არაა"
 ],
 "Not set up": [
  null,
  "მორგებული არაა"
 ],
 "Not synchronized": [
  null,
  "სინქრონიზებული არაა"
 ],
 "Notebook": [
  null,
  "ნოუთბუქი"
 ],
 "Occurrences": [
  null,
  "გამოვლენები"
 ],
 "Ok": [
  null,
  "დიახ"
 ],
 "Old password not accepted": [
  null,
  "ძველი პაროლი მიუღებელია"
 ],
 "Once Cockpit is installed, enable it with \"systemctl enable --now cockpit.socket\".": [
  null,
  "როცა Cockpit-ს დააყენებთ, შეგიძლიათ მისი ჩართვაც, ბრძანებით \"systemctl enable --now cockpit.socket\"."
 ],
 "Other": [
  null,
  "სხვა"
 ],
 "Package information": [
  null,
  "ინფორმაცია პაკეტის შესახებ"
 ],
 "PackageKit crashed": [
  null,
  "PackageKit-ის ავარია"
 ],
 "PackageKit is not installed": [
  null,
  "PackageKit დაყენებული არაა"
 ],
 "PackageKit reported error code $0": [
  null,
  "PackageKit-ის შეცდომის კოდი $0"
 ],
 "Packages": [
  null,
  "პაკეტები"
 ],
 "Password": [
  null,
  "პაროლი"
 ],
 "Password is not acceptable": [
  null,
  "პაროლი მიუღებელია"
 ],
 "Password is too weak": [
  null,
  "პაროლი ძალიან სუსტია"
 ],
 "Password not accepted": [
  null,
  "პაროლი მიუღებელია"
 ],
 "Paste": [
  null,
  "ჩასმა"
 ],
 "Paste error": [
  null,
  "ჩასმის შეცდომა"
 ],
 "Path to file": [
  null,
  "ბილიკი ფაილამდე"
 ],
 "Peripheral chassis": [
  null,
  "გარე კორპუსი"
 ],
 "Pick date": [
  null,
  "აირჩიეთ თარიღი"
 ],
 "Pizza box": [
  null,
  "პიცისყუთი"
 ],
 "Please resolve the issue and reload this page.": [
  null,
  "გადაწყვიტეთ პრობლემა და განაახლეთ ეს გვერდი."
 ],
 "Portable": [
  null,
  "გადატანადი"
 ],
 "Present": [
  null,
  "წარმოდგენილია"
 ],
 "Prompting via ssh-add timed out": [
  null,
  "მოთხოვნას ssh-add-ის გავლით დრო გაუვიდა"
 ],
 "Prompting via ssh-keygen timed out": [
  null,
  "მოთხოვნას ssh-keygen-ის გავლით დრო გაუვიდა"
 ],
 "RAID chassis": [
  null,
  "RAID კალათი"
 ],
 "Rack mount chassis": [
  null,
  "რეკში ჩასადგმელი შასი"
 ],
 "Reboot": [
  null,
  "გადატვირთვა"
 ],
 "Reboot after completion": [
  null,
  "გადატვირთვა დასრულების შემდეგ"
 ],
 "Reboot recommended": [
  null,
  "რეკომენდებულია გადატვირთვა"
 ],
 "Reboot system...": [
  null,
  "სისტემის გადატვირთვა..."
 ],
 "Refreshing package information": [
  null,
  "პაკეტების ინფორმაციის განახლება"
 ],
 "Register…": [
  null,
  "რეგისტრაცია…"
 ],
 "Reloading the state of remaining services": [
  null,
  "დარჩენილი სერვისების მდგომარეობის გადატვირთვა"
 ],
 "Removals:": [
  null,
  "წაიშლება:"
 ],
 "Removing $0": [
  null,
  "$0-ის წაშლა"
 ],
 "Restart services": [
  null,
  "სერვისების რესტარტი"
 ],
 "Restart services...": [
  null,
  "სერვისების რესტარტი..."
 ],
 "Restarting": [
  null,
  "გადატვირთვა"
 ],
 "Row expansion": [
  null,
  "მწკრივის გაფართოება"
 ],
 "Row select": [
  null,
  "მწკრივის არჩევა"
 ],
 "Run this command over a trusted network or physically on the remote machine:": [
  null,
  "გაუშვით ეს ბრძანება სანდო ქსელით ან ფიზიკურად, დაშორებულ მანქანაზე:"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "SSH key": [
  null,
  "SSH გასაღები"
 ],
 "SSH key login": [
  null,
  "SSH გასაღებით შესვლა"
 ],
 "Saturdays": [
  null,
  "შაბათობით"
 ],
 "Save": [
  null,
  "შენახვა"
 ],
 "Save changes": [
  null,
  "ცვლილებების შენახვა"
 ],
 "Sealed-case PC": [
  null,
  "დალუქული PC"
 ],
 "Security Enhanced Linux configuration and troubleshooting": [
  null,
  "Linux-ის გაფართოებული უსაფრთხოების (SELinux) მორგება და გამართვა"
 ],
 "Security updates available": [
  null,
  "ხელმისაწვდომია უსაფრთოხების განახლებები"
 ],
 "Security updates only": [
  null,
  "მხოლოდ უსაფრთხოების განახლებები"
 ],
 "Security updates will be applied $0 at $1": [
  null,
  "უსაფრთხოების პაჩები გადატარდება $0-ზე $1-ზე"
 ],
 "Select an option": [
  null,
  "აირჩიეთ პარამეტრი"
 ],
 "Server has closed the connection.": [
  null,
  "სერვერმა დახურა კავშირი."
 ],
 "Set time": [
  null,
  "დროის დაყენება"
 ],
 "Set up": [
  null,
  "მორგება"
 ],
 "Setting up": [
  null,
  "მორგება"
 ],
 "Settings": [
  null,
  "მორგება"
 ],
 "Severity": [
  null,
  "სიმძიმე"
 ],
 "Shell script": [
  null,
  "გარსის სკრიპტი"
 ],
 "Shift+Insert": [
  null,
  "Shift+Insert"
 ],
 "Show confirmation password": [
  null,
  "დადასტურების პაროლის ჩვენება"
 ],
 "Show password": [
  null,
  "პაროლის ჩვენება"
 ],
 "Shut down": [
  null,
  "გამორთვა"
 ],
 "Single rank": [
  null,
  "ერთრანგიანი"
 ],
 "Software updates": [
  null,
  "პროგრამების განახლებები"
 ],
 "Some other program is currently using the package manager, please wait...": [
  null,
  "პაკეტების მმართველს ამჟამად სხვა პროგრამა იყენებს. გთხოვთ, მოითმინოთ..."
 ],
 "Some software needs to be restarted manually": [
  null,
  "ზოგიერთ პროგრამულ უზრუნველყოფას ხელით გადატვირთვა სჭირდება"
 ],
 "Space-saving computer": [
  null,
  "პატარა ზომის კომპიუტერი"
 ],
 "Specific time": [
  null,
  "მითითებული დრო"
 ],
 "Status": [
  null,
  "მდგომარეობა"
 ],
 "Stick PC": [
  null,
  "Stick PC"
 ],
 "Storage": [
  null,
  "საცავი"
 ],
 "Strong password": [
  null,
  "ძლიერი პაროლი"
 ],
 "Sub-Chassis": [
  null,
  "ქვე-კორპუსი"
 ],
 "Sub-Notebook": [
  null,
  "ქვე-ნოუთბუქი"
 ],
 "Sundays": [
  null,
  "კვირაობით"
 ],
 "Synchronized": [
  null,
  "სინქრონიზებულია"
 ],
 "Synchronized with $0": [
  null,
  "სინქრონიზებულია $0-თან"
 ],
 "Synchronizing": [
  null,
  "სინქრონიზაცია"
 ],
 "System is up to date": [
  null,
  "სისტემა განახლებულია"
 ],
 "Tablet": [
  null,
  "ტაბლეტი"
 ],
 "The SSH key $0 of $1 on $2 will be added to the $3 file of $4 on $5.": [
  null,
  "SSH გასაღები $1-ის $0 $2-ზე დაემატება ფაილ $3-ს $5-ზე $4-ს."
 ],
 "The SSH key $0 will be made available for the remainder of the session and will be available for login to other hosts as well.": [
  null,
  "SSH გასაღები $0 ხელმისაწვდომია სესიის ბოლომდე და ხელმისაწვდომი იქნება სხვა ჰოსტებზე შესასვლელადაც."
 ],
 "The SSH key for logging in to $0 is protected by a password, and the host does not allow logging in with a password. Please provide the password of the key at $1.": [
  null,
  "$0-ზე შესასვლელი SSH გასაღები პაროლითაა დაცული და ჰოსტს პაროლით შესვლა გამორთული აქვს. შეიყვანეთ $1-ზე არსებული გასაღების პაროლი."
 ],
 "The SSH key for logging in to $0 is protected. You can log in with either your login password or by providing the password of the key at $1.": [
  null,
  "$0-ზე შესასვლელი SSH გასაღები დაცულია. შეგიძლიათ შეხვიდეთ ან თქვენი პაროლით ან გასაღები $1-ის პაროლით."
 ],
 "The fingerprint should match:": [
  null,
  "ანაბეჭდების უნდა ემთხვეოდეს:"
 ],
 "The following service will be restarted:": [
  null,
  "დარესტარტდება შემდეგი სერვისი:",
  "დარესტარტდება შემდეგი სერვისები:"
 ],
 "The key password can not be empty": [
  null,
  "გასაღების პაროლი ცარიელი ვერ იქნება"
 ],
 "The key passwords do not match": [
  null,
  "გასაღების პაროლები არ ემთხვევა"
 ],
 "The logged in user is not permitted to view system modifications": [
  null,
  "შესულ მომხმარებელს არ აქვს სისტემური ცვლილებების ნახვს უფლება"
 ],
 "The password can not be empty": [
  null,
  "პაროლი არ შეიძლება ცარიელი იყოს"
 ],
 "The resulting fingerprint is fine to share via public methods, including email.": [
  null,
  "მიღებული ანაბეჭდების გაზიარება პრობლემა არაა."
 ],
 "The resulting fingerprint is fine to share via public methods, including email. If you are asking someone else to do the verification for you, they can send the results using any method.": [
  null,
  "მიღებული ანაბეჭდის გაზიარება, ელფოსტის ჩათვლით, უსაფრთხოა. თუ თქვენ სხვას სთხოვთ, თქვენი სახელით გადაამოწმოს, მათ, შედეგების გამოგზავნა ნებისმიერი მეთოდით შეუძლიათ."
 ],
 "The server refused to authenticate using any supported methods.": [
  null,
  "სერვერმა ყველა მხარდაჭერილი მეთოდით ავთენტიკაცია უარჰყო."
 ],
 "This host will reboot after updates are installed.": [
  null,
  "განახლებების დაყენების შემდეგ სისტემა გადაიტვირთება."
 ],
 "This system is not registered": [
  null,
  "სისტემა რეგისტრირებული არაა"
 ],
 "This tool configures the SELinux policy and can help with understanding and resolving policy violations.": [
  null,
  "ეს პროგრამა როგორც SELinux-ის პოლიტიკის მორგებაში, ასევე მის ბოლომდე გაგებაში და პოლიტიკის დარღვევის გადაწყვეტაში დაგეხმარებათ."
 ],
 "This tool configures the system to write kernel crash dumps. It supports the \"local\" (disk), \"ssh\", and \"nfs\" dump targets.": [
  null,
  "ეს პროგრამა სისტემას ბირთვის ავარიის შემთხვევაში დისკზე დამპის ჩაწერის მორგებაში დაგეხმარებათ. დამპის მხარდაჭერილი სამიზნეებია: \"local\" (დისკი), \"ssh\" და \"nfs\"."
 ],
 "This tool generates an archive of configuration and diagnostic information from the running system. The archive may be stored locally or centrally for recording or tracking purposes or may be sent to technical support representatives, developers or system administrators to assist with technical fault-finding and debugging.": [
  null,
  "ეს პროგრამა გაშვებული სისტემიდან კონფიგურაცისა და დიაგნოსტიკის მოგროვებაში დაგეხმარებათ. არქივი შეგიძლიათ ლოკალურად შეინახოთ, ან ცენტრალურად, ჩაწერისა და ტრეკინგის მიზნებისთვის, ან შეგიძლიათ გადააგზავნოთ მხარდაჭერის, პროგრამისტებისა და სისტემური ადმინისტრატორების ჯგუფებთან, რათა აპარატურული პრობლემები აღმოაჩინოთ და გადაჭრათ."
 ],
 "This tool manages local storage, such as filesystems, LVM2 volume groups, and NFS mounts.": [
  null,
  "ეს პროგრამა ლოკალურ საცავს, როგორიცაა ფაილურ სისტემები, LVM2 ტომის ჯგუფები და NFS მიმაგრებები, მართავს."
 ],
 "This tool manages networking such as bonds, bridges, teams, VLANs and firewalls using NetworkManager and Firewalld. NetworkManager is incompatible with Ubuntu's default systemd-networkd and Debian's ifupdown scripts.": [
  null,
  "ეს პროგრამა მართავს ქსელს. bond ინტერფეისების, ხიდების, ჯგუფური ინტერფეისების, VLAN-ების და ბრანდმაუერების მართვა NetworkManager-ისა და FIrewalld-ის საშუალებით. NetworkManager-ი Ubuntu-ის ნაგულისხმებ systemd-networkd და Debian-ის ifupdown სკრიპტებთან შეუთავსებელია."
 ],
 "Thursdays": [
  null,
  "ხუთშაბათობით"
 ],
 "Time": [
  null,
  "დრო"
 ],
 "Time zone": [
  null,
  "დროის სარტყელი"
 ],
 "To ensure that your connection is not intercepted by a malicious third-party, please verify the host key fingerprint:": [
  null,
  "იმაში დასარწმუნებლად, რომ არ ხდება კავშირის გადაჭერა, შეამოწმეთ ჰოსტის ანაბეჭდი:"
 ],
 "To get software updates, this system needs to be registered with Red Hat, either using the Red Hat Customer Portal or a local subscription server.": [
  null,
  "პროგრამების განახლებების მისაღებად საჭიროა სისტემის Red Hat-ში დარეგისტრირება RedHat-ის პორტალით ან გამოწერების ლოკალური სერვერით."
 ],
 "To verify a fingerprint, run the following on $0 while physically sitting at the machine or through a trusted network:": [
  null,
  "ანაბეჭდის შესამოწმებლად გაუშვით ეს ბრძანება $0-ზე როცა ფიზიკურად ან სანდო ქსელით იქნებით შესული მანქანაზე:"
 ],
 "Toggle date picker": [
  null,
  "თარიღის ამრჩევის გადართვა"
 ],
 "Too much data": [
  null,
  "მეტისმეტად ბევრი მონაცემი"
 ],
 "Total size: $0": [
  null,
  "ჯამური ზომა: $0"
 ],
 "Tower": [
  null,
  "კომპიუტერის კორპუსი"
 ],
 "Trust and add host": [
  null,
  "ჰოსტის ნდობა და დამატება"
 ],
 "Trying to synchronize with $0": [
  null,
  "$0-თან სინქრონიზაციის მცდელობა"
 ],
 "Tuesdays": [
  null,
  "სამშაბათობით"
 ],
 "Type": [
  null,
  "ტიპი"
 ],
 "Unable to log in to $0 using SSH key authentication. Please provide the password.": [
  null,
  "$0-ზე SSH გასაღებით ავთენტიკაციის შესვლის პრობლემა. შეიყვანეთ პაროლი."
 ],
 "Unable to log in to $0. The host does not accept password login or any of your SSH keys.": [
  null,
  "$0-ზე შესვლის პრობლემა. ჰოსტი არ იღებს პაროლით შესვლას ან არცერთ თქვენს SSH გასაღებს."
 ],
 "Unavailable packages": [
  null,
  "ხელმიუწვდომელი პაკეტები"
 ],
 "Unknown": [
  null,
  "უცნობი"
 ],
 "Unknown host: $0": [
  null,
  "უცნობი ჰოსტი: $0"
 ],
 "Untrusted host": [
  null,
  "არასანდო ჰოსტი"
 ],
 "Update Success Table": [
  null,
  "წარმატების ცხრილის განახლება"
 ],
 "Update history": [
  null,
  "ისტორიის განახლება"
 ],
 "Update was successful": [
  null,
  "განახლება წარმატებულად დასრულდა"
 ],
 "Updated": [
  null,
  "განახლებულია"
 ],
 "Updated packages may require a reboot to take effect.": [
  null,
  "განახლებული პაკეტების ძალაში შესასვლელად შეიძლება გადატვირთვა გახდეს საჭირო."
 ],
 "Updates available": [
  null,
  "ხელმისაწვდომია განახლება"
 ],
 "Updates history": [
  null,
  "განახლებების ისტორია"
 ],
 "Updates will be applied $0 at $1": [
  null,
  "განახლებები გადატარდება $0 $1-ზე"
 ],
 "Updating": [
  null,
  "მიმდინარეობს განახლება"
 ],
 "Verified": [
  null,
  "შემოწმებული"
 ],
 "Verify fingerprint": [
  null,
  "ანაბეჭდის გადამოწმება"
 ],
 "Verifying": [
  null,
  "შემოწმება"
 ],
 "Version": [
  null,
  "ვერსია"
 ],
 "View all logs": [
  null,
  "ყველა ჟურნალის ნახვა"
 ],
 "View automation script": [
  null,
  "ავტომატიზაციის სკრიპტის ნახვა"
 ],
 "View update log": [
  null,
  "განახლების ჟურნალის ნახვა"
 ],
 "Visit firewall": [
  null,
  "ბრანდმაუერზე გადასვლა"
 ],
 "Waiting for other software management operations to finish": [
  null,
  "პროგრამების მართვის სხვა ოპერაციების დასრულების მოლოდინი"
 ],
 "Weak password": [
  null,
  "სუსტი პაროლი"
 ],
 "Web Console for Linux servers": [
  null,
  "ვებ კონსოლი Linux სერვერებისთვის"
 ],
 "Web Console will restart": [
  null,
  "ვებ კონსოლი დარესტარტდება"
 ],
 "Wednesdays": [
  null,
  "ოთხშაბათობით"
 ],
 "When": [
  null,
  "როდის"
 ],
 "When the Web Console is restarted, you will no longer see progress information. However, the update process will continue in the background. Reconnect to continue watching the update process.": [
  null,
  "როცა ვებ კონსოლი გადაიტვირთება, თქვენ ვეღარ დაინახავთ ინფორმაციას მიმდინარეობის შესახებ. მაგრამ განახლების პროცესი ფონურად გაგრძელდება. მიმდინარეობის დასანახავად დაუკავშირდით თავიდან."
 ],
 "You are connecting to $0 for the first time.": [
  null,
  "$0-ს პირველად უკავშირდებით."
 ],
 "Your browser does not allow paste from the context menu. You can use Shift+Insert.": [
  null,
  "თქვენს ბრაუზერს არ გააჩნია კონტექსტური მენიუდან ჩასმის მხარდაჭერა. სცადეთ დააჭიროთ Shift+Insert-ს."
 ],
 "Your server will close the connection soon. You can reconnect after it has restarted.": [
  null,
  "თქვენი სერვერი მალე კავშირს დახურავს. გადატვირთვის შემდეგ შეგეძლებათ თავიდან დაუკავშირდეთ."
 ],
 "Your session has been terminated.": [
  null,
  "თქვენი სესია გაწყვეტილია."
 ],
 "Your session has expired. Please log in again.": [
  null,
  "სესიის ვადა გასულია. თავიდან შედით."
 ],
 "Zone": [
  null,
  "ზონა"
 ],
 "[binary data]": [
  null,
  "[ბინარული მონაცემები]"
 ],
 "[no data]": [
  null,
  "[მონაცემების გარეშე]"
 ],
 "at": [
  null,
  "დრო"
 ],
 "bug fix": [
  null,
  "შეცდ. გასწ"
 ],
 "enhancement": [
  null,
  "გაუმჯობესება"
 ],
 "every Friday": [
  null,
  "ყოველ პარასკევს"
 ],
 "every Monday": [
  null,
  "ყოველ ორშაბათს"
 ],
 "every Saturday": [
  null,
  "ყოველ შაბათს"
 ],
 "every Sunday": [
  null,
  "ყოველ კვირას"
 ],
 "every Thursday": [
  null,
  "ყოველ ხუთშაბათს"
 ],
 "every Tuesday": [
  null,
  "ყოველ სამშაბათს"
 ],
 "every Wednesday": [
  null,
  "ყოველ ოთხშაბათს"
 ],
 "every day": [
  null,
  "ყოველდღე"
 ],
 "for current and future kernels": [
  null,
  "მიმდინარე და მომავალი ბირთვებისთვის"
 ],
 "for current kernel only": [
  null,
  "მხოლოდ მიმდინარე ბირთვისთვის"
 ],
 "in less than a minute": [
  null,
  "წუთზე ნაკლებში"
 ],
 "less than a minute ago": [
  null,
  "წუთზე ნაკლების წინ"
 ],
 "password quality": [
  null,
  "პაროლის ხარისხი"
 ],
 "patches": [
  null,
  "პაჩები"
 ],
 "security": [
  null,
  "უსაფრთხოება"
 ],
 "show less": [
  null,
  "ნაკლების ჩვენება"
 ],
 "show more": [
  null,
  "მეტის ჩვენება"
 ]
});
