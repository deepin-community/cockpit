cockpit.locale({
 "": {
  "plural-forms": (n) => (n>1),
  "language": "tr",
  "language-direction": "ltr"
 },
 "$0 GiB": [
  null,
  "$0 GiB"
 ],
 "$0 day": [
  null,
  "$0 gün",
  "$0 gün"
 ],
 "$0 documentation": [
  null,
  "$0 belgeleleri"
 ],
 "$0 exited with code $1": [
  null,
  "$0, $1 koduyla çıkış yaptı"
 ],
 "$0 failed": [
  null,
  "$0 başarısız oldu"
 ],
 "$0 hour": [
  null,
  "$0 saat",
  "$0 saat"
 ],
 "$0 is not available from any repository.": [
  null,
  "$0, hiçbir depoda yok."
 ],
 "$0 key changed": [
  null,
  "$0 anahtarı değişti"
 ],
 "$0 killed with signal $1": [
  null,
  "$0, $1 sinyali ile sonlandırıldı"
 ],
 "$0 minute": [
  null,
  "$0 dakika",
  "$0 dakika"
 ],
 "$0 month": [
  null,
  "$0 ay",
  "$0 ay"
 ],
 "$0 week": [
  null,
  "$0 hafta",
  "$0 hafta"
 ],
 "$0 will be installed.": [
  null,
  "$0 kurulacak."
 ],
 "$0 year": [
  null,
  "$0 yıl",
  "$0 yıl"
 ],
 "1 day": [
  null,
  "1 gün"
 ],
 "1 hour": [
  null,
  "1 saat"
 ],
 "1 minute": [
  null,
  "1 dakika"
 ],
 "1 week": [
  null,
  "1 hafta"
 ],
 "20 minutes": [
  null,
  "20 dakika"
 ],
 "40 minutes": [
  null,
  "40 dakika"
 ],
 "5 minutes": [
  null,
  "5 dakika"
 ],
 "6 hours": [
  null,
  "6 saat"
 ],
 "60 minutes": [
  null,
  "60 dakika"
 ],
 "A compatible version of Cockpit is not installed on $0.": [
  null,
  "$0 üzerinde uyumlu bir Cockpit sürümü kurulu değil."
 ],
 "A new SSH key at $0 will be created for $1 on $2 and it will be added to the $3 file of $4 on $5.": [
  null,
  "$2 üzerinde $1 için $0 konumunda yeni bir SSH anahtarı oluşturulacak ve $5 üzerindeki $4 kullanıcısının $3 dosyasına eklenecektir."
 ],
 "About Web Console": [
  null,
  "Web Konsolu Hakkında"
 ],
 "Absent": [
  null,
  "Yok"
 ],
 "Acceptable password": [
  null,
  "Kabul edilebilir parola"
 ],
 "Active pages": [
  null,
  "Etkin sayfalar"
 ],
 "Add": [
  null,
  "Ekle"
 ],
 "Add $0": [
  null,
  "$0 ekle"
 ],
 "Add key": [
  null,
  "Anahtar ekle"
 ],
 "Add new host": [
  null,
  "Yeni anamakine ekle"
 ],
 "Additional packages:": [
  null,
  "Ek paketler:"
 ],
 "Administration with Cockpit Web Console": [
  null,
  "Cockpit Web Konsolu ile Yönetim"
 ],
 "Administrative access": [
  null,
  "Yönetimsel erişim"
 ],
 "Advanced TCA": [
  null,
  "Gelişmiş TCA"
 ],
 "All-in-one": [
  null,
  "Hepsi-bir-arada"
 ],
 "Ansible": [
  null,
  "Ansible"
 ],
 "Ansible roles documentation": [
  null,
  "Ansible rolleri belgeleri"
 ],
 "Apps": [
  null,
  "Uygulamalar"
 ],
 "Authenticate": [
  null,
  "Kimlik doğrula"
 ],
 "Authentication": [
  null,
  "Kimlik doğrulama"
 ],
 "Authentication is required to perform privileged tasks with the Cockpit Web Console": [
  null,
  "Cockpit Web Konsolu ile yetkili görevleri gerçekleştirmek için kimlik doğrulaması gerekir"
 ],
 "Authorize SSH key": [
  null,
  "SSH anahtarını yetkilendir"
 ],
 "Automatic login": [
  null,
  "Otomatik oturum açma"
 ],
 "Automatically using NTP": [
  null,
  "Otomatik olarak NTP kullanarak"
 ],
 "Automatically using additional NTP servers": [
  null,
  "Otomatik olarak ek NTP sunucularını kullanarak"
 ],
 "Automatically using specific NTP servers": [
  null,
  "Otomatik olarak belirli NTP sunucularını kullanarak"
 ],
 "Automation script": [
  null,
  "Otomatikleştirme betiği"
 ],
 "Blade": [
  null,
  "Blade"
 ],
 "Blade enclosure": [
  null,
  "Blade kasası"
 ],
 "Bus expansion chassis": [
  null,
  "Veri yolu genişletme kasası"
 ],
 "By changing the password of the SSH key $0 to the login password of $1 on $2, the key will be automatically made available and you can log in to $3 without password in the future.": [
  null,
  "$0 SSH anahtarının parolasını $2 üzerindeki $1 kullanıcısının oturum açma parolasıyla değiştirdiğinizde, anahtar otomatik olarak kullanılabilir hale getirilecek ve gelecekte parola olmadan $3 üzerinde oturum açabileceksiniz."
 ],
 "Can be a hostname, IP address, alias name, or ssh:// URI": [
  null,
  "Bir anamakine adı, IP adresi, kod adı veya ssh:// URI olabilir"
 ],
 "Cancel": [
  null,
  "İptal"
 ],
 "Cannot connect to an unknown host": [
  null,
  "Bilinmeyen bir anamakineye bağlanılamıyor"
 ],
 "Cannot forward login credentials": [
  null,
  "Oturum açma kimlik bilgileri yönlendirilemiyor"
 ],
 "Cannot schedule event in the past": [
  null,
  "Geçmişteki olay zamanlanamıyor"
 ],
 "Change": [
  null,
  "Değiştir"
 ],
 "Change password": [
  null,
  "Parolayı değiştir"
 ],
 "Change system time": [
  null,
  "Sistem saatini değiştir"
 ],
 "Change the password of $0": [
  null,
  "$0 parolasını değiştir"
 ],
 "Changed keys are often the result of an operating system reinstallation. However, an unexpected change may indicate a third-party attempt to intercept your connection.": [
  null,
  "Değiştirilen anahtarlar genellikle bir işletim sisteminin yeniden kurulması sonucudur. Ancak, beklenmeyen bir değişiklik, üçüncü tarafın bağlantınıza müdahale etme girişimini gösterebilir."
 ],
 "Checking installed software": [
  null,
  "Kurulu yazılımlar denetleniyor"
 ],
 "Choose the language to be used in the application": [
  null,
  "Uygulamada kullanılacak dili seçin"
 ],
 "Clear input value": [
  null,
  "Giriş değerini temizle"
 ],
 "Clear search": [
  null,
  "Aramayı temizle"
 ],
 "Close": [
  null,
  "Kapat"
 ],
 "Close selected pages": [
  null,
  "Seçilen sayfaları kapat"
 ],
 "Cockpit": [
  null,
  "Cockpit"
 ],
 "Cockpit configuration of NetworkManager and Firewalld": [
  null,
  "NetworkManager ve Firewalld'un Cockpit yapılandırması"
 ],
 "Cockpit could not contact the given host.": [
  null,
  "Cockpit, verilen anamakineyle iletişim kuramadı."
 ],
 "Cockpit had an unexpected internal error.": [
  null,
  "Cockpit'te beklenmeyen bir iç hata oldu."
 ],
 "Cockpit is a server manager that makes it easy to administer your Linux servers via a web browser. Jumping between the terminal and the web tool is no problem. A service started via Cockpit can be stopped via the terminal. Likewise, if an error occurs in the terminal, it can be seen in the Cockpit journal interface.": [
  null,
  "Cockpit, Linux sunucularınızı bir web tarayıcısı aracılığıyla yönetmenizi kolaylaştıran bir sunucu yöneticisidir. Terminal ve web aracı arasında geçiş yapmak sorun değildir. Cockpit aracılığıyla başlatılan bir hizmet terminal aracılığıyla durdurulabilir. Aynı şekilde, terminalde bir hata meydana gelirse, Cockpit günlüğü arayüzünde görülebilir."
 ],
 "Cockpit is an interactive Linux server admin interface.": [
  null,
  "Cockpit, etkileşimli bir Linux sunucu yönetim arayüzüdür."
 ],
 "Cockpit is not compatible with the software on the system.": [
  null,
  "Cockpit, sistemdeki yazılımla uyumlu değil."
 ],
 "Cockpit is not installed": [
  null,
  "Cockpit kurulu değil"
 ],
 "Cockpit is not installed on the system.": [
  null,
  "Cockpit sistemde kurulu değil."
 ],
 "Cockpit is perfect for new sysadmins, allowing them to easily perform simple tasks such as storage administration, inspecting journals and starting and stopping services. You can monitor and administer several servers at the same time. Just add them with a single click and your machines will look after its buddies.": [
  null,
  "Cockpit yeni sistem yöneticileri için mükemmeldir; depolama yönetimi, günlükleri inceleme, hizmetleri başlatma ve durdurma gibi basit görevleri kolayca gerçekleştirmelerine olanak tanır. Aynı anda birkaç sunucuyu izleyebilir ve yönetebilirsiniz. Bunları tek bir tıklama ile ekleyin ve makineleriniz arkadaşlarıyla ilgilensin."
 ],
 "Collect and package diagnostic and support data": [
  null,
  "Tanılama ve destek verilerini topla ve paketle"
 ],
 "Collect kernel crash dumps": [
  null,
  "Çekirdek çökme dökümlerini topla"
 ],
 "Color": [
  null,
  "Renk"
 ],
 "Comment": [
  null,
  "Yorum"
 ],
 "Compact PCI": [
  null,
  "Compact PCI"
 ],
 "Confirm key password": [
  null,
  "Anahtar parolasını onayla"
 ],
 "Confirm new key password": [
  null,
  "Yeni anahtar parolasını onayla"
 ],
 "Confirm password": [
  null,
  "Parolayı onayla"
 ],
 "Connect": [
  null,
  "Bağlan"
 ],
 "Connect to $0?": [
  null,
  "$0 cihazına bağlansın mı?"
 ],
 "Connected hosts can fully control each other. This includes running programs that could harm your system or steal data. Only connect to trusted machines.": [
  null,
  "Bağlı anamakineler birbirlerini tamamen denetleyebilir. Buna, sisteminize zarar verebilecek veya verileri çalabilecek programların çalıştırılması da dahildir. Yalnızca güvenilir makinelere bağlanın."
 ],
 "Connecting to the machine": [
  null,
  "Makineye bağlanılıyor"
 ],
 "Connection error": [
  null,
  "Bağlantı hatası"
 ],
 "Connection failed": [
  null,
  "Bağlantı başarısız oldu"
 ],
 "Connection has timed out.": [
  null,
  "Bağlantı zaman aşımına uğradı."
 ],
 "Contains:": [
  null,
  "İçerdikleri:"
 ],
 "Continue session": [
  null,
  "Oturuma devam et"
 ],
 "Convertible": [
  null,
  "Dönüştürülebilir"
 ],
 "Copied": [
  null,
  "Kopyalandı"
 ],
 "Copy": [
  null,
  "Kopyala"
 ],
 "Copy to clipboard": [
  null,
  "Panoya kopyala"
 ],
 "Could not contact $0": [
  null,
  "$0 ile iletişim kurulamadı"
 ],
 "Create $0": [
  null,
  "$0 oluştur"
 ],
 "Create a new SSH key and authorize it": [
  null,
  "Yeni bir SSH anahtarı oluştur ve yetkilendir"
 ],
 "Create new task file with this content.": [
  null,
  "Bu içerikle yeni görev dosyası oluştur."
 ],
 "Ctrl+Insert": [
  null,
  "Ctrl+Insert"
 ],
 "Ctrl-Shift-I": [
  null,
  "Ctrl-Shift-I"
 ],
 "Dark": [
  null,
  "Koyu"
 ],
 "Default": [
  null,
  "Öntanımlı"
 ],
 "Delay": [
  null,
  "Gecikme"
 ],
 "Desktop": [
  null,
  "Masaüstü"
 ],
 "Detachable": [
  null,
  "Ayrılabilir"
 ],
 "Details": [
  null,
  "Ayrıntılar"
 ],
 "Diagnostic reports": [
  null,
  "Tanılama raporları"
 ],
 "Disconnected": [
  null,
  "Bağlantı kesildi"
 ],
 "Display language": [
  null,
  "Görüntüleme dili"
 ],
 "Docking station": [
  null,
  "Kenetleme istasyonu"
 ],
 "Downloading $0": [
  null,
  "$0 indiriliyor"
 ],
 "Dual rank": [
  null,
  "Çift sıra"
 ],
 "Edit": [
  null,
  "Düzenle"
 ],
 "Edit host": [
  null,
  "Anamakineyi düzenle"
 ],
 "Edit hosts": [
  null,
  "Anamakineleri düzenle"
 ],
 "Embedded PC": [
  null,
  "Gömülü PC"
 ],
 "Excellent password": [
  null,
  "Mükemmel parola"
 ],
 "Expansion chassis": [
  null,
  "Genişletme kasası"
 ],
 "Failed to add machine: $0": [
  null,
  "Makine ekleme başarısız oldu: $0"
 ],
 "Failed to change password": [
  null,
  "Parolayı değiştirme başarısız oldu"
 ],
 "Failed to edit machine: $0": [
  null,
  "Şu makineyi düzenleme başarısız oldu: $0"
 ],
 "Failed to enable $0 in firewalld": [
  null,
  "firewalld içinde $0 etkinleştirme başarısız oldu"
 ],
 "Filter menu items": [
  null,
  "Menü öğelerini süz"
 ],
 "Fingerprint": [
  null,
  "Parmak izi"
 ],
 "Go to now": [
  null,
  "Şimdiye git"
 ],
 "Handheld": [
  null,
  "Elde taşınan"
 ],
 "Help": [
  null,
  "Yardım"
 ],
 "Hide confirmation password": [
  null,
  "Onay parolasını gizle"
 ],
 "Hide password": [
  null,
  "Parolayı gizle"
 ],
 "Host": [
  null,
  "Anamakine"
 ],
 "Host key is incorrect": [
  null,
  "Anamakine anahtarı yanlış"
 ],
 "Hosts": [
  null,
  "Anamakineler"
 ],
 "If the fingerprint matches, click 'Trust and add host'. Otherwise, do not connect and contact your administrator.": [
  null,
  "Eğer parmak izi eşleşirse, 'Anamakineye güven ve ekle'ye tıklayın. Aksi takdirde, bağlanmayın ve yöneticinize başvurun."
 ],
 "In order to allow log in to $0 as $1 without password in the future, use the login password of $2 on $3 as the key password, or leave the key password blank.": [
  null,
  "Gelecekte $0 üzerinde parola olmadan $1 olarak oturum açmaya izin vermek için anahtar parolası olarak $3 üzerinde $2 kullanıcısının oturum açma parolasını kullanın veya anahtar parolasını boş bırakın."
 ],
 "Install": [
  null,
  "Kur"
 ],
 "Install software": [
  null,
  "Yazılım kur"
 ],
 "Installing $0": [
  null,
  "$0 kuruluyor"
 ],
 "Internal error": [
  null,
  "İç hata"
 ],
 "Invalid date format": [
  null,
  "Geçersiz tarih biçimi"
 ],
 "Invalid date format and invalid time format": [
  null,
  "Geçersiz tarih ve saat biçimi"
 ],
 "Invalid file permissions": [
  null,
  "Geçersiz dosya izinleri"
 ],
 "Invalid time format": [
  null,
  "Geçersiz saat biçimi"
 ],
 "Invalid timezone": [
  null,
  "Geçersiz saat dilimi"
 ],
 "IoT gateway": [
  null,
  "IoT ağ geçidi"
 ],
 "Is sshd running on a different port?": [
  null,
  "sshd farklı bir bağlantı noktasında mı çalışıyor?"
 ],
 "Kernel dump": [
  null,
  "Çekirdek dökümü"
 ],
 "Key password": [
  null,
  "Anahtar parolası"
 ],
 "Laptop": [
  null,
  "Dizüstü"
 ],
 "Learn more": [
  null,
  "Daha fazla bilgi edinin"
 ],
 "Licensed under GNU LGPL version 2.1": [
  null,
  "GNU LGPL sürüm 2.1 altında lisanslıdır"
 ],
 "Light": [
  null,
  "Açık"
 ],
 "Limit access": [
  null,
  "Erişimi sınırla"
 ],
 "Limited access": [
  null,
  "Sınırlı erişim"
 ],
 "Limited access mode restricts administrative privileges. Some parts of the web console will have reduced functionality.": [
  null,
  "Sınırlı erişim kipi, yönetimsel yetkileri kısıtlar. Web konsolunun bazı kısımları sınırlı işlevselliğe sahip olacaktır."
 ],
 "Loading packages...": [
  null,
  "Paketler yükleniyor..."
 ],
 "Loading system modifications...": [
  null,
  "Sistem değişiklikleri yükleniyor..."
 ],
 "Log in": [
  null,
  "Oturum aç"
 ],
 "Log in to $0": [
  null,
  "$0 üzerinde oturum aç"
 ],
 "Log messages": [
  null,
  "Günlük iletileri"
 ],
 "Log out": [
  null,
  "Oturumu kapat"
 ],
 "Login failed": [
  null,
  "Oturum açma başarısız oldu"
 ],
 "Low profile desktop": [
  null,
  "Düşük profilli masaüstü"
 ],
 "Lunch box": [
  null,
  "Lunch box"
 ],
 "Main server chassis": [
  null,
  "Ana sunucu kasası"
 ],
 "Malicious pages on a remote machine may affect other connected hosts": [
  null,
  "Uzak bir makinedeki kötü amaçlı sayfalar bağlı diğer anamakineleri etkileyebilir"
 ],
 "Manage storage": [
  null,
  "Depolamayı yönet"
 ],
 "Manually": [
  null,
  "El ile"
 ],
 "Message to logged in users": [
  null,
  "Oturum açmış kullanıcılar için ileti"
 ],
 "Messages related to the failure might be found in the journal:": [
  null,
  "Hatayla ilgili iletiler günlükte bulunabilir:"
 ],
 "Method": [
  null,
  "Yöntem"
 ],
 "Mini PC": [
  null,
  "Mini PC"
 ],
 "Mini tower": [
  null,
  "Mini tower"
 ],
 "Multi-system chassis": [
  null,
  "Çok sistemli kasa"
 ],
 "NTP server": [
  null,
  "NTP sunucusu"
 ],
 "Name": [
  null,
  "Ad"
 ],
 "Need at least one NTP server": [
  null,
  "En az bir NTP sunucusu gerekli"
 ],
 "Networking": [
  null,
  "Ağ"
 ],
 "New host: $0": [
  null,
  "Yeni anamakine: $0"
 ],
 "New key password": [
  null,
  "Yeni anahtar parolası"
 ],
 "New password": [
  null,
  "Yeni parola"
 ],
 "New password was not accepted": [
  null,
  "Yeni parola kabul edilmedi"
 ],
 "No delay": [
  null,
  "Gecikme yok"
 ],
 "No languages match": [
  null,
  "Eşleşen diller yok"
 ],
 "No results found": [
  null,
  "Bulunan sonuçlar yok"
 ],
 "No such file or directory": [
  null,
  "Böyle bir dosya ya da dizin yok"
 ],
 "No system modifications": [
  null,
  "Sistem değişiklikleri yok"
 ],
 "Not a valid private key": [
  null,
  "Geçerli bir özel anahtar değil"
 ],
 "Not connected to host": [
  null,
  "Anamakineye bağlı değil"
 ],
 "Not permitted to perform this action.": [
  null,
  "Bu eylemi gerçekleştirmeye izinli değil."
 ],
 "Not synchronized": [
  null,
  "Eşitlenmedi"
 ],
 "Notebook": [
  null,
  "Notebook"
 ],
 "Occurrences": [
  null,
  "Oluşumlar"
 ],
 "Ok": [
  null,
  "Tamam"
 ],
 "Old password not accepted": [
  null,
  "Eski parola kabul edilmedi"
 ],
 "Once Cockpit is installed, enable it with \"systemctl enable --now cockpit.socket\".": [
  null,
  "Cockpit kurulduktan sonra, \"systemctl enable --now cockpit.socket\" komutuyla etkinleştirin."
 ],
 "Ooops!": [
  null,
  "Eyvah!"
 ],
 "Other": [
  null,
  "Diğer"
 ],
 "PackageKit crashed": [
  null,
  "PackageKit çöktü"
 ],
 "Page name": [
  null,
  "Sayfa adı"
 ],
 "Password": [
  null,
  "Parola"
 ],
 "Password changed successfully": [
  null,
  "Parola başarılı olarak değiştirildi"
 ],
 "Password is not acceptable": [
  null,
  "Parola kabul edilebilir değil"
 ],
 "Password is too weak": [
  null,
  "Parola çok zayıf"
 ],
 "Password not accepted": [
  null,
  "Parola kabul edilmedi"
 ],
 "Password tip": [
  null,
  "Parola ipucu"
 ],
 "Paste": [
  null,
  "Yapıştır"
 ],
 "Paste error": [
  null,
  "Yapıştırma hatası"
 ],
 "Path to file": [
  null,
  "Dosyanın yolu"
 ],
 "Peripheral chassis": [
  null,
  "Çevresel donanım kasası"
 ],
 "Pick date": [
  null,
  "Tarih seçin"
 ],
 "Pizza box": [
  null,
  "Pizza box"
 ],
 "Please authenticate to gain administrative access": [
  null,
  "Lütfen yönetimsel erişim elde etmek için kimlik doğrulayın"
 ],
 "Port": [
  null,
  "Bağlantı noktası"
 ],
 "Portable": [
  null,
  "Taşınabilir"
 ],
 "Present": [
  null,
  "Mevcut"
 ],
 "Problem becoming administrator": [
  null,
  "Yönetici olma sorunu"
 ],
 "Project website": [
  null,
  "Proje web sitesi"
 ],
 "Prompting via ssh-add timed out": [
  null,
  "ssh-add aracılığıyla sorma zaman aşımına uğradı"
 ],
 "Prompting via ssh-keygen timed out": [
  null,
  "ssh-keygen aracılığıyla sorma zaman aşımına uğradı"
 ],
 "Public key": [
  null,
  "Ortak anahtar"
 ],
 "RAID chassis": [
  null,
  "RAID kasası"
 ],
 "Rack mount chassis": [
  null,
  "Raf montajlı kasa"
 ],
 "Read more": [
  null,
  "Devamını oku"
 ],
 "Reboot": [
  null,
  "Yeniden başlat"
 ],
 "Reconnect": [
  null,
  "Yeniden bağlan"
 ],
 "Removals:": [
  null,
  "Kaldırılanlar:"
 ],
 "Remove": [
  null,
  "Kaldır"
 ],
 "Removing $0": [
  null,
  "$0 kaldırılıyor"
 ],
 "Row expansion": [
  null,
  "Satır genişletme"
 ],
 "Row select": [
  null,
  "Satır seçimi"
 ],
 "Run this command over a trusted network or physically on the remote machine:": [
  null,
  "Bu komutu güvenilir bir ağ üzerinden veya fiziksel olarak uzaktaki makinede çalıştırın:"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "SSH key": [
  null,
  "SSH anahtarı"
 ],
 "SSH key login": [
  null,
  "SSH anahtarı oturum açma"
 ],
 "SSH keys": [
  null,
  "SSH anahtarları"
 ],
 "Safari users need to import and trust the certificate of the self-signing CA:": [
  null,
  "Safari kullanıcılarının kendi kendine imzalanan CA sertifikasını içe aktarması ve ona güvenmesi gerekir:"
 ],
 "Sealed-case PC": [
  null,
  "Mühürlü Kasa PC"
 ],
 "Search": [
  null,
  "Ara"
 ],
 "Security Enhanced Linux configuration and troubleshooting": [
  null,
  "Güvenlik Gelişmiş Linux yapılandırması ve sorun giderme"
 ],
 "Select": [
  null,
  "Seç"
 ],
 "Select an option": [
  null,
  "Bir seçenek seçin"
 ],
 "Server has closed the connection.": [
  null,
  "Sunucu bağlantıyı kapattı."
 ],
 "Session": [
  null,
  "Oturum"
 ],
 "Session is about to expire": [
  null,
  "Oturumun süresi dolmak üzere"
 ],
 "Set": [
  null,
  "Ayarla"
 ],
 "Set time": [
  null,
  "Saati ayarla"
 ],
 "Shell script": [
  null,
  "Kabuk betiği"
 ],
 "Shift+Insert": [
  null,
  "Shift+Insert"
 ],
 "Show confirmation password": [
  null,
  "Onay parolasını göster"
 ],
 "Show password": [
  null,
  "Parolayı göster"
 ],
 "Shut down": [
  null,
  "Kapat"
 ],
 "Single rank": [
  null,
  "Tek sıra"
 ],
 "Skip main navigation": [
  null,
  "Ana gezinmeyi atla"
 ],
 "Skip to content": [
  null,
  "İçeriğe atla"
 ],
 "Space-saving computer": [
  null,
  "Yerden kazandıran bilgisayar"
 ],
 "Specific time": [
  null,
  "Belirli bir zaman"
 ],
 "Stick PC": [
  null,
  "Çubuk PC"
 ],
 "Stop editing hosts": [
  null,
  "Anamakineleri düzenlemeyi durdur"
 ],
 "Storage": [
  null,
  "Depolama"
 ],
 "Strong password": [
  null,
  "Güçlü parola"
 ],
 "Style": [
  null,
  "Stil"
 ],
 "Sub-Chassis": [
  null,
  "Alt Kasa"
 ],
 "Sub-Notebook": [
  null,
  "Alt Dizüstü"
 ],
 "Switch to administrative access": [
  null,
  "Yönetimsel erişime geç"
 ],
 "Switch to limited access": [
  null,
  "Sınırlı erişime geç"
 ],
 "Synchronized": [
  null,
  "Eşitlendi"
 ],
 "Synchronized with $0": [
  null,
  "$0 ile eşitlendi"
 ],
 "Synchronizing": [
  null,
  "Eşitleniyor"
 ],
 "System": [
  null,
  "Sistem"
 ],
 "Tablet": [
  null,
  "Tablet"
 ],
 "The IP address or hostname cannot contain whitespace.": [
  null,
  "IP adresi veya anamakine adı boşluk karakteri içeremez."
 ],
 "The SSH key $0 of $1 on $2 will be added to the $3 file of $4 on $5.": [
  null,
  "$2 üzerindeki $1 kullanıcısının $0 SSH anahtarı, $5 üzerindeki $4 kullanıcısının $3 dosyasına eklenecektir."
 ],
 "The SSH key $0 will be made available for the remainder of the session and will be available for login to other hosts as well.": [
  null,
  "$0 SSH anahtarı, oturumun geri kalanı için kullanılabilir olacak ve diğer anamakinelerde oturum açmak için de kullanılabilecektir."
 ],
 "The SSH key for logging in to $0 is protected by a password, and the host does not allow logging in with a password. Please provide the password of the key at $1.": [
  null,
  "$0 üzerinde oturum açmak için kullanılan SSH anahtarı korumalı ve anamakine bir parola ile oturum açmaya izin vermiyor. Lütfen $1 konumundaki anahtarın parolasını sağlayın."
 ],
 "The SSH key for logging in to $0 is protected. You can log in with either your login password or by providing the password of the key at $1.": [
  null,
  "$0 üzerinde oturum açmak için kullanılan SSH anahtarı korumalı. Oturum açma parolanızla veya $1 konumundaki anahtarın parolasını sağlayarak oturum açabilirsiniz."
 ],
 "The fingerprint should match:": [
  null,
  "Parmak izi eşleşmeli:"
 ],
 "The key password can not be empty": [
  null,
  "Anahtar parolası boş olamaz"
 ],
 "The key passwords do not match": [
  null,
  "Anahtar parolaları eşleşmiyor"
 ],
 "The logged in user is not permitted to view system modifications": [
  null,
  "Oturum açmış kullanıcının sistem değişikliklerini görüntülemesine izin verilmiyor"
 ],
 "The machine is rebooting": [
  null,
  "Makine yeniden başlatılıyor"
 ],
 "The new key password can not be empty": [
  null,
  "Yeni anahtar parolası boş olamaz"
 ],
 "The password can not be empty": [
  null,
  "Parola boş olamaz"
 ],
 "The resulting fingerprint is fine to share via public methods, including email.": [
  null,
  "Ortaya çıkan parmak izinin, e-posta dahil olmak üzere herkese açık yöntemlerle paylaşılması uygundur."
 ],
 "The resulting fingerprint is fine to share via public methods, including email. If you are asking someone else to do the verification for you, they can send the results using any method.": [
  null,
  "Ortaya çıkan parmak izi, e-posta dahil ortak yöntemler aracılığıyla paylaşılabilir. Eğer başka birinden doğrulamayı sizin için yapmasını istiyorsanız, sonuçları herhangi bir yöntemi kullanarak gönderebilirler."
 ],
 "The server refused to authenticate using any supported methods.": [
  null,
  "Sunucu, desteklenen herhangi bir yöntemi kullanarak kimlik doğrulamayı reddetti."
 ],
 "There are currently no active pages": [
  null,
  "Şu anda etkin sayfalar yok"
 ],
 "There was an unexpected error while connecting to the machine.": [
  null,
  "Makineye bağlanırken beklenmeyen bir hata oldu."
 ],
 "This machine has already been added.": [
  null,
  "Bu makine zaten eklenmiş."
 ],
 "This tool configures the SELinux policy and can help with understanding and resolving policy violations.": [
  null,
  "Bu araç, SELinux ilkesini yapılandırır ve ilke ihlallerinin anlaşılmasına ve çözülmesine yardımcı olabilir."
 ],
 "This tool configures the system to write kernel crash dumps. It supports the \"local\" (disk), \"ssh\", and \"nfs\" dump targets.": [
  null,
  "Bu araç, sistemi çekirdek çökme dökümlerini yazmak için yapılandırır. \"Yerel\" (disk), \"ssh\" ve \"nfs\" döküm hedeflerini destekler."
 ],
 "This tool generates an archive of configuration and diagnostic information from the running system. The archive may be stored locally or centrally for recording or tracking purposes or may be sent to technical support representatives, developers or system administrators to assist with technical fault-finding and debugging.": [
  null,
  "Bu araç, çalışan sistemden bir yapılandırma ve tanılama bilgileri arşivi oluşturur. Arşiv, kayıt veya izleme amacıyla yerel veya merkezi olarak depolanabilir veya teknik hata bulma ve hata ayıklamaya yardımcı olması için teknik destek temsilcilerine, geliştiricilere veya sistem yöneticilerine gönderilebilir."
 ],
 "This tool manages local storage, such as filesystems, LVM2 volume groups, and NFS mounts.": [
  null,
  "Bu araç, dosya sistemleri, LVM2 birim grupları ve NFS bağlamaları gibi yerel depolamayı yönetir."
 ],
 "This tool manages networking such as bonds, bridges, teams, VLANs and firewalls using NetworkManager and Firewalld. NetworkManager is incompatible with Ubuntu's default systemd-networkd and Debian's ifupdown scripts.": [
  null,
  "Bu araç, NetworkManager ve Firewalld kullanarak birleştirmeler, köprüler, takımlar, VLAN'lar ve güvenlik duvarları gibi ağları yönetir. NetworkManager, Ubuntu'nun varsayılan systemd-networkd ve Debian'ın ifupdown betikleriyle uyumsuzdur."
 ],
 "This will allow you to log in without password in the future.": [
  null,
  "Bu, gelecekte parola olmadan oturum açmanıza izin verecek."
 ],
 "Time zone": [
  null,
  "Saat dilimi"
 ],
 "Tip: Make your key password match your login password to automatically authenticate against other systems.": [
  null,
  "İpucu: Diğer sistemlerde otomatik olarak kimlik doğrulaması yapmak için anahtar parolanızın oturum açma parolanızla eşleşmesini sağlayın."
 ],
 "To ensure that your connection is not intercepted by a malicious third-party, please verify the host key fingerprint:": [
  null,
  "Bağlantınızın kötü niyetli bir üçüncü tarafça engellenmediğinden emin olmak için lütfen anamakine anahtar parmak izini doğrulayın:"
 ],
 "To verify a fingerprint, run the following on $0 while physically sitting at the machine or through a trusted network:": [
  null,
  "Bir parmak izini doğrulamak için makinede fiziksel olarak bulunurken veya güvenilir bir ağ aracılığıyla $0 üzerinde aşağıdakileri çalıştırın:"
 ],
 "Toggle": [
  null,
  "Değiştir"
 ],
 "Toggle date picker": [
  null,
  "Tarihi seçiciyi aç/kapat"
 ],
 "Too much data": [
  null,
  "Çok fazla veri"
 ],
 "Tools": [
  null,
  "Araçlar"
 ],
 "Total size: $0": [
  null,
  "Toplam boyut: $0"
 ],
 "Tower": [
  null,
  "Tower"
 ],
 "Trust and add host": [
  null,
  "Anamakineye güven ve ekle"
 ],
 "Trying to synchronize with $0": [
  null,
  "$0 ile eşitlemeye çalışılıyor"
 ],
 "Turn on administrative access": [
  null,
  "Yönetimsel erişimi aç"
 ],
 "Type": [
  null,
  "Tür"
 ],
 "Unable to contact $0.": [
  null,
  "$0 ile bağlantı kurulamıyor."
 ],
 "Unable to contact the given host $0. Make sure it has ssh running on port $1, or specify another port in the address.": [
  null,
  "Verilen $0 anamakinesiyle iletişim kurulamıyor. SSH hizmetinin $1 nolu bağlantı noktasında çalıştığından emin olun veya adreste başka bir bağlantı noktası belirtin."
 ],
 "Unable to log in to $0 using SSH key authentication. Please provide the password.": [
  null,
  "SSH anahtar kimlik doğrulaması kullanılarak $0 için oturum açılamıyor. Lütfen parolayı girin."
 ],
 "Unable to log in to $0 using SSH key authentication. Please provide the password. You may want to set up your SSH keys for automatic login.": [
  null,
  "SSH anahtar kimlik doğrulaması kullanılarak $0 üzerinde oturum açılamıyor. Lütfen parolayı girin. Otomatik oturum açma için SSH anahtarlarınızı ayarlamak isteyebilirsiniz."
 ],
 "Unable to log in to $0. The host does not accept password login or any of your SSH keys.": [
  null,
  "$0 üzerinde oturum açılamıyor. Anamakine, parola ile oturum açmayı veya SSH anahtarlarınızdan hiçbirini kabul etmiyor."
 ],
 "Unexpected error": [
  null,
  "Beklenmeyen hata"
 ],
 "Unknown": [
  null,
  "Bilinmiyor"
 ],
 "Unknown host: $0": [
  null,
  "Bilinmeyen anamakine: $0"
 ],
 "Unlock": [
  null,
  "Kilidi aç"
 ],
 "Unlock key $0": [
  null,
  "$0 anahtarı kilidini aç"
 ],
 "Untrusted host": [
  null,
  "Güvenilmeyen anamakine"
 ],
 "Update": [
  null,
  "Güncelle"
 ],
 "Use key": [
  null,
  "Anahtar kullan"
 ],
 "Use the following keys to authenticate against other systems": [
  null,
  "Diğer sistemlerde kimlik doğrulamak için aşağıdaki anahtarları kullan"
 ],
 "User name": [
  null,
  "Kullanıcı adı"
 ],
 "Verify fingerprint": [
  null,
  "Parmak izini doğrula"
 ],
 "View all logs": [
  null,
  "Tüm günlükleri görüntüle"
 ],
 "View automation script": [
  null,
  "Otomatikleştirme betiğini görüntüle"
 ],
 "Visit firewall": [
  null,
  "Güvenlik duvarını ziyaret et"
 ],
 "Waiting for other software management operations to finish": [
  null,
  "Diğer yazılım yönetimi işlemlerinin bitmesi bekleniyor"
 ],
 "Weak password": [
  null,
  "Zayıf parola"
 ],
 "Web Console": [
  null,
  "Web Konsolu"
 ],
 "Web Console for Linux servers": [
  null,
  "Linux sunucuları için Web Konsolu"
 ],
 "Web console logo": [
  null,
  "Web konsol logosu"
 ],
 "When empty, connect with the current user": [
  null,
  "Boş olduğunda, şu anki kullanıcıyla bağlan"
 ],
 "You are connecting to $0 for the first time.": [
  null,
  "İlk kez $0 için bağlanıyorsunuz."
 ],
 "You have been logged out due to inactivity.": [
  null,
  "Etkinlik olmamasından dolayı oturumunuz kapatıldı."
 ],
 "You may want to change the password of the key for automatic login.": [
  null,
  "Otomatik oturum açmak için anahtarın parolasını değiştirmek isteyebilirsiniz."
 ],
 "You now have administrative access.": [
  null,
  "Artık yönetimsel erişiminiz var."
 ],
 "You will be logged out in $0 seconds.": [
  null,
  "$0 saniye içinde oturumunuz kapatılacak."
 ],
 "You will be reminded once per session.": [
  null,
  "Her oturumda size bir kez hatırlatılacaktır."
 ],
 "Your browser does not allow paste from the context menu. You can use Shift+Insert.": [
  null,
  "Tarayıcınız, bağlam menüsünden yapıştırmaya izin vermiyor. Shift+Insert kullanabilirsiniz."
 ],
 "Your browser will remember your access level across sessions.": [
  null,
  "Tarayıcınız, oturumlar arasında erişim seviyenizi hatırlayacaktır."
 ],
 "Your session has been terminated.": [
  null,
  "Oturumunuz sonlandırıldı."
 ],
 "Your session has expired. Please log in again.": [
  null,
  "Oturumunuzun süresi doldu. Lütfen tekrar oturum açın."
 ],
 "Zone": [
  null,
  "Bölge"
 ],
 "[binary data]": [
  null,
  "[ikili veri]"
 ],
 "[no data]": [
  null,
  "[veri yok]"
 ],
 "active": [
  null,
  "etkin"
 ],
 "in less than a minute": [
  null,
  "bir dakikadan az süre"
 ],
 "in most browsers": [
  null,
  "çoğu tarayıcıda"
 ],
 "less than a minute ago": [
  null,
  "bir dakikadan az bir süre önce"
 ],
 "password quality": [
  null,
  "parola kalitesi"
 ],
 "show less": [
  null,
  "daha az göster"
 ],
 "show more": [
  null,
  "daha fazla göster"
 ]
});
