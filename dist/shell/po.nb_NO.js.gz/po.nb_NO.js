cockpit.locale({
 "": {
  "plural-forms": (n) => n != 1,
  "language": "nb_NO",
  "language-direction": "ltr"
 },
 "$0 day": [
  null,
  "$0 dag",
  "$0 dager"
 ],
 "$0 documentation": [
  null,
  "$0 dokumentasjon"
 ],
 "$0 exited with code $1": [
  null,
  "$0 avsluttet med koden $1"
 ],
 "$0 failed": [
  null,
  "$0 feilet"
 ],
 "$0 hour": [
  null,
  "$0 time",
  "$0 timer"
 ],
 "$0 is not available from any repository.": [
  null,
  "$0 er ikke tilgjengelig fra noe depot."
 ],
 "$0 key changed": [
  null,
  "$0 nøkkel endret"
 ],
 "$0 killed with signal $1": [
  null,
  "$0 drept med signal $1"
 ],
 "$0 minute": [
  null,
  "$0 minutt",
  "$0 minutter"
 ],
 "$0 month": [
  null,
  "$0 måned",
  "$0 måneder"
 ],
 "$0 week": [
  null,
  "$0 uke",
  "$0 uker"
 ],
 "$0 will be installed.": [
  null,
  "$0 vil bli installert."
 ],
 "$0 year": [
  null,
  "$0 år",
  "$0 år"
 ],
 "1 day": [
  null,
  "1 dag"
 ],
 "1 hour": [
  null,
  "1 time"
 ],
 "1 minute": [
  null,
  "1 minutt"
 ],
 "1 week": [
  null,
  "1 uke"
 ],
 "20 minutes": [
  null,
  "20 minutter"
 ],
 "40 minutes": [
  null,
  "40 minutter"
 ],
 "5 minutes": [
  null,
  "5 minutter"
 ],
 "6 hours": [
  null,
  "6 timer"
 ],
 "60 minutes": [
  null,
  "60 minutter"
 ],
 "About Web Console": [
  null,
  "Om Web konsoll"
 ],
 "Absent": [
  null,
  "Fraværende"
 ],
 "Active pages": [
  null,
  "Aktive sider"
 ],
 "Add": [
  null,
  "Legg til"
 ],
 "Add $0": [
  null,
  "Legg til $0"
 ],
 "Add key": [
  null,
  "Legg til nøkkel"
 ],
 "Add new host": [
  null,
  "Legg til ny vert"
 ],
 "Additional packages:": [
  null,
  "Ekstra pakker:"
 ],
 "Administration with Cockpit Web Console": [
  null,
  "Administrasjon med Cockpit Web konsoll"
 ],
 "Administrative access": [
  null,
  "Administrativ tilgang"
 ],
 "Advanced TCA": [
  null,
  "Avansert TCA"
 ],
 "All-in-one": [
  null,
  "Alt i ett"
 ],
 "Ansible": [
  null,
  "Ansible"
 ],
 "Ansible roles documentation": [
  null,
  "Ansible roller dokumentasjon"
 ],
 "Apps": [
  null,
  "Apper"
 ],
 "Authenticate": [
  null,
  "Autentiser"
 ],
 "Authentication": [
  null,
  "Autentisering"
 ],
 "Authentication is required to perform privileged tasks with the Cockpit Web Console": [
  null,
  "Autentisering er nødvendig for å utføre privilegerte oppgaver med Cockpit Web konsoll"
 ],
 "Automatic login": [
  null,
  "Automatisk pålogging"
 ],
 "Automatically using NTP": [
  null,
  "Automatisk med bruk av NTP"
 ],
 "Automatically using specific NTP servers": [
  null,
  "Automatisk med bruk av spesifikke NTP servere"
 ],
 "Automation script": [
  null,
  "Automatiseringsskript"
 ],
 "Blade": [
  null,
  "Blad"
 ],
 "Blade enclosure": [
  null,
  "Blad-kabinett"
 ],
 "Bus expansion chassis": [
  null,
  ""
 ],
 "Can be a hostname, IP address, alias name, or ssh:// URI": [
  null,
  "Kan være et vertsnavn, IP-adresse, aliasnavn eller ssh:// URI"
 ],
 "Cancel": [
  null,
  "Avbryt"
 ],
 "Cannot connect to an unknown host": [
  null,
  "Kan ikke koble til en ukjent vert"
 ],
 "Cannot forward login credentials": [
  null,
  "Kan ikke videresende påloggingsinformasjonen"
 ],
 "Cannot schedule event in the past": [
  null,
  "Kan ikke tidsplanlegge hendelse i fortiden"
 ],
 "Change": [
  null,
  "Endre"
 ],
 "Change password": [
  null,
  "Endre passord"
 ],
 "Change system time": [
  null,
  "Endre systemtid"
 ],
 "Changed keys are often the result of an operating system reinstallation. However, an unexpected change may indicate a third-party attempt to intercept your connection.": [
  null,
  "Endrede nøkler er ofte resultatet av reinstallering av operativsystemet. Imidlertid kan en uventet endring indikere et tredjepartsforsøk på å fange opp forbindelsen din."
 ],
 "Checking installed software": [
  null,
  "Kontrollerer installert programvare"
 ],
 "Choose the language to be used in the application": [
  null,
  ""
 ],
 "Clear search": [
  null,
  "Tøm søket"
 ],
 "Close": [
  null,
  "Lukk"
 ],
 "Close selected pages": [
  null,
  "Lukk valgte sider"
 ],
 "Cockpit": [
  null,
  "Cockpit"
 ],
 "Cockpit configuration of NetworkManager and Firewalld": [
  null,
  ""
 ],
 "Cockpit could not contact the given host.": [
  null,
  "Cockpit kunne ikke kontakte den angitte verten."
 ],
 "Cockpit had an unexpected internal error.": [
  null,
  "Cockpit hadde en uventet intern feil."
 ],
 "Cockpit is a server manager that makes it easy to administer your Linux servers via a web browser. Jumping between the terminal and the web tool is no problem. A service started via Cockpit can be stopped via the terminal. Likewise, if an error occurs in the terminal, it can be seen in the Cockpit journal interface.": [
  null,
  "Cockpit er en serveradministrator som gjør det enkelt å administrere Linux-serverne dine via en nettleser. Å bytte mellom terminalen og nettverktøyet er ikke noe problem. En tjeneste startet via Cockpit kan stoppes via terminalen. På samme måte, hvis det oppstår en feil i terminalen, kan den sees i Cockpit journal-grensesnittet."
 ],
 "Cockpit is an interactive Linux server admin interface.": [
  null,
  "Cockpit er et interaktivt administrasjonsgrensesnitt for Linux-server."
 ],
 "Cockpit is not compatible with the software on the system.": [
  null,
  "Cockpit er ikke kompatibel med programvaren på systemet."
 ],
 "Cockpit is not installed": [
  null,
  "Cockpit er ikke installert"
 ],
 "Cockpit is not installed on the system.": [
  null,
  "Cockpit er ikke installert på systemet."
 ],
 "Cockpit is perfect for new sysadmins, allowing them to easily perform simple tasks such as storage administration, inspecting journals and starting and stopping services. You can monitor and administer several servers at the same time. Just add them with a single click and your machines will look after its buddies.": [
  null,
  "Cockpit er perfekt for nye sysadminer, slik at de enkelt kan utføre enkle oppgaver som lagringsadministrasjon, inspisere journaler og starte og stoppe tjenester. Du kan overvåke og administrere flere servere samtidig. Bare legg dem til med et enkelt klikk, så vil maskinene dine se etter kompisene."
 ],
 "Collect and package diagnostic and support data": [
  null,
  ""
 ],
 "Color": [
  null,
  "Farge"
 ],
 "Comment": [
  null,
  "Kommentar"
 ],
 "Compact PCI": [
  null,
  ""
 ],
 "Confirm key password": [
  null,
  "Bekreft nøkkel-passord"
 ],
 "Confirm new key password": [
  null,
  "Bekreft nytt nøkkel-passord"
 ],
 "Connect": [
  null,
  "Koble til"
 ],
 "Connected hosts can fully control each other. This includes running programs that could harm your system or steal data. Only connect to trusted machines.": [
  null,
  ""
 ],
 "Connecting to the machine": [
  null,
  "Kobler til maskinen"
 ],
 "Connection error": [
  null,
  "Tilkoblingsfeil"
 ],
 "Connection failed": [
  null,
  "Tilkoblingen feilet"
 ],
 "Connection has timed out.": [
  null,
  "Tidsavbrudd for tilkoblingen."
 ],
 "Contains:": [
  null,
  "Inneholder:"
 ],
 "Continue session": [
  null,
  "Fortsett økt"
 ],
 "Convertible": [
  null,
  "Konverterbar"
 ],
 "Copied": [
  null,
  ""
 ],
 "Copy": [
  null,
  "Kopier"
 ],
 "Copy to clipboard": [
  null,
  "Kopier til utklippstavle"
 ],
 "Create new task file with this content.": [
  null,
  "Opprett ny oppgavefil med dette innholdet."
 ],
 "Ctrl+Insert": [
  null,
  "Ctrl+Insert"
 ],
 "Dark": [
  null,
  "Mørk"
 ],
 "Default": [
  null,
  ""
 ],
 "Delay": [
  null,
  "Forsinkelse"
 ],
 "Desktop": [
  null,
  ""
 ],
 "Detachable": [
  null,
  ""
 ],
 "Details": [
  null,
  "Detaljer"
 ],
 "Diagnostic reports": [
  null,
  "Diagnose rapporter"
 ],
 "Disconnected": [
  null,
  "Frakoblet"
 ],
 "Display language": [
  null,
  "Visnings språk"
 ],
 "Docking station": [
  null,
  "Dokkingstasjon"
 ],
 "Downloading $0": [
  null,
  "Laster ned $0"
 ],
 "Dual rank": [
  null,
  "Dobbel rangering"
 ],
 "Edit": [
  null,
  "Rediger"
 ],
 "Edit host": [
  null,
  "Rediger vert"
 ],
 "Edit hosts": [
  null,
  "Rediger verter"
 ],
 "Embedded PC": [
  null,
  "Innebygd PC"
 ],
 "Excellent password": [
  null,
  "Utmerket passord"
 ],
 "Expansion chassis": [
  null,
  ""
 ],
 "Failed to add machine: $0": [
  null,
  "Kunne ikke legge til maskin: $0"
 ],
 "Failed to change password": [
  null,
  "Kunne ikke endre passord"
 ],
 "Failed to edit machine: $0": [
  null,
  "Kunne ikke redigere maskin: $0"
 ],
 "Fingerprint": [
  null,
  "Fingeravtrykk"
 ],
 "Go to now": [
  null,
  "Gå til nå"
 ],
 "Handheld": [
  null,
  "Håndholdt"
 ],
 "Help": [
  null,
  "Hjelp"
 ],
 "Host": [
  null,
  "Vert"
 ],
 "Host key is incorrect": [
  null,
  "Vertsnøkkelen er feil"
 ],
 "Hosts": [
  null,
  "Verter"
 ],
 "Install": [
  null,
  "Installer"
 ],
 "Install software": [
  null,
  "Installer programvare"
 ],
 "Installing $0": [
  null,
  "Installerer $0"
 ],
 "Internal error": [
  null,
  "Intern feil"
 ],
 "Invalid date format": [
  null,
  "Ugyldig datoformat"
 ],
 "Invalid date format and invalid time format": [
  null,
  "Ugyldig datoformat og ugyldig tidsformat"
 ],
 "Invalid file permissions": [
  null,
  "Ugyldige filtillatelser"
 ],
 "Invalid time format": [
  null,
  "Ugyldig tidsformat"
 ],
 "Invalid timezone": [
  null,
  "Ugyldig tidssone"
 ],
 "IoT gateway": [
  null,
  "IoT-gateway"
 ],
 "Is sshd running on a different port?": [
  null,
  "Kjører sshd på en annen port?"
 ],
 "Kernel dump": [
  null,
  "Kjerne dump"
 ],
 "Key password": [
  null,
  "Nøkkel-passord"
 ],
 "Laptop": [
  null,
  ""
 ],
 "Learn more": [
  null,
  "Lær mer"
 ],
 "Light": [
  null,
  "Lys"
 ],
 "Limit access": [
  null,
  "Begrens tilgang"
 ],
 "Limited access": [
  null,
  "Begrenset tilgang"
 ],
 "Limited access mode restricts administrative privileges. Some parts of the web console will have reduced functionality.": [
  null,
  "Begrenset tilgangsmodus begrenser administrative rettigheter. Noen deler av webkonsollet har redusert funksjonalitet."
 ],
 "Loading system modifications...": [
  null,
  "Laster inn systemendringer ..."
 ],
 "Log in": [
  null,
  "Logg inn"
 ],
 "Log messages": [
  null,
  "Logg meldinger"
 ],
 "Log out": [
  null,
  "Logg ut"
 ],
 "Login failed": [
  null,
  "Innlogging feilet"
 ],
 "Low profile desktop": [
  null,
  ""
 ],
 "Lunch box": [
  null,
  "Lunsjboks"
 ],
 "Main server chassis": [
  null,
  ""
 ],
 "Malicious pages on a remote machine may affect other connected hosts": [
  null,
  ""
 ],
 "Manually": [
  null,
  "Manuelt"
 ],
 "Message to logged in users": [
  null,
  "Melding til innloggede brukere"
 ],
 "Messages related to the failure might be found in the journal:": [
  null,
  "Meldinger relatert til feilen kan finnes i journalen:"
 ],
 "Method": [
  null,
  "Metode"
 ],
 "Mini PC": [
  null,
  "Mini-PC"
 ],
 "Mini tower": [
  null,
  ""
 ],
 "Multi-system chassis": [
  null,
  ""
 ],
 "NTP server": [
  null,
  "NTP Server"
 ],
 "Name": [
  null,
  "Navn"
 ],
 "Need at least one NTP server": [
  null,
  "Trenger minst en NTP-server"
 ],
 "Networking": [
  null,
  "Nettverk"
 ],
 "New key password": [
  null,
  "Nytt nøkkelpassord"
 ],
 "New password": [
  null,
  "Nytt passord"
 ],
 "New password was not accepted": [
  null,
  "Nytt passord ble ikke godtatt"
 ],
 "No delay": [
  null,
  "Ingen forsinkelse"
 ],
 "No languages match": [
  null,
  ""
 ],
 "No results found": [
  null,
  "Ingen resultater funnet"
 ],
 "No such file or directory": [
  null,
  "Ingen slik fil eller katalog"
 ],
 "No system modifications": [
  null,
  "Ingen systemendringer"
 ],
 "Not a valid private key": [
  null,
  "Ikke en gyldig privat nøkkel"
 ],
 "Not connected to host": [
  null,
  "Ikke koblet til verten"
 ],
 "Not permitted to perform this action.": [
  null,
  "Ikke tillatt å utføre denne handlingen."
 ],
 "Not synchronized": [
  null,
  "Ikke synkronisert"
 ],
 "Notebook": [
  null,
  ""
 ],
 "Ok": [
  null,
  "Ok"
 ],
 "Old password not accepted": [
  null,
  "Gammelt passord aksepteres ikke"
 ],
 "Once Cockpit is installed, enable it with \"systemctl enable --now cockpit.socket\".": [
  null,
  "Når Cockpit er installert, kan den aktiveres med \"systemctl enable --now cockpit.socket\"."
 ],
 "Ooops!": [
  null,
  ""
 ],
 "Other": [
  null,
  "Annen"
 ],
 "PackageKit crashed": [
  null,
  "PackageKit krasjet"
 ],
 "Page name": [
  null,
  "Sidenavn"
 ],
 "Password": [
  null,
  "Passord"
 ],
 "Password is not acceptable": [
  null,
  "Passord er ikke akseptabelt"
 ],
 "Password is too weak": [
  null,
  "Passordet er for svakt"
 ],
 "Password not accepted": [
  null,
  "Passord ikke akseptert"
 ],
 "Paste": [
  null,
  "Lim inn"
 ],
 "Path to file": [
  null,
  "Sti til fil"
 ],
 "Peripheral chassis": [
  null,
  "Perifert chassis"
 ],
 "Pick date": [
  null,
  "Velg dato"
 ],
 "Pizza box": [
  null,
  "Pizzaboks"
 ],
 "Please authenticate to gain administrative access": [
  null,
  "Autentiser for å få administrativ tilgang"
 ],
 "Port": [
  null,
  "Port"
 ],
 "Portable": [
  null,
  "Bærbar"
 ],
 "Present": [
  null,
  "Til stede"
 ],
 "Project website": [
  null,
  "Prosjektets nettsted"
 ],
 "Prompting via ssh-add timed out": [
  null,
  "Spørring via ssh-add ble tidsavbrutt"
 ],
 "Prompting via ssh-keygen timed out": [
  null,
  "Spørring via ssh-keygen ble tidsavbrutt"
 ],
 "Public key": [
  null,
  "Offentlig nøkkel"
 ],
 "RAID chassis": [
  null,
  "RAID chassis"
 ],
 "Rack mount chassis": [
  null,
  ""
 ],
 "Reboot": [
  null,
  "Omstart"
 ],
 "Reconnect": [
  null,
  "Koble til på nytt"
 ],
 "Removals:": [
  null,
  ""
 ],
 "Remove": [
  null,
  "Fjern"
 ],
 "Removing $0": [
  null,
  "Fjerner $0"
 ],
 "Run this command over a trusted network or physically on the remote machine:": [
  null,
  ""
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "SSH key": [
  null,
  "SSH-nøkkel"
 ],
 "SSH keys": [
  null,
  "SSH-nøkler"
 ],
 "Safari users need to import and trust the certificate of the self-signing CA:": [
  null,
  "Safari-brukere må importere og stole på sertifikatet for den selvsignerende CA:"
 ],
 "Sealed-case PC": [
  null,
  ""
 ],
 "Search": [
  null,
  "Søk"
 ],
 "Security Enhanced Linux configuration and troubleshooting": [
  null,
  ""
 ],
 "Select": [
  null,
  "Velg"
 ],
 "Server has closed the connection.": [
  null,
  "Serveren har lukket forbindelsen."
 ],
 "Session": [
  null,
  "Økt"
 ],
 "Session is about to expire": [
  null,
  "Økten er i ferd med å utløpe"
 ],
 "Set": [
  null,
  "Sett"
 ],
 "Set time": [
  null,
  "Sett tid"
 ],
 "Shell script": [
  null,
  "Shell-skript"
 ],
 "Shift+Insert": [
  null,
  "Shift+Insert"
 ],
 "Shut down": [
  null,
  "Slå av"
 ],
 "Single rank": [
  null,
  ""
 ],
 "Skip main navigation": [
  null,
  ""
 ],
 "Skip to content": [
  null,
  "Gå til innhold"
 ],
 "Space-saving computer": [
  null,
  "Plassbesparende datamaskin"
 ],
 "Specific time": [
  null,
  "Spesifikk tid"
 ],
 "Stick PC": [
  null,
  ""
 ],
 "Stop editing hosts": [
  null,
  "Slutt å redigere verter"
 ],
 "Storage": [
  null,
  "Lagring"
 ],
 "Style": [
  null,
  ""
 ],
 "Sub-Chassis": [
  null,
  ""
 ],
 "Sub-Notebook": [
  null,
  ""
 ],
 "Switch to limited access": [
  null,
  "Bytt til begrenset tilgang"
 ],
 "Synchronized": [
  null,
  "Synkronisert"
 ],
 "Synchronized with $0": [
  null,
  "Synkronisert med $0"
 ],
 "Synchronizing": [
  null,
  "Synkroniserer"
 ],
 "System": [
  null,
  "System"
 ],
 "Tablet": [
  null,
  "Nettbrett"
 ],
 "The IP address or hostname cannot contain whitespace.": [
  null,
  "IP-adressen eller vertsnavnet kan ikke inneholde mellomrom."
 ],
 "The key password can not be empty": [
  null,
  "Nøkkelpassordet kan ikke være tomt"
 ],
 "The key passwords do not match": [
  null,
  "Nøkkelpassordene stemmer ikke overens"
 ],
 "The logged in user is not permitted to view system modifications": [
  null,
  "Den påloggede brukeren har ikke lov til å se systemendringer"
 ],
 "The machine is rebooting": [
  null,
  "Maskinen starter på nytt"
 ],
 "The new key password can not be empty": [
  null,
  "Det nye nøkkelpassordet kan ikke være tomt"
 ],
 "The resulting fingerprint is fine to share via public methods, including email.": [
  null,
  "Det resulterende fingeravtrykket er greit å dele via offentlige metoder, inkludert e-post."
 ],
 "The resulting fingerprint is fine to share via public methods, including email. If you are asking someone else to do the verification for you, they can send the results using any method.": [
  null,
  ""
 ],
 "The server refused to authenticate using any supported methods.": [
  null,
  "Serveren nektet å godkjenne ved hjelp av de støttede metodene."
 ],
 "There are currently no active pages": [
  null,
  "Det er for øyeblikket ingen aktive sider"
 ],
 "There was an unexpected error while connecting to the machine.": [
  null,
  "Det oppsto en uventet feil under tilkoblingen til maskinen."
 ],
 "This machine has already been added.": [
  null,
  "Denne maskinen er allerede lagt til."
 ],
 "This tool configures the SELinux policy and can help with understanding and resolving policy violations.": [
  null,
  ""
 ],
 "This tool configures the system to write kernel crash dumps. It supports the \"local\" (disk), \"ssh\", and \"nfs\" dump targets.": [
  null,
  ""
 ],
 "This tool generates an archive of configuration and diagnostic information from the running system. The archive may be stored locally or centrally for recording or tracking purposes or may be sent to technical support representatives, developers or system administrators to assist with technical fault-finding and debugging.": [
  null,
  ""
 ],
 "This tool manages local storage, such as filesystems, LVM2 volume groups, and NFS mounts.": [
  null,
  ""
 ],
 "This tool manages networking such as bonds, bridges, teams, VLANs and firewalls using NetworkManager and Firewalld. NetworkManager is incompatible with Ubuntu's default systemd-networkd and Debian's ifupdown scripts.": [
  null,
  ""
 ],
 "This will allow you to log in without password in the future.": [
  null,
  "Dette vil tillate deg å logge på uten passord i fremtiden."
 ],
 "Time zone": [
  null,
  "Tidssone"
 ],
 "Tip: Make your key password match your login password to automatically authenticate against other systems.": [
  null,
  "Tips: Gjør at nøkkelpassordet ditt samsvarer med påloggingspassordet ditt for automatisk autentisering mot andre systemer."
 ],
 "To ensure that your connection is not intercepted by a malicious third-party, please verify the host key fingerprint:": [
  null,
  "For å sikre at forbindelsen din ikke blir fanget opp av en ondsinnet tredjepart, må du verifisere vertsnøkkelens fingeravtrykk:"
 ],
 "To verify a fingerprint, run the following on $0 while physically sitting at the machine or through a trusted network:": [
  null,
  "For å bekrefte et fingeravtrykk, kjør følgende på $ 0 mens du sitter fysisk ved maskinen eller gjennom et pålitelig nettverk:"
 ],
 "Toggle": [
  null,
  ""
 ],
 "Toggle date picker": [
  null,
  ""
 ],
 "Too much data": [
  null,
  "For mye data"
 ],
 "Tools": [
  null,
  "Verktøy"
 ],
 "Total size: $0": [
  null,
  "Total størrelse: $0"
 ],
 "Tower": [
  null,
  ""
 ],
 "Trust and add host": [
  null,
  ""
 ],
 "Trying to synchronize with $0": [
  null,
  "Prøver å synkronisere med $0"
 ],
 "Turn on administrative access": [
  null,
  "Slå på administrativ tilgang"
 ],
 "Type": [
  null,
  "Type"
 ],
 "Unable to contact the given host $0. Make sure it has ssh running on port $1, or specify another port in the address.": [
  null,
  "Kan ikke kontakte den angitte verten $0. Forsikre deg om at den har ssh på port $1, eller angi en annen port i adressen."
 ],
 "Unexpected error": [
  null,
  "Uventet feil"
 ],
 "Unknown": [
  null,
  "Ukjent"
 ],
 "Unlock": [
  null,
  "Lås opp"
 ],
 "Untrusted host": [
  null,
  ""
 ],
 "Update": [
  null,
  "Oppdater"
 ],
 "Use key": [
  null,
  "Bruk nøkkel"
 ],
 "Use the following keys to authenticate against other systems": [
  null,
  "Bruk følgende nøkler for å autentisere mot andre systemer"
 ],
 "User name": [
  null,
  "Brukernavn"
 ],
 "View automation script": [
  null,
  "Vis automatiseringsskript"
 ],
 "Waiting for other software management operations to finish": [
  null,
  "Venter på at andre programvareadministrasjons-operasjoner skal fullføres"
 ],
 "Web Console": [
  null,
  "Web konsoll"
 ],
 "Web Console for Linux servers": [
  null,
  "Web konsoll for Linux servere"
 ],
 "When empty, connect with the current user": [
  null,
  ""
 ],
 "You are connecting to $0 for the first time.": [
  null,
  "Du kobler til $0 for første gang."
 ],
 "You have been logged out due to inactivity.": [
  null,
  "Du har blitt logget ut på grunn av inaktivitet."
 ],
 "You may want to change the password of the key for automatic login.": [
  null,
  "Det kan være lurt å endre passordet til nøkkelen for automatisk pålogging."
 ],
 "You now have administrative access.": [
  null,
  "Du har nå administrativ tilgang."
 ],
 "You will be logged out in $0 seconds.": [
  null,
  "Du blir logget ut om $0 sekunder."
 ],
 "Your browser does not allow paste from the context menu. You can use Shift+Insert.": [
  null,
  ""
 ],
 "Your browser will remember your access level across sessions.": [
  null,
  "Nettleseren din husker tilgangsnivået ditt på tvers av øktene."
 ],
 "Your session has been terminated.": [
  null,
  "Økten din er avsluttet."
 ],
 "Your session has expired. Please log in again.": [
  null,
  "Økten din har utløpt. Vennligst logg inn igjen."
 ],
 "Zone": [
  null,
  ""
 ],
 "[binary data]": [
  null,
  "[binære data]"
 ],
 "[no data]": [
  null,
  "[ingen data]"
 ],
 "active": [
  null,
  "aktiv"
 ],
 "in less than a minute": [
  null,
  ""
 ],
 "in most browsers": [
  null,
  "i de fleste nettlesere"
 ],
 "less than a minute ago": [
  null,
  ""
 ],
 "password quality": [
  null,
  "passordkvalitet"
 ],
 "show less": [
  null,
  "vis mindre"
 ],
 "show more": [
  null,
  "vis mer"
 ]
});
