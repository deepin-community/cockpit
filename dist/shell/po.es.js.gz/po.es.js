cockpit.locale({
 "": {
  "plural-forms": (n) => n != 1,
  "language": "es",
  "language-direction": "ltr"
 },
 "$0 GiB": [
  null,
  "$0 GiB"
 ],
 "$0 day": [
  null,
  "$0 día",
  "$0 días"
 ],
 "$0 documentation": [
  null,
  "Documentación de $0"
 ],
 "$0 exited with code $1": [
  null,
  "$0 finalizó con el código $1"
 ],
 "$0 failed": [
  null,
  "$0 falló"
 ],
 "$0 hour": [
  null,
  "$0 hora",
  "$0 horas"
 ],
 "$0 is not available from any repository.": [
  null,
  "$0 no está disponible en ningún repositorio."
 ],
 "$0 key changed": [
  null,
  "$0 clave cambiada"
 ],
 "$0 killed with signal $1": [
  null,
  "$0 terminado con señal $1"
 ],
 "$0 minute": [
  null,
  "$0 minuto",
  "$0 minutos"
 ],
 "$0 month": [
  null,
  "$0 mes",
  "$0 meses"
 ],
 "$0 week": [
  null,
  "$0 semana",
  "$0 semanas"
 ],
 "$0 will be installed.": [
  null,
  "Se instalará: $0."
 ],
 "$0 year": [
  null,
  "$0 año",
  "$0 años"
 ],
 "1 day": [
  null,
  "1 día"
 ],
 "1 hour": [
  null,
  "1 hora"
 ],
 "1 minute": [
  null,
  "1 minuto"
 ],
 "1 week": [
  null,
  "1 semana"
 ],
 "20 minutes": [
  null,
  "20 minutos"
 ],
 "40 minutes": [
  null,
  "40 minutos"
 ],
 "5 minutes": [
  null,
  "5 minutos"
 ],
 "6 hours": [
  null,
  "6 horas"
 ],
 "60 minutes": [
  null,
  "60 minutos"
 ],
 "A compatible version of Cockpit is not installed on $0.": [
  null,
  "No se ha instalado una versión compatible de Cockpit en $0."
 ],
 "A new SSH key at $0 will be created for $1 on $2 and it will be added to the $3 file of $4 on $5.": [
  null,
  "Se creará una nueva clave SSH en $0 para $1 en $2 y se añadirá al fichero $3 de $4 en $5."
 ],
 "About Web Console": [
  null,
  "Acerca de la consola Web"
 ],
 "Absent": [
  null,
  "Ausente"
 ],
 "Acceptable password": [
  null,
  "Contraseña aceptable"
 ],
 "Active pages": [
  null,
  "Páginas activas"
 ],
 "Add": [
  null,
  "Añadir"
 ],
 "Add $0": [
  null,
  "Añadir $0"
 ],
 "Add key": [
  null,
  "Añadir clave"
 ],
 "Add new host": [
  null,
  "Añadir un nuevo anfitrión"
 ],
 "Additional packages:": [
  null,
  "Paquetes adicionales:"
 ],
 "Administration with Cockpit Web Console": [
  null,
  "Administrando con la consola Web de Cockpit"
 ],
 "Administrative access": [
  null,
  "Acceso administrativo"
 ],
 "Advanced TCA": [
  null,
  "TCA avanzado"
 ],
 "All-in-one": [
  null,
  "Todo en uno"
 ],
 "Ansible": [
  null,
  "Ansible"
 ],
 "Ansible roles documentation": [
  null,
  "Documentación de los roles de Ansible"
 ],
 "Apps": [
  null,
  "Aplicaciones"
 ],
 "Authenticate": [
  null,
  "Autenticar"
 ],
 "Authentication": [
  null,
  "Autenticación"
 ],
 "Authentication is required to perform privileged tasks with the Cockpit Web Console": [
  null,
  "Se requiere autenticación para elevar privilegios y realizar tareas de administración en la consola Web de Cockpit"
 ],
 "Authorize SSH key": [
  null,
  "Autorice la clave SSH"
 ],
 "Automatic login": [
  null,
  "Acceso automático"
 ],
 "Automatically using NTP": [
  null,
  "Utilizando NTP de forma automática"
 ],
 "Automatically using additional NTP servers": [
  null,
  "Utilizando automáticamente servidores NTP adicionales"
 ],
 "Automatically using specific NTP servers": [
  null,
  "Utilizando automáticamente servidores NTP específicos"
 ],
 "Automation script": [
  null,
  "Script de automatización"
 ],
 "Blade": [
  null,
  "Blade"
 ],
 "Blade enclosure": [
  null,
  "Chasis tipo blade"
 ],
 "Bus expansion chassis": [
  null,
  "Chasis de expansión de bus"
 ],
 "By changing the password of the SSH key $0 to the login password of $1 on $2, the key will be automatically made available and you can log in to $3 without password in the future.": [
  null,
  "Al cambiar la contraseña de la clave SSH $0 a la contraseña de acceso de $1 en $2, dicha clave quedará disponible automáticamente y podrá acceder a $3 sin contraseña en el futuro."
 ],
 "Can be a hostname, IP address, alias name, or ssh:// URI": [
  null,
  "Puede ser un hostname, dirección IP, alias, o URI ssh://"
 ],
 "Cancel": [
  null,
  "Cancelar"
 ],
 "Cannot connect to an unknown host": [
  null,
  "No se puede conectar con un anfitrión desconocido"
 ],
 "Cannot forward login credentials": [
  null,
  "No se pueden transferir los datos de acceso"
 ],
 "Cannot schedule event in the past": [
  null,
  "No se puede planificar un evento ocurrido en el pasado"
 ],
 "Change": [
  null,
  "Cambiar"
 ],
 "Change password": [
  null,
  "Cambiar la contraseña"
 ],
 "Change system time": [
  null,
  "Cambiar la hora del sistema"
 ],
 "Change the password of $0": [
  null,
  "Cambiar la contraseña de $0"
 ],
 "Changed keys are often the result of an operating system reinstallation. However, an unexpected change may indicate a third-party attempt to intercept your connection.": [
  null,
  "Las llaves cambiadas pueden llevar una reinstalación del sistema operativo. Sin embargo, un cambio inesperado puede indicar un intento de interceptar su conexión mediante un tercero."
 ],
 "Checking installed software": [
  null,
  "Comprobando el software instalado"
 ],
 "Choose the language to be used in the application": [
  null,
  "Seleccione el idioma que se va a utilizar en la aplicación"
 ],
 "Clear input value": [
  null,
  "Vaciar valor de entrada"
 ],
 "Clear search": [
  null,
  "Limpiar la búsqueda"
 ],
 "Close": [
  null,
  "Cerrar"
 ],
 "Close selected pages": [
  null,
  "Cerrar las páginas seleccionadas"
 ],
 "Cockpit": [
  null,
  "Cockpit"
 ],
 "Cockpit configuration of NetworkManager and Firewalld": [
  null,
  "Configuración en Cockpit de NetworkManager y Firewalld"
 ],
 "Cockpit could not contact the given host.": [
  null,
  "Cockpit no se pudo conectar con el anfitrión especificado."
 ],
 "Cockpit had an unexpected internal error.": [
  null,
  "Cockpit tuvo un error interno no esperado."
 ],
 "Cockpit is a server manager that makes it easy to administer your Linux servers via a web browser. Jumping between the terminal and the web tool is no problem. A service started via Cockpit can be stopped via the terminal. Likewise, if an error occurs in the terminal, it can be seen in the Cockpit journal interface.": [
  null,
  "Cockpit es un gestor de servidores que facilita la administración de servidores Linux a través de un navegador web. Es posible alternar entre el portal web y la consola sin problemas. Un servicio que haya empezado por Cockpit se puede parar desde la terminal. Asimismo, si se produce un error en el terminal, podrá verlo en la bitácora de Cockpit."
 ],
 "Cockpit is an interactive Linux server admin interface.": [
  null,
  "Cockpit es una interfaz interactiva que permite la gestión de servidores Linux."
 ],
 "Cockpit is not compatible with the software on the system.": [
  null,
  "Cockpit no es compatible con el software del sistema."
 ],
 "Cockpit is not installed": [
  null,
  "Cockpit no está instalado"
 ],
 "Cockpit is not installed on the system.": [
  null,
  "Cockpit no está instalado en el sistema."
 ],
 "Cockpit is perfect for new sysadmins, allowing them to easily perform simple tasks such as storage administration, inspecting journals and starting and stopping services. You can monitor and administer several servers at the same time. Just add them with a single click and your machines will look after its buddies.": [
  null,
  "Cockpit es ideal para administradores de sistemas nóveles, ya que permite realizar con sencillez tareas como gestionar almacenamiento, inspeccionar bitácoras e iniciar y detener servicios. Puede monitorizar y administrar varios servidores a la vez. Tan solo añádalos con solo pulsar un botón y sus máquinas se encargarán del resto."
 ],
 "Collect and package diagnostic and support data": [
  null,
  "Recoger y empaquetar datos de diagnóstico y soporte"
 ],
 "Collect kernel crash dumps": [
  null,
  "Recoger volcados de colapso del kernel"
 ],
 "Color": [
  null,
  "Color"
 ],
 "Comment": [
  null,
  "Comentario"
 ],
 "Compact PCI": [
  null,
  "PCI compacto"
 ],
 "Confirm key password": [
  null,
  "Confirme la contraseña de la clave"
 ],
 "Confirm new key password": [
  null,
  "Confirme la nueva contraseña de la clave"
 ],
 "Confirm password": [
  null,
  "Confirmar contraseña"
 ],
 "Connect": [
  null,
  "Conectar"
 ],
 "Connect to $0?": [
  null,
  "¿Conectar a $0?"
 ],
 "Connected hosts can fully control each other. This includes running programs that could harm your system or steal data. Only connect to trusted machines.": [
  null,
  "Hospedajes conectado pueden controlar completamente cada otro. Esto incluye ejecutar programas que pudieron dañar su sistema o robar datos. Solamente conecte a máquinas confiables."
 ],
 "Connecting to the machine": [
  null,
  "Conectándose a la máquina"
 ],
 "Connection error": [
  null,
  "Error de conexión"
 ],
 "Connection failed": [
  null,
  "Conexión fallida"
 ],
 "Connection has timed out.": [
  null,
  "La conexión ha caducado."
 ],
 "Contains:": [
  null,
  "Contenidos:"
 ],
 "Continue session": [
  null,
  "Continúe con la sesión"
 ],
 "Convertible": [
  null,
  "Convertible"
 ],
 "Copied": [
  null,
  "Copiado"
 ],
 "Copy": [
  null,
  "Copiar"
 ],
 "Copy to clipboard": [
  null,
  "Copiar al portapapeles"
 ],
 "Could not contact $0": [
  null,
  "No se pudo contactar con $0"
 ],
 "Create $0": [
  null,
  "Crear $0"
 ],
 "Create a new SSH key and authorize it": [
  null,
  "Crear una clave SSH nueva y autorícela"
 ],
 "Create new task file with this content.": [
  null,
  "Crear un archivo de tarea con este contenido."
 ],
 "Ctrl+Insert": [
  null,
  "Ctrl+Insert"
 ],
 "Ctrl-Shift-I": [
  null,
  "Ctrl-Shift-I"
 ],
 "Dark": [
  null,
  "Oscuro"
 ],
 "Default": [
  null,
  "Predeterminado"
 ],
 "Delay": [
  null,
  "Retardo"
 ],
 "Desktop": [
  null,
  "Escritorio"
 ],
 "Detachable": [
  null,
  "Desmontable"
 ],
 "Details": [
  null,
  "Detalles"
 ],
 "Diagnostic reports": [
  null,
  "Informes de diagnóstico"
 ],
 "Disconnected": [
  null,
  "Desconectado"
 ],
 "Display language": [
  null,
  "Idioma de visualización"
 ],
 "Docking station": [
  null,
  "Estación de acoplamiento"
 ],
 "Downloading $0": [
  null,
  "Descargando $0"
 ],
 "Dual rank": [
  null,
  "Rango dual"
 ],
 "Edit": [
  null,
  "Editar"
 ],
 "Edit host": [
  null,
  "Editar anfitrión"
 ],
 "Edit hosts": [
  null,
  "Editar anfitriones"
 ],
 "Embedded PC": [
  null,
  "PC integrado"
 ],
 "Excellent password": [
  null,
  "Contraseña excelente"
 ],
 "Expansion chassis": [
  null,
  "Chasis de expansión"
 ],
 "Failed to add machine: $0": [
  null,
  "Fallo al añadir la máquina: $0"
 ],
 "Failed to change password": [
  null,
  "Error al cambiar contraseña"
 ],
 "Failed to edit machine: $0": [
  null,
  "Fallo al editar máquina: $0"
 ],
 "Failed to enable $0 in firewalld": [
  null,
  "Fallo al habilitar $0 en firewalld"
 ],
 "Filter menu items": [
  null,
  "Filtrar elementos del menú"
 ],
 "Fingerprint": [
  null,
  "Huella dactilar"
 ],
 "Go to now": [
  null,
  "Ir a ahora"
 ],
 "Handheld": [
  null,
  "Dispositivo de mano"
 ],
 "Help": [
  null,
  "Ayuda"
 ],
 "Hide confirmation password": [
  null,
  "Ocultar contraseña de confirmación"
 ],
 "Hide password": [
  null,
  "Ocultar contraseña"
 ],
 "Host": [
  null,
  "Anfitrión"
 ],
 "Host key is incorrect": [
  null,
  "La tecla del anfitrión es incorrecta"
 ],
 "Hosts": [
  null,
  "Anfitriones"
 ],
 "If the fingerprint matches, click 'Trust and add host'. Otherwise, do not connect and contact your administrator.": [
  null,
  "Si la huella coincide, pulse \"Confiar en el anfitrión y añadirlo\". En caso contrario, no se conecte y contacte con su administrador."
 ],
 "In order to allow log in to $0 as $1 without password in the future, use the login password of $2 on $3 as the key password, or leave the key password blank.": [
  null,
  "Para permitir iniciar sesión sin contraseña a $1 en $0 en adelante, use la contraseña de inicio de sesión de $2 en $3 como la contraseña de su clave, o deje la contraseña en blanco."
 ],
 "Install": [
  null,
  "Instalar"
 ],
 "Install software": [
  null,
  "Instalar software"
 ],
 "Installing $0": [
  null,
  "Instalando $0"
 ],
 "Internal error": [
  null,
  "Error interno"
 ],
 "Invalid date format": [
  null,
  "Formato de fecha inválido"
 ],
 "Invalid date format and invalid time format": [
  null,
  "Formato de fecha y hora inválidos"
 ],
 "Invalid file permissions": [
  null,
  "Permisos de archivo inválido"
 ],
 "Invalid time format": [
  null,
  "Formato de hora inválido"
 ],
 "Invalid timezone": [
  null,
  "Zona horaria no válida"
 ],
 "IoT gateway": [
  null,
  "Pasarela IoT"
 ],
 "Is sshd running on a different port?": [
  null,
  "¿El servicio SSHD está corriendo en un puerto diferente?"
 ],
 "Kernel dump": [
  null,
  "Volcado del kernel"
 ],
 "Key password": [
  null,
  "Contraseña de la clave"
 ],
 "Laptop": [
  null,
  "Portátil"
 ],
 "Learn more": [
  null,
  "Aprenda más"
 ],
 "Licensed under GNU LGPL version 2.1": [
  null,
  "Licenciada bajo la GNU LGPL versión 2.1"
 ],
 "Light": [
  null,
  "Claro"
 ],
 "Limit access": [
  null,
  "Limitar acceso"
 ],
 "Limited access": [
  null,
  "Acceso limitado"
 ],
 "Limited access mode restricts administrative privileges. Some parts of the web console will have reduced functionality.": [
  null,
  "El modo de acceso limitado restringe los privilegios administrativos. Algunas partes de la consola web tendrán funcionalidad reducida."
 ],
 "Loading packages...": [
  null,
  "Cargando paquetes..."
 ],
 "Loading system modifications...": [
  null,
  "Cargando modificaciones del sistema..."
 ],
 "Log in": [
  null,
  "Iniciar sesión"
 ],
 "Log in to $0": [
  null,
  "Iniciar sesión en $0"
 ],
 "Log messages": [
  null,
  "Mensajes de registro"
 ],
 "Log out": [
  null,
  "Salir"
 ],
 "Login failed": [
  null,
  "Inicio de sesión fallido"
 ],
 "Low profile desktop": [
  null,
  "Perfil bajo de escritorio"
 ],
 "Lunch box": [
  null,
  "Caja de almuerzo"
 ],
 "Main server chassis": [
  null,
  "Chasis del servidor principal"
 ],
 "Malicious pages on a remote machine may affect other connected hosts": [
  null,
  "Las páginas maliciosas en una máquina remota pueden afectar a otros hospedajes conectados"
 ],
 "Manage storage": [
  null,
  "Gestionar el almacenamiento"
 ],
 "Manually": [
  null,
  "Manualmente"
 ],
 "Message to logged in users": [
  null,
  "Mensaje para usuarios activos"
 ],
 "Messages related to the failure might be found in the journal:": [
  null,
  "Los mensajes relacionados con los fallos se podrían encontrar en la bitácora:"
 ],
 "Method": [
  null,
  "Método"
 ],
 "Mini PC": [
  null,
  "Mini PC"
 ],
 "Mini tower": [
  null,
  "Mini Torre"
 ],
 "Multi-system chassis": [
  null,
  "Chasis multisistema"
 ],
 "NTP server": [
  null,
  "Servidor NTP"
 ],
 "Name": [
  null,
  "Nombre"
 ],
 "Need at least one NTP server": [
  null,
  "Se requiere al menos un servidor NTP"
 ],
 "Networking": [
  null,
  "Redes"
 ],
 "New host: $0": [
  null,
  "Nuevo anfitrión: $0"
 ],
 "New key password": [
  null,
  "Nueva contraseña de la clave"
 ],
 "New password": [
  null,
  "Nueva contraseña"
 ],
 "New password was not accepted": [
  null,
  "No se aceptó la nueva contraseña"
 ],
 "No delay": [
  null,
  "Sin retardo"
 ],
 "No languages match": [
  null,
  "No coincide ningún idioma"
 ],
 "No results found": [
  null,
  "No se encontraron resultados"
 ],
 "No such file or directory": [
  null,
  "No existe el archivo o directorio"
 ],
 "No system modifications": [
  null,
  "No hay modificaciones para el sistema"
 ],
 "Not a valid private key": [
  null,
  "No es una clave privada válida"
 ],
 "Not connected to host": [
  null,
  "No se ha conectado al anfitrión"
 ],
 "Not permitted to perform this action.": [
  null,
  "No está permitido llevar a cabo esta acción."
 ],
 "Not synchronized": [
  null,
  "No está sincronizado"
 ],
 "Notebook": [
  null,
  "Portátil"
 ],
 "Occurrences": [
  null,
  "Ocurrencias"
 ],
 "Ok": [
  null,
  "Aceptar"
 ],
 "Old password not accepted": [
  null,
  "No se aceptó la contraseña vieja"
 ],
 "Once Cockpit is installed, enable it with \"systemctl enable --now cockpit.socket\".": [
  null,
  "Una vez que se instale Cockpit, habilítelo con \"systemctl enable --now cockpit.socket\"."
 ],
 "Ooops!": [
  null,
  "¡Ooops!"
 ],
 "Other": [
  null,
  "Otro"
 ],
 "PackageKit crashed": [
  null,
  "PackageKit colapsó"
 ],
 "Page name": [
  null,
  "Nombre de la página"
 ],
 "Password": [
  null,
  "Contraseña"
 ],
 "Password changed successfully": [
  null,
  "Contraseña cambiada con éxito"
 ],
 "Password is not acceptable": [
  null,
  "La contraseña no es válida"
 ],
 "Password is too weak": [
  null,
  "La contraseña es muy débil"
 ],
 "Password not accepted": [
  null,
  "Contraseña no válida"
 ],
 "Password tip": [
  null,
  "Consejo sobre la contraseña"
 ],
 "Paste": [
  null,
  "Pegar"
 ],
 "Paste error": [
  null,
  "Error al pegar"
 ],
 "Path to file": [
  null,
  "Ruta al fichero"
 ],
 "Peripheral chassis": [
  null,
  "Chasis periférico"
 ],
 "Pick date": [
  null,
  "Selecciona una fecha"
 ],
 "Pizza box": [
  null,
  "Caja de pizza"
 ],
 "Please authenticate to gain administrative access": [
  null,
  "Autentíquese para obtener acceso administrativo"
 ],
 "Port": [
  null,
  "Puerto"
 ],
 "Portable": [
  null,
  "Portable"
 ],
 "Present": [
  null,
  "Presente"
 ],
 "Problem becoming administrator": [
  null,
  "Problema al cambiar a administrador"
 ],
 "Project website": [
  null,
  "Sitio Web del proyecto"
 ],
 "Prompting via ssh-add timed out": [
  null,
  "Ha expirado el tiempo de ssh-add"
 ],
 "Prompting via ssh-keygen timed out": [
  null,
  "Se ha agotado el tiempo de espera para ssh-keygen"
 ],
 "Public key": [
  null,
  "Clave pública"
 ],
 "RAID chassis": [
  null,
  "Chasis RAID"
 ],
 "Rack mount chassis": [
  null,
  "Chasis montado en rack"
 ],
 "Read more": [
  null,
  "Leer más"
 ],
 "Reboot": [
  null,
  "Reiniciar"
 ],
 "Reconnect": [
  null,
  "Reconectarse"
 ],
 "Removals:": [
  null,
  "Borrados:"
 ],
 "Remove": [
  null,
  "Eliminar"
 ],
 "Removing $0": [
  null,
  "Eliminando $0"
 ],
 "Row expansion": [
  null,
  "Fila de expansión"
 ],
 "Row select": [
  null,
  "Seleccionar fila"
 ],
 "Run this command over a trusted network or physically on the remote machine:": [
  null,
  "Ejecute este comando en la máquina remota a través de una red de confianza o de forma física:"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "SSH key": [
  null,
  "Clave SSH"
 ],
 "SSH key login": [
  null,
  "Clave SSH de acceso"
 ],
 "SSH keys": [
  null,
  "Claves SSH"
 ],
 "Safari users need to import and trust the certificate of the self-signing CA:": [
  null,
  "Los usuarios de Safari tienen que importar y confiar en la CA del certificado autofirmado:"
 ],
 "Sealed-case PC": [
  null,
  "PC de caja sellada"
 ],
 "Search": [
  null,
  "Buscar"
 ],
 "Security Enhanced Linux configuration and troubleshooting": [
  null,
  "Configuración de Security Enhanced Linux y resolución de problemas"
 ],
 "Select": [
  null,
  "Seleccionar"
 ],
 "Select an option": [
  null,
  "Seleccione una opción"
 ],
 "Server has closed the connection.": [
  null,
  "El servidor ha cerrado la conexión."
 ],
 "Session": [
  null,
  "Sesión"
 ],
 "Session is about to expire": [
  null,
  "La sesión está apunto de expirar"
 ],
 "Set": [
  null,
  "Establecer"
 ],
 "Set time": [
  null,
  "Establecer la hora"
 ],
 "Shell script": [
  null,
  "Script de shell"
 ],
 "Shift+Insert": [
  null,
  "Shift+Insert"
 ],
 "Show confirmation password": [
  null,
  "Mostrar contraseña de confirmación"
 ],
 "Show password": [
  null,
  "Mostrar contraseña"
 ],
 "Shut down": [
  null,
  "Apagar"
 ],
 "Single rank": [
  null,
  "Rango único"
 ],
 "Skip main navigation": [
  null,
  "Saltar navegación principal"
 ],
 "Skip to content": [
  null,
  "Saltar al contenido"
 ],
 "Space-saving computer": [
  null,
  "Ordenador compacto"
 ],
 "Specific time": [
  null,
  "Hora específica"
 ],
 "Stick PC": [
  null,
  "PC USB"
 ],
 "Stop editing hosts": [
  null,
  "Dejar de editar anfitriones"
 ],
 "Storage": [
  null,
  "Almacenamiento"
 ],
 "Strong password": [
  null,
  "Contraseña fuerte"
 ],
 "Style": [
  null,
  "Estilo"
 ],
 "Sub-Chassis": [
  null,
  "Sub Chasis"
 ],
 "Sub-Notebook": [
  null,
  "Subportátil"
 ],
 "Switch to administrative access": [
  null,
  "Cambiar a acceso administrativo"
 ],
 "Switch to limited access": [
  null,
  "Pasar a acceso limitado"
 ],
 "Synchronized": [
  null,
  "Sincronizado"
 ],
 "Synchronized with $0": [
  null,
  "Sincronizado con $0"
 ],
 "Synchronizing": [
  null,
  "Sincronizando"
 ],
 "System": [
  null,
  "Sistema"
 ],
 "Tablet": [
  null,
  "Tableta"
 ],
 "The IP address or hostname cannot contain whitespace.": [
  null,
  "La dirección IP o el nombre de dominio no pueden contener espacios en blanco."
 ],
 "The SSH key $0 of $1 on $2 will be added to the $3 file of $4 on $5.": [
  null,
  "La clave SSH $0 de $1 en $2 será añadida al archivo $3 de $4 en $5."
 ],
 "The SSH key $0 will be made available for the remainder of the session and will be available for login to other hosts as well.": [
  null,
  "La clave SSH $0 estará disponible durante el resto de la sesión y también lo estará para unirse a otros anfitriones."
 ],
 "The SSH key for logging in to $0 is protected by a password, and the host does not allow logging in with a password. Please provide the password of the key at $1.": [
  null,
  "La clave SSH para iniciar sesión en $0 está protegida por contraseña, y el anfitrión no permite iniciar sesión con contraseña. Por favor, introduzca la contraseña de dicha clave en $1."
 ],
 "The SSH key for logging in to $0 is protected. You can log in with either your login password or by providing the password of the key at $1.": [
  null,
  "La clave SSH para iniciar sesión en $0 está protegida. Puedes iniciar sesión tanto con la contraseña de usuario como introduciendo la contraseña de dicha clave en $1."
 ],
 "The fingerprint should match:": [
  null,
  "La huella debería coincidir con:"
 ],
 "The key password can not be empty": [
  null,
  "La contraseña de la clave no puede estar vacía"
 ],
 "The key passwords do not match": [
  null,
  "Las contraseñas de la clave no coinciden"
 ],
 "The logged in user is not permitted to view system modifications": [
  null,
  "El usuario autenticado no tiene permisos para ver las modificaciones del sistema"
 ],
 "The machine is rebooting": [
  null,
  "La máquina se está reiniciando"
 ],
 "The new key password can not be empty": [
  null,
  "La nueva contraseña de la clave no puede estar vacía"
 ],
 "The password can not be empty": [
  null,
  "La contraseña no puede estar vacía"
 ],
 "The resulting fingerprint is fine to share via public methods, including email.": [
  null,
  "La huella resultante es apta para compartirse en público, incluyendo correo electrónico."
 ],
 "The resulting fingerprint is fine to share via public methods, including email. If you are asking someone else to do the verification for you, they can send the results using any method.": [
  null,
  "La huella resultante puede ser distribuida por medios públicos, incluyendo correo electrónico, sin riesgos. Si está pidiendo a alguien que haga la verificación por usted, pueden enviarle los resultados usando cualquier método."
 ],
 "The server refused to authenticate using any supported methods.": [
  null,
  "El servido rehusó autenticar usando los métodos soportados."
 ],
 "There are currently no active pages": [
  null,
  "No hay actualmente páginas activas"
 ],
 "There was an unexpected error while connecting to the machine.": [
  null,
  "Hubo un error no esperado mientra se conectaba a la máquina."
 ],
 "This machine has already been added.": [
  null,
  "Esta máquina ha sido añadida."
 ],
 "This tool configures the SELinux policy and can help with understanding and resolving policy violations.": [
  null,
  "Esta herramienta configura la política de SELinux y puede ayudarle a comprender y resolver infracciones de la política."
 ],
 "This tool configures the system to write kernel crash dumps. It supports the \"local\" (disk), \"ssh\", and \"nfs\" dump targets.": [
  null,
  "Esta herramienta configura el sistema para que escriba los volcados de colapso del kernel. Admite volcados de destino\"local\" (disco), \"ssh\" y \"nfs\"."
 ],
 "This tool generates an archive of configuration and diagnostic information from the running system. The archive may be stored locally or centrally for recording or tracking purposes or may be sent to technical support representatives, developers or system administrators to assist with technical fault-finding and debugging.": [
  null,
  "Esta herramienta genera un archivo de configuración e información de diagnóstico del sistema en ejecución. El archivo puede ser almacenado localmente o centralmente para propósitos de registro o seguimiento, o puede ser enviado a representantes de soporte técnico, desarrolladores o administradores de sistemas para asistir con la detección de fallos y su corrección."
 ],
 "This tool manages local storage, such as filesystems, LVM2 volume groups, and NFS mounts.": [
  null,
  "Esta herramienta gestiona el almacenamiento local, como sistemas de archivos, grupos de volúmenes LVM2 y montajes NFS."
 ],
 "This tool manages networking such as bonds, bridges, teams, VLANs and firewalls using NetworkManager and Firewalld. NetworkManager is incompatible with Ubuntu's default systemd-networkd and Debian's ifupdown scripts.": [
  null,
  "Esta herramienta gestiona la configuración de red como agrupaciones, puentes, grupos, las VLAN y cortafuegos usando NetworkManager y Firewalld. NetworkManager es incompatible con systemd-networkd habilitado por defecto en Ubuntu y con los scripts de ifupdown de Debian."
 ],
 "This will allow you to log in without password in the future.": [
  null,
  "Esto le permitirá iniciar sesión sin contraseña en el futuro."
 ],
 "Time zone": [
  null,
  "Huso horario"
 ],
 "Tip: Make your key password match your login password to automatically authenticate against other systems.": [
  null,
  "Consejo: Haga coincidir la contraseña de su clave y su contraseña de acceso para autenticarse de forma automática en otros sistemas."
 ],
 "To ensure that your connection is not intercepted by a malicious third-party, please verify the host key fingerprint:": [
  null,
  "Para garantizar que su conexión no sea interceptada por un tercero malicioso, por favor verifique la huella de clave del anfitrión:"
 ],
 "To verify a fingerprint, run the following on $0 while physically sitting at the machine or through a trusted network:": [
  null,
  "Para verificar una huella, ejecute lo siguiente en $0 mientras se sitúa físicamente frente a la máquina o a través de una red de confianza:"
 ],
 "Toggle": [
  null,
  "Alternar"
 ],
 "Toggle date picker": [
  null,
  "Alternar el selector de fecha"
 ],
 "Too much data": [
  null,
  "Demasiados datos"
 ],
 "Tools": [
  null,
  "Herramientas"
 ],
 "Total size: $0": [
  null,
  "Tamaño total: $0"
 ],
 "Tower": [
  null,
  "Torre"
 ],
 "Trust and add host": [
  null,
  "Confiar en el anfitrión y añadirlo"
 ],
 "Trying to synchronize with $0": [
  null,
  "Intentando sincronizar con $0"
 ],
 "Turn on administrative access": [
  null,
  "Habilitar el acceso administrativo"
 ],
 "Type": [
  null,
  "Tipo"
 ],
 "Unable to contact $0.": [
  null,
  "No se pudo contactar con $0."
 ],
 "Unable to contact the given host $0. Make sure it has ssh running on port $1, or specify another port in the address.": [
  null,
  "No es capaz de contactar con el hospedaje $0 dado. Asegúrese que se está ejecutando ssh en el puerto $1, o especifique otro puerto en la dirección."
 ],
 "Unable to log in to $0 using SSH key authentication. Please provide the password.": [
  null,
  "No se pudo iniciar sesión en $0 usando autenticación por clave SSH. Por favor, introduzca la contraseña."
 ],
 "Unable to log in to $0 using SSH key authentication. Please provide the password. You may want to set up your SSH keys for automatic login.": [
  null,
  "No se pudo iniciar sesión en $0 usando autenticación por clave SSH. Por favor, introduzca la contraseña. Quizás quiera configurar claves SSH para permitir inicios de sesión automáticos."
 ],
 "Unable to log in to $0. The host does not accept password login or any of your SSH keys.": [
  null,
  "No fue capaz de iniciar sesión en $0. El hospedaje no acepta inicio de sesión por contraseña ni ninguna de sus claves SSH."
 ],
 "Unexpected error": [
  null,
  "Error inesperado"
 ],
 "Unknown": [
  null,
  "Desconocido"
 ],
 "Unknown host: $0": [
  null,
  "Hospedaje desconocido: $0"
 ],
 "Unlock": [
  null,
  "Desbloquear"
 ],
 "Unlock key $0": [
  null,
  "Desbloquear clave $0"
 ],
 "Untrusted host": [
  null,
  "Anfitrión no seguro"
 ],
 "Update": [
  null,
  "Actualizar"
 ],
 "Use key": [
  null,
  "Usar clave"
 ],
 "Use the following keys to authenticate against other systems": [
  null,
  "Se utilizan las siguientes claves para autenticarse con otros sistemas"
 ],
 "User name": [
  null,
  "Nombre de usuario"
 ],
 "Verify fingerprint": [
  null,
  "Verifique la huella"
 ],
 "View all logs": [
  null,
  "Ver todos los registros"
 ],
 "View automation script": [
  null,
  "Ver el script de automatización"
 ],
 "Visit firewall": [
  null,
  "Ir al cortafuegos"
 ],
 "Waiting for other software management operations to finish": [
  null,
  "Esperando a que finalicen otras operaciones de gestión de software"
 ],
 "Weak password": [
  null,
  "Contraseña débil"
 ],
 "Web Console": [
  null,
  "Consola Web"
 ],
 "Web Console for Linux servers": [
  null,
  "Consola web para servidores Linux"
 ],
 "Web console logo": [
  null,
  "Logotipo de la consola Web"
 ],
 "When empty, connect with the current user": [
  null,
  "Si se deja vacío, se conectará usando el usuario actual"
 ],
 "You are connecting to $0 for the first time.": [
  null,
  "Se está conectando con $0 por primera vez."
 ],
 "You have been logged out due to inactivity.": [
  null,
  "Se le ha cerrado la sesión por inactividad."
 ],
 "You may want to change the password of the key for automatic login.": [
  null,
  "Quizás quieras cambiar la contraseña de la clave para iniciar sesión automáticamente."
 ],
 "You now have administrative access.": [
  null,
  "Ahora tienes acceso administrativo."
 ],
 "You will be logged out in $0 seconds.": [
  null,
  "Se cerrará la sesión en $0 segundos."
 ],
 "You will be reminded once per session.": [
  null,
  "Será recordado una vez por sesión."
 ],
 "Your browser does not allow paste from the context menu. You can use Shift+Insert.": [
  null,
  "Tu navegador no admite pegar desde el menú contextual. Puedes usar Shift+Insert."
 ],
 "Your browser will remember your access level across sessions.": [
  null,
  "Su navegador recordará su nivel de acceso entre sesiones."
 ],
 "Your session has been terminated.": [
  null,
  "Su sesión se ha terminado."
 ],
 "Your session has expired. Please log in again.": [
  null,
  "Su sesión ha expirado. Por favor inicie sesión otra vez."
 ],
 "Zone": [
  null,
  "Zona"
 ],
 "[binary data]": [
  null,
  "[datos binarios]"
 ],
 "[no data]": [
  null,
  "[no hay datos]"
 ],
 "active": [
  null,
  "activo"
 ],
 "in less than a minute": [
  null,
  "es menos de un minuto"
 ],
 "in most browsers": [
  null,
  "en la mayoría de los navegadores"
 ],
 "less than a minute ago": [
  null,
  "es menos que hace un minuto"
 ],
 "password quality": [
  null,
  "calidad de la contraseña"
 ],
 "show less": [
  null,
  "mostrar menos"
 ],
 "show more": [
  null,
  "mostrar más"
 ]
});
