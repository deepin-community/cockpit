cockpit.locale({
 "": {
  "plural-forms": (n) => n != 1,
  "language": "it",
  "language-direction": "ltr"
 },
 "$0 GiB": [
  null,
  "$0 GiB"
 ],
 "$0 day": [
  null,
  "$0 giorno",
  "$0 giorni"
 ],
 "$0 documentation": [
  null,
  "Documentazione $0"
 ],
 "$0 exited with code $1": [
  null,
  "$0 terminato con codice $1"
 ],
 "$0 failed": [
  null,
  "$0 fallito"
 ],
 "$0 hour": [
  null,
  "$0 ora",
  "$0 ore"
 ],
 "$0 is not available from any repository.": [
  null,
  "$0 non è disponibile in nessun archivio web."
 ],
 "$0 key changed": [
  null,
  "Chiave $0 modificata"
 ],
 "$0 killed with signal $1": [
  null,
  "$0 terminato con codice $1"
 ],
 "$0 minute": [
  null,
  "$0 minuto",
  "$0 minuti"
 ],
 "$0 month": [
  null,
  "$0 mese",
  "$0 mesi"
 ],
 "$0 week": [
  null,
  "$0 settimana",
  "$0 settimane"
 ],
 "$0 will be installed.": [
  null,
  "$0 sarà installato."
 ],
 "$0 year": [
  null,
  "$0 anno",
  "$0 anni"
 ],
 "1 day": [
  null,
  "1 giorno"
 ],
 "1 hour": [
  null,
  "1 ora"
 ],
 "1 minute": [
  null,
  "1 minuto"
 ],
 "1 week": [
  null,
  "1 settimana"
 ],
 "20 minutes": [
  null,
  "20 minuti"
 ],
 "40 minutes": [
  null,
  "40 minuti"
 ],
 "5 minutes": [
  null,
  "5 minuti"
 ],
 "6 hours": [
  null,
  "6 ore"
 ],
 "60 minutes": [
  null,
  "60 minuti"
 ],
 "A compatible version of Cockpit is not installed on $0.": [
  null,
  "Una versione compatibile di Cockpit non è installata su $0."
 ],
 "A new SSH key at $0 will be created for $1 on $2 and it will be added to the $3 file of $4 on $5.": [
  null,
  "Una nuova chiave SSH in $0 verrà creata per $1 su $2 e sarà aggiunta al file $3 di $4 su $5."
 ],
 "About Web Console": [
  null,
  "Informazioni su Web Console"
 ],
 "Absent": [
  null,
  "Assente"
 ],
 "Acceptable password": [
  null,
  "Password accettabile"
 ],
 "Active pages": [
  null,
  "Pagine attive"
 ],
 "Add": [
  null,
  "Aggiungi"
 ],
 "Add $0": [
  null,
  "Aggiungi $0"
 ],
 "Add key": [
  null,
  "Aggiungi chiave"
 ],
 "Add new host": [
  null,
  "Aggiungi un nuovo host"
 ],
 "Additional packages:": [
  null,
  "Pacchetti aggiuntivi:"
 ],
 "Administration with Cockpit Web Console": [
  null,
  "Amministrazione con Cockpit Web Console"
 ],
 "Administrative access": [
  null,
  "Accesso amministrativo"
 ],
 "Advanced TCA": [
  null,
  "TCA avanzato"
 ],
 "All-in-one": [
  null,
  "Tutto in una volta"
 ],
 "Ansible": [
  null,
  "Ansible"
 ],
 "Ansible roles documentation": [
  null,
  "Documentazione sui ruoli Ansible"
 ],
 "Apps": [
  null,
  "Applicazioni"
 ],
 "Authenticate": [
  null,
  "Autenticare"
 ],
 "Authentication": [
  null,
  "Autenticazione"
 ],
 "Authentication is required to perform privileged tasks with the Cockpit Web Console": [
  null,
  "E' necessario autenticarsi per eseguire azioni privilegiate con Cockpit Web Console"
 ],
 "Authorize SSH key": [
  null,
  "Autorizza chiave SSH"
 ],
 "Automatic login": [
  null,
  "Accesso automatico"
 ],
 "Automatically using NTP": [
  null,
  "Automaticamente utilizzando NTP"
 ],
 "Automatically using additional NTP servers": [
  null,
  "Automaticamente utilizzando server NTP addizionali"
 ],
 "Automatically using specific NTP servers": [
  null,
  "Automaticamente utilizzando server NTP specifici"
 ],
 "Automation script": [
  null,
  "Script di automazione"
 ],
 "Blade": [
  null,
  "Blade"
 ],
 "Blade enclosure": [
  null,
  "Chassis del blade"
 ],
 "Bus expansion chassis": [
  null,
  "Bus di espansione chassis"
 ],
 "By changing the password of the SSH key $0 to the login password of $1 on $2, the key will be automatically made available and you can log in to $3 without password in the future.": [
  null,
  "Cambiando la password della chiave SSH $0 con la password di accesso di $1 su $2, la chiave sarà automaticamente resa disponibile e potrai in futuro accedere a $3 senza password."
 ],
 "Can be a hostname, IP address, alias name, or ssh:// URI": [
  null,
  "Può essere un hostname, un indirizzo IP, un alias, o un URI ssh://"
 ],
 "Cancel": [
  null,
  "Annulla"
 ],
 "Cannot connect to an unknown host": [
  null,
  "Impossibile connettersi a un host sconosciuto"
 ],
 "Cannot forward login credentials": [
  null,
  "Impossibile inoltrare le credenziali di accesso"
 ],
 "Cannot schedule event in the past": [
  null,
  "Non è possibile programmare eventi del passato"
 ],
 "Change": [
  null,
  "Cambia"
 ],
 "Change password": [
  null,
  "Cambia password"
 ],
 "Change system time": [
  null,
  "Modifica dell'ora di sistema"
 ],
 "Change the password of $0": [
  null,
  "Cambia la password di $0"
 ],
 "Changed keys are often the result of an operating system reinstallation. However, an unexpected change may indicate a third-party attempt to intercept your connection.": [
  null,
  "La modifica delle chiavi sono di solito il risultato di una reinstallazione del sistema. Tuttavia, una modifica inaspettata può indicare un tentativo di intercettazione da parte di un soggetto terzo."
 ],
 "Checking installed software": [
  null,
  "Verifica del software installato"
 ],
 "Choose the language to be used in the application": [
  null,
  "Scegliere la lingua da utilizzare nell'applicazione"
 ],
 "Clear input value": [
  null,
  "Cancella il valore immesso"
 ],
 "Clear search": [
  null,
  "Cancella Ricerca"
 ],
 "Close": [
  null,
  "Chiudi"
 ],
 "Close selected pages": [
  null,
  "Chiudere le pagine selezionate"
 ],
 "Cockpit": [
  null,
  "Cockpit"
 ],
 "Cockpit configuration of NetworkManager and Firewalld": [
  null,
  "Configurazione Cockpit del NetworkManager e del Firewalld"
 ],
 "Cockpit could not contact the given host.": [
  null,
  "Cockpit non ha potuto contattare l'host inserito."
 ],
 "Cockpit had an unexpected internal error.": [
  null,
  "Cockpit ha avuto un errore interno inaspettato"
 ],
 "Cockpit is a server manager that makes it easy to administer your Linux servers via a web browser. Jumping between the terminal and the web tool is no problem. A service started via Cockpit can be stopped via the terminal. Likewise, if an error occurs in the terminal, it can be seen in the Cockpit journal interface.": [
  null,
  "Cockpit è un gestore di server che rende facile amministrare i server Linux tramite un browser web. Cambiare tra il terminale e lo strumento web non è un problema. Un servizio avviato tramite Cockpit può essere interrotto tramite il terminale. Allo stesso modo, se si verifica un errore nel terminale, può essere visto nella sezione del registro di Cockpit."
 ],
 "Cockpit is an interactive Linux server admin interface.": [
  null,
  "Cockpit è un'interfaccia amministrativa interattiva per server Linux."
 ],
 "Cockpit is not compatible with the software on the system.": [
  null,
  "Cockpit non è compatibile con il software del sistema."
 ],
 "Cockpit is not installed": [
  null,
  "Cockpit non è installato"
 ],
 "Cockpit is not installed on the system.": [
  null,
  "Cockpit non è installato sul sistema."
 ],
 "Cockpit is perfect for new sysadmins, allowing them to easily perform simple tasks such as storage administration, inspecting journals and starting and stopping services. You can monitor and administer several servers at the same time. Just add them with a single click and your machines will look after its buddies.": [
  null,
  "Cockpit è perfetto per i nuovi amministratori di sistema, consentendo loro di eseguire facilmente semplici operazioni come la gestione dell'archiviazione, l'ispezione del registro e l'avvio e l'arresto dei servizi. È possibile monitorare e amministrare più server allo stesso tempo. Basta aggiungerli con un solo clic e se ne prenderà subito cura."
 ],
 "Collect and package diagnostic and support data": [
  null,
  "Raccogliere e creare un pacchetto di dati diagnostici e di supporto"
 ],
 "Collect kernel crash dumps": [
  null,
  "Acquisisci i dump dei crash del kernel"
 ],
 "Color": [
  null,
  "Colore"
 ],
 "Comment": [
  null,
  "Commento"
 ],
 "Compact PCI": [
  null,
  "PCI compatto"
 ],
 "Confirm key password": [
  null,
  "Conferma la password chiave"
 ],
 "Confirm new key password": [
  null,
  "Conferma la nuova password chiave"
 ],
 "Confirm password": [
  null,
  "Conferma la password"
 ],
 "Connect": [
  null,
  "Connetti"
 ],
 "Connect to $0?": [
  null,
  "Connettersi a $0?"
 ],
 "Connected hosts can fully control each other. This includes running programs that could harm your system or steal data. Only connect to trusted machines.": [
  null,
  "Gli host connessi possono controllarsi completamente a vicenda. Ciò include l'esecuzione di programmi che potrebbero danneggiare il sistema o rubare dati. Connettiti solo a macchine attendibili."
 ],
 "Connecting to the machine": [
  null,
  "Collegamento alla macchina"
 ],
 "Connection error": [
  null,
  "Errore di connessione"
 ],
 "Connection failed": [
  null,
  "Connessione fallita"
 ],
 "Connection has timed out.": [
  null,
  "Il collegamento è scaduto."
 ],
 "Contains:": [
  null,
  "Contiene:"
 ],
 "Continue session": [
  null,
  "Continua la sessione"
 ],
 "Convertible": [
  null,
  "Convertibile"
 ],
 "Copied": [
  null,
  "Copiato"
 ],
 "Copy": [
  null,
  "Copia"
 ],
 "Copy to clipboard": [
  null,
  "Copia negli appunti"
 ],
 "Could not contact $0": [
  null,
  "Impossibile contattare $0"
 ],
 "Create $0": [
  null,
  "Crea $0"
 ],
 "Create a new SSH key and authorize it": [
  null,
  "Crea una nuova chiave SSH e autorizzala"
 ],
 "Create new task file with this content.": [
  null,
  "Crea un nuovo file di attività con questo contenuto."
 ],
 "Ctrl+Insert": [
  null,
  "Ctrl+Insert"
 ],
 "Ctrl-Shift-I": [
  null,
  "Ctrl-Shift-I"
 ],
 "Dark": [
  null,
  "Scuro"
 ],
 "Default": [
  null,
  "Predefinito"
 ],
 "Delay": [
  null,
  "Ritardo"
 ],
 "Desktop": [
  null,
  "Desktop"
 ],
 "Detachable": [
  null,
  "Rimovibile"
 ],
 "Details": [
  null,
  "Dettagli"
 ],
 "Diagnostic reports": [
  null,
  "Rapporti diagnostici"
 ],
 "Disconnected": [
  null,
  "Disconnesso"
 ],
 "Display language": [
  null,
  "Lingua di visualizzazione"
 ],
 "Docking station": [
  null,
  "Stazione di docking"
 ],
 "Downloading $0": [
  null,
  "Download di $0"
 ],
 "Dual rank": [
  null,
  "Dual rank"
 ],
 "Edit": [
  null,
  "Modifica"
 ],
 "Edit host": [
  null,
  "Modifica host"
 ],
 "Edit hosts": [
  null,
  "Modifica host"
 ],
 "Embedded PC": [
  null,
  "PC integrato"
 ],
 "Excellent password": [
  null,
  "Password eccellente"
 ],
 "Expansion chassis": [
  null,
  "Chassis di espansione"
 ],
 "Failed to add machine: $0": [
  null,
  "Impossibile aggiungere la macchina: $0"
 ],
 "Failed to change password": [
  null,
  "Impossibile cambiare la password"
 ],
 "Failed to edit machine: $0": [
  null,
  "Impossibile modificare la macchina: $0"
 ],
 "Failed to enable $0 in firewalld": [
  null,
  "Impossibile abilitare firewalld"
 ],
 "Filter menu items": [
  null,
  "Filtra oggetti menu"
 ],
 "Fingerprint": [
  null,
  "Impronta digitale"
 ],
 "Go to now": [
  null,
  "Vai ora"
 ],
 "Handheld": [
  null,
  "Palmare"
 ],
 "Help": [
  null,
  "Aiuto"
 ],
 "Hide confirmation password": [
  null,
  "Nascondi la password di conferma"
 ],
 "Hide password": [
  null,
  "Nascondi la password"
 ],
 "Host": [
  null,
  "Host"
 ],
 "Host key is incorrect": [
  null,
  "La chiave host non è corretta"
 ],
 "Hosts": [
  null,
  "Host"
 ],
 "If the fingerprint matches, click 'Trust and add host'. Otherwise, do not connect and contact your administrator.": [
  null,
  "Se l'impronta digitale corrisponde, fai clic su \"Affida e aggiungi host\". Altrimenti non connetterti e contatta il tuo amministratore."
 ],
 "In order to allow log in to $0 as $1 without password in the future, use the login password of $2 on $3 as the key password, or leave the key password blank.": [
  null,
  "Per consentire l'accesso a $0 come $1 senza password in futuro, utilizza la password di accesso di $2 su $3 come password della chiave, o lascia vuota la password della chiave."
 ],
 "Install": [
  null,
  "Installa"
 ],
 "Install software": [
  null,
  "Installa il software"
 ],
 "Installing $0": [
  null,
  "Installazione di $0"
 ],
 "Internal error": [
  null,
  "Errore interno"
 ],
 "Invalid date format": [
  null,
  "Formato data non valido"
 ],
 "Invalid date format and invalid time format": [
  null,
  "Formato data non valido e formato ora non valido"
 ],
 "Invalid file permissions": [
  null,
  "Autorizzazioni file non valide"
 ],
 "Invalid time format": [
  null,
  "Formato ora non valido"
 ],
 "Invalid timezone": [
  null,
  "Fuso orario non valido"
 ],
 "IoT gateway": [
  null,
  "Gateway IoT"
 ],
 "Is sshd running on a different port?": [
  null,
  "sshd è in esecuzione su una porta diversa?"
 ],
 "Kernel dump": [
  null,
  "Kernel dump"
 ],
 "Key password": [
  null,
  "Password della chiave"
 ],
 "Laptop": [
  null,
  "Portatile"
 ],
 "Learn more": [
  null,
  "Per saperne di più"
 ],
 "Licensed under GNU LGPL version 2.1": [
  null,
  "Concesso in licenza sotto GNU LGPL versione 2.1"
 ],
 "Light": [
  null,
  "Chiaro"
 ],
 "Limit access": [
  null,
  "Limitare l'accesso"
 ],
 "Limited access": [
  null,
  "Accesso limitato"
 ],
 "Limited access mode restricts administrative privileges. Some parts of the web console will have reduced functionality.": [
  null,
  "La modalità di accesso limitato limita i privilegi di amministratore. Alcune parti della Web Console avranno funzionalità ridotte."
 ],
 "Loading packages...": [
  null,
  "Caricamento pacchetti..."
 ],
 "Loading system modifications...": [
  null,
  "Caricamento modifiche del sistema..."
 ],
 "Log in": [
  null,
  "Accedi"
 ],
 "Log in to $0": [
  null,
  "Entra in $0"
 ],
 "Log messages": [
  null,
  "Messaggi di log"
 ],
 "Log out": [
  null,
  "Esci"
 ],
 "Login failed": [
  null,
  "Login fallito"
 ],
 "Low profile desktop": [
  null,
  "Desktop a basso profilo"
 ],
 "Lunch box": [
  null,
  "Lunch box"
 ],
 "Main server chassis": [
  null,
  "Chassis del server principale"
 ],
 "Malicious pages on a remote machine may affect other connected hosts": [
  null,
  "Le pagine dannose su un computer remoto possono influenzare altri host connessi"
 ],
 "Manage storage": [
  null,
  "Gestisci archiviazione"
 ],
 "Manually": [
  null,
  "Manualmente"
 ],
 "Message to logged in users": [
  null,
  "Messaggio agli utenti autenticati"
 ],
 "Messages related to the failure might be found in the journal:": [
  null,
  "I messaggi relativi all'errore potrebbero essere trovati nel registro:"
 ],
 "Method": [
  null,
  "Metodo"
 ],
 "Mini PC": [
  null,
  "Mini PC"
 ],
 "Mini tower": [
  null,
  "Mini tower"
 ],
 "Multi-system chassis": [
  null,
  "Chassis multisistema"
 ],
 "NTP server": [
  null,
  "Server NTP"
 ],
 "Name": [
  null,
  "Nome"
 ],
 "Need at least one NTP server": [
  null,
  "E' necessario almeno un server NTP"
 ],
 "Networking": [
  null,
  "Rete"
 ],
 "New host: $0": [
  null,
  "Nuovo host: $0"
 ],
 "New key password": [
  null,
  "Nuova password della chiave"
 ],
 "New password": [
  null,
  "Nuova password"
 ],
 "New password was not accepted": [
  null,
  "La nuova password non è stata accettata"
 ],
 "No delay": [
  null,
  "Nessun ritardo"
 ],
 "No languages match": [
  null,
  "Nessuna lingua trovata"
 ],
 "No results found": [
  null,
  "nessun risultato trovato"
 ],
 "No such file or directory": [
  null,
  "Nessun file o directory"
 ],
 "No system modifications": [
  null,
  "Nessuna modifica di sistema"
 ],
 "Not a valid private key": [
  null,
  "Chiave privata invalida"
 ],
 "Not connected to host": [
  null,
  "Non connesso all'host"
 ],
 "Not permitted to perform this action.": [
  null,
  "Non è consentito eseguire questa azione."
 ],
 "Not synchronized": [
  null,
  "Non sincronizzato"
 ],
 "Notebook": [
  null,
  "Portatile"
 ],
 "Occurrences": [
  null,
  "Occorrenze"
 ],
 "Ok": [
  null,
  "Ok"
 ],
 "Old password not accepted": [
  null,
  "Vecchia password non accettata"
 ],
 "Once Cockpit is installed, enable it with \"systemctl enable --now cockpit.socket\".": [
  null,
  "Una volta installato Cockpit, abilitarlo con \"systemctl enable --now cockpit.socket\"."
 ],
 "Ooops!": [
  null,
  "Ooops!"
 ],
 "Other": [
  null,
  "Altro"
 ],
 "PackageKit crashed": [
  null,
  "PackageKit si è interrotto"
 ],
 "Page name": [
  null,
  "Nome pagina"
 ],
 "Password": [
  null,
  "Password"
 ],
 "Password changed successfully": [
  null,
  "Password modificata con successo"
 ],
 "Password is not acceptable": [
  null,
  "La password non è accettabile"
 ],
 "Password is too weak": [
  null,
  "La password è troppo debole"
 ],
 "Password not accepted": [
  null,
  "Password non accettata"
 ],
 "Password tip": [
  null,
  "Suggerimento per la password"
 ],
 "Paste": [
  null,
  "Incolla"
 ],
 "Paste error": [
  null,
  "Incolla errore"
 ],
 "Path to file": [
  null,
  "Percorso del file"
 ],
 "Peripheral chassis": [
  null,
  "Chassis periferico"
 ],
 "Pick date": [
  null,
  "Scegli una data"
 ],
 "Pizza box": [
  null,
  "Pizza box"
 ],
 "Please authenticate to gain administrative access": [
  null,
  "Autenticarsi per ottenere l'accesso amministrativo"
 ],
 "Port": [
  null,
  "Porta"
 ],
 "Portable": [
  null,
  "Portatile"
 ],
 "Present": [
  null,
  "Presente"
 ],
 "Problem becoming administrator": [
  null,
  "Problema diventando amministratore"
 ],
 "Project website": [
  null,
  "Sito web del progetto"
 ],
 "Prompting via ssh-add timed out": [
  null,
  "Richiesta tramite ssh-add scaduta"
 ],
 "Prompting via ssh-keygen timed out": [
  null,
  "Richiesta tramite ssh-keygen scaduta"
 ],
 "Public key": [
  null,
  "Chiave pubblica"
 ],
 "RAID chassis": [
  null,
  "Chassis RAID"
 ],
 "Rack mount chassis": [
  null,
  "Chassis a rack"
 ],
 "Read more": [
  null,
  "Per saperne di più"
 ],
 "Reboot": [
  null,
  "Riavvia"
 ],
 "Reconnect": [
  null,
  "Ricollego"
 ],
 "Removals:": [
  null,
  "Rimozioni:"
 ],
 "Remove": [
  null,
  "Elimina"
 ],
 "Removing $0": [
  null,
  "Rimozione $0"
 ],
 "Row expansion": [
  null,
  "Espansione delle righe"
 ],
 "Row select": [
  null,
  "Seleziona riga"
 ],
 "Run this command over a trusted network or physically on the remote machine:": [
  null,
  "Esegui questo comando su una rete affidabile o fisicamente sul computer remoto:"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "SSH key": [
  null,
  "Chiave SSH"
 ],
 "SSH key login": [
  null,
  "Accesso tramite chiave SSH"
 ],
 "SSH keys": [
  null,
  "Chiavi SSH"
 ],
 "Safari users need to import and trust the certificate of the self-signing CA:": [
  null,
  "Gli utenti di Safari devono importare e fidarsi del certificato della CA autofirmata:"
 ],
 "Sealed-case PC": [
  null,
  "PC sigillato"
 ],
 "Search": [
  null,
  "Ricerca"
 ],
 "Security Enhanced Linux configuration and troubleshooting": [
  null,
  "Configurazione e risoluzione dei problemi di Security Enhanced Linux"
 ],
 "Select": [
  null,
  "Seleziona"
 ],
 "Select an option": [
  null,
  "Seleziona un'opzione"
 ],
 "Server has closed the connection.": [
  null,
  "Il server ha chiuso la connessione."
 ],
 "Session": [
  null,
  "Sessione"
 ],
 "Session is about to expire": [
  null,
  "La sessione sta per scadere"
 ],
 "Set": [
  null,
  "Imposta"
 ],
 "Set time": [
  null,
  "Imposta tempo"
 ],
 "Shell script": [
  null,
  "Script di shell"
 ],
 "Shift+Insert": [
  null,
  "Shift+Insert"
 ],
 "Show confirmation password": [
  null,
  "Mostra password di conferma"
 ],
 "Show password": [
  null,
  "Mostra password"
 ],
 "Shut down": [
  null,
  "Arresta"
 ],
 "Single rank": [
  null,
  "Single rank"
 ],
 "Skip main navigation": [
  null,
  "Salta la navigazione principale"
 ],
 "Skip to content": [
  null,
  "Salta al contenuto"
 ],
 "Space-saving computer": [
  null,
  "Computer space-saving"
 ],
 "Specific time": [
  null,
  "Tempo specifico"
 ],
 "Stick PC": [
  null,
  "Stick PC"
 ],
 "Stop editing hosts": [
  null,
  "Interrompi la modifica degli host"
 ],
 "Storage": [
  null,
  "Archiviazione"
 ],
 "Strong password": [
  null,
  "Password complessa"
 ],
 "Style": [
  null,
  "Stile"
 ],
 "Sub-Chassis": [
  null,
  "Sub-Chassis"
 ],
 "Sub-Notebook": [
  null,
  "Sub-Notebook"
 ],
 "Switch to administrative access": [
  null,
  "Passa all'accesso amministrativo"
 ],
 "Switch to limited access": [
  null,
  "Passa ad accesso limitato"
 ],
 "Synchronized": [
  null,
  "Sincronizzato"
 ],
 "Synchronized with $0": [
  null,
  "Sincronizzato con $0"
 ],
 "Synchronizing": [
  null,
  "Sincronizzazione"
 ],
 "System": [
  null,
  "Sistema"
 ],
 "Tablet": [
  null,
  "Tablet"
 ],
 "The IP address or hostname cannot contain whitespace.": [
  null,
  "L'indirizzo IP o il nome host non possono contenere spazi."
 ],
 "The key password can not be empty": [
  null,
  "La password della chiave non può essere vuota"
 ],
 "The key passwords do not match": [
  null,
  "Le password della chiave non corrispondono"
 ],
 "The logged in user is not permitted to view system modifications": [
  null,
  "L'utente che ha effettuato l'accesso non è autorizzato a visualizzare le modifiche di sistema"
 ],
 "The new key password can not be empty": [
  null,
  "La nuova password della chiave non può essere vuota"
 ],
 "The resulting fingerprint is fine to share via public methods, including email.": [
  null,
  "L'impronta digitale risultante è idonea per la condivisione pubblica, email inclusa."
 ],
 "The resulting fingerprint is fine to share via public methods, including email. If you are asking someone else to do the verification for you, they can send the results using any method.": [
  null,
  ""
 ],
 "The server refused to authenticate using any supported methods.": [
  null,
  "Il server ha rifiutato di autenticarsi utilizzando qualsiasi metodo supportato."
 ],
 "There are currently no active pages": [
  null,
  "Attualmente non ci sono pagine attive"
 ],
 "There was an unexpected error while connecting to the machine.": [
  null,
  "Si è verificato un errore imprevisto durante la connessione alla macchina."
 ],
 "This machine has already been added.": [
  null,
  "Questa macchina è già stata aggiunta."
 ],
 "This tool configures the SELinux policy and can help with understanding and resolving policy violations.": [
  null,
  "Questo strumento configura i criteri SELinux e può aiutare a comprendere e risolvere le violazioni dei criteri."
 ],
 "This tool generates an archive of configuration and diagnostic information from the running system. The archive may be stored locally or centrally for recording or tracking purposes or may be sent to technical support representatives, developers or system administrators to assist with technical fault-finding and debugging.": [
  null,
  "Questo strumento genera un archivio di informazioni sulla configurazione e sulla diagnostica del sistema in esecuzione. L'archivio può essere conservato localmente o centralmente per scopi di registrazione o tracciamento oppure può essere inviato ai rappresentanti dell'assistenza tecnica, agli sviluppatori o agli amministratori di sistema per aiutarli nella ricerca di errori e nel debug."
 ],
 "This tool manages local storage, such as filesystems, LVM2 volume groups, and NFS mounts.": [
  null,
  "Questo strumento gestisce lo storage locale, come i filesystem, i gruppi di volumi LVM2 e i mount NFS."
 ],
 "This tool manages networking such as bonds, bridges, teams, VLANs and firewalls using NetworkManager and Firewalld. NetworkManager is incompatible with Ubuntu's default systemd-networkd and Debian's ifupdown scripts.": [
  null,
  "Questo strumento gestisce le reti, come i bond, i bridge, i team, le VLAN e i firewall utilizzando NetworkManager e Firewalld. NetworkManager è incompatibile con gli script systemd-networkd di Ubuntu e ifupdown di Debian."
 ],
 "This will allow you to log in without password in the future.": [
  null,
  "Ciò ti consentirà di accedere senza password in futuro."
 ],
 "Time zone": [
  null,
  "Fuso Orario"
 ],
 "Tip: Make your key password match your login password to automatically authenticate against other systems.": [
  null,
  "Suggerimento: fai in modo che la password della tua chiave corrisponda alla password di accesso per l'autenticazione automatica in altri sistemi."
 ],
 "To ensure that your connection is not intercepted by a malicious third-party, please verify the host key fingerprint:": [
  null,
  "Per assicurare che la connessione non sia intercettata da un soggetto terzo malelvolo, verifica l'impronta digitale dell'host:"
 ],
 "To verify a fingerprint, run the following on $0 while physically sitting at the machine or through a trusted network:": [
  null,
  "Per verificare un'impronta digitale, esegui su $0 mentre sei fisicamente di fronte alla macchina o attraverso una rete fidata:"
 ],
 "Toggle": [
  null,
  "Attiva/disattiva"
 ],
 "Toggle date picker": [
  null,
  "Attiva/disattiva la selezione della data"
 ],
 "Too much data": [
  null,
  "Troppi dati"
 ],
 "Tools": [
  null,
  "Strumenti"
 ],
 "Total size: $0": [
  null,
  "Dimensione totale: $0"
 ],
 "Tower": [
  null,
  "Tower"
 ],
 "Trying to synchronize with $0": [
  null,
  "Tentativo di sincronizzazione con $0"
 ],
 "Turn on administrative access": [
  null,
  "Attiva l'accesso amministrativo"
 ],
 "Type": [
  null,
  "Tipo"
 ],
 "Unable to contact the given host $0. Make sure it has ssh running on port $1, or specify another port in the address.": [
  null,
  "Impossibile contattare l'host specificato $0. Assicurati che ssh sia in esecuzione sulla porta $1 o specifica un'altra porta nell'indirizzo."
 ],
 "Unexpected error": [
  null,
  "Errore imprevisto"
 ],
 "Unknown": [
  null,
  "Sconosciuto"
 ],
 "Unlock": [
  null,
  "Sblocca"
 ],
 "Untrusted host": [
  null,
  "Host non fidato"
 ],
 "Update": [
  null,
  "Aggiorna"
 ],
 "Use the following keys to authenticate against other systems": [
  null,
  "Utilizza le seguenti chiavi per autenticarti in altri sistemi"
 ],
 "User name": [
  null,
  "Nome utente"
 ],
 "View automation script": [
  null,
  "Visualizza script di automazione"
 ],
 "Waiting for other software management operations to finish": [
  null,
  "In attesa che finiscano le altre operazioni di gestione del software"
 ],
 "Web Console": [
  null,
  "Web Console"
 ],
 "Web Console for Linux servers": [
  null,
  "Web Console per server Linux"
 ],
 "When empty, connect with the current user": [
  null,
  "Se vuoti, connetti con l'utente corrente"
 ],
 "You are connecting to $0 for the first time.": [
  null,
  "Collegamento a $0 per la prima volta"
 ],
 "You have been logged out due to inactivity.": [
  null,
  "Sei stato disconnesso per inattività."
 ],
 "You may want to change the password of the key for automatic login.": [
  null,
  "Potrebbe essere necessario modificare la password della chiave per l'accesso automatico."
 ],
 "You now have administrative access.": [
  null,
  "Ora hai accesso amministrativo."
 ],
 "You will be logged out in $0 seconds.": [
  null,
  "Verrai disconnesso tra $0 secondi."
 ],
 "Your browser does not allow paste from the context menu. You can use Shift+Insert.": [
  null,
  "Il tuo browser non consente l'incolla dal menu contestuale. Puoi usare Maiusc+Ins."
 ],
 "Your browser will remember your access level across sessions.": [
  null,
  "Il tuo browser ricorderà il tuo livello di accesso tra le sessioni."
 ],
 "Your session has been terminated.": [
  null,
  "La tua sessione e' terminata."
 ],
 "Your session has expired. Please log in again.": [
  null,
  "La sessione è scaduta. Effettua di nuovo il login."
 ],
 "[binary data]": [
  null,
  "[dati binari]"
 ],
 "[no data]": [
  null,
  "[nessun dato]"
 ],
 "active": [
  null,
  "attivo"
 ],
 "in less than a minute": [
  null,
  ""
 ],
 "in most browsers": [
  null,
  "nella maggior parte dei browser"
 ],
 "less than a minute ago": [
  null,
  ""
 ],
 "show less": [
  null,
  "mostra meno"
 ],
 "show more": [
  null,
  "mostra di più"
 ]
});
