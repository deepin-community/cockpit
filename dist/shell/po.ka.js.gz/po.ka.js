cockpit.locale({
 "": {
  "plural-forms": (n) => n != 1,
  "language": "ka",
  "language-direction": "ltr"
 },
 "$0 GiB": [
  null,
  "$0 გიბ"
 ],
 "$0 day": [
  null,
  "$0 დღე",
  "დღეები: $0"
 ],
 "$0 documentation": [
  null,
  "$0 დოკუმენტაცია"
 ],
 "$0 exited with code $1": [
  null,
  "$0-ის გამოსვლის კოდია $1"
 ],
 "$0 failed": [
  null,
  "$0 წარუმატებელია"
 ],
 "$0 hour": [
  null,
  "$0 საათი",
  "საათი: $0"
 ],
 "$0 is not available from any repository.": [
  null,
  "$0 ხელმიუწვდომელია ყველა რეპოზიტორიიდან."
 ],
 "$0 key changed": [
  null,
  "$0 გასაღები შეიცვალა"
 ],
 "$0 killed with signal $1": [
  null,
  "$0 მოკვდა სიგნალით $1"
 ],
 "$0 minute": [
  null,
  "$0 წუთი",
  "წუთი: $0"
 ],
 "$0 month": [
  null,
  "$0 თვე",
  "თვე: $0"
 ],
 "$0 week": [
  null,
  "$0 კვირა",
  "კვირა: $0"
 ],
 "$0 will be installed.": [
  null,
  "დაყენდება $0."
 ],
 "$0 year": [
  null,
  "$0 წელი",
  "წელი: $0"
 ],
 "1 day": [
  null,
  "1 დღე"
 ],
 "1 hour": [
  null,
  "1 საათი"
 ],
 "1 minute": [
  null,
  "1 წთ"
 ],
 "1 week": [
  null,
  "1 კვირა"
 ],
 "20 minutes": [
  null,
  "20 წთ"
 ],
 "40 minutes": [
  null,
  "40 წთ"
 ],
 "5 minutes": [
  null,
  "5 წთ"
 ],
 "6 hours": [
  null,
  "5 სთ"
 ],
 "60 minutes": [
  null,
  "60 წთ"
 ],
 "A compatible version of Cockpit is not installed on $0.": [
  null,
  "$0-ზე არ აყენია Cockpit-ის თავსებადი ვერსია."
 ],
 "A new SSH key at $0 will be created for $1 on $2 and it will be added to the $3 file of $4 on $5.": [
  null,
  "ახალი SSH გასაღები $0-თვის შეიქნება $1-თვის $2-ზე და დაემატება $3 ფაილს $4-ის ფაილს $5-ზე."
 ],
 "About Web Console": [
  null,
  "ვებ კონსოლის შესახებ"
 ],
 "Absent": [
  null,
  "აკლია"
 ],
 "Acceptable password": [
  null,
  "მისაღები პაროლი"
 ],
 "Active pages": [
  null,
  "აქტიური გვერდები"
 ],
 "Add": [
  null,
  "დამატება"
 ],
 "Add $0": [
  null,
  "$0-ის დამატება"
 ],
 "Add key": [
  null,
  "გასაღების დამატება"
 ],
 "Add new host": [
  null,
  "ახალი ჰოსტის დამატება"
 ],
 "Additional packages:": [
  null,
  "დამატებითი პაკეტები:"
 ],
 "Administration with Cockpit Web Console": [
  null,
  "Cockput ვებ კონსოლით ადმინისტრირება"
 ],
 "Administrative access": [
  null,
  "ადმინისტრატიული წვდომა"
 ],
 "Advanced TCA": [
  null,
  "დამატებითი TCA"
 ],
 "All-in-one": [
  null,
  "ყველა-ერთში"
 ],
 "Ansible": [
  null,
  "Ansible"
 ],
 "Ansible roles documentation": [
  null,
  "Ansible-ის როლების დოკუმენტაცია"
 ],
 "Apps": [
  null,
  "აპები"
 ],
 "Authenticate": [
  null,
  "ავთენტიკაცია"
 ],
 "Authentication": [
  null,
  "ავთენტიკაცია"
 ],
 "Authentication is required to perform privileged tasks with the Cockpit Web Console": [
  null,
  "Cockpit ვებ კონსოლში პრივილეგირებული ამოცანების შესასრულებლად საჭიროა ავთენტიკაცია"
 ],
 "Authorize SSH key": [
  null,
  "SSH გასაღების ავტორიზაცია"
 ],
 "Automatic login": [
  null,
  "ავტომატური შესვლა"
 ],
 "Automatically using NTP": [
  null,
  "ავტომატურად, NTP-ით"
 ],
 "Automatically using additional NTP servers": [
  null,
  "დამატებითი NTP სერვერების ავტომატური გამოყენება"
 ],
 "Automatically using specific NTP servers": [
  null,
  "მითითებული NTP სერვერების ავტომატური გამოყენება"
 ],
 "Automation script": [
  null,
  "ავტომატიზაციის სკრიპტი"
 ],
 "Blade": [
  null,
  "Blade"
 ],
 "Blade enclosure": [
  null,
  "კალათი"
 ],
 "Bus expansion chassis": [
  null,
  "მატარებლის გაფართოების შასი"
 ],
 "By changing the password of the SSH key $0 to the login password of $1 on $2, the key will be automatically made available and you can log in to $3 without password in the future.": [
  null,
  "$1-ის $2-ზე შესასვლელი SSH გასაღების, $0-ზე პაროლის შეცვლით თქვენი გასაღები ავტომატურად გახდება ხელმისაწვდომი. ოპერაციის შემდეგ $3-ზე შესვლას პაროლის გარეშე შეძლებთ."
 ],
 "Can be a hostname, IP address, alias name, or ssh:// URI": [
  null,
  "შეიძლება იყოს ჰოსტის სახელი, IP მისამართი, DNS სახელი ან ssh://URI"
 ],
 "Cancel": [
  null,
  "გაუქმება"
 ],
 "Cannot connect to an unknown host": [
  null,
  "უცნობ ჰოსტთან მიერთების პრობლემა"
 ],
 "Cannot forward login credentials": [
  null,
  "მომხმარებლისადაპაროლის გადაგზავნის შეცდომა"
 ],
 "Cannot schedule event in the past": [
  null,
  "მოვლენის წარსულ დროში დანიშვნა შეუძლებელია"
 ],
 "Change": [
  null,
  "შეცვლა"
 ],
 "Change password": [
  null,
  "პაროლის შეცვლა"
 ],
 "Change system time": [
  null,
  "სისტემური დროის შეცვლა"
 ],
 "Change the password of $0": [
  null,
  "$0-ის პაროლის შეცვლა"
 ],
 "Changed keys are often the result of an operating system reinstallation. However, an unexpected change may indicate a third-party attempt to intercept your connection.": [
  null,
  "შეცვლილი გასაღებები ხშირად ოპერაციული სისტემის გადაყენებაზე მიუთითებს. ამავე დროს მოულოდნელი ცვლილება კავშირის გადასაჭერად მესამე პირის ჩარევასაც შეიძლება ნიშნავდეს."
 ],
 "Checking installed software": [
  null,
  "დაყენებული პროგრამული უზრუნველყოფის შემოწმება"
 ],
 "Choose the language to be used in the application": [
  null,
  "აირჩიეთ აპლიკაციის ენა"
 ],
 "Clear input value": [
  null,
  "შეყვანილი მნიშვნელობის გასუფთავება"
 ],
 "Clear search": [
  null,
  "ძებნის გასუფთავება"
 ],
 "Close": [
  null,
  "დახურვა"
 ],
 "Close selected pages": [
  null,
  "მონიშნული გვერდების დახურვა"
 ],
 "Cockpit": [
  null,
  "Cockpit"
 ],
 "Cockpit configuration of NetworkManager and Firewalld": [
  null,
  "NetworkManager-ის და Firewalld-ის მორგება Cockpit-ით"
 ],
 "Cockpit could not contact the given host.": [
  null,
  "Cockpit-ს მითითებულ ჰოსტთან დაკავშირება არ შეუძლია ."
 ],
 "Cockpit had an unexpected internal error.": [
  null,
  "Cockpit-ის შიდა შეცდომა."
 ],
 "Cockpit is a server manager that makes it easy to administer your Linux servers via a web browser. Jumping between the terminal and the web tool is no problem. A service started via Cockpit can be stopped via the terminal. Likewise, if an error occurs in the terminal, it can be seen in the Cockpit journal interface.": [
  null,
  "Cockpit წარმოადგენს სერვერის მმართველს, რომლითაც Linux სერვერების ადმინისტრირება ბრაუზერითაც შეგიძლიათ. ტერმინალსა და ვებ ხელსაწყოს შორის გადართვა პრობლემა არაა. Cockpit-ით გაშვებული სერვისი შეგიძლიათ გააჩეროთ ტერმინალთაც. ასევე, თუ შეცდომა დაფიქსირდება ტერმინალში, მისი ნახვა Cockpit-ის საშუალებითაც შეგიძლიათ."
 ],
 "Cockpit is an interactive Linux server admin interface.": [
  null,
  "Cockpit-ი წარმოადგენს ლინუქსის სერვერების ადმინისტრირების ინტერაქტიულ ინტერფეისს."
 ],
 "Cockpit is not compatible with the software on the system.": [
  null,
  "Cockpit-ი შეუთავსებელია თქვენს სერვერზე დაყენებულ პროგრამულ უზრუნველყოფასთან."
 ],
 "Cockpit is not installed": [
  null,
  "Cockpit-ი დაყენებული არაა"
 ],
 "Cockpit is not installed on the system.": [
  null,
  "Cockpit-ი ამ სისტემაზე დაყენებული არაა."
 ],
 "Cockpit is perfect for new sysadmins, allowing them to easily perform simple tasks such as storage administration, inspecting journals and starting and stopping services. You can monitor and administer several servers at the same time. Just add them with a single click and your machines will look after its buddies.": [
  null,
  "Cockpit შესანიშნავია ახალი სისტემური ადმინისტრატორებისთვის. ის მათ საშუალებას აძლევს ადვილად შეასრულონ ისეთი მარტივი ამოცანები, როგორიცაა შენახვის ადმინისტრირება, ჟურნალების შემოწმება და სერვისების დაწყება და გაჩერება. შეგიძლიათ ერთდროულად რამდენიმე სერვერის მონიტორინგი და ადმინისტრირება. უბრალოდ დაამატეთ ისინი ერთი დაწკაპუნებით და თქვენი მანქანები იზრუნებს მის მეგობრებზე."
 ],
 "Collect and package diagnostic and support data": [
  null,
  "მოაგროვეთ დიაგნოსტიკური და მხარდაჭერის მონაცემები"
 ],
 "Collect kernel crash dumps": [
  null,
  "ოპერაციული სისტემის ბირთვის ავარიის დამპები"
 ],
 "Color": [
  null,
  "ფერი"
 ],
 "Comment": [
  null,
  "კომენტარი"
 ],
 "Compact PCI": [
  null,
  "კომპაქტური PCI"
 ],
 "Confirm key password": [
  null,
  "მეორედ შეიყვანეთ გასაღების პაროლი"
 ],
 "Confirm new key password": [
  null,
  "დაადასტურეთ გასაღების ახალი პაროლი"
 ],
 "Confirm password": [
  null,
  "დაადასტურეთ პაროლი"
 ],
 "Connect": [
  null,
  "დაკავშირება"
 ],
 "Connect to $0?": [
  null,
  "დავუკავშირდე $0-ს?"
 ],
 "Connected hosts can fully control each other. This includes running programs that could harm your system or steal data. Only connect to trusted machines.": [
  null,
  "დაკავშირებულ ჰოსტებს ერთმანეთის კონტროლი შეუძლიათ. ეს შეიცავს გაშვებულ პროგრამებსაც, რომლებსაც ზიანის მოტანა, ან მონაცემების მოპარვა შეუძლიათ. დაუკავშირდით, მხოლოდ, სანდო მანქანებს."
 ],
 "Connecting to the machine": [
  null,
  "მანქანასთან დაკავშირება"
 ],
 "Connection error": [
  null,
  "დაკავშირების შეცდომა"
 ],
 "Connection failed": [
  null,
  "დაკავშირების შეცდომა"
 ],
 "Connection has timed out.": [
  null,
  "კავშირის დრო გავიდა."
 ],
 "Contains:": [
  null,
  "შეიცავს:"
 ],
 "Continue session": [
  null,
  "სესიის გაგრძელება"
 ],
 "Convertible": [
  null,
  "გარდაქმნადი"
 ],
 "Copied": [
  null,
  "დაკოპირებულია"
 ],
 "Copy": [
  null,
  "კოპირება"
 ],
 "Copy to clipboard": [
  null,
  "ბაფერში კოპირება"
 ],
 "Could not contact $0": [
  null,
  "$0-ს ვერ დავუკავშირდი"
 ],
 "Create $0": [
  null,
  "$0-ის შექმნა"
 ],
 "Create a new SSH key and authorize it": [
  null,
  "შექმენით SSH-ის ახალი გასაღები და გაატარეთ ავტორიზაცია"
 ],
 "Create new task file with this content.": [
  null,
  "ახალი ამოცანის ამ შემცველობით შექმნა."
 ],
 "Ctrl+Insert": [
  null,
  "Ctrl+Insert"
 ],
 "Ctrl-Shift-I": [
  null,
  "Ctrl-Shift-I"
 ],
 "Dark": [
  null,
  "ბლენი"
 ],
 "Default": [
  null,
  "ნაგულისხმები"
 ],
 "Delay": [
  null,
  "დაყოვნება"
 ],
 "Desktop": [
  null,
  "სამუშაო მაგიდა"
 ],
 "Detachable": [
  null,
  "მოძრობადი"
 ],
 "Details": [
  null,
  "დეტალები"
 ],
 "Diagnostic reports": [
  null,
  "დიაგნოსტიკის ანგარიშები"
 ],
 "Disconnected": [
  null,
  "გამომძვრალია"
 ],
 "Display language": [
  null,
  "ენა"
 ],
 "Docking station": [
  null,
  "სამაგრი დაფა"
 ],
 "Downloading $0": [
  null,
  "$0-ის გადმოწერა"
 ],
 "Dual rank": [
  null,
  "ორმაგი რანგი"
 ],
 "Edit": [
  null,
  "ჩასწორება"
 ],
 "Edit host": [
  null,
  "ჰოსტის ჩასწორება"
 ],
 "Edit hosts": [
  null,
  "hosts ფაილის ჩასწორება"
 ],
 "Embedded PC": [
  null,
  "ჩაშენებული PC"
 ],
 "Excellent password": [
  null,
  "გადასარევი პაროლი"
 ],
 "Expansion chassis": [
  null,
  "გაფართოების კორპუსი"
 ],
 "Failed to add machine: $0": [
  null,
  "მანქანის დამატების შეცდომა: $0"
 ],
 "Failed to change password": [
  null,
  "პაროლის შეცვლის შეცდომა"
 ],
 "Failed to edit machine: $0": [
  null,
  "მანქანის ჩასწორების შეცდომა: $0"
 ],
 "Failed to enable $0 in firewalld": [
  null,
  "firewalld-ში $0-ის ჩართვის შეცდომა"
 ],
 "Filter menu items": [
  null,
  "მენიუს ელემენტების გაფილტვრა"
 ],
 "Fingerprint": [
  null,
  "ანაბეჭდი"
 ],
 "Go to now": [
  null,
  "ახლავე გადასვლა"
 ],
 "Handheld": [
  null,
  "ჯიბის"
 ],
 "Help": [
  null,
  "დახმარება"
 ],
 "Hide confirmation password": [
  null,
  "დადასტურების პაროლის დამალვა"
 ],
 "Hide password": [
  null,
  "პაროლის დამალვა"
 ],
 "Host": [
  null,
  "ჰოსტი"
 ],
 "Host key is incorrect": [
  null,
  "ჰოსტის გასაღები არასწორია"
 ],
 "Hosts": [
  null,
  "ჰოსტები"
 ],
 "If the fingerprint matches, click 'Trust and add host'. Otherwise, do not connect and contact your administrator.": [
  null,
  "თუ ანაბეჭდი ემთხვევა, დააწექით \"ჰოსტის ნდობა და დამატებას\", ან არ შეხვიდეთ და დაუკავშირდით ადმინისტრატორს."
 ],
 "In order to allow log in to $0 as $1 without password in the future, use the login password of $2 on $3 as the key password, or leave the key password blank.": [
  null,
  "მომავალში $1-ზე $0-ით უპაროლოდ შესვლისთვის გამოიყენეთ $2-ის პაროლი $3-ზე როგორც გასაღების პაროლი ან დატოვეთ გასაღების პაროლი ცარიელი."
 ],
 "Install": [
  null,
  "დაყენება"
 ],
 "Install software": [
  null,
  "პროგრამების დაყენება"
 ],
 "Installing $0": [
  null,
  "$0-ის დაყენება"
 ],
 "Internal error": [
  null,
  "შიდა შეცდომა"
 ],
 "Invalid date format": [
  null,
  "თარიღის არასწორი ფორმატი"
 ],
 "Invalid date format and invalid time format": [
  null,
  "თარიღისა და დროის არასწორი ფორმატი"
 ],
 "Invalid file permissions": [
  null,
  "ფაილის არასწორი წვდომები"
 ],
 "Invalid time format": [
  null,
  "დროის არასწორი ფორმატი"
 ],
 "Invalid timezone": [
  null,
  "დროის არასწორი სარტყელი"
 ],
 "IoT gateway": [
  null,
  "IoT gateway"
 ],
 "Is sshd running on a different port?": [
  null,
  "sshd-ი სხვა პორტზე ხომ არაა გაშვებული?"
 ],
 "Kernel dump": [
  null,
  "ბირთვის დამპი"
 ],
 "Key password": [
  null,
  "გასაღების პაროლი"
 ],
 "Laptop": [
  null,
  "ლეპტოპი"
 ],
 "Learn more": [
  null,
  "გაიგეთ მეტი"
 ],
 "Licensed under GNU LGPL version 2.1": [
  null,
  "ლიცენზირებულია GNU LGPL -ის ვერსია 2.1-ით"
 ],
 "Light": [
  null,
  "ღია"
 ],
 "Limit access": [
  null,
  "წვდომის შეზღუდვა"
 ],
 "Limited access": [
  null,
  "შეზღუდული წვდომა"
 ],
 "Limited access mode restricts administrative privileges. Some parts of the web console will have reduced functionality.": [
  null,
  "შეზღუდული წვდომა გისაზღვრავთ ადმინისტრატიულ პრივილეგიებს. ვებ კონსოლის ზოგიერთი ნაწილი შეზღუდული იქნება."
 ],
 "Loading packages...": [
  null,
  "პაკეტების ჩატვირთვა..."
 ],
 "Loading system modifications...": [
  null,
  "სისტემის ცვლილებების ჩატვირთვა..."
 ],
 "Log in": [
  null,
  "შესვლა"
 ],
 "Log in to $0": [
  null,
  "$0-ში შესვლა"
 ],
 "Log messages": [
  null,
  "ჟურნალის შეტყობინებები"
 ],
 "Log out": [
  null,
  "გასვლა"
 ],
 "Login failed": [
  null,
  "შესვლა წარუმატებელია"
 ],
 "Low profile desktop": [
  null,
  "დაბალი პროფილის სამუშაო მაგიდა"
 ],
 "Lunch box": [
  null,
  "Lunch box"
 ],
 "Main server chassis": [
  null,
  "სერვერის მთავარი შასი"
 ],
 "Malicious pages on a remote machine may affect other connected hosts": [
  null,
  "დაშორებულ მანქანებზე დაჰოსტილ მავნე გვერდებს სხვა მიერთებულ ჰოსტებზეც შეუძლიათ გავლენს მოხდენა"
 ],
 "Manage storage": [
  null,
  "საცავის მართვა"
 ],
 "Manually": [
  null,
  "ხელით მითითებული"
 ],
 "Message to logged in users": [
  null,
  "შესული მომხმარებლებისთვის შეტყობინების გაგზავნა"
 ],
 "Messages related to the failure might be found in the journal:": [
  null,
  "შეტყობინებები ამ შეცდომის შესახებ შეგიძლიათ იპოვოთ ჟურნალში:"
 ],
 "Method": [
  null,
  "მეთოდი"
 ],
 "Mini PC": [
  null,
  "მინი PC"
 ],
 "Mini tower": [
  null,
  "კომპიუტერი პატარა ყუთით"
 ],
 "Multi-system chassis": [
  null,
  "მრავალსისტემიანი ყუთი"
 ],
 "NTP server": [
  null,
  "NTP სერვერი"
 ],
 "Name": [
  null,
  "სახელი"
 ],
 "Need at least one NTP server": [
  null,
  "საჭიროა ერთი NTP სერვერი მაინც"
 ],
 "Networking": [
  null,
  "ქსელი"
 ],
 "New host: $0": [
  null,
  "ახალი ჰოსტი: $0"
 ],
 "New key password": [
  null,
  "გასაღების ახალი პაროლი"
 ],
 "New password": [
  null,
  "ახალი პაროლი"
 ],
 "New password was not accepted": [
  null,
  "ახალი პაროლი მიუღებელია"
 ],
 "No delay": [
  null,
  "დაყოვნების გარეშე"
 ],
 "No languages match": [
  null,
  "შესაბამისი ენის გარეშე"
 ],
 "No results found": [
  null,
  "შედეგები ნაპოვნი არაა"
 ],
 "No such file or directory": [
  null,
  "ფაილი ან საქაღალდე არ არსებობს"
 ],
 "No system modifications": [
  null,
  "სისტემა შეცვლილი არაა"
 ],
 "Not a valid private key": [
  null,
  "არ წარმოადგენს სწორ პირად გასაღებს"
 ],
 "Not connected to host": [
  null,
  "არაა მიერთებული ჰოსტთან"
 ],
 "Not permitted to perform this action.": [
  null,
  "არ გაქვთ მითითებული მოქმედების შესასრულებლად საკმარისი წვდომა."
 ],
 "Not synchronized": [
  null,
  "სინქრონიზებული არაა"
 ],
 "Notebook": [
  null,
  "ნოუთბუქი"
 ],
 "Occurrences": [
  null,
  "გამოვლენები"
 ],
 "Ok": [
  null,
  "დიახ"
 ],
 "Old password not accepted": [
  null,
  "ძველი პაროლი მიუღებელია"
 ],
 "Once Cockpit is installed, enable it with \"systemctl enable --now cockpit.socket\".": [
  null,
  "როცა Cockpit-ს დააყენებთ, შეგიძლიათ მისი ჩართვაც, ბრძანებით \"systemctl enable --now cockpit.socket\"."
 ],
 "Ooops!": [
  null,
  "უკაცრავად!"
 ],
 "Other": [
  null,
  "სხვა"
 ],
 "PackageKit crashed": [
  null,
  "PackageKit-ის ავარია"
 ],
 "Page name": [
  null,
  "გვერდის სახელი"
 ],
 "Password": [
  null,
  "პაროლი"
 ],
 "Password changed successfully": [
  null,
  "პაროლი წარმატებით შეიცვალა"
 ],
 "Password is not acceptable": [
  null,
  "პაროლი მიუღებელია"
 ],
 "Password is too weak": [
  null,
  "პაროლი ძალიან სუსტია"
 ],
 "Password not accepted": [
  null,
  "პაროლი მიუღებელია"
 ],
 "Password tip": [
  null,
  "პაროლის მინიშნება"
 ],
 "Paste": [
  null,
  "ჩასმა"
 ],
 "Paste error": [
  null,
  "ჩასმის შეცდომა"
 ],
 "Path to file": [
  null,
  "ბილიკი ფაილამდე"
 ],
 "Peripheral chassis": [
  null,
  "გარე კორპუსი"
 ],
 "Pick date": [
  null,
  "აირჩიეთ თარიღი"
 ],
 "Pizza box": [
  null,
  "პიცისყუთი"
 ],
 "Please authenticate to gain administrative access": [
  null,
  "ადმინისტრატორი წვდომის მისაღებად გთხოვთ გაიაროთ ავთენტიკაცია"
 ],
 "Port": [
  null,
  "პორტი"
 ],
 "Portable": [
  null,
  "გადატანადი"
 ],
 "Present": [
  null,
  "წარმოდგენილია"
 ],
 "Problem becoming administrator": [
  null,
  "ადმინისტრატორად გახდომის შეცდომა"
 ],
 "Project website": [
  null,
  "პროექტის ვებგვერდი"
 ],
 "Prompting via ssh-add timed out": [
  null,
  "მოთხოვნას ssh-add-ის გავლით დრო გაუვიდა"
 ],
 "Prompting via ssh-keygen timed out": [
  null,
  "მოთხოვნას ssh-keygen-ის გავლით დრო გაუვიდა"
 ],
 "Public key": [
  null,
  "საჯარო გასაღები"
 ],
 "RAID chassis": [
  null,
  "RAID კალათი"
 ],
 "Rack mount chassis": [
  null,
  "რეკში ჩასადგმელი შასი"
 ],
 "Read more": [
  null,
  "იხილეთ მეტი"
 ],
 "Reboot": [
  null,
  "გადატვირთვა"
 ],
 "Reconnect": [
  null,
  "თავიდან დაკავშირება"
 ],
 "Removals:": [
  null,
  "წაიშლება:"
 ],
 "Remove": [
  null,
  "წაშლა"
 ],
 "Removing $0": [
  null,
  "$0-ის წაშლა"
 ],
 "Row expansion": [
  null,
  "მწკრივის გაფართოება"
 ],
 "Row select": [
  null,
  "მწკრივის არჩევა"
 ],
 "Run this command over a trusted network or physically on the remote machine:": [
  null,
  "გაუშვით ეს ბრძანება სანდო ქსელით ან ფიზიკურად, დაშორებულ მანქანაზე:"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "SSH key": [
  null,
  "SSH გასაღები"
 ],
 "SSH key login": [
  null,
  "SSH გასაღებით შესვლა"
 ],
 "SSH keys": [
  null,
  "SSH გასაღებები"
 ],
 "Safari users need to import and trust the certificate of the self-signing CA:": [
  null,
  "Safari-ის მომხმარებლებს სჭირდებათ სერტიფიკატის შემოტანა და სანდო სერტიფიკატების სიაში ჩამატება:"
 ],
 "Sealed-case PC": [
  null,
  "დალუქული PC"
 ],
 "Search": [
  null,
  "ძებნა"
 ],
 "Security Enhanced Linux configuration and troubleshooting": [
  null,
  "Linux-ის გაფართოებული უსაფრთხოების (SELinux) მორგება და გამართვა"
 ],
 "Select": [
  null,
  "არჩევა"
 ],
 "Select an option": [
  null,
  "აირჩიეთ პარამეტრი"
 ],
 "Server has closed the connection.": [
  null,
  "სერვერმა დახურა კავშირი."
 ],
 "Session": [
  null,
  "სესია"
 ],
 "Session is about to expire": [
  null,
  "სესიას ვადა გასდის"
 ],
 "Set": [
  null,
  "დაყენება"
 ],
 "Set time": [
  null,
  "დროის დაყენება"
 ],
 "Shell script": [
  null,
  "გარსის სკრიპტი"
 ],
 "Shift+Insert": [
  null,
  "Shift+Insert"
 ],
 "Show confirmation password": [
  null,
  "დადასტურების პაროლის ჩვენება"
 ],
 "Show password": [
  null,
  "პაროლის ჩვენება"
 ],
 "Shut down": [
  null,
  "გამორთვა"
 ],
 "Single rank": [
  null,
  "ერთრანგიანი"
 ],
 "Skip main navigation": [
  null,
  "მთავარი ნავიგაციის გამოტოვება"
 ],
 "Skip to content": [
  null,
  "შემცველობაზე გადახტომა"
 ],
 "Space-saving computer": [
  null,
  "პატარა ზომის კომპიუტერი"
 ],
 "Specific time": [
  null,
  "მითითებული დრო"
 ],
 "Stick PC": [
  null,
  "Stick PC"
 ],
 "Stop editing hosts": [
  null,
  "hosts ფაილის ჩასწორების დამთავრება"
 ],
 "Storage": [
  null,
  "საცავი"
 ],
 "Strong password": [
  null,
  "ძლიერი პაროლი"
 ],
 "Style": [
  null,
  "სტილი"
 ],
 "Sub-Chassis": [
  null,
  "ქვე-კორპუსი"
 ],
 "Sub-Notebook": [
  null,
  "ქვე-ნოუთბუქი"
 ],
 "Switch to administrative access": [
  null,
  "ადმინისტრატორის წვდომაზე გადართვა"
 ],
 "Switch to limited access": [
  null,
  "შეზღუდულ წვდომებზე გადართვა"
 ],
 "Synchronized": [
  null,
  "სინქრონიზებულია"
 ],
 "Synchronized with $0": [
  null,
  "სინქრონიზებულია $0-თან"
 ],
 "Synchronizing": [
  null,
  "სინქრონიზაცია"
 ],
 "System": [
  null,
  "სისტემა"
 ],
 "Tablet": [
  null,
  "ტაბლეტი"
 ],
 "The IP address or hostname cannot contain whitespace.": [
  null,
  "IP მისამართი და ჰოსტის სახელი არ შეიძლება ცარიელ ადგილებს შეიცავდეს."
 ],
 "The SSH key $0 of $1 on $2 will be added to the $3 file of $4 on $5.": [
  null,
  "SSH გასაღები $1-ის $0 $2-ზე დაემატება ფაილ $3-ს $5-ზე $4-ს."
 ],
 "The SSH key $0 will be made available for the remainder of the session and will be available for login to other hosts as well.": [
  null,
  "SSH გასაღები $0 ხელმისაწვდომია სესიის ბოლომდე და ხელმისაწვდომი იქნება სხვა ჰოსტებზე შესასვლელადაც."
 ],
 "The SSH key for logging in to $0 is protected by a password, and the host does not allow logging in with a password. Please provide the password of the key at $1.": [
  null,
  "$0-ზე შესასვლელი SSH გასაღები პაროლითაა დაცული და ჰოსტს პაროლით შესვლა გამორთული აქვს. შეიყვანეთ $1-ზე არსებული გასაღების პაროლი."
 ],
 "The SSH key for logging in to $0 is protected. You can log in with either your login password or by providing the password of the key at $1.": [
  null,
  "$0-ზე შესასვლელი SSH გასაღები დაცულია. შეგიძლიათ შეხვიდეთ ან თქვენი პაროლით ან გასაღები $1-ის პაროლით."
 ],
 "The fingerprint should match:": [
  null,
  "ანაბეჭდების უნდა ემთხვეოდეს:"
 ],
 "The key password can not be empty": [
  null,
  "გასაღების პაროლი ცარიელი ვერ იქნება"
 ],
 "The key passwords do not match": [
  null,
  "გასაღების პაროლები არ ემთხვევა"
 ],
 "The logged in user is not permitted to view system modifications": [
  null,
  "შესულ მომხმარებელს არ აქვს სისტემური ცვლილებების ნახვს უფლება"
 ],
 "The machine is rebooting": [
  null,
  "მიმდინარეობის მანქანის გადატვირთვა"
 ],
 "The new key password can not be empty": [
  null,
  "გასაღების ახალი საკვანძო სიტყვა ცარიელი ვერ იქნება"
 ],
 "The password can not be empty": [
  null,
  "პაროლი არ შეიძლება ცარიელი იყოს"
 ],
 "The resulting fingerprint is fine to share via public methods, including email.": [
  null,
  "მიღებული ანაბეჭდების გაზიარება პრობლემა არაა."
 ],
 "The resulting fingerprint is fine to share via public methods, including email. If you are asking someone else to do the verification for you, they can send the results using any method.": [
  null,
  "მიღებული ანაბეჭდის გაზიარება, ელფოსტის ჩათვლით, უსაფრთხოა. თუ თქვენ სხვას სთხოვთ, თქვენი სახელით გადაამოწმოს, მათ, შედეგების გამოგზავნა ნებისმიერი მეთოდით შეუძლიათ."
 ],
 "The server refused to authenticate using any supported methods.": [
  null,
  "სერვერმა ყველა მხარდაჭერილი მეთოდით ავთენტიკაცია უარჰყო."
 ],
 "There are currently no active pages": [
  null,
  "აქტიური გვერდების გარეშე"
 ],
 "There was an unexpected error while connecting to the machine.": [
  null,
  "მანქანასთან კავშირის გაუთვალისწინებელი შეცდომა."
 ],
 "This machine has already been added.": [
  null,
  "ეს მანქანა უკვე დამატებულია."
 ],
 "This tool configures the SELinux policy and can help with understanding and resolving policy violations.": [
  null,
  "ეს პროგრამა როგორც SELinux-ის პოლიტიკის მორგებაში, ასევე მის ბოლომდე გაგებაში და პოლიტიკის დარღვევის გადაწყვეტაში დაგეხმარებათ."
 ],
 "This tool configures the system to write kernel crash dumps. It supports the \"local\" (disk), \"ssh\", and \"nfs\" dump targets.": [
  null,
  "ეს პროგრამა სისტემას ბირთვის ავარიის შემთხვევაში დისკზე დამპის ჩაწერის მორგებაში დაგეხმარებათ. დამპის მხარდაჭერილი სამიზნეებია: \"local\" (დისკი), \"ssh\" და \"nfs\"."
 ],
 "This tool generates an archive of configuration and diagnostic information from the running system. The archive may be stored locally or centrally for recording or tracking purposes or may be sent to technical support representatives, developers or system administrators to assist with technical fault-finding and debugging.": [
  null,
  "ეს პროგრამა გაშვებული სისტემიდან კონფიგურაცისა და დიაგნოსტიკის მოგროვებაში დაგეხმარებათ. არქივი შეგიძლიათ ლოკალურად შეინახოთ, ან ცენტრალურად, ჩაწერისა და ტრეკინგის მიზნებისთვის, ან შეგიძლიათ გადააგზავნოთ მხარდაჭერის, პროგრამისტებისა და სისტემური ადმინისტრატორების ჯგუფებთან, რათა აპარატურული პრობლემები აღმოაჩინოთ და გადაჭრათ."
 ],
 "This tool manages local storage, such as filesystems, LVM2 volume groups, and NFS mounts.": [
  null,
  "ეს პროგრამა ლოკალურ საცავს, როგორიცაა ფაილურ სისტემები, LVM2 ტომის ჯგუფები და NFS მიმაგრებები, მართავს."
 ],
 "This tool manages networking such as bonds, bridges, teams, VLANs and firewalls using NetworkManager and Firewalld. NetworkManager is incompatible with Ubuntu's default systemd-networkd and Debian's ifupdown scripts.": [
  null,
  "ეს პროგრამა მართავს ქსელს. bond ინტერფეისების, ხიდების, ჯგუფური ინტერფეისების, VLAN-ების და ბრანდმაუერების მართვა NetworkManager-ისა და FIrewalld-ის საშუალებით. NetworkManager-ი Ubuntu-ის ნაგულისხმებ systemd-networkd და Debian-ის ifupdown სკრიპტებთან შეუთავსებელია."
 ],
 "This will allow you to log in without password in the future.": [
  null,
  "უფლებას მოგცემთ მომავალში პაროლის გარეშე შეხვიდეთ."
 ],
 "Time zone": [
  null,
  "დროის სარტყელი"
 ],
 "Tip: Make your key password match your login password to automatically authenticate against other systems.": [
  null,
  "მინიშნება: სხვა სისტემებში უპაროლოდ შესასვლელად დაამთხვიეთ თქვენი შესვლის პაროლი გასაღების პაროლს."
 ],
 "To ensure that your connection is not intercepted by a malicious third-party, please verify the host key fingerprint:": [
  null,
  "იმაში დასარწმუნებლად, რომ არ ხდება კავშირის გადაჭერა, შეამოწმეთ ჰოსტის ანაბეჭდი:"
 ],
 "To verify a fingerprint, run the following on $0 while physically sitting at the machine or through a trusted network:": [
  null,
  "ანაბეჭდის შესამოწმებლად გაუშვით ეს ბრძანება $0-ზე როცა ფიზიკურად ან სანდო ქსელით იქნებით შესული მანქანაზე:"
 ],
 "Toggle": [
  null,
  "გადართვა"
 ],
 "Toggle date picker": [
  null,
  "თარიღის ამრჩევის გადართვა"
 ],
 "Too much data": [
  null,
  "მეტისმეტად ბევრი მონაცემი"
 ],
 "Tools": [
  null,
  "ხელსაწყოები"
 ],
 "Total size: $0": [
  null,
  "ჯამური ზომა: $0"
 ],
 "Tower": [
  null,
  "კომპიუტერის კორპუსი"
 ],
 "Trust and add host": [
  null,
  "ჰოსტის ნდობა და დამატება"
 ],
 "Trying to synchronize with $0": [
  null,
  "$0-თან სინქრონიზაციის მცდელობა"
 ],
 "Turn on administrative access": [
  null,
  "ადმინისტრატორის წვდომების ჩართვა"
 ],
 "Type": [
  null,
  "ტიპი"
 ],
 "Unable to contact $0.": [
  null,
  "$0-თან კავშირის შეცდომა."
 ],
 "Unable to contact the given host $0. Make sure it has ssh running on port $1, or specify another port in the address.": [
  null,
  "მითითებულ, $0 ჰოსტთან კავშირის პრობლემა. დარწმუნდით, რომ ssh გაშვებულია $1-ე პორტზე ან მიუთითეთ სხვა პორტი."
 ],
 "Unable to log in to $0 using SSH key authentication. Please provide the password.": [
  null,
  "$0-ზე SSH გასაღებით ავთენტიკაციის შესვლის პრობლემა. შეიყვანეთ პაროლი."
 ],
 "Unable to log in to $0 using SSH key authentication. Please provide the password. You may want to set up your SSH keys for automatic login.": [
  null,
  "$0-ზე SSH გასაღებით ავთენტიკაციის შესვლის პრობლემა. შეიყვანეთ პაროლი. ავტომატური შესვლისთვის შეიძლება საჭირო გახდეს თქვენი SSH გასაღებების მორგება."
 ],
 "Unable to log in to $0. The host does not accept password login or any of your SSH keys.": [
  null,
  "$0-ზე შესვლის პრობლემა. ჰოსტი არ იღებს პაროლით შესვლას ან არცერთ თქვენს SSH გასაღებს."
 ],
 "Unexpected error": [
  null,
  "მოულოდნელი შეცდომა"
 ],
 "Unknown": [
  null,
  "უცნობი"
 ],
 "Unknown host: $0": [
  null,
  "უცნობი ჰოსტი: $0"
 ],
 "Unlock": [
  null,
  "განბლოკვა"
 ],
 "Unlock key $0": [
  null,
  "გასაღების განბლოკვა: $0"
 ],
 "Untrusted host": [
  null,
  "არასანდო ჰოსტი"
 ],
 "Update": [
  null,
  "განახლება"
 ],
 "Use key": [
  null,
  "გასაღების გამოყენება"
 ],
 "Use the following keys to authenticate against other systems": [
  null,
  "ამ გასაღებების სხვა სისტემებში შესასვლელად გამოყენება"
 ],
 "User name": [
  null,
  "მომხმარებლის სახელი"
 ],
 "Verify fingerprint": [
  null,
  "ანაბეჭდის გადამოწმება"
 ],
 "View all logs": [
  null,
  "ყველა ჟურნალის ნახვა"
 ],
 "View automation script": [
  null,
  "ავტომატიზაციის სკრიპტის ნახვა"
 ],
 "Visit firewall": [
  null,
  "ბრანდმაუერზე გადასვლა"
 ],
 "Waiting for other software management operations to finish": [
  null,
  "პროგრამების მართვის სხვა ოპერაციების დასრულების მოლოდინი"
 ],
 "Weak password": [
  null,
  "სუსტი პაროლი"
 ],
 "Web Console": [
  null,
  "ვებ კონსოლი"
 ],
 "Web Console for Linux servers": [
  null,
  "ვებ კონსოლი Linux სერვერებისთვის"
 ],
 "Web console logo": [
  null,
  "ვებ კონსოლის ლოგო"
 ],
 "When empty, connect with the current user": [
  null,
  "როცა ცარიელია, მიმდინარე მომხმარებლით შესვლა"
 ],
 "You are connecting to $0 for the first time.": [
  null,
  "$0-ს პირველად უკავშირდებით."
 ],
 "You have been logged out due to inactivity.": [
  null,
  "გამოხვედით უქმედ ყოფნის გამო."
 ],
 "You may want to change the password of the key for automatic login.": [
  null,
  "ავტომატურად შესაცვლელად შეიძლება გასაღების პაროლის შეცვლა მოგიწიოთ."
 ],
 "You now have administrative access.": [
  null,
  "ახლა გაქვთ ადმინისტრატორის წვდომა."
 ],
 "You will be logged out in $0 seconds.": [
  null,
  "გახვალთ $0 წამში."
 ],
 "You will be reminded once per session.": [
  null,
  "შეგახსენებთ ერთხელ თითოეული სესიისთვის."
 ],
 "Your browser does not allow paste from the context menu. You can use Shift+Insert.": [
  null,
  "თქვენს ბრაუზერს არ გააჩნია კონტექსტური მენიუდან ჩასმის მხარდაჭერა. სცადეთ დააჭიროთ Shift+Insert-ს."
 ],
 "Your browser will remember your access level across sessions.": [
  null,
  "თქვენი ბრაუზერი თქვენი წვდომის დონეებს სესიებს შორისაც დაიმახსოვრებს."
 ],
 "Your session has been terminated.": [
  null,
  "თქვენი სესია გაწყვეტილია."
 ],
 "Your session has expired. Please log in again.": [
  null,
  "სესიის ვადა გასულია. თავიდან შედით."
 ],
 "Zone": [
  null,
  "ზონა"
 ],
 "[binary data]": [
  null,
  "[ბინარული მონაცემები]"
 ],
 "[no data]": [
  null,
  "[მონაცემების გარეშე]"
 ],
 "active": [
  null,
  "აქტიური"
 ],
 "in less than a minute": [
  null,
  "წუთზე ნაკლებში"
 ],
 "in most browsers": [
  null,
  "ბრაუზერების უმეტესობაში"
 ],
 "less than a minute ago": [
  null,
  "წუთზე ნაკლების წინ"
 ],
 "password quality": [
  null,
  "პაროლის ხარისხი"
 ],
 "show less": [
  null,
  "ნაკლების ჩვენება"
 ],
 "show more": [
  null,
  "მეტის ჩვენება"
 ]
});
