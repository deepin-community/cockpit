cockpit.locale({
 "": {
  "plural-forms": (n) => n > 1,
  "language": "fr",
  "language-direction": "ltr"
 },
 "$0 GiB": [
  null,
  "$0 GiB"
 ],
 "$0 day": [
  null,
  "$0 jour",
  "$0 jours"
 ],
 "$0 documentation": [
  null,
  "$0 documentation"
 ],
 "$0 exited with code $1": [
  null,
  "$0 quitté avec le code $1"
 ],
 "$0 failed": [
  null,
  "$0 échoué"
 ],
 "$0 hour": [
  null,
  "$0 heure",
  "$0 heures"
 ],
 "$0 is not available from any repository.": [
  null,
  "$0 n’est disponible dans aucun référentiel."
 ],
 "$0 key changed": [
  null,
  "$0 clé modifiée"
 ],
 "$0 killed with signal $1": [
  null,
  "$0 killed avec un signal $1"
 ],
 "$0 minute": [
  null,
  "$0 minute",
  "$0 minutes"
 ],
 "$0 month": [
  null,
  "$0 mois",
  "$0 mois"
 ],
 "$0 week": [
  null,
  "$0 semaine",
  "$0 semaines"
 ],
 "$0 will be installed.": [
  null,
  "$0 sera installé."
 ],
 "$0 year": [
  null,
  "$0 an",
  "$0 ans"
 ],
 "1 day": [
  null,
  "1 jour"
 ],
 "1 hour": [
  null,
  "1 heure"
 ],
 "1 minute": [
  null,
  "1 minute"
 ],
 "1 week": [
  null,
  "1 semaine"
 ],
 "20 minutes": [
  null,
  "20 minutes"
 ],
 "40 minutes": [
  null,
  "40 minutes"
 ],
 "5 minutes": [
  null,
  "5 minutes"
 ],
 "6 hours": [
  null,
  "6 heures"
 ],
 "60 minutes": [
  null,
  "60 minutes"
 ],
 "A compatible version of Cockpit is not installed on $0.": [
  null,
  "Une version compatible de Cockpit n’est pas installée sur $0."
 ],
 "A new SSH key at $0 will be created for $1 on $2 and it will be added to the $3 file of $4 on $5.": [
  null,
  "Une nouvelle clé SSH à $0 sera créée pour $1 sur $2 et elle sera ajoutée au fichier $3 de $4 sur $5."
 ],
 "About Web Console": [
  null,
  "À propos de la console web"
 ],
 "Absent": [
  null,
  "Absent"
 ],
 "Acceptable password": [
  null,
  "Mot de passe acceptable"
 ],
 "Active pages": [
  null,
  "Pages actives"
 ],
 "Add": [
  null,
  "Ajouter"
 ],
 "Add $0": [
  null,
  "Ajouter $0"
 ],
 "Add key": [
  null,
  "Ajouter une clé"
 ],
 "Add new host": [
  null,
  "Ajouter un nouvel hôte"
 ],
 "Additional packages:": [
  null,
  "Paquets supplémentaires :"
 ],
 "Administration with Cockpit Web Console": [
  null,
  "Administration avec la console web de Cockpit"
 ],
 "Administrative access": [
  null,
  "Accès administrateur"
 ],
 "Advanced TCA": [
  null,
  "TCA avancé"
 ],
 "All-in-one": [
  null,
  "Tout en un"
 ],
 "Ansible": [
  null,
  "Ansible"
 ],
 "Ansible roles documentation": [
  null,
  "Documentation des rôles Ansible"
 ],
 "Apps": [
  null,
  "Applis"
 ],
 "Authenticate": [
  null,
  "S’authentifier"
 ],
 "Authentication": [
  null,
  "Authentification"
 ],
 "Authentication is required to perform privileged tasks with the Cockpit Web Console": [
  null,
  "Une authentification est nécessaire pour effectuer les tâches privilégiées dans la console web Cockpit"
 ],
 "Authorize SSH key": [
  null,
  "Autoriser la clé SSH"
 ],
 "Automatic login": [
  null,
  "Connexion automatique"
 ],
 "Automatically using NTP": [
  null,
  "Utiliser automatiquement NTP"
 ],
 "Automatically using additional NTP servers": [
  null,
  "Utilisation automatique de serveurs NTP supplémentaires"
 ],
 "Automatically using specific NTP servers": [
  null,
  "Utiliser automatiquement des serveurs NTP spécifiques"
 ],
 "Automation script": [
  null,
  "Script d’automatisation"
 ],
 "Blade": [
  null,
  "Lame"
 ],
 "Blade enclosure": [
  null,
  "Boîtier en lame"
 ],
 "Bus expansion chassis": [
  null,
  "Châssis d’extension de bus"
 ],
 "By changing the password of the SSH key $0 to the login password of $1 on $2, the key will be automatically made available and you can log in to $3 without password in the future.": [
  null,
  "En remplaçant le mot de passe de la clé SSH $0 par le mot de passe de connexion de $1 sur $2, la clé sera automatiquement rendue disponible et vous pourrez vous connecter à $3 sans mot de passe à l’avenir."
 ],
 "Can be a hostname, IP address, alias name, or ssh:// URI": [
  null,
  "Il peut s’agir d’un nom d’hôte, d'une adresse IP, d’un nom d'alias ou de ssh:// URI"
 ],
 "Cancel": [
  null,
  "Annuler"
 ],
 "Cannot connect to an unknown host": [
  null,
  "Impossible de se connecter à une machine inconnue"
 ],
 "Cannot forward login credentials": [
  null,
  "Impossible de transférer les identifiants de connexion"
 ],
 "Cannot schedule event in the past": [
  null,
  "Impossible de planifier un événement dans le passé"
 ],
 "Change": [
  null,
  "Modifier"
 ],
 "Change password": [
  null,
  "Modifier le mot de passe"
 ],
 "Change system time": [
  null,
  "Modifier l’heure du système"
 ],
 "Change the password of $0": [
  null,
  "Changer le mot de passe de $0"
 ],
 "Changed keys are often the result of an operating system reinstallation. However, an unexpected change may indicate a third-party attempt to intercept your connection.": [
  null,
  "Les changements de clés sont souvent le résultat d’une réinstallation du système d’exploitation. Cependant, un changement inattendu peut indiquer une tentative d’interception de votre connexion par un tiers."
 ],
 "Checking installed software": [
  null,
  "Vérification des logiciels installés"
 ],
 "Choose the language to be used in the application": [
  null,
  "Choisissez la langue à utiliser dans l’application"
 ],
 "Clear input value": [
  null,
  "Effacer la valeur saisie"
 ],
 "Clear search": [
  null,
  "Effacer la recherche"
 ],
 "Close": [
  null,
  "Fermer"
 ],
 "Close selected pages": [
  null,
  "Fermer les pages sélectionnées"
 ],
 "Cockpit": [
  null,
  "Cockpit"
 ],
 "Cockpit configuration of NetworkManager and Firewalld": [
  null,
  "Configuration du cockpit de NetworkManager et Firewalld"
 ],
 "Cockpit could not contact the given host.": [
  null,
  "Cockpit n’a pas pu contacter l’hôte indiqué."
 ],
 "Cockpit had an unexpected internal error.": [
  null,
  "Erreur interne inattendue dans cockpit."
 ],
 "Cockpit is a server manager that makes it easy to administer your Linux servers via a web browser. Jumping between the terminal and the web tool is no problem. A service started via Cockpit can be stopped via the terminal. Likewise, if an error occurs in the terminal, it can be seen in the Cockpit journal interface.": [
  null,
  "Cockpit est un gestionnaire de serveur qui facilite l’administration de vos serveurs Linux via un navigateur Web. Sauter entre le terminal et l’outil web n’est pas un problème. Un service démarré via Cockpit peut être arrêté via le terminal. De même, si une erreur se produit dans le terminal, elle s’affiche dans l’interface du journal Cockpit."
 ],
 "Cockpit is an interactive Linux server admin interface.": [
  null,
  "Cockpit est une interface interactive d’administration de serveur Linux."
 ],
 "Cockpit is not compatible with the software on the system.": [
  null,
  "Cockpit n’est pas compatible avec le logiciel sur le système."
 ],
 "Cockpit is not installed": [
  null,
  "Cockpit n’est pas installé"
 ],
 "Cockpit is not installed on the system.": [
  null,
  "Cockpit n’est pas installé sur le système."
 ],
 "Cockpit is perfect for new sysadmins, allowing them to easily perform simple tasks such as storage administration, inspecting journals and starting and stopping services. You can monitor and administer several servers at the same time. Just add them with a single click and your machines will look after its buddies.": [
  null,
  "Cockpit est parfait pour les nouveaux administrateurs système, leur permettant d’effectuer facilement des tâches simples telles que l’administration du stockage, l’inspection des journaux, le démarrage et l’arrêt des services. Vous pouvez surveiller et administrer plusieurs serveurs en même temps. Il suffit de les ajouter en un seul clic et vos machines s’occuperont de leurs pairs."
 ],
 "Collect and package diagnostic and support data": [
  null,
  "Collecte et regroupement des données de diagnostic et d'assistance"
 ],
 "Collect kernel crash dumps": [
  null,
  "Collecter les vidages de mémoire sur incidents du noyau"
 ],
 "Color": [
  null,
  "Couleur"
 ],
 "Comment": [
  null,
  "Commentaire"
 ],
 "Compact PCI": [
  null,
  "PCI compact"
 ],
 "Confirm key password": [
  null,
  "Confirmer le mot de passe de la clé"
 ],
 "Confirm new key password": [
  null,
  "Confirmer le nouveau mot de passe de la clé"
 ],
 "Confirm password": [
  null,
  "Confirmer le mot de passe"
 ],
 "Connect": [
  null,
  "Connecter"
 ],
 "Connect to $0?": [
  null,
  "Connecter à $0 ?"
 ],
 "Connected hosts can fully control each other. This includes running programs that could harm your system or steal data. Only connect to trusted machines.": [
  null,
  "Les hôtes connectés ont un contrôle total les uns sur les autres. Cela comprend l'exécution de programmes pouvant porter atteinte à votre système ou voler des données. Connectez uniquement des machines en lesquelles vous avez confiance."
 ],
 "Connecting to the machine": [
  null,
  "Connexion à la machine"
 ],
 "Connection error": [
  null,
  "Erreur de connexion"
 ],
 "Connection failed": [
  null,
  "Échec de la connexion"
 ],
 "Connection has timed out.": [
  null,
  "La connexion a expiré."
 ],
 "Contains:": [
  null,
  "Contient :"
 ],
 "Continue session": [
  null,
  "Continuer la session"
 ],
 "Convertible": [
  null,
  "Convertible"
 ],
 "Copied": [
  null,
  "Copié"
 ],
 "Copy": [
  null,
  "Copier"
 ],
 "Copy to clipboard": [
  null,
  "Copier dans le presse-papier"
 ],
 "Could not contact $0": [
  null,
  "Impossible à contacter $0"
 ],
 "Create $0": [
  null,
  "Créer $0"
 ],
 "Create a new SSH key and authorize it": [
  null,
  "Créer une nouvelle clé SSH et l’autoriser"
 ],
 "Create new task file with this content.": [
  null,
  "Créez un nouveau fichier de tâches avec ce contenu."
 ],
 "Ctrl+Insert": [
  null,
  "Ctrl+Inser"
 ],
 "Ctrl-Shift-I": [
  null,
  "Ctrl-Shift-I"
 ],
 "Dark": [
  null,
  "Sombre"
 ],
 "Default": [
  null,
  "Par défaut"
 ],
 "Delay": [
  null,
  "Retard"
 ],
 "Desktop": [
  null,
  "Bureau"
 ],
 "Detachable": [
  null,
  "Détachable"
 ],
 "Details": [
  null,
  "Détails"
 ],
 "Diagnostic reports": [
  null,
  "Rapports de diagnostic"
 ],
 "Disconnected": [
  null,
  "Déconnecté"
 ],
 "Display language": [
  null,
  "Langue d’affichage"
 ],
 "Docking station": [
  null,
  "Station d’accueil"
 ],
 "Downloading $0": [
  null,
  "Téléchargement de $0"
 ],
 "Dual rank": [
  null,
  "Double rang"
 ],
 "Edit": [
  null,
  "Modifier"
 ],
 "Edit host": [
  null,
  "Modifier hôte"
 ],
 "Edit hosts": [
  null,
  "Modifier hôtes"
 ],
 "Embedded PC": [
  null,
  "PC intégré"
 ],
 "Excellent password": [
  null,
  "Mot de passe excellent"
 ],
 "Expansion chassis": [
  null,
  "Châssis d’extension"
 ],
 "Failed to add machine: $0": [
  null,
  "Échec de l’ajout de la machine : $0"
 ],
 "Failed to change password": [
  null,
  "Échec de la modification du mot de passe"
 ],
 "Failed to edit machine: $0": [
  null,
  "Échec de la modification de la machine : $0"
 ],
 "Failed to enable $0 in firewalld": [
  null,
  "Échec de l’activation $0 dans firewalld"
 ],
 "Filter menu items": [
  null,
  "Filtrer les éléments de menu"
 ],
 "Fingerprint": [
  null,
  "Empreinte de la clé"
 ],
 "Go to now": [
  null,
  "Aller à maintenant"
 ],
 "Handheld": [
  null,
  "Portable"
 ],
 "Help": [
  null,
  "Aide"
 ],
 "Hide confirmation password": [
  null,
  "Masquer le mot de passe de confirmation"
 ],
 "Hide password": [
  null,
  "Masquer le mot de passe"
 ],
 "Host": [
  null,
  "Hôte"
 ],
 "Host key is incorrect": [
  null,
  "La clé de l’hôte est incorrecte"
 ],
 "Hosts": [
  null,
  "Hôtes"
 ],
 "If the fingerprint matches, click 'Trust and add host'. Otherwise, do not connect and contact your administrator.": [
  null,
  "Si l’empreinte digitale correspond, cliquez sur « Accepter la clé et ajouter l'hôte ». Sinon, ne vous connectez pas et contactez votre administrateur."
 ],
 "In order to allow log in to $0 as $1 without password in the future, use the login password of $2 on $3 as the key password, or leave the key password blank.": [
  null,
  "Afin d’autoriser la connexion à $0 en tant que $1 sans mot de passe à l’avenir, utilisez le mot de passe de connexion de $2 sur $3 comme mot de passe clé, ou laissez le mot de passe clé vide."
 ],
 "Install": [
  null,
  "Installer"
 ],
 "Install software": [
  null,
  "Installer le logiciel"
 ],
 "Installing $0": [
  null,
  "Installation de $0"
 ],
 "Internal error": [
  null,
  "Erreur interne"
 ],
 "Invalid date format": [
  null,
  "Format de date non valide"
 ],
 "Invalid date format and invalid time format": [
  null,
  "Format de date non valide et format d’heure non valide"
 ],
 "Invalid file permissions": [
  null,
  "Les autorisations de fichier ne sont pas valides"
 ],
 "Invalid time format": [
  null,
  "Format d’heure non valide"
 ],
 "Invalid timezone": [
  null,
  "Fuseau horaire incorrect"
 ],
 "IoT gateway": [
  null,
  "Passerelle IoT"
 ],
 "Is sshd running on a different port?": [
  null,
  "« sshd » est-il en cours d’exécution sur un port différent ?"
 ],
 "Kernel dump": [
  null,
  "Kernel Dump"
 ],
 "Key password": [
  null,
  "Mot de passe clé"
 ],
 "Laptop": [
  null,
  "Portable"
 ],
 "Learn more": [
  null,
  "En savoir plus"
 ],
 "Licensed under GNU LGPL version 2.1": [
  null,
  "Sous licence GNU LGPL version 2.1"
 ],
 "Light": [
  null,
  "Clair"
 ],
 "Limit access": [
  null,
  "Limiter l’accès"
 ],
 "Limited access": [
  null,
  "Accès limité"
 ],
 "Limited access mode restricts administrative privileges. Some parts of the web console will have reduced functionality.": [
  null,
  "Le mode accès limité restreint les privilèges d’administration. Certaines parties de la console web auront des fonctionnalités réduites."
 ],
 "Loading packages...": [
  null,
  "Chargement des paquets..."
 ],
 "Loading system modifications...": [
  null,
  "Chargement des modifications système..."
 ],
 "Log in": [
  null,
  "Connexion"
 ],
 "Log in to $0": [
  null,
  "Connectez-vous à $0"
 ],
 "Log messages": [
  null,
  "Enregistrer les messages"
 ],
 "Log out": [
  null,
  "Déconnexion"
 ],
 "Login failed": [
  null,
  "Échec de la connexion"
 ],
 "Low profile desktop": [
  null,
  "Bureau de profil bas"
 ],
 "Lunch box": [
  null,
  "Lunch Box"
 ],
 "Main server chassis": [
  null,
  "Châssis principal du serveur"
 ],
 "Malicious pages on a remote machine may affect other connected hosts": [
  null,
  "Des pages malveillantes sur une machine à distance peuvent affecter d’autres hôtes connectés"
 ],
 "Manage storage": [
  null,
  "Gérer le stockage"
 ],
 "Manually": [
  null,
  "Manuellement"
 ],
 "Message to logged in users": [
  null,
  "Message aux utilisateurs connectés"
 ],
 "Messages related to the failure might be found in the journal:": [
  null,
  "Les messages relatifs à la défaillance se trouvent dans le journal :"
 ],
 "Method": [
  null,
  "Méthode"
 ],
 "Mini PC": [
  null,
  "Mini PC"
 ],
 "Mini tower": [
  null,
  "Mini Tour"
 ],
 "Multi-system chassis": [
  null,
  "Châssis multi-système"
 ],
 "NTP server": [
  null,
  "Serveur NTP"
 ],
 "Name": [
  null,
  "Nom"
 ],
 "Need at least one NTP server": [
  null,
  "Besoin d’au moins un serveur NTP"
 ],
 "Networking": [
  null,
  "Réseau"
 ],
 "New host: $0": [
  null,
  "Nouvel hôte : $0"
 ],
 "New key password": [
  null,
  "Nouveau mot de passe clé"
 ],
 "New password": [
  null,
  "Nouveau mot de passe"
 ],
 "New password was not accepted": [
  null,
  "Le nouveau mot de passe n’a pas été accepté"
 ],
 "No delay": [
  null,
  "Aucun délai"
 ],
 "No languages match": [
  null,
  "Aucune langue ne correspond"
 ],
 "No results found": [
  null,
  "Aucun résultat trouvé"
 ],
 "No such file or directory": [
  null,
  "Aucun fichier ou répertoire de ce nom"
 ],
 "No system modifications": [
  null,
  "Aucune modification système"
 ],
 "Not a valid private key": [
  null,
  "Clé privée non valide"
 ],
 "Not connected to host": [
  null,
  "Non connecté à l’hôte"
 ],
 "Not permitted to perform this action.": [
  null,
  "Non autorisé à effectuer cette action."
 ],
 "Not synchronized": [
  null,
  "Non synchronisé"
 ],
 "Notebook": [
  null,
  "Ordinateur portable"
 ],
 "Occurrences": [
  null,
  "Occurrences"
 ],
 "Ok": [
  null,
  "Ok"
 ],
 "Old password not accepted": [
  null,
  "Ancien mot de passe non accepté"
 ],
 "Once Cockpit is installed, enable it with \"systemctl enable --now cockpit.socket\".": [
  null,
  "Une fois que Cockpit est installé, l’activer avec « systemctl enable --now cockpit.socket »."
 ],
 "Ooops!": [
  null,
  "Zut !"
 ],
 "Other": [
  null,
  "Autre"
 ],
 "PackageKit crashed": [
  null,
  "Plantage de « PackageKit »"
 ],
 "Page name": [
  null,
  "Nom de la page"
 ],
 "Password": [
  null,
  "Mot de passe"
 ],
 "Password changed successfully": [
  null,
  "Le mot de passe a été modifié avec succès"
 ],
 "Password is not acceptable": [
  null,
  "Le mot de passe n’est pas acceptable"
 ],
 "Password is too weak": [
  null,
  "Le mot de passe est trop faible"
 ],
 "Password not accepted": [
  null,
  "Mot de passe non accepté"
 ],
 "Password tip": [
  null,
  "Conseil sur les mots de passe"
 ],
 "Paste": [
  null,
  "Coller"
 ],
 "Paste error": [
  null,
  "Erreur de collage"
 ],
 "Path to file": [
  null,
  "Chemin d’accès au fichier"
 ],
 "Peripheral chassis": [
  null,
  "Châssis périphérique"
 ],
 "Pick date": [
  null,
  "Choisissez une date"
 ],
 "Pizza box": [
  null,
  "Pizza Box"
 ],
 "Please authenticate to gain administrative access": [
  null,
  "Veuillez vous authentifier pour obtenir un accès administrateur"
 ],
 "Port": [
  null,
  "Port"
 ],
 "Portable": [
  null,
  "Portable"
 ],
 "Present": [
  null,
  "Présent"
 ],
 "Problem becoming administrator": [
  null,
  "Problème pour devenir administrateur"
 ],
 "Project website": [
  null,
  "Site du projet"
 ],
 "Prompting via ssh-add timed out": [
  null,
  "L’invite via ssh-add a expiré"
 ],
 "Prompting via ssh-keygen timed out": [
  null,
  "L’invite via ssh-keygen a expiré"
 ],
 "Public key": [
  null,
  "Clé publique"
 ],
 "RAID chassis": [
  null,
  "Châssis RAID"
 ],
 "Rack mount chassis": [
  null,
  "Châssis de montage en rack"
 ],
 "Read more": [
  null,
  "En savoir plus"
 ],
 "Reboot": [
  null,
  "Redémarrer"
 ],
 "Reconnect": [
  null,
  "Reconnecter"
 ],
 "Removals:": [
  null,
  "Suppressions :"
 ],
 "Remove": [
  null,
  "Retirer"
 ],
 "Removing $0": [
  null,
  "Suppression de $0"
 ],
 "Row expansion": [
  null,
  "Agrandissement de ligne"
 ],
 "Row select": [
  null,
  "Sélection de ligne"
 ],
 "Run this command over a trusted network or physically on the remote machine:": [
  null,
  "Exécutez cette commande sur un réseau de confiance ou en la tapant physiquement sur la machine distante :"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "SSH key": [
  null,
  "Clé SSH"
 ],
 "SSH key login": [
  null,
  "Connexion par clé SSH"
 ],
 "SSH keys": [
  null,
  "Clés SSH"
 ],
 "Safari users need to import and trust the certificate of the self-signing CA:": [
  null,
  "Les utilisateurs de Safari doivent importer et accepter le certificat de l’AC autosignataire :"
 ],
 "Sealed-case PC": [
  null,
  "PC scellé"
 ],
 "Search": [
  null,
  "Recherche"
 ],
 "Security Enhanced Linux configuration and troubleshooting": [
  null,
  "Configuration et dépannage de Linux avec renforcement de la sécurité"
 ],
 "Select": [
  null,
  "Sélectionner"
 ],
 "Select an option": [
  null,
  "Sélectionner une option"
 ],
 "Server has closed the connection.": [
  null,
  "Le serveur a fermé la connexion."
 ],
 "Session": [
  null,
  "Session"
 ],
 "Session is about to expire": [
  null,
  "La session est sur le point d’expirer"
 ],
 "Set": [
  null,
  "Ensemble"
 ],
 "Set time": [
  null,
  "Régler l’heure"
 ],
 "Shell script": [
  null,
  "Script shell"
 ],
 "Shift+Insert": [
  null,
  "Maj+Inser"
 ],
 "Show confirmation password": [
  null,
  "Afficher le mot de passe de confirmation"
 ],
 "Show password": [
  null,
  "Afficher le mot de passe"
 ],
 "Shut down": [
  null,
  "Fermeture"
 ],
 "Single rank": [
  null,
  "Rang unique"
 ],
 "Skip main navigation": [
  null,
  "Sauter la navigation principale"
 ],
 "Skip to content": [
  null,
  "Passer au contenu"
 ],
 "Space-saving computer": [
  null,
  "Ordinateur gain de place"
 ],
 "Specific time": [
  null,
  "Temps spécifique"
 ],
 "Stick PC": [
  null,
  "Stick PC"
 ],
 "Stop editing hosts": [
  null,
  "Arrêter de modifier les hôtes"
 ],
 "Storage": [
  null,
  "Stockage"
 ],
 "Strong password": [
  null,
  "Mot de passe fort"
 ],
 "Style": [
  null,
  "Style"
 ],
 "Sub-Chassis": [
  null,
  "Sous-châssis"
 ],
 "Sub-Notebook": [
  null,
  "Sub-Notebook"
 ],
 "Switch to administrative access": [
  null,
  "Passer à l’accès administrateur"
 ],
 "Switch to limited access": [
  null,
  "Passer en accès limité"
 ],
 "Synchronized": [
  null,
  "Synchronisé"
 ],
 "Synchronized with $0": [
  null,
  "Synchronisé avec $0"
 ],
 "Synchronizing": [
  null,
  "Synchronisation"
 ],
 "System": [
  null,
  "Système"
 ],
 "Tablet": [
  null,
  "Tablette"
 ],
 "The IP address or hostname cannot contain whitespace.": [
  null,
  "L’adresse IP ou le nom d’hôte ne peut pas contenir d’espace."
 ],
 "The SSH key $0 of $1 on $2 will be added to the $3 file of $4 on $5.": [
  null,
  "La clé SSH $0 de $1 sur $2 sera ajoutée au fichier $3 de $4 sur $5."
 ],
 "The SSH key $0 will be made available for the remainder of the session and will be available for login to other hosts as well.": [
  null,
  "La clé SSH $0 sera disponible pour le reste de la session et sera également disponible pour la connexion à d’autres hôtes."
 ],
 "The SSH key for logging in to $0 is protected by a password, and the host does not allow logging in with a password. Please provide the password of the key at $1.": [
  null,
  "La clé SSH permettant de se connecter à $0 est protégée par un mot de passe, et l’hôte ne permet pas de se connecter avec un mot de passe. Veuillez fournir le mot de passe de la clé à $1."
 ],
 "The SSH key for logging in to $0 is protected. You can log in with either your login password or by providing the password of the key at $1.": [
  null,
  "La clé SSH permettant de se connecter à $0 est protégée. Vous pouvez vous connecter avec votre mot de passe de connexion ou en fournissant le mot de passe de la clé à $1."
 ],
 "The fingerprint should match:": [
  null,
  "Les empreintes doivent correspondre :"
 ],
 "The key password can not be empty": [
  null,
  "Le mot de passe de la clé ne peut pas être vide"
 ],
 "The key passwords do not match": [
  null,
  "Les mots de passe sont différents"
 ],
 "The logged in user is not permitted to view system modifications": [
  null,
  "L’utilisateur actuellement connecté n’est pas autorisé à voir les modifications système"
 ],
 "The machine is rebooting": [
  null,
  "La machine est en train de redémarrer"
 ],
 "The new key password can not be empty": [
  null,
  "Le nouveau mot de passe de la clé ne peut pas être vide"
 ],
 "The password can not be empty": [
  null,
  "Le mot de passe ne peut pas être vide"
 ],
 "The resulting fingerprint is fine to share via public methods, including email.": [
  null,
  "L’empreinte digitale qui en résulte peut être partagée via des méthodes publiques, y compris par courrier électronique."
 ],
 "The resulting fingerprint is fine to share via public methods, including email. If you are asking someone else to do the verification for you, they can send the results using any method.": [
  null,
  "L'empreinte qui en découle peut être partagée publiquement par e-mail ou autre sans risque. Si vous demandez à quelqu'un d'autre de faire la vérification pour vous, cette personne peut vous envoyer les résultats par n'importe quel biais."
 ],
 "The server refused to authenticate using any supported methods.": [
  null,
  "Le serveur a refusé d’authentifier en utilisant des méthodes prises en charge."
 ],
 "There are currently no active pages": [
  null,
  "Il n’y a actuellement aucune page active"
 ],
 "There was an unexpected error while connecting to the machine.": [
  null,
  "Il y a eu une erreur inattendue lors de la connexion à la machine."
 ],
 "This machine has already been added.": [
  null,
  "Cette machine a déjà été ajoutée."
 ],
 "This tool configures the SELinux policy and can help with understanding and resolving policy violations.": [
  null,
  "Cet outil configure la politique SELinux et peut aider à comprendre et à résoudre les violations de la politique."
 ],
 "This tool configures the system to write kernel crash dumps. It supports the \"local\" (disk), \"ssh\", and \"nfs\" dump targets.": [
  null,
  "Cet outil configure le système pour qu'il écrive les vidages de mémoire sur incidents du noyau. Il prend en charge les cibles \"local\" (disque), \"ssh\" et \"nfs\"."
 ],
 "This tool generates an archive of configuration and diagnostic information from the running system. The archive may be stored locally or centrally for recording or tracking purposes or may be sent to technical support representatives, developers or system administrators to assist with technical fault-finding and debugging.": [
  null,
  "Cet outil génère une archive des informations de configuration et de diagnostic du système en cours d'exécution. Ces archives peuvent être stockées localement ou centralement à des fins d'enregistrement ou de suivi, ou être envoyées aux représentants du support technique, aux développeurs ou aux administrateurs système pour les aider dans la recherche d'erreurs techniques et le débogage."
 ],
 "This tool manages local storage, such as filesystems, LVM2 volume groups, and NFS mounts.": [
  null,
  "Cet outil gère le stockage local, tel que les systèmes de fichiers, les groupes de volumes LVM2 et les montages NFS."
 ],
 "This tool manages networking such as bonds, bridges, teams, VLANs and firewalls using NetworkManager and Firewalld. NetworkManager is incompatible with Ubuntu's default systemd-networkd and Debian's ifupdown scripts.": [
  null,
  "Cet outil gère les réseaux tels que les liens, les ponts, les équipes, les VLAN et les pare-feu en utilisant NetworkManager et Firewalld. NetworkManager est incompatible avec les scripts par défaut systemd-networkd d'Ubuntu et ifupdown de Debian."
 ],
 "This will allow you to log in without password in the future.": [
  null,
  "Cela vous permettra de vous connecter sans mot de passe à l’avenir."
 ],
 "Time zone": [
  null,
  "Fuseau horaire"
 ],
 "Tip: Make your key password match your login password to automatically authenticate against other systems.": [
  null,
  "Conseil : associez votre mot de passe clé à votre mot de passe de connexion pour vous authentifier automatiquement à d’autres systèmes."
 ],
 "To ensure that your connection is not intercepted by a malicious third-party, please verify the host key fingerprint:": [
  null,
  "Pour vous assurer que votre connexion n’est pas interceptée par un tiers malveillant, veuillez vérifier l’empreinte de la clé de l’hôte :"
 ],
 "To verify a fingerprint, run the following on $0 while physically sitting at the machine or through a trusted network:": [
  null,
  "Pour vérifier une empreinte digitale, exécutez les opérations suivantes sur $0 en étant physiquement assis devant la machine ou en passant par un réseau de confiance :"
 ],
 "Toggle": [
  null,
  "Basculer"
 ],
 "Toggle date picker": [
  null,
  "Basculer le sélecteur de date"
 ],
 "Too much data": [
  null,
  "Trop de données"
 ],
 "Tools": [
  null,
  "Outils"
 ],
 "Total size: $0": [
  null,
  "Taille totale : $0"
 ],
 "Tower": [
  null,
  "Tower"
 ],
 "Trust and add host": [
  null,
  "Faire confiance à l'hôte et l'ajouter"
 ],
 "Trying to synchronize with $0": [
  null,
  "Synchronisation avec $0 en cours d'essai"
 ],
 "Turn on administrative access": [
  null,
  "Activez l’accès administrateur"
 ],
 "Type": [
  null,
  "Type"
 ],
 "Unable to contact $0.": [
  null,
  "Impossible de contacter $0."
 ],
 "Unable to contact the given host $0. Make sure it has ssh running on port $1, or specify another port in the address.": [
  null,
  "Impossible de contacter l’hôte $0. Assurez-vous que SSH fonctionne sur le port $1 ou spécifiez un autre port dans l’adresse."
 ],
 "Unable to log in to $0 using SSH key authentication. Please provide the password.": [
  null,
  "Impossible de se connecter à $0 en utilisant l'authentification par clé SSH. Veuillez fournir le mot de passe."
 ],
 "Unable to log in to $0 using SSH key authentication. Please provide the password. You may want to set up your SSH keys for automatic login.": [
  null,
  "Impossible de se connecter à $0 en utilisant l’authentification par clé SSH. Veuillez fournir le mot de passe. Vous pouvez configurer vos clés SSH pour une connexion automatique."
 ],
 "Unable to log in to $0. The host does not accept password login or any of your SSH keys.": [
  null,
  "Impossible de se connecter à $0. L’hôte n’accepte pas le mot de passe de connexion ou l’une de vos clés SSH."
 ],
 "Unexpected error": [
  null,
  "Erreur inattendue"
 ],
 "Unknown": [
  null,
  "Inconnu"
 ],
 "Unknown host: $0": [
  null,
  "Hôte inconnu : $0"
 ],
 "Unlock": [
  null,
  "Déverrouiller"
 ],
 "Unlock key $0": [
  null,
  "Clé de déverrouillage $0"
 ],
 "Untrusted host": [
  null,
  "Hôte non sécurisé"
 ],
 "Update": [
  null,
  "Mise à jour"
 ],
 "Use key": [
  null,
  "Utiliser la clé"
 ],
 "Use the following keys to authenticate against other systems": [
  null,
  "Utilisez les clés suivantes pour vous authentifier à d’autres systèmes"
 ],
 "User name": [
  null,
  "Nom d’utilisateur"
 ],
 "Verify fingerprint": [
  null,
  "Vérifier l'empreinte digitale"
 ],
 "View all logs": [
  null,
  "Voir tous les journaux"
 ],
 "View automation script": [
  null,
  "Afficher le script d’automation"
 ],
 "Visit firewall": [
  null,
  "Visitez le pare-feu"
 ],
 "Waiting for other software management operations to finish": [
  null,
  "Attente de la fin des autres opérations de gestion du logiciel"
 ],
 "Weak password": [
  null,
  "Mot de passe faible"
 ],
 "Web Console": [
  null,
  "Console Web"
 ],
 "Web Console for Linux servers": [
  null,
  "Console web pour serveurs Linux"
 ],
 "Web console logo": [
  null,
  "Logo de la console web"
 ],
 "When empty, connect with the current user": [
  null,
  "Lorsqu’il est vide, connectez-vous avec l’utilisateur actuel"
 ],
 "You are connecting to $0 for the first time.": [
  null,
  "Vous vous connectez à $0 pour la première fois."
 ],
 "You have been logged out due to inactivity.": [
  null,
  "Vous avez été déconnecté pour cause d’inactivité."
 ],
 "You may want to change the password of the key for automatic login.": [
  null,
  "Vous pouvez modifier le mot de passe de la clé de connexion automatique."
 ],
 "You now have administrative access.": [
  null,
  "Vous avez l’accès administrateur."
 ],
 "You will be logged out in $0 seconds.": [
  null,
  "Vous serez déconnecté dans $0 secondes."
 ],
 "You will be reminded once per session.": [
  null,
  "Vous recevrez ce rappel une fois par session."
 ],
 "Your browser does not allow paste from the context menu. You can use Shift+Insert.": [
  null,
  "Votre navigateur n’autorise pas le collage à partir du menu contextuel. Vous pouvez utiliser Maj+Insérer."
 ],
 "Your browser will remember your access level across sessions.": [
  null,
  "Votre navigateur se souviendra de votre niveau d’accès d’une session à l’autre."
 ],
 "Your session has been terminated.": [
  null,
  "Votre session a été interrompue."
 ],
 "Your session has expired. Please log in again.": [
  null,
  "Votre session a expiré. Veuillez vous reconnecter."
 ],
 "Zone": [
  null,
  "Zone"
 ],
 "[binary data]": [
  null,
  "[données binaires]"
 ],
 "[no data]": [
  null,
  "[pas de données]"
 ],
 "active": [
  null,
  "actif"
 ],
 "in less than a minute": [
  null,
  "dans moins d'une minute"
 ],
 "in most browsers": [
  null,
  "dans la plupart des navigateurs"
 ],
 "less than a minute ago": [
  null,
  "il y a moins d'une minute"
 ],
 "password quality": [
  null,
  "qualité mot de passe"
 ],
 "show less": [
  null,
  "montrer moins"
 ],
 "show more": [
  null,
  "montrer plus"
 ]
});
