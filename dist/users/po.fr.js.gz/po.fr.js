cockpit.locale({
 "": {
  "plural-forms": (n) => n > 1,
  "language": "fr",
  "language-direction": "ltr"
 },
 "# of users": [
  null,
  "Nbre d'utilisateurs"
 ],
 "$0 GiB": [
  null,
  "$0 GiB"
 ],
 "$0 day": [
  null,
  "$0 jour",
  "$0 jours"
 ],
 "$0 exited with code $1": [
  null,
  "$0 quitté avec le code $1"
 ],
 "$0 failed": [
  null,
  "$0 échoué"
 ],
 "$0 hour": [
  null,
  "$0 heure",
  "$0 heures"
 ],
 "$0 is an existing file": [
  null,
  "$0 est un fichier existant"
 ],
 "$0 is not available from any repository.": [
  null,
  "$0 n’est disponible dans aucun référentiel."
 ],
 "$0 key changed": [
  null,
  "$0 clé modifiée"
 ],
 "$0 killed with signal $1": [
  null,
  "$0 killed avec un signal $1"
 ],
 "$0 minute": [
  null,
  "$0 minute",
  "$0 minutes"
 ],
 "$0 month": [
  null,
  "$0 mois",
  "$0 mois"
 ],
 "$0 more...": [
  null,
  "$0 plus..."
 ],
 "$0 week": [
  null,
  "$0 semaine",
  "$0 semaines"
 ],
 "$0 will be installed.": [
  null,
  "$0 sera installé."
 ],
 "$0 year": [
  null,
  "$0 an",
  "$0 ans"
 ],
 "1 day": [
  null,
  "1 jour"
 ],
 "1 hour": [
  null,
  "1 heure"
 ],
 "1 minute": [
  null,
  "1 minute"
 ],
 "1 week": [
  null,
  "1 semaine"
 ],
 "20 minutes": [
  null,
  "20 minutes"
 ],
 "40 minutes": [
  null,
  "40 minutes"
 ],
 "5 minutes": [
  null,
  "5 minutes"
 ],
 "6 hours": [
  null,
  "6 heures"
 ],
 "60 minutes": [
  null,
  "60 minutes"
 ],
 "A compatible version of Cockpit is not installed on $0.": [
  null,
  "Une version compatible de Cockpit n’est pas installée sur $0."
 ],
 "A group with this name already exists": [
  null,
  "Un groupe portant ce nom existe déjà"
 ],
 "A new SSH key at $0 will be created for $1 on $2 and it will be added to the $3 file of $4 on $5.": [
  null,
  "Une nouvelle clé SSH à $0 sera créée pour $1 sur $2 et elle sera ajoutée au fichier $3 de $4 sur $5."
 ],
 "Absent": [
  null,
  "Absent"
 ],
 "Acceptable password": [
  null,
  "Mot de passe acceptable"
 ],
 "Account expiration": [
  null,
  "Expiration du compte"
 ],
 "Account not available or cannot be edited.": [
  null,
  "Le compte n’est pas disponible ou ne peut pas être modifié."
 ],
 "Accounts": [
  null,
  "Comptes"
 ],
 "Actions": [
  null,
  "Actions"
 ],
 "Add": [
  null,
  "Ajouter"
 ],
 "Add $0": [
  null,
  "Ajouter $0"
 ],
 "Add key": [
  null,
  "Ajouter une clé"
 ],
 "Add public key": [
  null,
  "Ajouter une clé publique"
 ],
 "Additional packages:": [
  null,
  "Paquets supplémentaires :"
 ],
 "Administration with Cockpit Web Console": [
  null,
  "Administration avec la console web de Cockpit"
 ],
 "Advanced TCA": [
  null,
  "TCA avancé"
 ],
 "All-in-one": [
  null,
  "Tout en un"
 ],
 "Ansible": [
  null,
  "Ansible"
 ],
 "Ansible roles documentation": [
  null,
  "Documentation des rôles Ansible"
 ],
 "Authentication": [
  null,
  "Authentification"
 ],
 "Authentication is required to perform privileged tasks with the Cockpit Web Console": [
  null,
  "Une authentification est nécessaire pour effectuer les tâches privilégiées dans la console web Cockpit"
 ],
 "Authorize SSH key": [
  null,
  "Autoriser la clé SSH"
 ],
 "Authorized public SSH keys": [
  null,
  "Clés SSH publiques autorisées"
 ],
 "Automatically using NTP": [
  null,
  "Utiliser automatiquement NTP"
 ],
 "Automatically using additional NTP servers": [
  null,
  "Utilisation automatique de serveurs NTP supplémentaires"
 ],
 "Automatically using specific NTP servers": [
  null,
  "Utiliser automatiquement des serveurs NTP spécifiques"
 ],
 "Automation script": [
  null,
  "Script d’automatisation"
 ],
 "Back to accounts": [
  null,
  "Retour aux comptes"
 ],
 "Blade": [
  null,
  "Lame"
 ],
 "Blade enclosure": [
  null,
  "Boîtier en lame"
 ],
 "Bus expansion chassis": [
  null,
  "Châssis d’extension de bus"
 ],
 "Cancel": [
  null,
  "Annuler"
 ],
 "Cannot forward login credentials": [
  null,
  "Impossible de transférer les identifiants de connexion"
 ],
 "Cannot schedule event in the past": [
  null,
  "Impossible de planifier un événement dans le passé"
 ],
 "Change": [
  null,
  "Modifier"
 ],
 "Change shell": [
  null,
  "Changer de shell"
 ],
 "Change system time": [
  null,
  "Modifier l’heure du système"
 ],
 "Changed keys are often the result of an operating system reinstallation. However, an unexpected change may indicate a third-party attempt to intercept your connection.": [
  null,
  "Les changements de clés sont souvent le résultat d’une réinstallation du système d’exploitation. Cependant, un changement inattendu peut indiquer une tentative d’interception de votre connexion par un tiers."
 ],
 "Checking installed software": [
  null,
  "Vérification des logiciels installés"
 ],
 "Clear filter": [
  null,
  "Effacer le filtre"
 ],
 "Clear input value": [
  null,
  "Effacer la valeur saisie"
 ],
 "Close": [
  null,
  "Fermer"
 ],
 "Cockpit": [
  null,
  "Cockpit"
 ],
 "Cockpit configuration of NetworkManager and Firewalld": [
  null,
  "Configuration du cockpit de NetworkManager et Firewalld"
 ],
 "Cockpit could not contact the given host.": [
  null,
  "Cockpit n’a pas pu contacter l’hôte indiqué."
 ],
 "Cockpit is a server manager that makes it easy to administer your Linux servers via a web browser. Jumping between the terminal and the web tool is no problem. A service started via Cockpit can be stopped via the terminal. Likewise, if an error occurs in the terminal, it can be seen in the Cockpit journal interface.": [
  null,
  "Cockpit est un gestionnaire de serveur qui facilite l’administration de vos serveurs Linux via un navigateur Web. Sauter entre le terminal et l’outil web n’est pas un problème. Un service démarré via Cockpit peut être arrêté via le terminal. De même, si une erreur se produit dans le terminal, elle s’affiche dans l’interface du journal Cockpit."
 ],
 "Cockpit is not compatible with the software on the system.": [
  null,
  "Cockpit n’est pas compatible avec le logiciel sur le système."
 ],
 "Cockpit is not installed": [
  null,
  "Cockpit n’est pas installé"
 ],
 "Cockpit is not installed on the system.": [
  null,
  "Cockpit n’est pas installé sur le système."
 ],
 "Cockpit is perfect for new sysadmins, allowing them to easily perform simple tasks such as storage administration, inspecting journals and starting and stopping services. You can monitor and administer several servers at the same time. Just add them with a single click and your machines will look after its buddies.": [
  null,
  "Cockpit est parfait pour les nouveaux administrateurs système, leur permettant d’effectuer facilement des tâches simples telles que l’administration du stockage, l’inspection des journaux, le démarrage et l’arrêt des services. Vous pouvez surveiller et administrer plusieurs serveurs en même temps. Il suffit de les ajouter en un seul clic et vos machines s’occuperont de leurs pairs."
 ],
 "Collect and package diagnostic and support data": [
  null,
  "Collecte et regroupement des données de diagnostic et d'assistance"
 ],
 "Collect kernel crash dumps": [
  null,
  "Collecter les vidages de mémoire sur incidents du noyau"
 ],
 "Compact PCI": [
  null,
  "PCI compact"
 ],
 "Confirm key password": [
  null,
  "Confirmer le mot de passe de la clé"
 ],
 "Confirm new password": [
  null,
  "Confirmer le nouveau mot de passe"
 ],
 "Confirm password": [
  null,
  "Confirmer le mot de passe"
 ],
 "Connection has timed out.": [
  null,
  "La connexion a expiré."
 ],
 "Convertible": [
  null,
  "Convertible"
 ],
 "Copied": [
  null,
  "Copié"
 ],
 "Copy": [
  null,
  "Copier"
 ],
 "Copy to clipboard": [
  null,
  "Copier dans le presse-papier"
 ],
 "Create": [
  null,
  "Créer"
 ],
 "Create $0": [
  null,
  "Créer $0"
 ],
 "Create a new SSH key and authorize it": [
  null,
  "Créer une nouvelle clé SSH et l’autoriser"
 ],
 "Create account with non-unique UID": [
  null,
  "Créer un compte avec un UID non unique"
 ],
 "Create account with weak password": [
  null,
  "Créer un compte avec un mot de passe faible"
 ],
 "Create and change ownership of home directory": [
  null,
  "Créer et modifier la propriété du répertoire personnel"
 ],
 "Create new account": [
  null,
  "Créer un nouveau compte"
 ],
 "Create new group": [
  null,
  "Créer un nouveau groupe"
 ],
 "Create new task file with this content.": [
  null,
  "Créez un nouveau fichier de tâches avec ce contenu."
 ],
 "Ctrl+Insert": [
  null,
  "Ctrl+Inser"
 ],
 "Delay": [
  null,
  "Retard"
 ],
 "Delete": [
  null,
  "Supprimer"
 ],
 "Delete $0": [
  null,
  "Supprimer $0"
 ],
 "Delete account": [
  null,
  "Supprimer le compte"
 ],
 "Delete files": [
  null,
  "Supprimer les fichiers"
 ],
 "Delete group": [
  null,
  "Supprimer le groupe"
 ],
 "Desktop": [
  null,
  "Bureau"
 ],
 "Detachable": [
  null,
  "Détachable"
 ],
 "Diagnostic reports": [
  null,
  "Rapports de diagnostic"
 ],
 "Disallow interactive password": [
  null,
  "Interdire le mot de passe interactif"
 ],
 "Disallow password authentication": [
  null,
  "Interdire l’authentification par mot de passe"
 ],
 "Docking station": [
  null,
  "Station d’accueil"
 ],
 "Downloading $0": [
  null,
  "Téléchargement de $0"
 ],
 "Dual rank": [
  null,
  "Double rang"
 ],
 "Edit user": [
  null,
  "Modifier l'utilisateur"
 ],
 "Embedded PC": [
  null,
  "PC intégré"
 ],
 "Empty password": [
  null,
  "Mot de passe vide"
 ],
 "Ended": [
  null,
  "Terminé"
 ],
 "Error saving authorized keys: ": [
  null,
  "Erreur lors de l’enregistrement des clés autorisées : "
 ],
 "Excellent password": [
  null,
  "Mot de passe excellent"
 ],
 "Expansion chassis": [
  null,
  "Châssis d’extension"
 ],
 "Expire account on": [
  null,
  "Expiration du compte le"
 ],
 "Expire account on $0": [
  null,
  "Expiration du compte le $0"
 ],
 "Failed to change password": [
  null,
  "Échec de la modification du mot de passe"
 ],
 "Failed to enable $0 in firewalld": [
  null,
  "Échec de l’activation $0 dans firewalld"
 ],
 "Failed to load authorized keys.": [
  null,
  "Échec du chargement des clés autorisées."
 ],
 "Fingerprint": [
  null,
  "Empreinte de la clé"
 ],
 "Force change": [
  null,
  "Forcer la modification"
 ],
 "Force delete": [
  null,
  "Forcer la suppression"
 ],
 "Force password change": [
  null,
  "Forcer la modification de mot de passe"
 ],
 "From": [
  null,
  "De"
 ],
 "Full name": [
  null,
  "Nom complet"
 ],
 "Go to now": [
  null,
  "Aller à maintenant"
 ],
 "Group": [
  null,
  "Groupe"
 ],
 "Group name": [
  null,
  "Nom du groupe"
 ],
 "Groups": [
  null,
  "Groupes"
 ],
 "Handheld": [
  null,
  "Portable"
 ],
 "Hide confirmation password": [
  null,
  "Masquer le mot de passe de confirmation"
 ],
 "Hide password": [
  null,
  "Masquer le mot de passe"
 ],
 "Home directory": [
  null,
  "Répertoire utilisateur"
 ],
 "Host key is incorrect": [
  null,
  "La clé de l’hôte est incorrecte"
 ],
 "ID": [
  null,
  "ID"
 ],
 "If the fingerprint matches, click 'Trust and add host'. Otherwise, do not connect and contact your administrator.": [
  null,
  "Si l’empreinte digitale correspond, cliquez sur « Accepter la clé et ajouter l'hôte ». Sinon, ne vous connectez pas et contactez votre administrateur."
 ],
 "Install": [
  null,
  "Installer"
 ],
 "Install software": [
  null,
  "Installer le logiciel"
 ],
 "Installing $0": [
  null,
  "Installation de $0"
 ],
 "Internal error": [
  null,
  "Erreur interne"
 ],
 "Invalid date format": [
  null,
  "Format de date non valide"
 ],
 "Invalid date format and invalid time format": [
  null,
  "Format de date non valide et format d’heure non valide"
 ],
 "Invalid expiration date": [
  null,
  "Date d’expiration non valide"
 ],
 "Invalid file permissions": [
  null,
  "Les autorisations de fichier ne sont pas valides"
 ],
 "Invalid key": [
  null,
  "Clé non valide"
 ],
 "Invalid number of days": [
  null,
  "Nombre de jours non valide"
 ],
 "Invalid time format": [
  null,
  "Format d’heure non valide"
 ],
 "Invalid timezone": [
  null,
  "Fuseau horaire incorrect"
 ],
 "IoT gateway": [
  null,
  "Passerelle IoT"
 ],
 "Kernel dump": [
  null,
  "Kernel Dump"
 ],
 "Key password": [
  null,
  "Mot de passe clé"
 ],
 "Laptop": [
  null,
  "Portable"
 ],
 "Last active": [
  null,
  "Dernier actif"
 ],
 "Last login": [
  null,
  "Dernière connexion"
 ],
 "Learn more": [
  null,
  "En savoir plus"
 ],
 "Loading system modifications...": [
  null,
  "Chargement des modifications système..."
 ],
 "Loading...": [
  null,
  "Chargement..."
 ],
 "Local accounts": [
  null,
  "Comptes locaux"
 ],
 "Lock": [
  null,
  "Verrouillage"
 ],
 "Lock $0": [
  null,
  "Verrouillage $0"
 ],
 "Lock account": [
  null,
  "Verrouiller le compte"
 ],
 "Log in": [
  null,
  "Connexion"
 ],
 "Log in to $0": [
  null,
  "Connectez-vous à $0"
 ],
 "Log messages": [
  null,
  "Enregistrer les messages"
 ],
 "Log out": [
  null,
  "Déconnexion"
 ],
 "Log user out": [
  null,
  "Déconnexion de l'utilisateur"
 ],
 "Logged in": [
  null,
  "Connecté"
 ],
 "Login failed": [
  null,
  "Échec de la connexion"
 ],
 "Login history": [
  null,
  "Historique des connexions"
 ],
 "Login history list": [
  null,
  "Liste de l’historique des connexions"
 ],
 "Logout $0": [
  null,
  "Déconnexion $0"
 ],
 "Low profile desktop": [
  null,
  "Bureau de profil bas"
 ],
 "Lunch box": [
  null,
  "Lunch Box"
 ],
 "Main server chassis": [
  null,
  "Châssis principal du serveur"
 ],
 "Manage storage": [
  null,
  "Gérer le stockage"
 ],
 "Manually": [
  null,
  "Manuellement"
 ],
 "Message to logged in users": [
  null,
  "Message aux utilisateurs connectés"
 ],
 "Mini PC": [
  null,
  "Mini PC"
 ],
 "Mini tower": [
  null,
  "Mini Tour"
 ],
 "Multi-system chassis": [
  null,
  "Châssis multi-système"
 ],
 "NTP server": [
  null,
  "Serveur NTP"
 ],
 "Name": [
  null,
  "Nom"
 ],
 "Need at least one NTP server": [
  null,
  "Besoin d’au moins un serveur NTP"
 ],
 "Networking": [
  null,
  "Réseau"
 ],
 "Never": [
  null,
  "Jamais"
 ],
 "Never expire account": [
  null,
  "Ne jamais expirer le compte"
 ],
 "Never expire password": [
  null,
  "Ne jamais faire expirer le mot de passe"
 ],
 "Never logged in": [
  null,
  "Jamais connecté"
 ],
 "New name": [
  null,
  "Nouveau nom"
 ],
 "New password": [
  null,
  "Nouveau mot de passe"
 ],
 "New password was not accepted": [
  null,
  "Le nouveau mot de passe n’a pas été accepté"
 ],
 "No ID specified": [
  null,
  "Pas d'ID spécifié"
 ],
 "No delay": [
  null,
  "Aucun délai"
 ],
 "No group name specified": [
  null,
  "Aucun nom de groupe spécifié"
 ],
 "No matching results": [
  null,
  "Aucun résultat correspondant n’a été trouvé"
 ],
 "No real name specified": [
  null,
  "Aucun nom réel n’est renseigné"
 ],
 "No results found": [
  null,
  "Aucun résultat trouvé"
 ],
 "No such file or directory": [
  null,
  "Aucun fichier ou répertoire de ce nom"
 ],
 "No system modifications": [
  null,
  "Aucune modification système"
 ],
 "No user name specified": [
  null,
  "Aucun nom d’utilisateur n’est renseigné"
 ],
 "Not a valid private key": [
  null,
  "Clé privée non valide"
 ],
 "Not permitted to perform this action.": [
  null,
  "Non autorisé à effectuer cette action."
 ],
 "Not synchronized": [
  null,
  "Non synchronisé"
 ],
 "Notebook": [
  null,
  "Ordinateur portable"
 ],
 "Occurrences": [
  null,
  "Occurrences"
 ],
 "Ok": [
  null,
  "Ok"
 ],
 "Old password": [
  null,
  "Ancien mot de passe"
 ],
 "Old password not accepted": [
  null,
  "Ancien mot de passe non accepté"
 ],
 "Once Cockpit is installed, enable it with \"systemctl enable --now cockpit.socket\".": [
  null,
  "Une fois que Cockpit est installé, l’activer avec « systemctl enable --now cockpit.socket »."
 ],
 "Options": [
  null,
  "Options"
 ],
 "Other": [
  null,
  "Autre"
 ],
 "Other authentication methods are still available even when interactive password authentication is not allowed.": [
  null,
  "D’autres méthodes d’authentification sont toujours disponibles même lorsque l’authentification par mot de passe interactif n’est pas autorisée."
 ],
 "PackageKit crashed": [
  null,
  "Plantage de « PackageKit »"
 ],
 "Password": [
  null,
  "Mot de passe"
 ],
 "Password expiration": [
  null,
  "Expiration du mot de passe"
 ],
 "Password is longer than 256 characters": [
  null,
  "Le mot de passe fait plus de 256 caractères"
 ],
 "Password is not acceptable": [
  null,
  "Le mot de passe n’est pas acceptable"
 ],
 "Password is too weak": [
  null,
  "Le mot de passe est trop faible"
 ],
 "Password must be changed": [
  null,
  "Le mot de passe doit être changé"
 ],
 "Password not accepted": [
  null,
  "Mot de passe non accepté"
 ],
 "Paste": [
  null,
  "Coller"
 ],
 "Paste error": [
  null,
  "Erreur de collage"
 ],
 "Paste the contents of your public SSH key file here": [
  null,
  "Collez le contenu de votre clé publique SSH ici"
 ],
 "Path to directory": [
  null,
  "Chemin vers le répertoire"
 ],
 "Path to file": [
  null,
  "Chemin d’accès au fichier"
 ],
 "Peripheral chassis": [
  null,
  "Châssis périphérique"
 ],
 "Permanently delete $0 group?": [
  null,
  "Supprimer définitivement le groupe $0 ?"
 ],
 "Pick date": [
  null,
  "Choisissez une date"
 ],
 "Pizza box": [
  null,
  "Pizza Box"
 ],
 "Please specify an expiration date": [
  null,
  "Veuillez spécifier une date d’expiration"
 ],
 "Portable": [
  null,
  "Portable"
 ],
 "Present": [
  null,
  "Présent"
 ],
 "Prompting via passwd timed out": [
  null,
  "L’invite via passwd a expiré"
 ],
 "Prompting via ssh-add timed out": [
  null,
  "L’invite via ssh-add a expiré"
 ],
 "Prompting via ssh-keygen timed out": [
  null,
  "L’invite via ssh-keygen a expiré"
 ],
 "RAID chassis": [
  null,
  "Châssis RAID"
 ],
 "Rack mount chassis": [
  null,
  "Châssis de montage en rack"
 ],
 "Reboot": [
  null,
  "Redémarrer"
 ],
 "Removals:": [
  null,
  "Suppressions :"
 ],
 "Remove": [
  null,
  "Retirer"
 ],
 "Removing $0": [
  null,
  "Suppression de $0"
 ],
 "Rename": [
  null,
  "Renommer"
 ],
 "Rename group": [
  null,
  "Renommer le groupe"
 ],
 "Rename group $0": [
  null,
  "Renommer le groupe $0"
 ],
 "Renaming a group may affect sudo and similar rules": [
  null,
  "Renommer un groupe peut affecter sudo et les règles similaires"
 ],
 "Require password change every $0 days": [
  null,
  "Exiger un changement de mot de passe tous les $0 jours"
 ],
 "Require password change on $0": [
  null,
  "Exiger un changement de mot de passe sur $0"
 ],
 "Require password change on first login": [
  null,
  "Exiger un changement de mot de passe à la première connexion"
 ],
 "Reset password": [
  null,
  "Définir le mot de passe"
 ],
 "Row expansion": [
  null,
  "Agrandissement de ligne"
 ],
 "Row select": [
  null,
  "Sélection de ligne"
 ],
 "Run this command over a trusted network or physically on the remote machine:": [
  null,
  "Exécutez cette commande sur un réseau de confiance ou en la tapant physiquement sur la machine distante :"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "SSH key": [
  null,
  "Clé SSH"
 ],
 "SSH key login": [
  null,
  "Connexion par clé SSH"
 ],
 "Sealed-case PC": [
  null,
  "PC scellé"
 ],
 "Search for name or ID": [
  null,
  "Recherche de nom ou d'identification"
 ],
 "Search for name, group or ID": [
  null,
  "Recherche par nom, groupe ou ID"
 ],
 "Security Enhanced Linux configuration and troubleshooting": [
  null,
  "Configuration et dépannage de Linux avec renforcement de la sécurité"
 ],
 "Select an option": [
  null,
  "Sélectionner une option"
 ],
 "Server has closed the connection.": [
  null,
  "Le serveur a fermé la connexion."
 ],
 "Set password": [
  null,
  "Définir le mot de passe"
 ],
 "Set time": [
  null,
  "Régler l’heure"
 ],
 "Set weak password": [
  null,
  "Définir un mot de passe faible"
 ],
 "Shell": [
  null,
  "Shell"
 ],
 "Shell script": [
  null,
  "Script shell"
 ],
 "Shift+Insert": [
  null,
  "Maj+Inser"
 ],
 "Show confirmation password": [
  null,
  "Afficher le mot de passe de confirmation"
 ],
 "Show password": [
  null,
  "Afficher le mot de passe"
 ],
 "Shut down": [
  null,
  "Fermeture"
 ],
 "Single rank": [
  null,
  "Rang unique"
 ],
 "Space-saving computer": [
  null,
  "Ordinateur gain de place"
 ],
 "Specific time": [
  null,
  "Temps spécifique"
 ],
 "Started": [
  null,
  "Démarré"
 ],
 "Stick PC": [
  null,
  "Stick PC"
 ],
 "Storage": [
  null,
  "Stockage"
 ],
 "Strong password": [
  null,
  "Mot de passe fort"
 ],
 "Sub-Chassis": [
  null,
  "Sous-châssis"
 ],
 "Sub-Notebook": [
  null,
  "Sub-Notebook"
 ],
 "Synchronized": [
  null,
  "Synchronisé"
 ],
 "Synchronized with $0": [
  null,
  "Synchronisé avec $0"
 ],
 "Synchronizing": [
  null,
  "Synchronisation"
 ],
 "Tablet": [
  null,
  "Tablette"
 ],
 "Terminate session": [
  null,
  "Terminer la session"
 ],
 "The SSH key $0 of $1 on $2 will be added to the $3 file of $4 on $5.": [
  null,
  "La clé SSH $0 de $1 sur $2 sera ajoutée au fichier $3 de $4 sur $5."
 ],
 "The SSH key $0 will be made available for the remainder of the session and will be available for login to other hosts as well.": [
  null,
  "La clé SSH $0 sera disponible pour le reste de la session et sera également disponible pour la connexion à d’autres hôtes."
 ],
 "The SSH key for logging in to $0 is protected by a password, and the host does not allow logging in with a password. Please provide the password of the key at $1.": [
  null,
  "La clé SSH permettant de se connecter à $0 est protégée par un mot de passe, et l’hôte ne permet pas de se connecter avec un mot de passe. Veuillez fournir le mot de passe de la clé à $1."
 ],
 "The SSH key for logging in to $0 is protected. You can log in with either your login password or by providing the password of the key at $1.": [
  null,
  "La clé SSH permettant de se connecter à $0 est protégée. Vous pouvez vous connecter avec votre mot de passe de connexion ou en fournissant le mot de passe de la clé à $1."
 ],
 "The account '$0' will be forced to change their password on next login": [
  null,
  "Le compte « $0 » sera forcé de changer de mot de passe lors de la prochaine connexion"
 ],
 "The fingerprint should match:": [
  null,
  "Les empreintes doivent correspondre :"
 ],
 "The full name must not contain colons.": [
  null,
  "Le nom complet ne doit pas contenir de deux-points."
 ],
 "The group ID must be positive integer": [
  null,
  "L'ID du groupe doit être un nombre entier positif"
 ],
 "The group name can only consist of letters from a-z, digits, dots, dashes and underscores": [
  null,
  "Le nom du groupe ne peut contenir que des lettres de a à z, des chiffres, des points, des tirets et des tirets bas"
 ],
 "The home directory $0 already exists. Its ownership will be changed to the new user.": [
  null,
  "Le répertoire personnel $0 existe déjà. Son propriétaire sera le nouvel utilisateur."
 ],
 "The key password can not be empty": [
  null,
  "Le mot de passe de la clé ne peut pas être vide"
 ],
 "The key passwords do not match": [
  null,
  "Les mots de passe sont différents"
 ],
 "The key you provided was not valid.": [
  null,
  "La clé que vous avez fournie n’était pas valide."
 ],
 "The logged in user is not permitted to view system modifications": [
  null,
  "L’utilisateur actuellement connecté n’est pas autorisé à voir les modifications système"
 ],
 "The password can not be empty": [
  null,
  "Le mot de passe ne peut pas être vide"
 ],
 "The passwords do not match": [
  null,
  "Le mot de passe ne correspond pas"
 ],
 "The resulting fingerprint is fine to share via public methods, including email.": [
  null,
  "L’empreinte digitale qui en résulte peut être partagée via des méthodes publiques, y compris par courrier électronique."
 ],
 "The resulting fingerprint is fine to share via public methods, including email. If you are asking someone else to do the verification for you, they can send the results using any method.": [
  null,
  "L'empreinte qui en découle peut être partagée publiquement par e-mail ou autre sans risque. Si vous demandez à quelqu'un d'autre de faire la vérification pour vous, cette personne peut vous envoyer les résultats par n'importe quel biais."
 ],
 "The server refused to authenticate using any supported methods.": [
  null,
  "Le serveur a refusé d’authentifier en utilisant des méthodes prises en charge."
 ],
 "The user must log out and log back in for the new configuration to take effect.": [
  null,
  "L'utilisateur doit se déconnecter et se reconnecter pour que la nouvelle configuration prenne effet."
 ],
 "The user name can only consist of letters from a-z, digits, dots, dashes and underscores.": [
  null,
  "Le nom d’utilisateur ne peut contenir que des lettres de az, des chiffres, des points, des tirets et des traits de soulignement."
 ],
 "There are no authorized public keys for this account.": [
  null,
  "Il n’y a aucune clé publique autorisée pour ce compte."
 ],
 "This group is the primary group for the following users:": [
  null,
  "Ce groupe est le groupe primaire pour les utilisateurs suivants :"
 ],
 "This tool configures the SELinux policy and can help with understanding and resolving policy violations.": [
  null,
  "Cet outil configure la politique SELinux et peut aider à comprendre et à résoudre les violations de la politique."
 ],
 "This tool configures the system to write kernel crash dumps. It supports the \"local\" (disk), \"ssh\", and \"nfs\" dump targets.": [
  null,
  "Cet outil configure le système pour qu'il écrive les vidages de mémoire sur incidents du noyau. Il prend en charge les cibles \"local\" (disque), \"ssh\" et \"nfs\"."
 ],
 "This tool generates an archive of configuration and diagnostic information from the running system. The archive may be stored locally or centrally for recording or tracking purposes or may be sent to technical support representatives, developers or system administrators to assist with technical fault-finding and debugging.": [
  null,
  "Cet outil génère une archive des informations de configuration et de diagnostic du système en cours d'exécution. Ces archives peuvent être stockées localement ou centralement à des fins d'enregistrement ou de suivi, ou être envoyées aux représentants du support technique, aux développeurs ou aux administrateurs système pour les aider dans la recherche d'erreurs techniques et le débogage."
 ],
 "This tool manages local storage, such as filesystems, LVM2 volume groups, and NFS mounts.": [
  null,
  "Cet outil gère le stockage local, tel que les systèmes de fichiers, les groupes de volumes LVM2 et les montages NFS."
 ],
 "This tool manages networking such as bonds, bridges, teams, VLANs and firewalls using NetworkManager and Firewalld. NetworkManager is incompatible with Ubuntu's default systemd-networkd and Debian's ifupdown scripts.": [
  null,
  "Cet outil gère les réseaux tels que les liens, les ponts, les équipes, les VLAN et les pare-feu en utilisant NetworkManager et Firewalld. NetworkManager est incompatible avec les scripts par défaut systemd-networkd d'Ubuntu et ifupdown de Debian."
 ],
 "This user name already exists": [
  null,
  "Cet identifiant existe déjà"
 ],
 "Time zone": [
  null,
  "Fuseau horaire"
 ],
 "To ensure that your connection is not intercepted by a malicious third-party, please verify the host key fingerprint:": [
  null,
  "Pour vous assurer que votre connexion n’est pas interceptée par un tiers malveillant, veuillez vérifier l’empreinte de la clé de l’hôte :"
 ],
 "To verify a fingerprint, run the following on $0 while physically sitting at the machine or through a trusted network:": [
  null,
  "Pour vérifier une empreinte digitale, exécutez les opérations suivantes sur $0 en étant physiquement assis devant la machine ou en passant par un réseau de confiance :"
 ],
 "Toggle date picker": [
  null,
  "Basculer le sélecteur de date"
 ],
 "Too much data": [
  null,
  "Trop de données"
 ],
 "Total size: $0": [
  null,
  "Taille totale : $0"
 ],
 "Tower": [
  null,
  "Tower"
 ],
 "Trust and add host": [
  null,
  "Faire confiance à l'hôte et l'ajouter"
 ],
 "Trying to synchronize with $0": [
  null,
  "Synchronisation avec $0 en cours d'essai"
 ],
 "Unable to log in to $0 using SSH key authentication. Please provide the password.": [
  null,
  "Impossible de se connecter à $0 en utilisant l'authentification par clé SSH. Veuillez fournir le mot de passe."
 ],
 "Unable to log in to $0. The host does not accept password login or any of your SSH keys.": [
  null,
  "Impossible de se connecter à $0. L’hôte n’accepte pas le mot de passe de connexion ou l’une de vos clés SSH."
 ],
 "Undo": [
  null,
  "Annuler"
 ],
 "Unexpected error": [
  null,
  "Erreur inattendue"
 ],
 "Unknown": [
  null,
  "Inconnu"
 ],
 "Unknown host: $0": [
  null,
  "Hôte inconnu : $0"
 ],
 "Unnamed": [
  null,
  "Anonyme"
 ],
 "Untrusted host": [
  null,
  "Hôte non sécurisé"
 ],
 "Use password": [
  null,
  "Utiliser un mot de passe"
 ],
 "User ID": [
  null,
  "Identifiant utilisateur"
 ],
 "User ID is already used by another user": [
  null,
  "L'identifiant de l'utilisateur est déjà utilisé par un autre utilisateur"
 ],
 "User ID must be a positive integer": [
  null,
  "L'identifiant de l'utilisateur doit être un nombre entier positif"
 ],
 "User ID must not be higher than $0": [
  null,
  "L'ID de l'utilisateur ne doit pas être supérieur à $0"
 ],
 "User ID must not be lower than $0": [
  null,
  "L'ID de l'utilisateur ne doit pas être inférieur à $0"
 ],
 "User name": [
  null,
  "Nom d’utilisateur"
 ],
 "Username": [
  null,
  "Nom d’utilisateur"
 ],
 "Verify fingerprint": [
  null,
  "Vérifier l'empreinte digitale"
 ],
 "View all logs": [
  null,
  "Voir tous les journaux"
 ],
 "View automation script": [
  null,
  "Afficher le script d’automation"
 ],
 "Visit firewall": [
  null,
  "Visitez le pare-feu"
 ],
 "Waiting for other software management operations to finish": [
  null,
  "Attente de la fin des autres opérations de gestion du logiciel"
 ],
 "Weak password": [
  null,
  "Mot de passe faible"
 ],
 "Web Console for Linux servers": [
  null,
  "Console web pour serveurs Linux"
 ],
 "You are connecting to $0 for the first time.": [
  null,
  "Vous vous connectez à $0 pour la première fois."
 ],
 "You do not have permission to view the authorized public keys for this account.": [
  null,
  "Vous n’êtes pas autorisé à afficher les clés publiques autorisées pour ce compte."
 ],
 "You must wait longer to change your password": [
  null,
  "Vous devez encore attendre avant de changer votre mot de passe"
 ],
 "Your account": [
  null,
  "Votre compte"
 ],
 "Your browser does not allow paste from the context menu. You can use Shift+Insert.": [
  null,
  "Votre navigateur n’autorise pas le collage à partir du menu contextuel. Vous pouvez utiliser Maj+Insérer."
 ],
 "Your session has been terminated.": [
  null,
  "Votre session a été interrompue."
 ],
 "Your session has expired. Please log in again.": [
  null,
  "Votre session a expiré. Veuillez vous reconnecter."
 ],
 "Zone": [
  null,
  "Zone"
 ],
 "[binary data]": [
  null,
  "[données binaires]"
 ],
 "[no data]": [
  null,
  "[pas de données]"
 ],
 "change": [
  null,
  "modifier"
 ],
 "edit": [
  null,
  "modifier"
 ],
 "in less than a minute": [
  null,
  "dans moins d'une minute"
 ],
 "less than a minute ago": [
  null,
  "il y a moins d'une minute"
 ],
 "password quality": [
  null,
  "qualité mot de passe"
 ],
 "show less": [
  null,
  "montrer moins"
 ],
 "show more": [
  null,
  "montrer plus"
 ],
 "user": [
  null,
  "utilisateur"
 ]
});
