cockpit.locale({
 "": {
  "plural-forms": (n) => n != 1,
  "language": "sv",
  "language-direction": "ltr"
 },
 "# of users": [
  null,
  "# av användare"
 ],
 "$0 GiB": [
  null,
  "$0 GiB"
 ],
 "$0 day": [
  null,
  "$0 dag",
  "$0 dagar"
 ],
 "$0 exited with code $1": [
  null,
  "$0 avslutade med kod $1"
 ],
 "$0 failed": [
  null,
  "$0 misslyckades"
 ],
 "$0 hour": [
  null,
  "$0 timme",
  "$0 timmar"
 ],
 "$0 is an existing file": [
  null,
  "$0 är en existerande fil"
 ],
 "$0 is not available from any repository.": [
  null,
  "$0 är inte tillgängligt från något förråd."
 ],
 "$0 key changed": [
  null,
  "$0 nyckel ändrad"
 ],
 "$0 killed with signal $1": [
  null,
  "$0 dödad med signal $1"
 ],
 "$0 minute": [
  null,
  "$0 minut",
  "$0 minuter"
 ],
 "$0 month": [
  null,
  "$0 månad",
  "$0 månader"
 ],
 "$0 more...": [
  null,
  "$0 mer..."
 ],
 "$0 week": [
  null,
  "$0 vecka",
  "$0 veckor"
 ],
 "$0 will be installed.": [
  null,
  "$0 kommer att installeras."
 ],
 "$0 year": [
  null,
  "$0 år",
  "$0 år"
 ],
 "1 day": [
  null,
  "1 dag"
 ],
 "1 hour": [
  null,
  "1 timme"
 ],
 "1 minute": [
  null,
  "1 minut"
 ],
 "1 week": [
  null,
  "1 vecka"
 ],
 "20 minutes": [
  null,
  "20 minuter"
 ],
 "40 minutes": [
  null,
  "40 minuter"
 ],
 "5 minutes": [
  null,
  "5 minuter"
 ],
 "6 hours": [
  null,
  "6 timmar"
 ],
 "60 minutes": [
  null,
  "60 minuter"
 ],
 "A compatible version of Cockpit is not installed on $0.": [
  null,
  "Ingen kompatibel version av Cockpit är installerad på $0."
 ],
 "A group with this name already exists": [
  null,
  "En grupp med detta namn finns redan"
 ],
 "A new SSH key at $0 will be created for $1 on $2 and it will be added to the $3 file of $4 on $5.": [
  null,
  "En ny SSH-nyckel på $0 kommer att skapas för $1 på $2 och den kommer att läggas till $3-filen på $4 på $5."
 ],
 "Absent": [
  null,
  "Frånvarande"
 ],
 "Acceptable password": [
  null,
  "Acceptabelt lösenord"
 ],
 "Account expiration": [
  null,
  "Utgång av konto"
 ],
 "Account not available or cannot be edited.": [
  null,
  "Kontot är inte tillgängligt eller kan inte redigeras."
 ],
 "Accounts": [
  null,
  "Konton"
 ],
 "Actions": [
  null,
  "Åtgärder"
 ],
 "Add": [
  null,
  "Lägg till"
 ],
 "Add $0": [
  null,
  "Lägg till $0"
 ],
 "Add key": [
  null,
  "Lägg till nyckel"
 ],
 "Add public key": [
  null,
  "Lägg till publik nyckel"
 ],
 "Additional packages:": [
  null,
  "Ytterligare paket:"
 ],
 "Administration with Cockpit Web Console": [
  null,
  "Administration med Cockpits webbkonsol"
 ],
 "Advanced TCA": [
  null,
  "Avancerad TCA"
 ],
 "All-in-one": [
  null,
  "Allt i ett"
 ],
 "Ansible": [
  null,
  "Ansible"
 ],
 "Ansible roles documentation": [
  null,
  "Dokumentation för Ansibleroller"
 ],
 "Authentication": [
  null,
  "Autentisering"
 ],
 "Authentication is required to perform privileged tasks with the Cockpit Web Console": [
  null,
  "Autentisering krävs för att utföra privilegierade uppgifter med Cockpits webbkonsol"
 ],
 "Authorize SSH key": [
  null,
  "Auktorisera SSH-nyckel"
 ],
 "Authorized public SSH keys": [
  null,
  "Auktoriserade publika SSH-nycklar"
 ],
 "Automatically using NTP": [
  null,
  "Använder automatiskt NTP"
 ],
 "Automatically using additional NTP servers": [
  null,
  "Använder automatiskt ytterligare NTP-servrar"
 ],
 "Automatically using specific NTP servers": [
  null,
  "Använder automatiskt specifika NTP-servrar"
 ],
 "Automation script": [
  null,
  "Automatiseringsskript"
 ],
 "Back to accounts": [
  null,
  "Tilllbaka till konton"
 ],
 "Blade": [
  null,
  "Blad"
 ],
 "Blade enclosure": [
  null,
  "Bladhölje"
 ],
 "Bus expansion chassis": [
  null,
  "Bussexpansionschassi"
 ],
 "Cancel": [
  null,
  "Avbryt"
 ],
 "Cannot forward login credentials": [
  null,
  "Kan inte vidarebefordra inloggningsuppgifterna"
 ],
 "Cannot schedule event in the past": [
  null,
  "Kan inte schemalägga händelser som redan hänt"
 ],
 "Change": [
  null,
  "Ändra"
 ],
 "Change shell": [
  null,
  "Ändra skal"
 ],
 "Change system time": [
  null,
  "Ändra systemtid"
 ],
 "Changed keys are often the result of an operating system reinstallation. However, an unexpected change may indicate a third-party attempt to intercept your connection.": [
  null,
  "Ändrade nycklar är ofta resultatet av en ominstallation av operativsystemet. En oväntad förändring kan dock indikera ett försök från tredje part att avlyssna din anslutning."
 ],
 "Checking installed software": [
  null,
  "Kontrollerar installerad programvara"
 ],
 "Clear filter": [
  null,
  "Rensa filter"
 ],
 "Clear input value": [
  null,
  "Rensa inmatningsvärde"
 ],
 "Close": [
  null,
  "Stäng"
 ],
 "Cockpit": [
  null,
  "Cockpit"
 ],
 "Cockpit configuration of NetworkManager and Firewalld": [
  null,
  "Cockpit konfiguration av NetworkManager och Firewalld"
 ],
 "Cockpit could not contact the given host.": [
  null,
  "Cockpit kunde inte kontakta den angivna värden."
 ],
 "Cockpit is a server manager that makes it easy to administer your Linux servers via a web browser. Jumping between the terminal and the web tool is no problem. A service started via Cockpit can be stopped via the terminal. Likewise, if an error occurs in the terminal, it can be seen in the Cockpit journal interface.": [
  null,
  "Cockpit är en serverhanterare som gör det lätt att administrera dina Linuxservrar via en webbläsare. Att hoppa mellan terminalen och webbverktyget är inget problem. En tjänst som startas via Cockpit kan stoppas via terminalen. Likaledes, om ett fel uppstår i terminalen kan det ses i Cockpits journalgränssnitt."
 ],
 "Cockpit is not compatible with the software on the system.": [
  null,
  "Cockpit är inte kompatibelt med programvaran på systemet."
 ],
 "Cockpit is not installed": [
  null,
  "Cockpit är inte installerat"
 ],
 "Cockpit is not installed on the system.": [
  null,
  "Cockpit är inte installerat på systemet."
 ],
 "Cockpit is perfect for new sysadmins, allowing them to easily perform simple tasks such as storage administration, inspecting journals and starting and stopping services. You can monitor and administer several servers at the same time. Just add them with a single click and your machines will look after its buddies.": [
  null,
  "Cockpit är perfekt för nya systemadministratörer, låter dem lätt utföra enkla uppgifter såsom lagringsadministration, inspektion av journaler och att starta och stoppa tjänster. Du kan övervaka och administrera flera servrar på samma gång. Lägg bara till dem med ett enda klick och dina maskiner kommer se efter sina kompisar."
 ],
 "Collect and package diagnostic and support data": [
  null,
  "Samla och paketera diagnostik och support data"
 ],
 "Collect kernel crash dumps": [
  null,
  "Samla kärnkraschdumpar"
 ],
 "Compact PCI": [
  null,
  "Kompakt PCI"
 ],
 "Confirm key password": [
  null,
  "Bekräfta lösenord för nyckel"
 ],
 "Confirm new password": [
  null,
  "Bekräfta nytt lösenord"
 ],
 "Confirm password": [
  null,
  "Bekräfta lösenord"
 ],
 "Connection has timed out.": [
  null,
  "Anslutningens tidsgräns överskreds."
 ],
 "Convertible": [
  null,
  "Konvertibel"
 ],
 "Copied": [
  null,
  "Kopierade"
 ],
 "Copy": [
  null,
  "Kopiera"
 ],
 "Copy to clipboard": [
  null,
  "Kopiera till urklipp"
 ],
 "Create": [
  null,
  "Skapa"
 ],
 "Create $0": [
  null,
  "Skapa $0"
 ],
 "Create a new SSH key and authorize it": [
  null,
  "Skapa en ny SSH-nyckel och auktorisera den"
 ],
 "Create account with non-unique UID": [
  null,
  "Skapa konto med icke-unik UID"
 ],
 "Create account with weak password": [
  null,
  "Skapa konto med svagt lösenord"
 ],
 "Create and change ownership of home directory": [
  null,
  "Skapa och ändra ägarskap av hemkatalog"
 ],
 "Create new account": [
  null,
  "Skapa ett nytt konto"
 ],
 "Create new group": [
  null,
  "Skapa en ny grupp"
 ],
 "Create new task file with this content.": [
  null,
  "Skapa en ny uppgiftsfil med detta innehåll."
 ],
 "Ctrl+Insert": [
  null,
  "Ctrl+Insert"
 ],
 "Delay": [
  null,
  "Fördröjning"
 ],
 "Delete": [
  null,
  "Ta bort"
 ],
 "Delete $0": [
  null,
  "Ta bort $0"
 ],
 "Delete account": [
  null,
  "Ta bort konto"
 ],
 "Delete files": [
  null,
  "Ta bort filer"
 ],
 "Delete group": [
  null,
  "Ta bort grupp"
 ],
 "Desktop": [
  null,
  "Skrivbord"
 ],
 "Detachable": [
  null,
  "Frånkopplingsbar"
 ],
 "Diagnostic reports": [
  null,
  "Diagnostikrapporter"
 ],
 "Disallow interactive password": [
  null,
  "Tillåt inte interaktivt lösenord"
 ],
 "Disallow password authentication": [
  null,
  "Tillåt inte lösenordsautentisering"
 ],
 "Docking station": [
  null,
  "Dockningsstation"
 ],
 "Downloading $0": [
  null,
  "Hämtar $0"
 ],
 "Dual rank": [
  null,
  "Dubbelrad"
 ],
 "Edit user": [
  null,
  "Redigera användare"
 ],
 "Embedded PC": [
  null,
  "Inbäddad PC"
 ],
 "Empty password": [
  null,
  "Tomt lösenord"
 ],
 "Ended": [
  null,
  "Slutade"
 ],
 "Error saving authorized keys: ": [
  null,
  "Fel när auktoriserade nycklar sparades: "
 ],
 "Excellent password": [
  null,
  "Utmärkt lösenord"
 ],
 "Expansion chassis": [
  null,
  "Expansionschassin"
 ],
 "Expire account on": [
  null,
  "Upphör konto på"
 ],
 "Expire account on $0": [
  null,
  "Upphör konto på $0"
 ],
 "Failed to change password": [
  null,
  "Misslyckades att ändra lösenord"
 ],
 "Failed to enable $0 in firewalld": [
  null,
  "Misslyckades med att aktivera $0 i firewalld"
 ],
 "Failed to load authorized keys.": [
  null,
  "Misslyckades att läsa in auktoriserade nycklar."
 ],
 "Fingerprint": [
  null,
  "Fingeravtryck"
 ],
 "Force change": [
  null,
  "Framtvinga ändring"
 ],
 "Force delete": [
  null,
  "Framtvinga borttagande"
 ],
 "Force password change": [
  null,
  "Framtvinga lösenordsändring"
 ],
 "From": [
  null,
  "Från"
 ],
 "Full name": [
  null,
  "Fullständigt namn"
 ],
 "Go to now": [
  null,
  "Gå till nu"
 ],
 "Group": [
  null,
  "Grupp"
 ],
 "Group name": [
  null,
  "Gruppnamn"
 ],
 "Groups": [
  null,
  "Grupper"
 ],
 "Handheld": [
  null,
  "Handhållen"
 ],
 "Hide confirmation password": [
  null,
  "Dölj bekräftelselösenord"
 ],
 "Hide password": [
  null,
  "Dölj lösenord"
 ],
 "Home directory": [
  null,
  "Hemkatalog"
 ],
 "Host key is incorrect": [
  null,
  "Värdnyckeln är felaktig"
 ],
 "ID": [
  null,
  "ID"
 ],
 "If the fingerprint matches, click 'Trust and add host'. Otherwise, do not connect and contact your administrator.": [
  null,
  "Om fingeravtrycket stämmer, klicka på \"Lita på och lägg till värd\". Annars, anslut inte och kontakta din administratör."
 ],
 "Install": [
  null,
  "Installera"
 ],
 "Install software": [
  null,
  "Installera programvara"
 ],
 "Installing $0": [
  null,
  "Installerar $0"
 ],
 "Internal error": [
  null,
  "Internt fel"
 ],
 "Invalid date format": [
  null,
  "Felaktigt datumformat"
 ],
 "Invalid date format and invalid time format": [
  null,
  "Felaktigt datumformat och felaktigt tidsformat"
 ],
 "Invalid expiration date": [
  null,
  "Felaktigt utgångsdatum"
 ],
 "Invalid file permissions": [
  null,
  "Felaktiga filrättigheter"
 ],
 "Invalid key": [
  null,
  "Felaktig nyckel"
 ],
 "Invalid number of days": [
  null,
  "Felaktigt antal dagar"
 ],
 "Invalid time format": [
  null,
  "Felaktigt tidsformat"
 ],
 "Invalid timezone": [
  null,
  "Felaktig tidszon"
 ],
 "IoT gateway": [
  null,
  "IoT-gateway"
 ],
 "Kernel dump": [
  null,
  "Kärndump"
 ],
 "Key password": [
  null,
  "Nyckellösenord"
 ],
 "Laptop": [
  null,
  "Bärbar dator"
 ],
 "Last active": [
  null,
  "Senast aktiv"
 ],
 "Last login": [
  null,
  "Senaste inloggning"
 ],
 "Learn more": [
  null,
  "Mer information"
 ],
 "Loading system modifications...": [
  null,
  "Läser in anpassningar till systemet..."
 ],
 "Loading...": [
  null,
  "Läser in …"
 ],
 "Local accounts": [
  null,
  "Lokala konton"
 ],
 "Lock": [
  null,
  "Lås"
 ],
 "Lock $0": [
  null,
  "Lås $0"
 ],
 "Lock account": [
  null,
  "Lås kontot"
 ],
 "Log in": [
  null,
  "Logga in"
 ],
 "Log in to $0": [
  null,
  "Logga in till $0"
 ],
 "Log messages": [
  null,
  "Loggmeddelanden"
 ],
 "Log out": [
  null,
  "Logga ut"
 ],
 "Log user out": [
  null,
  "Logga ut användare"
 ],
 "Logged in": [
  null,
  "Inloggad"
 ],
 "Login failed": [
  null,
  "Inloggningen misslyckades"
 ],
 "Login history": [
  null,
  "Inloggningshistorik"
 ],
 "Login history list": [
  null,
  "Inloggningshistorielista"
 ],
 "Logout $0": [
  null,
  "Logga ut $0"
 ],
 "Low profile desktop": [
  null,
  "Lågprofilskrivbord"
 ],
 "Lunch box": [
  null,
  "Lunchlåda"
 ],
 "Main server chassis": [
  null,
  "Huvudserverchassi"
 ],
 "Manage storage": [
  null,
  "Hantera lagring"
 ],
 "Manually": [
  null,
  "Manuellt"
 ],
 "Message to logged in users": [
  null,
  "Meddelande till inloggade användare"
 ],
 "Mini PC": [
  null,
  "Mini-PC"
 ],
 "Mini tower": [
  null,
  "Minitorn"
 ],
 "Multi-system chassis": [
  null,
  "Multisystemschassi"
 ],
 "NTP server": [
  null,
  "NTP-server"
 ],
 "Name": [
  null,
  "Namn"
 ],
 "Need at least one NTP server": [
  null,
  "Behöver åtminstone en NTP-server"
 ],
 "Networking": [
  null,
  "Nätverk"
 ],
 "Never": [
  null,
  "Aldrig"
 ],
 "Never expire account": [
  null,
  "Upphör aldrig konto"
 ],
 "Never expire password": [
  null,
  "Låt aldrig lösenord gå ut"
 ],
 "Never logged in": [
  null,
  "Aldrig inloggad"
 ],
 "New name": [
  null,
  "Nytt namn"
 ],
 "New password": [
  null,
  "Nytt lösenord"
 ],
 "New password was not accepted": [
  null,
  "Det nya lösenordet godtogs inte"
 ],
 "No ID specified": [
  null,
  "Inget ID angivet"
 ],
 "No delay": [
  null,
  "Ingen fördröjning"
 ],
 "No group name specified": [
  null,
  "Inget gruppnamn angivet"
 ],
 "No matching results": [
  null,
  "Inga matchande resultat"
 ],
 "No real name specified": [
  null,
  "Inget verkligt namn angivet"
 ],
 "No results found": [
  null,
  "Inga resultat funna"
 ],
 "No such file or directory": [
  null,
  "Filen eller katalogen finns inte"
 ],
 "No system modifications": [
  null,
  "Inga systemändringar"
 ],
 "No user name specified": [
  null,
  "Inget användarnamn angivet"
 ],
 "Not a valid private key": [
  null,
  "Inte en giltig privat nyckel"
 ],
 "Not permitted to perform this action.": [
  null,
  "Inte tillåtet att utföra denna åtgärd."
 ],
 "Not synchronized": [
  null,
  "Inte synkroniserad"
 ],
 "Notebook": [
  null,
  "Bärbar (notebook)"
 ],
 "Occurrences": [
  null,
  "Förekomster"
 ],
 "Ok": [
  null,
  "Ok"
 ],
 "Old password": [
  null,
  "Gammalt lösenord"
 ],
 "Old password not accepted": [
  null,
  "Det gamla lösenordet accepterades inte"
 ],
 "Once Cockpit is installed, enable it with \"systemctl enable --now cockpit.socket\".": [
  null,
  "När Cockpit är installerat, aktivera det med ”systemctl enable --now cockpit.socket”."
 ],
 "Options": [
  null,
  "Alternativ"
 ],
 "Other": [
  null,
  "Annan"
 ],
 "Other authentication methods are still available even when interactive password authentication is not allowed.": [
  null,
  "Andra autentiseringsmetoder är fortfarande tillgängliga även när interaktiv lösenordsautentisering inte är tillåten."
 ],
 "PackageKit crashed": [
  null,
  "PackageKit kraschade"
 ],
 "Password": [
  null,
  "Lösenord"
 ],
 "Password expiration": [
  null,
  "Utgång av lösenord"
 ],
 "Password is longer than 256 characters": [
  null,
  "Lösenord får inte vara längre än 256 tecken"
 ],
 "Password is not acceptable": [
  null,
  "Lösenordet är inte godtagbart"
 ],
 "Password is too weak": [
  null,
  "Lösenordet är för svagt"
 ],
 "Password must be changed": [
  null,
  "Lösenordet måste ändras"
 ],
 "Password not accepted": [
  null,
  "Lösenordet accepterades inte"
 ],
 "Paste": [
  null,
  "Klistra in"
 ],
 "Paste error": [
  null,
  "Klistra in fel"
 ],
 "Paste the contents of your public SSH key file here": [
  null,
  "Klistra in innehållet i din publika SSH-nyckelfil här"
 ],
 "Path to directory": [
  null,
  "Sökväg till katalog"
 ],
 "Path to file": [
  null,
  "Sökväg till filen"
 ],
 "Peripheral chassis": [
  null,
  "Periferichassi"
 ],
 "Permanently delete $0 group?": [
  null,
  "Permanent ta bort $0 grupp?"
 ],
 "Pick date": [
  null,
  "Välj datum"
 ],
 "Pizza box": [
  null,
  "Pizzalåda"
 ],
 "Please specify an expiration date": [
  null,
  "Ange ett utgångsdatum"
 ],
 "Portable": [
  null,
  "Bärbar"
 ],
 "Present": [
  null,
  "Närvarande"
 ],
 "Prompting via passwd timed out": [
  null,
  "Tidsgränsen överskreds vid fråga via passwd"
 ],
 "Prompting via ssh-add timed out": [
  null,
  "Tidsgränsen överskreds vid fråga via ssh-add"
 ],
 "Prompting via ssh-keygen timed out": [
  null,
  "Tidsgränsen överskreds vid fråga via ssh-keygen"
 ],
 "RAID chassis": [
  null,
  "RAID-chassi"
 ],
 "Rack mount chassis": [
  null,
  "Rackmonteringschassi"
 ],
 "Reboot": [
  null,
  "Starta om"
 ],
 "Removals:": [
  null,
  "Borttagningar:"
 ],
 "Remove": [
  null,
  "Ta bort"
 ],
 "Removing $0": [
  null,
  "Tar bort $0"
 ],
 "Rename": [
  null,
  "Byt namn"
 ],
 "Rename group": [
  null,
  "Byt namn på grupp"
 ],
 "Rename group $0": [
  null,
  "Bytt namn på grupp $0"
 ],
 "Renaming a group may affect sudo and similar rules": [
  null,
  "Att byta namn på en grupp kan påverka sudo och liknande regler"
 ],
 "Require password change every $0 days": [
  null,
  "Begär en lösenordsändring var $0:e dag"
 ],
 "Require password change on $0": [
  null,
  "Begär lösenordsändring den $0"
 ],
 "Require password change on first login": [
  null,
  "Begär lösenordsändring vid första inloggningen"
 ],
 "Reset password": [
  null,
  "Återställ lösenord"
 ],
 "Row expansion": [
  null,
  "Radexpansion"
 ],
 "Row select": [
  null,
  "Radval"
 ],
 "Run this command over a trusted network or physically on the remote machine:": [
  null,
  "Kör det här kommandot över ett pålitligt nätverk eller fysiskt på fjärrdatorn:"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "SSH key": [
  null,
  "SSH-nyckel"
 ],
 "SSH key login": [
  null,
  "SSH-nyckel inloggning"
 ],
 "Sealed-case PC": [
  null,
  "PC med slutet hölje"
 ],
 "Search for name or ID": [
  null,
  "Sök efter namn eller ID"
 ],
 "Search for name, group or ID": [
  null,
  "Sök efter namn, grupp eller ID"
 ],
 "Security Enhanced Linux configuration and troubleshooting": [
  null,
  "Säkerhetsförbättrad Linux-konfiguration och felsökning"
 ],
 "Select an option": [
  null,
  "Välj ett alternativ"
 ],
 "Server has closed the connection.": [
  null,
  "Servern har stängt förbindelsen."
 ],
 "Set password": [
  null,
  "Sätt lösenord"
 ],
 "Set time": [
  null,
  "Ställ in tiden"
 ],
 "Set weak password": [
  null,
  "Ställ in ett svagt lösenord"
 ],
 "Shell": [
  null,
  "Skal"
 ],
 "Shell script": [
  null,
  "Skalskript"
 ],
 "Shift+Insert": [
  null,
  "Skift+Insert"
 ],
 "Show confirmation password": [
  null,
  "Visa bekräftelselösenord"
 ],
 "Show password": [
  null,
  "Visa lösenord"
 ],
 "Shut down": [
  null,
  "Stäng av"
 ],
 "Single rank": [
  null,
  "Ensam ordning"
 ],
 "Space-saving computer": [
  null,
  "Utrymmessparande dator"
 ],
 "Specific time": [
  null,
  "Specifik tid"
 ],
 "Started": [
  null,
  "Startad"
 ],
 "Stick PC": [
  null,
  "Pinndator"
 ],
 "Storage": [
  null,
  "Lagring"
 ],
 "Strong password": [
  null,
  "Starkt lösenord"
 ],
 "Sub-Chassis": [
  null,
  "Under-chassi"
 ],
 "Sub-Notebook": [
  null,
  "ULPC"
 ],
 "Synchronized": [
  null,
  "Synkroniserad"
 ],
 "Synchronized with $0": [
  null,
  "Synkroniserad med $0"
 ],
 "Synchronizing": [
  null,
  "Synkroniserar"
 ],
 "Tablet": [
  null,
  "Platta"
 ],
 "Terminate session": [
  null,
  "Avsluta sessionen"
 ],
 "The SSH key $0 of $1 on $2 will be added to the $3 file of $4 on $5.": [
  null,
  "SSH-nyckeln $0 av $1 på $2 kommer att läggas till $3-filen på $4 på $5."
 ],
 "The SSH key $0 will be made available for the remainder of the session and will be available for login to other hosts as well.": [
  null,
  "SSH-nyckeln $0 kommer att göras tillgänglig för resten av sessionen och kommer att vara tillgänglig för inloggning även för andra värdar."
 ],
 "The SSH key for logging in to $0 is protected by a password, and the host does not allow logging in with a password. Please provide the password of the key at $1.": [
  null,
  "SSH-nyckeln för att logga in på $0 är skyddad av ett lösenord, och värden tillåter inte inloggning med ett lösenord. Vänligen ange lösenordet för nyckeln på $1."
 ],
 "The SSH key for logging in to $0 is protected. You can log in with either your login password or by providing the password of the key at $1.": [
  null,
  "SSH-nyckeln för att logga in på $0 är skyddad. Du kan logga in med antingen ditt inloggningslösenord eller genom att ange lösenordet för nyckeln för $1."
 ],
 "The account '$0' will be forced to change their password on next login": [
  null,
  "Kontot ”$0” kommer att tvingas ändra sitt lösenord vid nästa inloggning"
 ],
 "The fingerprint should match:": [
  null,
  "Fingeravtrycket ska matcha:"
 ],
 "The full name must not contain colons.": [
  null,
  "Det fullständiga namnet får inte innehålla kolon."
 ],
 "The group ID must be positive integer": [
  null,
  "Grupp-ID:t måste vara ett positivt heltal"
 ],
 "The group name can only consist of letters from a-z, digits, dots, dashes and underscores": [
  null,
  "Gruppnamnet får endast bestå av bokstäver från a-z, siffror, punkter, bindestreck och understreck"
 ],
 "The home directory $0 already exists. Its ownership will be changed to the new user.": [
  null,
  "Hemkatalogen $0 existerar redan. Dess ägarskap kommer att ändras till den nya användaren."
 ],
 "The key password can not be empty": [
  null,
  "Nyckellösenordet får inte vara tomt"
 ],
 "The key passwords do not match": [
  null,
  "Nyckellösenorden stämmer inte överens"
 ],
 "The key you provided was not valid.": [
  null,
  "Nyckeln du angav var inte giltig."
 ],
 "The logged in user is not permitted to view system modifications": [
  null,
  "Den inloggade användaren har inte tillåtelse att se systemändringar"
 ],
 "The password can not be empty": [
  null,
  "Lösenordet får inte vara tomt"
 ],
 "The passwords do not match": [
  null,
  "Lösenorden stämmer inte överens"
 ],
 "The resulting fingerprint is fine to share via public methods, including email.": [
  null,
  "Det resulterande fingeravtrycket går bra att dela via offentliga metoder, inklusive e-post."
 ],
 "The resulting fingerprint is fine to share via public methods, including email. If you are asking someone else to do the verification for you, they can send the results using any method.": [
  null,
  "Det resulterande fingeravtrycket är okej att dela via offentliga metoder, inklusive e-post. Om du ber någon annan att göra verifieringen åt dig kan de skicka resultaten med vilken metod som helst."
 ],
 "The server refused to authenticate using any supported methods.": [
  null,
  "Servern vägrade att autentisera med några stödda metoder."
 ],
 "The user must log out and log back in for the new configuration to take effect.": [
  null,
  "Användaren måste logga ut och logga in igen för att den nya konfigurationen ska träda i kraft."
 ],
 "The user name can only consist of letters from a-z, digits, dots, dashes and underscores.": [
  null,
  "Användarnamnet får endast bestå av bokstäver från a-z, siffror, punkter, bindestreck och understreck."
 ],
 "There are no authorized public keys for this account.": [
  null,
  "Det finns inga auktoriserade publika nycklar för detta konto."
 ],
 "This group is the primary group for the following users:": [
  null,
  "Den här gruppen är den primära gruppen för följande användare:"
 ],
 "This tool configures the SELinux policy and can help with understanding and resolving policy violations.": [
  null,
  "Det här verktyget konfigurerar SELinux-policyn och kan hjälpa till med att förstå och lösa policy överträdelser."
 ],
 "This tool configures the system to write kernel crash dumps. It supports the \"local\" (disk), \"ssh\", and \"nfs\" dump targets.": [
  null,
  "Det här verktyget konfigurerar systemet till att kunna skriva kärnkraschdumpar till disken. Det stödjer \"lokala\" (disk), \"ssh\" och \"nfs\" dumpmål."
 ],
 "This tool generates an archive of configuration and diagnostic information from the running system. The archive may be stored locally or centrally for recording or tracking purposes or may be sent to technical support representatives, developers or system administrators to assist with technical fault-finding and debugging.": [
  null,
  "Detta verktyg genererar ett arkiv med konfiguration och diagnostisk information från det körande systemet. Arkivet kan förvaras lokalt eller centralt för inspelning eller spårningsändamål eller kan skickas till tekniska supportrepresentanter, utvecklare eller systemadministratörer för att hjälpa till med teknisk felspårning och felsökning."
 ],
 "This tool manages local storage, such as filesystems, LVM2 volume groups, and NFS mounts.": [
  null,
  "Detta verktyg hanterar lokal lagring, såsom filsystem, LVM2-volymgrupper och NFS-monteringar."
 ],
 "This tool manages networking such as bonds, bridges, teams, VLANs and firewalls using NetworkManager and Firewalld. NetworkManager is incompatible with Ubuntu's default systemd-networkd and Debian's ifupdown scripts.": [
  null,
  "Detta verktyg hanterar nätverk som bindningar, broar, team, VLAN och brandväggar med NetworkManager och Firewalld. NetworkManager är inkompatibelt med Ubuntus standard systemd-networkd och Debians ifupdown skript."
 ],
 "This user name already exists": [
  null,
  "Detta användarnamn finns redan"
 ],
 "Time zone": [
  null,
  "Tidszon"
 ],
 "To ensure that your connection is not intercepted by a malicious third-party, please verify the host key fingerprint:": [
  null,
  "För att säkerställa att din anslutning inte fångas upp av en skadlig tredje part, vänligen verifiera värdnyckelns fingeravtryck:"
 ],
 "To verify a fingerprint, run the following on $0 while physically sitting at the machine or through a trusted network:": [
  null,
  "För att verifiera ett fingeravtryck, kör följande på $0 medan du fysiskt sitter vid maskinen eller genom ett pålitligt nätverk:"
 ],
 "Toggle date picker": [
  null,
  "Växla datumväljare"
 ],
 "Too much data": [
  null,
  "För mycket data"
 ],
 "Total size: $0": [
  null,
  "Total storlek: $0"
 ],
 "Tower": [
  null,
  "Torn"
 ],
 "Trust and add host": [
  null,
  "Lita på och lägg till värd"
 ],
 "Trying to synchronize with $0": [
  null,
  "Försök att synkronisera med $0"
 ],
 "Unable to log in to $0 using SSH key authentication. Please provide the password.": [
  null,
  "Det går inte att logga in på $0 med SSH-nyckelautentisering. Ange lösenordet."
 ],
 "Unable to log in to $0. The host does not accept password login or any of your SSH keys.": [
  null,
  "Det går inte att logga in på $0. Värden accepterar inte lösenordsinloggning eller någon av dina SSH-nycklar."
 ],
 "Undo": [
  null,
  "Ångra"
 ],
 "Unexpected error": [
  null,
  "Oväntat fel"
 ],
 "Unknown": [
  null,
  "Okänd"
 ],
 "Unknown host: $0": [
  null,
  "Okänd värd: $0"
 ],
 "Unnamed": [
  null,
  "Namnlös"
 ],
 "Untrusted host": [
  null,
  "Ej betrodd värd"
 ],
 "Use password": [
  null,
  "Använd lösenord"
 ],
 "User ID": [
  null,
  "Användar-ID"
 ],
 "User ID is already used by another user": [
  null,
  "Användar-ID används redan av en annan användare"
 ],
 "User ID must be a positive integer": [
  null,
  "Användar-ID måste vara ett positivt heltal"
 ],
 "User ID must not be higher than $0": [
  null,
  "Användar-ID måste inte vara högre än $0"
 ],
 "User ID must not be lower than $0": [
  null,
  "Användar-ID får inte vara lägre än $0"
 ],
 "User name": [
  null,
  "Användarnamn"
 ],
 "Username": [
  null,
  "Användarnamn"
 ],
 "Verify fingerprint": [
  null,
  "Verifiera fingeravtryck"
 ],
 "View all logs": [
  null,
  "Visa alla loggar"
 ],
 "View automation script": [
  null,
  "Visa automatiseringsskript"
 ],
 "Visit firewall": [
  null,
  "Besök brandvägg"
 ],
 "Waiting for other software management operations to finish": [
  null,
  "Väntar på att andra programvaruhanteringsåtgärder skall bli klara"
 ],
 "Weak password": [
  null,
  "Svagt lösenord"
 ],
 "Web Console for Linux servers": [
  null,
  "Webbkonsol för Linuxservrar"
 ],
 "You are connecting to $0 for the first time.": [
  null,
  "Du ansluter till $0 för första gången."
 ],
 "You do not have permission to view the authorized public keys for this account.": [
  null,
  "Du har inte rättigheter att se de auktoriserade publika nycklarna för detta konto."
 ],
 "You must wait longer to change your password": [
  null,
  "Du måste vänta längre på att ändra ditt lösenord"
 ],
 "Your account": [
  null,
  "Ditt konto"
 ],
 "Your browser does not allow paste from the context menu. You can use Shift+Insert.": [
  null,
  "Din webbläsare tillåter inte att klistra in från sammanhangsmenyn. Du kan använda Skift+Insert."
 ],
 "Your session has been terminated.": [
  null,
  "Din session har avslutats."
 ],
 "Your session has expired. Please log in again.": [
  null,
  "Din session har gått ut. Logga in igen."
 ],
 "Zone": [
  null,
  "Zon"
 ],
 "[binary data]": [
  null,
  "[binärdata]"
 ],
 "[no data]": [
  null,
  "[inga data]"
 ],
 "change": [
  null,
  "ändra"
 ],
 "edit": [
  null,
  "redigera"
 ],
 "in less than a minute": [
  null,
  "i mindre än en minut"
 ],
 "less than a minute ago": [
  null,
  "mindre än en minut sedan"
 ],
 "password quality": [
  null,
  "lösenordskvalitet"
 ],
 "show less": [
  null,
  "visa mindre"
 ],
 "show more": [
  null,
  "visa mer"
 ],
 "user": [
  null,
  "användare"
 ]
});
