cockpit.locale({
 "": {
  "plural-forms": (n) => n != 1,
  "language": "nb_NO",
  "language-direction": "ltr"
 },
 "# of users": [
  null,
  ""
 ],
 "$0 day": [
  null,
  "$0 dag",
  "$0 dager"
 ],
 "$0 exited with code $1": [
  null,
  "$0 avsluttet med koden $1"
 ],
 "$0 failed": [
  null,
  "$0 feilet"
 ],
 "$0 hour": [
  null,
  "$0 time",
  "$0 timer"
 ],
 "$0 is not available from any repository.": [
  null,
  "$0 er ikke tilgjengelig fra noe depot."
 ],
 "$0 key changed": [
  null,
  "$0 nøkkel endret"
 ],
 "$0 killed with signal $1": [
  null,
  "$0 drept med signal $1"
 ],
 "$0 minute": [
  null,
  "$0 minutt",
  "$0 minutter"
 ],
 "$0 month": [
  null,
  "$0 måned",
  "$0 måneder"
 ],
 "$0 week": [
  null,
  "$0 uke",
  "$0 uker"
 ],
 "$0 will be installed.": [
  null,
  "$0 vil bli installert."
 ],
 "$0 year": [
  null,
  "$0 år",
  "$0 år"
 ],
 "1 day": [
  null,
  "1 dag"
 ],
 "1 hour": [
  null,
  "1 time"
 ],
 "1 minute": [
  null,
  "1 minutt"
 ],
 "1 week": [
  null,
  "1 uke"
 ],
 "20 minutes": [
  null,
  "20 minutter"
 ],
 "40 minutes": [
  null,
  "40 minutter"
 ],
 "5 minutes": [
  null,
  "5 minutter"
 ],
 "6 hours": [
  null,
  "6 timer"
 ],
 "60 minutes": [
  null,
  "60 minutter"
 ],
 "Absent": [
  null,
  "Fraværende"
 ],
 "Account expiration": [
  null,
  "Konto utløper"
 ],
 "Account not available or cannot be edited.": [
  null,
  "Kontoen er ikke tilgjengelig eller kan ikke redigeres."
 ],
 "Accounts": [
  null,
  "Kontoer"
 ],
 "Actions": [
  null,
  "Handlinger"
 ],
 "Add": [
  null,
  "Legg til"
 ],
 "Add $0": [
  null,
  "Legg til $0"
 ],
 "Add key": [
  null,
  "Legg til nøkkel"
 ],
 "Add public key": [
  null,
  "Legg til offentlig nøkkel"
 ],
 "Additional packages:": [
  null,
  "Ekstra pakker:"
 ],
 "Administration with Cockpit Web Console": [
  null,
  "Administrasjon med Cockpit Web konsoll"
 ],
 "Advanced TCA": [
  null,
  "Avansert TCA"
 ],
 "All-in-one": [
  null,
  "Alt i ett"
 ],
 "Ansible": [
  null,
  "Ansible"
 ],
 "Ansible roles documentation": [
  null,
  "Ansible roller dokumentasjon"
 ],
 "Authentication": [
  null,
  "Autentisering"
 ],
 "Authentication is required to perform privileged tasks with the Cockpit Web Console": [
  null,
  "Autentisering er nødvendig for å utføre privilegerte oppgaver med Cockpit Web konsoll"
 ],
 "Authorized public SSH keys": [
  null,
  "Autoriserte offentlige SSH-nøkler"
 ],
 "Automatically using NTP": [
  null,
  "Automatisk med bruk av NTP"
 ],
 "Automatically using specific NTP servers": [
  null,
  "Automatisk med bruk av spesifikke NTP servere"
 ],
 "Automation script": [
  null,
  "Automatiseringsskript"
 ],
 "Back to accounts": [
  null,
  "Tilbake til kontoer"
 ],
 "Blade": [
  null,
  "Blad"
 ],
 "Blade enclosure": [
  null,
  "Blad-kabinett"
 ],
 "Bus expansion chassis": [
  null,
  ""
 ],
 "Cancel": [
  null,
  "Avbryt"
 ],
 "Cannot forward login credentials": [
  null,
  "Kan ikke videresende påloggingsinformasjonen"
 ],
 "Cannot schedule event in the past": [
  null,
  "Kan ikke tidsplanlegge hendelse i fortiden"
 ],
 "Change": [
  null,
  "Endre"
 ],
 "Change system time": [
  null,
  "Endre systemtid"
 ],
 "Changed keys are often the result of an operating system reinstallation. However, an unexpected change may indicate a third-party attempt to intercept your connection.": [
  null,
  "Endrede nøkler er ofte resultatet av reinstallering av operativsystemet. Imidlertid kan en uventet endring indikere et tredjepartsforsøk på å fange opp forbindelsen din."
 ],
 "Checking installed software": [
  null,
  "Kontrollerer installert programvare"
 ],
 "Close": [
  null,
  "Lukk"
 ],
 "Cockpit": [
  null,
  "Cockpit"
 ],
 "Cockpit configuration of NetworkManager and Firewalld": [
  null,
  ""
 ],
 "Cockpit could not contact the given host.": [
  null,
  "Cockpit kunne ikke kontakte den angitte verten."
 ],
 "Cockpit is a server manager that makes it easy to administer your Linux servers via a web browser. Jumping between the terminal and the web tool is no problem. A service started via Cockpit can be stopped via the terminal. Likewise, if an error occurs in the terminal, it can be seen in the Cockpit journal interface.": [
  null,
  "Cockpit er en serveradministrator som gjør det enkelt å administrere Linux-serverne dine via en nettleser. Å bytte mellom terminalen og nettverktøyet er ikke noe problem. En tjeneste startet via Cockpit kan stoppes via terminalen. På samme måte, hvis det oppstår en feil i terminalen, kan den sees i Cockpit journal-grensesnittet."
 ],
 "Cockpit is not compatible with the software on the system.": [
  null,
  "Cockpit er ikke kompatibel med programvaren på systemet."
 ],
 "Cockpit is not installed": [
  null,
  "Cockpit er ikke installert"
 ],
 "Cockpit is not installed on the system.": [
  null,
  "Cockpit er ikke installert på systemet."
 ],
 "Cockpit is perfect for new sysadmins, allowing them to easily perform simple tasks such as storage administration, inspecting journals and starting and stopping services. You can monitor and administer several servers at the same time. Just add them with a single click and your machines will look after its buddies.": [
  null,
  "Cockpit er perfekt for nye sysadminer, slik at de enkelt kan utføre enkle oppgaver som lagringsadministrasjon, inspisere journaler og starte og stoppe tjenester. Du kan overvåke og administrere flere servere samtidig. Bare legg dem til med et enkelt klikk, så vil maskinene dine se etter kompisene."
 ],
 "Collect and package diagnostic and support data": [
  null,
  ""
 ],
 "Compact PCI": [
  null,
  ""
 ],
 "Confirm key password": [
  null,
  "Bekreft nøkkel-passord"
 ],
 "Confirm new password": [
  null,
  "Bekreft nytt passord"
 ],
 "Connection has timed out.": [
  null,
  "Tidsavbrudd for tilkoblingen."
 ],
 "Convertible": [
  null,
  "Konverterbar"
 ],
 "Copied": [
  null,
  ""
 ],
 "Copy": [
  null,
  "Kopier"
 ],
 "Copy to clipboard": [
  null,
  "Kopier til utklippstavle"
 ],
 "Create": [
  null,
  "Opprett"
 ],
 "Create account with non-unique UID": [
  null,
  ""
 ],
 "Create account with weak password": [
  null,
  ""
 ],
 "Create and change ownership of home directory": [
  null,
  ""
 ],
 "Create new account": [
  null,
  "Opprett ny konto"
 ],
 "Create new task file with this content.": [
  null,
  "Opprett ny oppgavefil med dette innholdet."
 ],
 "Ctrl+Insert": [
  null,
  "Ctrl+Insert"
 ],
 "Delay": [
  null,
  "Forsinkelse"
 ],
 "Delete": [
  null,
  "Slett"
 ],
 "Delete $0": [
  null,
  "Slett $0"
 ],
 "Delete files": [
  null,
  "Slett filer"
 ],
 "Desktop": [
  null,
  ""
 ],
 "Detachable": [
  null,
  ""
 ],
 "Diagnostic reports": [
  null,
  "Diagnose rapporter"
 ],
 "Disallow password authentication": [
  null,
  ""
 ],
 "Docking station": [
  null,
  "Dokkingstasjon"
 ],
 "Downloading $0": [
  null,
  "Laster ned $0"
 ],
 "Dual rank": [
  null,
  "Dobbel rangering"
 ],
 "Embedded PC": [
  null,
  "Innebygd PC"
 ],
 "Ended": [
  null,
  ""
 ],
 "Error saving authorized keys: ": [
  null,
  "Feil ved lagring av autoriserte nøkler: "
 ],
 "Excellent password": [
  null,
  "Utmerket passord"
 ],
 "Expansion chassis": [
  null,
  ""
 ],
 "Failed to change password": [
  null,
  "Kunne ikke endre passord"
 ],
 "Failed to load authorized keys.": [
  null,
  "Kunne ikke laste autoriserte nøkler."
 ],
 "Fingerprint": [
  null,
  "Fingeravtrykk"
 ],
 "Force change": [
  null,
  "Tving endring"
 ],
 "Force password change": [
  null,
  "Tving passordendring"
 ],
 "From": [
  null,
  ""
 ],
 "Full name": [
  null,
  "Fullt navn"
 ],
 "Go to now": [
  null,
  "Gå til nå"
 ],
 "Group": [
  null,
  "Gruppe"
 ],
 "Handheld": [
  null,
  "Håndholdt"
 ],
 "Host key is incorrect": [
  null,
  "Vertsnøkkelen er feil"
 ],
 "ID": [
  null,
  "ID"
 ],
 "Install": [
  null,
  "Installer"
 ],
 "Install software": [
  null,
  "Installer programvare"
 ],
 "Installing $0": [
  null,
  "Installerer $0"
 ],
 "Internal error": [
  null,
  "Intern feil"
 ],
 "Invalid date format": [
  null,
  "Ugyldig datoformat"
 ],
 "Invalid date format and invalid time format": [
  null,
  "Ugyldig datoformat og ugyldig tidsformat"
 ],
 "Invalid expiration date": [
  null,
  "Ugyldig utløpsdato"
 ],
 "Invalid file permissions": [
  null,
  "Ugyldige filtillatelser"
 ],
 "Invalid key": [
  null,
  "Ugyldig nøkkel"
 ],
 "Invalid number of days": [
  null,
  "Ugyldig antall dager"
 ],
 "Invalid time format": [
  null,
  "Ugyldig tidsformat"
 ],
 "Invalid timezone": [
  null,
  "Ugyldig tidssone"
 ],
 "IoT gateway": [
  null,
  "IoT-gateway"
 ],
 "Kernel dump": [
  null,
  "Kjerne dump"
 ],
 "Key password": [
  null,
  "Nøkkel-passord"
 ],
 "Laptop": [
  null,
  ""
 ],
 "Last login": [
  null,
  "Siste innlogging"
 ],
 "Learn more": [
  null,
  "Lær mer"
 ],
 "Loading system modifications...": [
  null,
  "Laster inn systemendringer ..."
 ],
 "Loading...": [
  null,
  "Laster..."
 ],
 "Local accounts": [
  null,
  "Lokale kontoer"
 ],
 "Lock": [
  null,
  "Lås"
 ],
 "Lock account": [
  null,
  "Lås konto"
 ],
 "Log in": [
  null,
  "Logg inn"
 ],
 "Log messages": [
  null,
  "Logg meldinger"
 ],
 "Log out": [
  null,
  "Logg ut"
 ],
 "Logged in": [
  null,
  "Logget inn"
 ],
 "Login failed": [
  null,
  "Innlogging feilet"
 ],
 "Login history list": [
  null,
  ""
 ],
 "Low profile desktop": [
  null,
  ""
 ],
 "Lunch box": [
  null,
  "Lunsjboks"
 ],
 "Main server chassis": [
  null,
  ""
 ],
 "Manually": [
  null,
  "Manuelt"
 ],
 "Message to logged in users": [
  null,
  "Melding til innloggede brukere"
 ],
 "Mini PC": [
  null,
  "Mini-PC"
 ],
 "Mini tower": [
  null,
  ""
 ],
 "Multi-system chassis": [
  null,
  ""
 ],
 "NTP server": [
  null,
  "NTP Server"
 ],
 "Name": [
  null,
  "Navn"
 ],
 "Need at least one NTP server": [
  null,
  "Trenger minst en NTP-server"
 ],
 "Networking": [
  null,
  "Nettverk"
 ],
 "Never": [
  null,
  "Aldri"
 ],
 "Never expire password": [
  null,
  "Passordet utløper aldri"
 ],
 "New password": [
  null,
  "Nytt passord"
 ],
 "New password was not accepted": [
  null,
  "Nytt passord ble ikke godtatt"
 ],
 "No delay": [
  null,
  "Ingen forsinkelse"
 ],
 "No matching results": [
  null,
  "Ingen samsvarende resultater"
 ],
 "No real name specified": [
  null,
  "Ingen virkelige navn angitt"
 ],
 "No results found": [
  null,
  "Ingen resultater funnet"
 ],
 "No such file or directory": [
  null,
  "Ingen slik fil eller katalog"
 ],
 "No system modifications": [
  null,
  "Ingen systemendringer"
 ],
 "No user name specified": [
  null,
  "Ingen brukernavn spesifisert"
 ],
 "Not a valid private key": [
  null,
  "Ikke en gyldig privat nøkkel"
 ],
 "Not permitted to perform this action.": [
  null,
  "Ikke tillatt å utføre denne handlingen."
 ],
 "Not synchronized": [
  null,
  "Ikke synkronisert"
 ],
 "Notebook": [
  null,
  ""
 ],
 "Ok": [
  null,
  "Ok"
 ],
 "Old password": [
  null,
  "Gammelt passord"
 ],
 "Old password not accepted": [
  null,
  "Gammelt passord aksepteres ikke"
 ],
 "Once Cockpit is installed, enable it with \"systemctl enable --now cockpit.socket\".": [
  null,
  "Når Cockpit er installert, kan den aktiveres med \"systemctl enable --now cockpit.socket\"."
 ],
 "Options": [
  null,
  "Alternativer"
 ],
 "Other": [
  null,
  "Annen"
 ],
 "Other authentication methods are still available even when interactive password authentication is not allowed.": [
  null,
  ""
 ],
 "PackageKit crashed": [
  null,
  "PackageKit krasjet"
 ],
 "Password": [
  null,
  "Passord"
 ],
 "Password expiration": [
  null,
  "Passord utløper"
 ],
 "Password is not acceptable": [
  null,
  "Passord er ikke akseptabelt"
 ],
 "Password is too weak": [
  null,
  "Passordet er for svakt"
 ],
 "Password must be changed": [
  null,
  "Passord må endres"
 ],
 "Password not accepted": [
  null,
  "Passord ikke akseptert"
 ],
 "Paste": [
  null,
  "Lim inn"
 ],
 "Paste the contents of your public SSH key file here": [
  null,
  "Lim inn innholdet i den offentlige SSH-nøkkelfilen din her"
 ],
 "Path to file": [
  null,
  "Sti til fil"
 ],
 "Peripheral chassis": [
  null,
  "Perifert chassis"
 ],
 "Pick date": [
  null,
  "Velg dato"
 ],
 "Pizza box": [
  null,
  "Pizzaboks"
 ],
 "Please specify an expiration date": [
  null,
  "Angi en utløpsdato"
 ],
 "Portable": [
  null,
  "Bærbar"
 ],
 "Present": [
  null,
  "Til stede"
 ],
 "Prompting via passwd timed out": [
  null,
  "Spørring via passwd ble tidsavbrutt"
 ],
 "Prompting via ssh-add timed out": [
  null,
  "Spørring via ssh-add ble tidsavbrutt"
 ],
 "Prompting via ssh-keygen timed out": [
  null,
  "Spørring via ssh-keygen ble tidsavbrutt"
 ],
 "RAID chassis": [
  null,
  "RAID chassis"
 ],
 "Rack mount chassis": [
  null,
  ""
 ],
 "Reboot": [
  null,
  "Omstart"
 ],
 "Removals:": [
  null,
  ""
 ],
 "Remove": [
  null,
  "Fjern"
 ],
 "Removing $0": [
  null,
  "Fjerner $0"
 ],
 "Rename": [
  null,
  "Omdøp"
 ],
 "Renaming a group may affect sudo and similar rules": [
  null,
  ""
 ],
 "Require password change every $0 days": [
  null,
  "Krev passordendring hver $0 dager"
 ],
 "Require password change on $0": [
  null,
  "Krev passordendring på $0"
 ],
 "Reset password": [
  null,
  "Tilbakestill passord"
 ],
 "Run this command over a trusted network or physically on the remote machine:": [
  null,
  ""
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "SSH key": [
  null,
  "SSH-nøkkel"
 ],
 "Sealed-case PC": [
  null,
  ""
 ],
 "Search for name or ID": [
  null,
  ""
 ],
 "Search for name, group or ID": [
  null,
  ""
 ],
 "Security Enhanced Linux configuration and troubleshooting": [
  null,
  ""
 ],
 "Server has closed the connection.": [
  null,
  "Serveren har lukket forbindelsen."
 ],
 "Set password": [
  null,
  "Angi passord"
 ],
 "Set time": [
  null,
  "Sett tid"
 ],
 "Shell script": [
  null,
  "Shell-skript"
 ],
 "Shift+Insert": [
  null,
  "Shift+Insert"
 ],
 "Shut down": [
  null,
  "Slå av"
 ],
 "Single rank": [
  null,
  ""
 ],
 "Space-saving computer": [
  null,
  "Plassbesparende datamaskin"
 ],
 "Specific time": [
  null,
  "Spesifikk tid"
 ],
 "Stick PC": [
  null,
  ""
 ],
 "Storage": [
  null,
  "Lagring"
 ],
 "Sub-Chassis": [
  null,
  ""
 ],
 "Sub-Notebook": [
  null,
  ""
 ],
 "Synchronized": [
  null,
  "Synkronisert"
 ],
 "Synchronized with $0": [
  null,
  "Synkronisert med $0"
 ],
 "Synchronizing": [
  null,
  "Synkroniserer"
 ],
 "Tablet": [
  null,
  "Nettbrett"
 ],
 "Terminate session": [
  null,
  "Avslutt økt"
 ],
 "The account '$0' will be forced to change their password on next login": [
  null,
  "Kontoen '$0' vil bli tvunget til å endre passordet ved neste pålogging"
 ],
 "The full name must not contain colons.": [
  null,
  ""
 ],
 "The home directory $0 already exists. Its ownership will be changed to the new user.": [
  null,
  ""
 ],
 "The key password can not be empty": [
  null,
  "Nøkkelpassordet kan ikke være tomt"
 ],
 "The key passwords do not match": [
  null,
  "Nøkkelpassordene stemmer ikke overens"
 ],
 "The key you provided was not valid.": [
  null,
  "Nøkkelen du oppga var ikke gyldig."
 ],
 "The logged in user is not permitted to view system modifications": [
  null,
  "Den påloggede brukeren har ikke lov til å se systemendringer"
 ],
 "The passwords do not match": [
  null,
  "Passordene samsvarer ikke"
 ],
 "The resulting fingerprint is fine to share via public methods, including email.": [
  null,
  "Det resulterende fingeravtrykket er greit å dele via offentlige metoder, inkludert e-post."
 ],
 "The resulting fingerprint is fine to share via public methods, including email. If you are asking someone else to do the verification for you, they can send the results using any method.": [
  null,
  ""
 ],
 "The server refused to authenticate using any supported methods.": [
  null,
  "Serveren nektet å godkjenne ved hjelp av de støttede metodene."
 ],
 "The user name can only consist of letters from a-z, digits, dots, dashes and underscores.": [
  null,
  "Brukernavnet kan bare bestå av bokstaver fra a-z, sifre, prikker, bindestreker og understrekninger."
 ],
 "There are no authorized public keys for this account.": [
  null,
  "Det er ingen autoriserte offentlige nøkler for denne kontoen."
 ],
 "This group is the primary group for the following users:": [
  null,
  ""
 ],
 "This tool configures the SELinux policy and can help with understanding and resolving policy violations.": [
  null,
  ""
 ],
 "This tool configures the system to write kernel crash dumps. It supports the \"local\" (disk), \"ssh\", and \"nfs\" dump targets.": [
  null,
  ""
 ],
 "This tool generates an archive of configuration and diagnostic information from the running system. The archive may be stored locally or centrally for recording or tracking purposes or may be sent to technical support representatives, developers or system administrators to assist with technical fault-finding and debugging.": [
  null,
  ""
 ],
 "This tool manages local storage, such as filesystems, LVM2 volume groups, and NFS mounts.": [
  null,
  ""
 ],
 "This tool manages networking such as bonds, bridges, teams, VLANs and firewalls using NetworkManager and Firewalld. NetworkManager is incompatible with Ubuntu's default systemd-networkd and Debian's ifupdown scripts.": [
  null,
  ""
 ],
 "This user name already exists": [
  null,
  "Dette brukernavnet finnes allerede"
 ],
 "Time zone": [
  null,
  "Tidssone"
 ],
 "To ensure that your connection is not intercepted by a malicious third-party, please verify the host key fingerprint:": [
  null,
  "For å sikre at forbindelsen din ikke blir fanget opp av en ondsinnet tredjepart, må du verifisere vertsnøkkelens fingeravtrykk:"
 ],
 "To verify a fingerprint, run the following on $0 while physically sitting at the machine or through a trusted network:": [
  null,
  "For å bekrefte et fingeravtrykk, kjør følgende på $ 0 mens du sitter fysisk ved maskinen eller gjennom et pålitelig nettverk:"
 ],
 "Toggle date picker": [
  null,
  ""
 ],
 "Too much data": [
  null,
  "For mye data"
 ],
 "Total size: $0": [
  null,
  "Total størrelse: $0"
 ],
 "Tower": [
  null,
  ""
 ],
 "Trust and add host": [
  null,
  ""
 ],
 "Trying to synchronize with $0": [
  null,
  "Prøver å synkronisere med $0"
 ],
 "Undo": [
  null,
  ""
 ],
 "Unexpected error": [
  null,
  "Uventet feil"
 ],
 "Unknown": [
  null,
  "Ukjent"
 ],
 "Unnamed": [
  null,
  "Uten navn"
 ],
 "Untrusted host": [
  null,
  ""
 ],
 "User ID must not be higher than $0": [
  null,
  ""
 ],
 "User name": [
  null,
  "Brukernavn"
 ],
 "Username": [
  null,
  "Brukernavn"
 ],
 "View automation script": [
  null,
  "Vis automatiseringsskript"
 ],
 "Waiting for other software management operations to finish": [
  null,
  "Venter på at andre programvareadministrasjons-operasjoner skal fullføres"
 ],
 "Web Console for Linux servers": [
  null,
  "Web konsoll for Linux servere"
 ],
 "You are connecting to $0 for the first time.": [
  null,
  "Du kobler til $0 for første gang."
 ],
 "You do not have permission to view the authorized public keys for this account.": [
  null,
  "Du har ikke tillatelse til å se de autoriserte offentlige nøklene for denne kontoen."
 ],
 "You must wait longer to change your password": [
  null,
  "Du må vente lenger på å endre passordet ditt"
 ],
 "Your account": [
  null,
  "Din konto"
 ],
 "Your browser does not allow paste from the context menu. You can use Shift+Insert.": [
  null,
  ""
 ],
 "Your session has been terminated.": [
  null,
  "Økten din er avsluttet."
 ],
 "Your session has expired. Please log in again.": [
  null,
  "Økten din har utløpt. Vennligst logg inn igjen."
 ],
 "Zone": [
  null,
  ""
 ],
 "[binary data]": [
  null,
  "[binære data]"
 ],
 "[no data]": [
  null,
  "[ingen data]"
 ],
 "change": [
  null,
  "Endre"
 ],
 "edit": [
  null,
  "rediger"
 ],
 "in less than a minute": [
  null,
  ""
 ],
 "less than a minute ago": [
  null,
  ""
 ],
 "password quality": [
  null,
  "passordkvalitet"
 ],
 "show less": [
  null,
  "vis mindre"
 ],
 "show more": [
  null,
  "vis mer"
 ],
 "user": [
  null,
  "bruker"
 ]
});
